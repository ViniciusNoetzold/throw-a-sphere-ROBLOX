"""
110_Twinsmog_Weezing_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "110. Twinsmog — Gêmeos Tóxicos (Ref: Weezing)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Twinsmog_Shiny (1.0x - Paleta Shiny Turquesa + Nuvens de Gás Rosa-Lavanda + Marcas Creme)
  2. Twinsmog_Normal (1.0x - Roxo-Tóxico + Duas Cabeças Assimétricas + Nódulo + Gás Oliva)
  3. Twinsmog_Grande (1.35x - Normal)
  4. Twinsmog_Gigante (1.85x - Normal)
  5. Twinsmog_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Nuvens Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para esferas gêmeas, tubos conectores e nuvens)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base alinhada exatamente em `Z = 0.0` (sem partes flutuantes soltas) e rostos apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_purple": (0.60, 0.50, 0.70, 1.0),
        "body_shade": (0.44, 0.36, 0.54, 1.0),
        "vent_dark": (0.30, 0.24, 0.40, 1.0),
        "emblem_cream": (0.91, 0.89, 0.78, 1.0),
        "gas_yellow": (0.80, 0.80, 0.50, 1.0),
        "gas_shade": (0.66, 0.66, 0.40, 1.0),
        "mouth_pink": (0.76, 0.48, 0.54, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "eye_dark": (0.10, 0.10, 0.14, 1.0),
    },
    "shiny_palette": {
        "body_purple": (0.24, 0.72, 0.74, 1.0),
        "body_shade": (0.16, 0.52, 0.56, 1.0),
        "vent_dark": (0.10, 0.36, 0.40, 1.0),
        "emblem_cream": (0.94, 0.92, 0.82, 1.0),
        "gas_yellow": (0.84, 0.52, 0.82, 1.0),
        "gas_shade": (0.68, 0.36, 0.68, 1.0),
        "mouth_pink": (0.82, 0.46, 0.56, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "eye_dark": (0.10, 0.10, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "body_purple": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.60, 0.08, 1.0),
        "vent_dark": (0.64, 0.44, 0.06, 1.0),
        "emblem_cream": (1.00, 0.96, 0.72, 1.0),
        "gas_yellow": (0.10, 0.92, 1.00, 1.0),
        "gas_shade": (0.08, 0.70, 0.84, 1.0),
        "mouth_pink": (0.86, 0.56, 0.12, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_vent(parts: list, tag: str, loc: tuple, rot_deg: tuple, r1: float, r2: float, dp: float, mat_prefix: str, pal: dict):
    rot = tuple(math.radians(a) for a in rot_deg)
    _add_part(parts, create_cone(f"_tmp_vrim_{tag}", 7, r1, r2, dp, loc, rotation=rot), mat_prefix, "body_purple", pal)
    _add_part(parts, create_cylinder(f"_tmp_vhole_{tag}", 7, r2 * 0.65, dp * 0.90, loc, rotation=rot), mat_prefix, "vent_dark", pal)


def _add_smoke_cloud(parts: list, tag: str, center: tuple, rad: float, mat_prefix: str, pal: dict):
    cx, cy, cz = center
    for idx, (pr, off, mkey) in enumerate([
        (rad, (0.0, 0.0, 0.0), "gas_yellow"),
        (rad * 0.78, (-rad * 0.58, 0.03, rad * 0.28), "gas_yellow"),
        (rad * 0.72, (rad * 0.56, -0.02, rad * 0.24), "gas_yellow"),
        (rad * 0.68, (rad * 0.12, 0.06, -rad * 0.42), "gas_shade"),
    ]):
        _add_part(
            parts,
            create_icosphere(f"_tmp_cloud_{tag}_{idx}", 2, pr, (cx + off[0], cy + off[1], cz + off[2])),
            mat_prefix,
            mkey,
            pal,
        )


def build_twinsmog(
    name: str = "Twinsmog_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 110. Twinsmog (Ref: Weezing):
      - Duas esferas gêmeas assimétricas (grande à esquerda, média erguida à direita) + 3º nódulo inferior
      - Tubos orgânicos ligando as três esferas em triângulo + crateras tubulares
      - Expressões carrancudas distintas: cabeça grande com 2 presas inferiores erguidas + caveira;
        cabeça menor com olhos caídos, boca mal-humorada + anel oval creme no queixo
      - Nuvens de fumaça conectadas às crateras (incluindo plumas de apoio em Z = 0.0)
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Twin_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Twin_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Twin_Norm"

    parts = []

    # 1. ESFERA PRINCIPAL (ESQUERDA), ESFERA SECUNDÁRIA (DIREITA-ALTA) E NÓDULO INFERIOR
    _add_part(
        parts,
        create_icosphere("_tmp_head_main", 2, 0.78, (-0.34, -0.02, 1.08), scale=(1.04, 0.96, 0.98)),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_head_twin", 2, 0.52, (0.76, 0.04, 1.44), scale=(1.02, 0.96, 0.98)),
        mat_prefix,
        "body_purple",
        pal,
    )
    # Tubo grosso ligando cabeça principal à secundária
    _add_part(
        parts,
        create_cylinder(
            "_tmp_bridge_main_twin",
            8,
            0.26,
            0.72,
            (0.24, 0.02, 1.28),
            rotation=(0.0, math.radians(70.0), 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )
    # 3ª esfera pequena (nódulo inferior direito) + 2 tubos de conexão
    _add_part(
        parts,
        create_icosphere("_tmp_nodule_small", 2, 0.25, (0.64, 0.10, 0.66)),
        mat_prefix,
        "body_shade",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_tube_low_L",
            6,
            0.10,
            0.56,
            (0.26, 0.06, 0.76),
            rotation=(0.0, math.radians(102.0), 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_tube_low_R",
            6,
            0.10,
            0.52,
            (0.70, 0.08, 1.00),
            rotation=(0.0, math.radians(10.0), 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    # 2. CRATERAS TUBULARES NAS DUAS ESFERAS
    vents = [
        ("M0", (-0.86, -0.02, 1.62), (0.0, -42.0, 0.0), 0.20, 0.14, 0.26),
        ("M1", (-0.08, 0.00, 1.82), (0.0, 14.0, 0.0), 0.20, 0.14, 0.24),
        ("M2", (-0.98, 0.02, 0.66), (0.0, -126.0, 0.0), 0.20, 0.14, 0.26),
        ("M3", (-0.34, 0.00, 0.32), (180.0, 0.0, 0.0), 0.19, 0.13, 0.24),
        ("M4", (-0.42, 0.68, 1.36), (-56.0, -16.0, 0.0), 0.20, 0.14, 0.24),
        ("T0", (0.76, 0.04, 1.96), (0.0, 0.0, 0.0), 0.15, 0.11, 0.20),
        ("T1", (1.22, 0.04, 1.68), (0.0, 62.0, 0.0), 0.15, 0.11, 0.20),
        ("T2", (1.24, 0.06, 1.24), (0.0, 108.0, 0.0), 0.14, 0.10, 0.20),
        ("T3", (0.40, 0.06, 1.82), (0.0, -40.0, 0.0), 0.14, 0.10, 0.18),
    ]
    for tag, vloc, vrot, r1, r2, dp in vents:
        _add_vent(parts, tag, vloc, vrot, r1, r2, dp, mat_prefix, pal)

    # 3. PLUMAS DE FUMAÇA TÓXICA CONECTADAS ÀS CRATERAS (ZERO PEÇAS SOLTAS)
    # Pluma superior esquerda
    _add_part(
        parts,
        create_cone("_tmp_p_UL", 6, 0.08, 0.18, 0.52, (-1.08, 0.04, 1.86), rotation=(0.0, math.radians(-42.0), 0.0)),
        mat_prefix,
        "gas_shade",
        pal,
    )
    _add_smoke_cloud(parts, "UL", (-1.30, 0.06, 2.06), 0.26, mat_prefix, pal)

    # Pluma topo central
    _add_part(
        parts,
        create_cone("_tmp_p_TOP", 6, 0.08, 0.17, 0.44, (-0.02, 0.04, 2.06), rotation=(0.0, math.radians(12.0), 0.0)),
        mat_prefix,
        "gas_shade",
        pal,
    )
    _add_smoke_cloud(parts, "TOP", (0.06, 0.06, 2.28), 0.24, mat_prefix, pal)

    # Pluma lateral direita saindo da cabeça menor
    _add_part(
        parts,
        create_cone("_tmp_p_R", 6, 0.07, 0.15, 0.42, (1.42, 0.08, 1.12), rotation=(0.0, math.radians(114.0), 0.0)),
        mat_prefix,
        "gas_shade",
        pal,
    )
    _add_smoke_cloud(parts, "R", (1.62, 0.10, 1.00), 0.20, mat_prefix, pal)

    # Plumas inferiores de apoio no chão (faz o Twinsmog pairar sobre o gás em Z = 0.0)
    _add_part(
        parts,
        create_cone("_tmp_p_BL", 6, 0.08, 0.17, 0.46, (-1.12, 0.06, 0.44), rotation=(0.0, math.radians(-136.0), 0.0)),
        mat_prefix,
        "gas_shade",
        pal,
    )
    _add_smoke_cloud(parts, "BL", (-1.24, 0.08, 0.24), 0.21, mat_prefix, pal)

    _add_part(
        parts,
        create_cone("_tmp_p_BR", 6, 0.07, 0.15, 0.40, (0.64, 0.12, 0.42), rotation=(0.0, math.radians(180.0), 0.0)),
        mat_prefix,
        "gas_shade",
        pal,
    )
    _add_smoke_cloud(parts, "BR", (0.64, 0.14, 0.22), 0.20, mat_prefix, pal)

    # 4. ROSTO CARRANCUDO DA CABEÇA PRINCIPAL (ESQUERDA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        ex = -0.34 + side * 0.29
        # Olho branco semi-fechado
        _add_part(
            parts,
            create_icosphere(f"_tmp_main_eye_{tag}", 2, 0.15, (ex, -0.71, 1.24), scale=(1.12, 0.42, 0.62)),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Sobrancelha pesada franzida sobre o olho
        _add_part(
            parts,
            create_cube(
                f"_tmp_main_brow_{tag}",
                (0.38, 0.14, 0.11),
                (ex, -0.75, 1.32),
                rotation=(0.0, math.radians(side * 14.0), math.radians(side * -8.0)),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_main_lid_{tag}",
                (0.34, 0.05, 0.045),
                (ex, -0.78, 1.27),
                rotation=(0.0, math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_main_pupil_{tag}", 1, 0.032, (ex, -0.78, 1.22), scale=(0.8, 0.5, 1.1)),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Boca carrancuda aberta com 2 presas inferiores grandes subindo + 2 dentes superiores
    _add_part(
        parts,
        create_icosphere("_tmp_main_mouth", 2, 0.30, (-0.34, -0.74, 0.96), scale=(1.36, 0.36, 0.46)),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_main_mouth_rim", (0.76, 0.07, 0.05), (-0.34, -0.82, 1.05)),
        mat_prefix,
        "eye_dark",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Presas inferiores pontudas apontando para cima
        _add_part(
            parts,
            create_cone(
                f"_tmp_main_fang_{tag}",
                4,
                0.085,
                0.015,
                0.22,
                (-0.34 + side * 0.31, -0.84, 0.99),
                rotation=(math.radians(-6.0), math.radians(side * -8.0), 0.0),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Dentinhos superiores retos
        _add_part(
            parts,
            create_cube(
                f"_tmp_main_tooth_{tag}",
                (0.09, 0.05, 0.06),
                (-0.34 + side * 0.14, -0.84, 1.02),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # Emblema de caveira e ossos cruzados na barriga da cabeça principal
    _add_part(
        parts,
        create_icosphere("_tmp_skull_outer", 2, 0.19, (-0.34, -0.74, 0.72), scale=(1.22, 0.34, 0.80)),
        mat_prefix,
        "emblem_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_skull_inner", 1, 0.10, (-0.34, -0.785, 0.73), scale=(1.22, 0.34, 0.68)),
        mat_prefix,
        "body_purple",
        pal,
    )
    for side, b_idx in [(-1.0, 0), (1.0, 1)]:
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_bone_{b_idx}",
                6,
                0.052,
                0.56,
                (-0.34, -0.75, 0.50),
                rotation=(0.0, math.radians(side * 60.0), 0.0),
                scale=(1.0, 0.48, 1.0),
            ),
            mat_prefix,
            "emblem_cream",
            pal,
        )
        for end_s in (-1.0, 1.0):
            ex = -0.34 + end_s * side * 0.24
            ez = 0.50 + end_s * 0.14
            _add_part(
                parts,
                create_icosphere(f"_tmp_bknob_{b_idx}_{int(end_s + 1)}", 1, 0.064, (ex, -0.74, ez), scale=(1.0, 0.50, 1.0)),
                mat_prefix,
                "emblem_cream",
                pal,
            )

    # 5. ROSTO ENTEDIADO DA CABEÇA SECUNDÁRIA (DIREITA-ALTA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        ex = 0.76 + side * 0.19
        ez = 1.56 - side * 0.04
        _add_part(
            parts,
            create_icosphere(f"_tmp_twin_eye_{tag}", 2, 0.11, (ex, -0.42, ez), scale=(1.10, 0.42, 0.62)),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_twin_lid_{tag}",
                (0.24, 0.06, 0.045),
                (ex, -0.46, ez + 0.04),
                rotation=(0.0, math.radians(side * 16.0), 0.0),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_twin_pupil_{tag}", 1, 0.025, (ex, -0.47, ez - 0.01), scale=(0.8, 0.5, 1.0)),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Boca mal-humorada reta + 2 presinhas pequenas + anel oval creme no queixo
    _add_part(
        parts,
        create_cube(
            "_tmp_twin_mouth",
            (0.48, 0.06, 0.048),
            (0.76, -0.45, 1.36),
            rotation=(0.0, math.radians(-12.0), 0.0),
        ),
        mat_prefix,
        "eye_dark",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_twin_fang_{tag}",
                4,
                0.036,
                0.008,
                0.09,
                (0.76 + side * 0.18, -0.46, 1.32 - side * 0.03),
                rotation=(math.radians(178.0), 0.0, 0.0),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
    _add_part(
        parts,
        create_icosphere("_tmp_twin_ring", 2, 0.13, (0.76, -0.44, 1.18), scale=(1.22, 0.34, 0.72)),
        mat_prefix,
        "emblem_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_twin_ring_hole", 1, 0.068, (0.76, -0.475, 1.18), scale=(1.20, 0.34, 0.60)),
        mat_prefix,
        "body_purple",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 110. Twinsmog lado a lado."""
    specs = [
        ("Twinsmog_Shiny", (-12.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Twinsmog_Normal", (-6.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Twinsmog_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Twinsmog_Gigante", (7.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Twinsmog_Dourada_SuperRara", (16.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_twinsmog(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
