"""
042_Fangbat_Golbat_5Variacoes_Blender.py
========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "042. Fangbat — Morcego Voraz (Ref: Golbat)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Fangbat_Shiny (1.0x - Paleta Shiny Verde-Limão + Membranas das Asas Rosa-Coral)
  2. Fangbat_Normal (1.0x - Azul-Cobalto + Enorme Boca com 4 Presas + Olhos Zangados + Asas Roxas)
  3. Fangbat_Grande (1.35x - Normal)
  4. Fangbat_Gigante (1.85x - Normal)
  5. Fangbat_Dourada_SuperRara (2.25x - Ouro Reluzente + Membranas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + estrutura óssea de asas em cones 6 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e boca voraz apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.26, 0.54, 0.78, 1.0),
        "body_shade": (0.18, 0.40, 0.62, 1.0),
        "wing_purple": (0.68, 0.40, 0.68, 1.0),
        "mouth_dark": (0.09, 0.09, 0.12, 1.0),
        "mouth_inner": (0.24, 0.22, 0.28, 1.0),
        "white": (0.99, 0.99, 1.00, 1.0),
        "pupil_dark": (0.08, 0.08, 0.10, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.42, 0.80, 0.26, 1.0),
        "body_shade": (0.28, 0.62, 0.18, 1.0),
        "wing_purple": (0.76, 0.42, 0.56, 1.0),
        "mouth_dark": (0.09, 0.10, 0.10, 1.0),
        "mouth_inner": (0.28, 0.22, 0.26, 1.0),
        "white": (0.99, 0.99, 1.00, 1.0),
        "pupil_dark": (0.08, 0.08, 0.10, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.60, 0.08, 1.0),
        "wing_purple": (0.10, 0.92, 1.00, 1.0),
        "mouth_dark": (0.18, 0.12, 0.06, 1.0),
        "mouth_inner": (0.50, 0.34, 0.08, 1.0),
        "white": (1.00, 0.99, 0.92, 1.0),
        "pupil_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def _segment_between(name: str, p0: tuple, p1: tuple, r0: float, r1: float, verts: int = 6):
    dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
    horiz = math.sqrt(dx * dx + dy * dy)
    ry = math.atan2(horiz, dz)
    rz = math.atan2(dy, dx)
    return create_cone(name, verts, r0, r1, length, mid, rotation=(0.0, ry, rz))


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_fangbat(
    name: str = "Fangbat_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de alta fidelidade do 042. Fangbat (Ref: Golbat):
      - Corpo oval alto dominado por uma gigantesca boca aberta com 4 grandes presas afiadas
      - Olhos triangulares brancos furiosos com sobrancelhas inclinadas logo acima da boca
      - Orelhas pequenas triangulares com interior roxo no topo da cabeça
      - Asas enormes e pontiagudas erguidas para o alto com membrana roxa recortada
      - Perninhas curtas com pés alongados de morcego apoiados em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Fangbat_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Fangbat_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Fangbat_Norm"

    parts = []

    # 1. CORPO OVAL ALTO AZUL-COBALTO
    _add_part(
        parts,
        create_icosphere("_tmp_body", 2, 0.62, (0.0, 0.06, 1.18), scale=(0.94, 0.84, 1.28)),
        mat_prefix,
        "body_blue",
        pal,
    )
    # Testa levemente projetada sobre a boca
    _add_part(
        parts,
        create_icosphere("_tmp_brow_mass", 2, 0.44, (0.0, -0.14, 1.72), scale=(1.12, 0.78, 0.56)),
        mat_prefix,
        "body_blue",
        pal,
    )

    # 2. GIGANTESCA BOCA ABERTA + 4 GRANDES PRESAS BRANCAS (ASSINATURA DO GOLBAT)
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_cavern", 2, 0.48, (0.0, -0.28, 1.08), scale=(0.88, 0.54, 1.24)),
        mat_prefix,
        "mouth_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_throat", 1, 0.34, (0.0, -0.32, 0.94), scale=(0.84, 0.42, 0.92)),
        mat_prefix,
        "mouth_inner",
        pal,
    )
    # 2 presas superiores grandes + 2 presas inferiores robustas
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_up_{tag}",
                5,
                0.088,
                0.014,
                0.28,
                (side * 0.25, -0.49, 1.48),
                rotation=(math.radians(174.0), math.radians(side * 6.0), 0.0),
            ),
            mat_prefix,
            "white",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_lo_{tag}",
                5,
                0.078,
                0.014,
                0.24,
                (side * 0.24, -0.49, 0.68),
                rotation=(math.radians(6.0), math.radians(side * -12.0), 0.0),
            ),
            mat_prefix,
            "white",
            pal,
        )

    # 3. OLHOS TRIANGULARES FURIOSOS + ORELHAS PEQUENAS NO TOPO
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Olho branco triangular zangado
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                1,
                0.12,
                (side * 0.24, -0.45, 1.72),
                rotation=(0.0, math.radians(side * 16.0), math.radians(side * -14.0)),
                scale=(1.26, 0.42, 0.62),
            ),
            mat_prefix,
            "white",
            pal,
        )
        # Pupila preta feroz
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.048,
                (side * 0.23, -0.50, 1.72),
                scale=(0.75, 0.42, 1.15),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )
        # Sobrancelha furiosa inclinada para o centro
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.28, 0.12, 0.065),
                (side * 0.24, -0.46, 1.80),
                rotation=(0.0, math.radians(side * 22.0), math.radians(side * -10.0)),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Orelha pequena triangular com interior roxo
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{tag}",
                5,
                0.17,
                0.024,
                0.34,
                (side * 0.34, -0.02, 2.02),
                rotation=(math.radians(-6.0), math.radians(side * 18.0), 0.0),
                scale=(1.0, 0.56, 1.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_in_{tag}",
                4,
                0.10,
                0.016,
                0.22,
                (side * 0.33, -0.08, 2.00),
                rotation=(math.radians(-6.0), math.radians(side * 18.0), 0.0),
                scale=(0.90, 0.34, 1.0),
            ),
            mat_prefix,
            "wing_purple",
            pal,
        )

    # 4. ASAS ENORMES E PONTIAGUDAS ERGUIDAS (ESTRUTURA ÓSSEA AZUL + MEMBRANA ROXA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        p_shoulder = (side * 0.48, 0.10, 1.26)
        p_elbow = (side * 1.02, 0.12, 1.98)
        p_tip_top = (side * 2.06, -0.04, 2.74)
        p_tip_mid = (side * 1.84, 0.04, 1.54)
        p_tip_low = (side * 1.24, 0.10, 0.94)
        p_hip = (side * 0.48, 0.12, 0.88)

        bones = [
            (p_shoulder, p_elbow, 0.095, 0.078),
            (p_elbow, p_tip_top, 0.078, 0.028),
            (p_elbow, p_tip_mid, 0.056, 0.026),
            (p_elbow, p_tip_low, 0.052, 0.026),
        ]
        for b_idx, (a, b, r0, r1) in enumerate(bones):
            _add_part(
                parts,
                _segment_between(f"_tmp_wbone_{tag}_{b_idx}", a, b, r0, r1, verts=6),
                mat_prefix,
                "body_blue",
                pal,
            )

        mem_panels = [
            # Painel interno perto do corpo (bem preenchido sem frestas)
            ((side * 0.84, 0.13, 1.38), (0.50, 0.058, 0.56), (0.0, math.radians(side * 12.0), 0.0)),
            # Painel médio amplo
            ((side * 1.38, 0.09, 1.62), (0.48, 0.056, 0.56), (0.0, math.radians(side * -22.0), 0.0)),
            # Painel superior erguido até a ponta alta da asa
            ((side * 1.62, 0.04, 2.18), (0.50, 0.054, 0.44), (0.0, math.radians(side * -42.0), 0.0)),
        ]
        for m_idx, (mloc, msc, mrot) in enumerate(mem_panels):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_wmem_{tag}_{m_idx}",
                    1,
                    1.0,
                    mloc,
                    rotation=mrot,
                    scale=msc,
                ),
                mat_prefix,
                "wing_purple",
                pal,
            )

    # 5. PERNINHAS COM PÉS ALONGADOS DE MORCEGO APOIADOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        p_hip_leg = (side * 0.34, 0.02, 0.56)
        p_ankle = (side * 0.62, -0.06, 0.34)
        _add_part(
            parts,
            _segment_between(f"_tmp_leg_{tag}", p_hip_leg, p_ankle, 0.088, 0.068, verts=6),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Pé longo característico do Golbat inclinado tocando Z = 0.0
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.15,
                (side * 0.66, -0.08, 0.30),
                rotation=(0.0, math.radians(side * -26.0), 0.0),
                scale=(0.76, 0.86, 2.45),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 042. Fangbat lado a lado."""
    specs = [
        ("Fangbat_Shiny", (-14.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Fangbat_Normal", (-7.9, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Fangbat_Grande", (-1.0, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Fangbat_Gigante", (7.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Fangbat_Dourada_SuperRara", (17.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_fangbat(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
