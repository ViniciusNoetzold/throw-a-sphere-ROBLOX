"""
063_Mindfox_Abra_5Variacoes_Blender.py
======================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "063. Mindfox — Místico Adormecido (Ref: Abra)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Mindfox_Shiny (1.0x - Paleta Shiny Amarelo-Limão Pastel + Armadura Malva Claro)
  2. Mindfox_Normal (1.0x - Amarelo-Ouro + Armadura e Ombreiras Marrom-Taupe + Cauda Listrada)
  3. Mindfox_Grande (1.35x - Normal)
  4. Mindfox_Gigante (1.85x - Normal)
  5. Mindfox_Dourada_SuperRara (2.25x - Ouro Reluzente + Armadura, Olhos e Faixa Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2, cones/cilindros 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base alinhada exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_yellow": (0.95, 0.84, 0.28, 1.0),
        "body_shade": (0.83, 0.72, 0.22, 1.0),
        "ear_inner": (0.84, 0.78, 0.64, 1.0),
        "armor_brown": (0.48, 0.41, 0.43, 1.0),
        "joint_dark": (0.14, 0.13, 0.15, 1.0),
        "eye_dark": (0.12, 0.10, 0.12, 1.0),
    },
    "shiny_palette": {
        "body_yellow": (0.98, 0.94, 0.56, 1.0),
        "body_shade": (0.88, 0.84, 0.46, 1.0),
        "ear_inner": (0.94, 0.90, 0.78, 1.0),
        "armor_brown": (0.58, 0.48, 0.54, 1.0),
        "joint_dark": (0.20, 0.18, 0.22, 1.0),
        "eye_dark": (0.14, 0.12, 0.16, 1.0),
    },
    "golden_super_rare_palette": {
        "body_yellow": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.86, 0.64, 0.10, 1.0),
        "ear_inner": (1.00, 0.92, 0.48, 1.0),
        "armor_brown": (0.10, 0.92, 1.00, 1.0),
        "joint_dark": (0.06, 0.56, 0.72, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_segment(
    name: str,
    p1: tuple,
    p2: tuple,
    r1: float,
    r2: float,
    vertices: int = 8,
    extend: float = 1.04,
):
    """Cria um cone/segmento conectando exatamente p1 -> p2 sem folgas."""
    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    dz = p2[2] - p1[2]
    dist = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dist < 1e-6:
        dist = 1e-6
    mid = ((p1[0] + p2[0]) * 0.5, (p1[1] + p2[1]) * 0.5, (p1[2] + p2[2]) * 0.5)
    theta = math.acos(max(-1.0, min(1.0, dz / dist)))
    phi = math.atan2(dy, dx)
    return create_cone(
        name=name,
        vertices=vertices,
        radius1=r1,
        radius2=r2,
        depth=dist * extend,
        location=mid,
        rotation=(0.0, theta, phi),
    )


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_mindfox(
    name: str = "Mindfox_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 063. Mindfox (Ref: Abra):
      - Postura sentada meditativa com pernas estendidas para frente e pés de 3 dedos abertos
      - Cabeça triangular de raposa inclinada para frente com grandes orelhas triangulares
      - Olhos fechados serenos em linhas inclinadas + focinho delicado com narinas
      - Pescoço e juntas escuras + couraça peitoral e ombreiras arredondadas marrom-taupe
      - Cauda amarela grossa e longa curvada para a direita (+X) e para cima com anel marrom
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Mindfox_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Mindfox_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Mindfox_Norm"

    parts = []

    # 1. TRONCO SENTADO, PESCOÇO ESCURO E ARMADURA PEITORAL MARROM
    _add_part(
        parts,
        create_icosphere("_tmp_pelvis", 2, 0.34, (0.0, 0.04, 0.40), scale=(1.04, 0.96, 1.06)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Peitoral blindado marrom-taupe
    _add_part(
        parts,
        create_icosphere("_tmp_chest_armor", 2, 0.34, (0.0, 0.04, 0.80), scale=(1.02, 0.88, 0.82)),
        mat_prefix,
        "armor_brown",
        pal,
    )
    # Pescoço escuro conectando tronco à cabeça
    _add_part(
        parts,
        create_cylinder("_tmp_neck_dark", 8, 0.17, 0.34, (0.0, 0.02, 1.02)),
        mat_prefix,
        "joint_dark",
        pal,
    )
    # Ombreiras arredondadas em domo marrom-taupe
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_shoulder_dark_{tag}",
                1,
                0.16,
                (side * 0.24, 0.02, 0.92),
            ),
            mat_prefix,
            "joint_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pauldron_{tag}",
                2,
                0.26,
                (side * 0.36, 0.00, 0.92),
                rotation=(math.radians(8.0), math.radians(side * 22.0), 0.0),
                scale=(1.08, 0.96, 0.78),
            ),
            mat_prefix,
            "armor_brown",
            pal,
        )

    # 2. CABEÇA TRIANGULAR DE RAPOSA INCLINADA EM MEDITAÇÃO
    # Crânio largo na parte superior
    _add_part(
        parts,
        create_icosphere(
            "_tmp_head_cranium",
            2,
            0.46,
            (0.0, -0.06, 1.48),
            rotation=(math.radians(16.0), 0.0, 0.0),
            scale=(1.12, 0.96, 0.92),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Bochechas laterais triangulares marcando o formato de raposa
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_head_cheek_{tag}",
                2,
                0.24,
                (side * 0.32, -0.14, 1.32),
                scale=(1.05, 0.90, 0.84),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
    # Focinho afilado apontando para frente-baixo (-Y, -Z)
    _add_part(
        parts,
        create_segment(
            "_tmp_snout",
            (0.0, -0.10, 1.40),
            (0.0, -0.56, 1.08),
            r1=0.34,
            r2=0.10,
            vertices=8,
            extend=1.02,
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Ponta arredondada do focinho + narinas sutis
    _add_part(
        parts,
        create_icosphere("_tmp_snout_tip", 2, 0.11, (0.0, -0.56, 1.08), scale=(1.08, 0.90, 0.82)),
        mat_prefix,
        "ear_inner",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_nostril_{tag}",
                1,
                0.022,
                (side * 0.042, -0.65, 1.08),
                scale=(0.8, 0.6, 1.0),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Olhos fechados serenos (fendas escuras inclinadas para o centro do focinho)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_segment(
                f"_tmp_eye_slit_a_{tag}",
                (side * 0.30, -0.34, 1.36),
                (side * 0.19, -0.45, 1.27),
                r1=0.022,
                r2=0.024,
                vertices=6,
                extend=1.06,
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_segment(
                f"_tmp_eye_slit_b_{tag}",
                (side * 0.19, -0.45, 1.27),
                (side * 0.11, -0.51, 1.19),
                r1=0.022,
                r2=0.016,
                vertices=6,
                extend=1.06,
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Orelhas triangulares grandes de raposa + triângulo interno bege
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        ear_base = (side * 0.34, -0.02, 1.64)
        ear_tip = (side * 0.62, -0.06, 2.02)
        _add_part(
            parts,
            create_segment(
                f"_tmp_ear_outer_{tag}",
                ear_base,
                ear_tip,
                r1=0.22,
                r2=0.03,
                vertices=6,
                extend=1.04,
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_segment(
                f"_tmp_ear_inner_{tag}",
                (side * 0.36, -0.14, 1.66),
                (side * 0.56, -0.13, 1.94),
                r1=0.11,
                r2=0.018,
                vertices=5,
                extend=1.00,
            ),
            mat_prefix,
            "ear_inner",
            pal,
        )

    # 3. BRAÇOS ESBELTOS APOIADOS JUNTO AO COLO COM 3 DEDINHOS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        p_sh = (side * 0.38, 0.00, 0.84)
        p_el = (side * 0.42, -0.08, 0.52)
        p_wr = (side * 0.22, -0.32, 0.36)
        _add_part(
            parts,
            create_segment(f"_tmp_upper_arm_{tag}", p_sh, p_el, 0.085, 0.075, vertices=6),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_elbow_{tag}", 1, 0.09, p_el),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_segment(f"_tmp_forearm_{tag}", p_el, p_wr, 0.11, 0.085, vertices=6),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_hand_{tag}", 1, 0.095, p_wr),
            mat_prefix,
            "body_yellow",
            pal,
        )
        for f_idx, (fx, fy, fz) in enumerate([
            (side * -0.04, -0.13, -0.04),
            (side * 0.03, -0.14, -0.02),
            (side * 0.09, -0.10, -0.05),
        ]):
            _add_part(
                parts,
                create_segment(
                    f"_tmp_finger_{tag}_{f_idx}",
                    p_wr,
                    (p_wr[0] + fx, p_wr[1] + fy, p_wr[2] + fz),
                    0.035,
                    0.012,
                    vertices=5,
                ),
                mat_prefix,
                "body_yellow",
                pal,
            )

    # 4. PERNAS SENTADAS ESTENDIDAS PARA FRENTE COM GRANDES PÉS DE 3 DEDOS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        p_hip = (side * 0.22, -0.02, 0.28)
        p_knee = (side * 0.58, -0.34, 0.32)
        p_ankle = (side * 0.72, -0.62, 0.20)
        # Junta escura do quadril
        _add_part(
            parts,
            create_icosphere(f"_tmp_hip_joint_{tag}", 1, 0.14, p_hip),
            mat_prefix,
            "joint_dark",
            pal,
        )
        # Coxa
        _add_part(
            parts,
            create_segment(f"_tmp_thigh_{tag}", p_hip, p_knee, 0.12, 0.13, vertices=7),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # Joelho pontudo característico
        _add_part(
            parts,
            create_icosphere(f"_tmp_knee_{tag}", 2, 0.15, p_knee, scale=(0.95, 1.05, 1.12)),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # Canela até o tornozelo/pé
        _add_part(
            parts,
            create_segment(f"_tmp_shin_{tag}", p_knee, p_ankle, 0.14, 0.15, vertices=7),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # Planta do pé voltada para frente-fora
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_pad_{tag}",
                2,
                0.18,
                (p_ankle[0] + side * 0.06, p_ankle[1] - 0.10, 0.18),
                scale=(1.08, 0.92, 0.85),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # 3 dedos grandes abertos em leque (como na referência da Abra!)
        toe_base = (p_ankle[0] + side * 0.08, p_ankle[1] - 0.14, 0.18)
        toe_targets = [
            (toe_base[0] + side * 0.26, toe_base[1] - 0.10, 0.36),   # dedo superior-externo
            (toe_base[0] + side * 0.12, toe_base[1] - 0.30, 0.28),   # dedo frontal
            (toe_base[0] - side * 0.06, toe_base[1] - 0.22, 0.08),   # dedo inferior
        ]
        for t_idx, t_end in enumerate(toe_targets):
            _add_part(
                parts,
                create_segment(f"_tmp_toe_{tag}_{t_idx}", toe_base, t_end, 0.072, 0.022, vertices=6),
                mat_prefix,
                "body_yellow",
                pal,
            )

    # 5. CAUDA GROSSA CURVADA PARA A DIREITA (+X) E PARA CIMA COM ANEL MARROM
    tail_pts = [
        (0.08, 0.26, 0.32, 0.26),
        (0.46, 0.40, 0.34, 0.27),
        (0.86, 0.34, 0.48, 0.25),
        (1.14, 0.22, 0.78, 0.21),
        (1.26, 0.12, 1.14, 0.15),  # início da faixa marrom
        (1.28, 0.08, 1.30, 0.13),  # fim da faixa marrom
        (1.22, 0.06, 1.62, 0.03),  # ponta afilada apontando para cima
    ]
    for i in range(len(tail_pts) - 1):
        p1 = tail_pts[i][:3]
        p2 = tail_pts[i + 1][:3]
        r1 = tail_pts[i][3]
        r2 = tail_pts[i + 1][3]
        mat_key = "armor_brown" if i == 4 else "body_yellow"
        _add_part(
            parts,
            create_segment(f"_tmp_tail_seg_{i}", p1, p2, r1, r2, vertices=8, extend=1.08),
            mat_prefix,
            mat_key,
            pal,
        )
        if i < len(tail_pts) - 2 and i != 4:
            _add_part(
                parts,
                create_icosphere(f"_tmp_tail_joint_{i}", 2, r2 * 0.98, p2),
                mat_prefix,
                "body_yellow",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 063. Mindfox lado a lado."""
    specs = [
        ("Mindfox_Shiny", (-10.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Mindfox_Normal", (-6.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Mindfox_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Mindfox_Gigante", (5.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Mindfox_Dourada_SuperRara", (14.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_mindfox(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
