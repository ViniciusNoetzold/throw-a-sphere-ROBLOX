"""
044_Nectarbloom_Gloom_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "044. Nectarbloom — Flor Sonolenta (Ref: Gloom)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Nectarbloom_Shiny (1.0x - Paleta Shiny Corpo Verde-Oliva + Flor e Folhas Ocre-Douradas)
  2. Nectarbloom_Normal (1.0x - Corpo Azul-Ardósia + Flor 4 Bulbos Ferrugem Pintalgada + Gota de Néctar)
  3. Nectarbloom_Grande (1.35x - Normal)
  4. Nectarbloom_Gigante (1.85x - Normal)
  5. Nectarbloom_Dourada_SuperRara (2.25x - Ouro Reluzente + Pintas e Néctar Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para corpo e os 4 bulbos da flor)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pezinhos achatados alinhados exatamente em `Z = 0.0` e rosto sonolento apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.34, 0.48, 0.64, 1.0),
        "bulb_rust": (0.62, 0.32, 0.26, 1.0),
        "leaf_orange": (0.86, 0.44, 0.24, 1.0),
        "stigma_orange": (0.88, 0.50, 0.30, 1.0),
        "spot_cream": (0.94, 0.88, 0.82, 1.0),
        "lip_lavender": (0.58, 0.48, 0.74, 1.0),
        "dark_line": (0.12, 0.14, 0.18, 1.0),
        "drool_white": (0.96, 0.97, 0.96, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.54, 0.72, 0.28, 1.0),
        "bulb_rust": (0.76, 0.58, 0.20, 1.0),
        "leaf_orange": (0.90, 0.70, 0.22, 1.0),
        "stigma_orange": (0.96, 0.78, 0.30, 1.0),
        "spot_cream": (0.98, 0.94, 0.80, 1.0),
        "lip_lavender": (0.64, 0.50, 0.76, 1.0),
        "dark_line": (0.14, 0.16, 0.12, 1.0),
        "drool_white": (0.97, 0.98, 0.94, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.98, 0.78, 0.14, 1.0),
        "bulb_rust": (0.86, 0.60, 0.08, 1.0),
        "leaf_orange": (1.00, 0.88, 0.32, 1.0),
        "stigma_orange": (0.10, 0.92, 1.00, 1.0),
        "spot_cream": (0.10, 0.92, 1.00, 1.0),
        "lip_lavender": (0.96, 0.84, 0.36, 1.0),
        "dark_line": (0.24, 0.16, 0.04, 1.0),
        "drool_white": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def _segment_between(name: str, p0: tuple, p1: tuple, r0: float, r1: float, verts: int = 6, flat_y: float = 1.0):
    dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
    horiz = math.sqrt(dx * dx + dy * dy)
    ry = math.atan2(horiz, dz)
    rz = math.atan2(dy, dx)
    return create_cone(name, verts, r0, r1, length, mid, rotation=(0.0, ry, rz), scale=(1.0, flat_y, 1.0))


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_nectarbloom(
    name: str = "Nectarbloom_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de alta fidelidade do 044. Nectarbloom (Ref: Gloom):
      - Corpo arredondado azul-ardósia com bracinhos caídos e pezinhos chatos em Z = 0.0
      - Expressão sonolenta icônica: olhos fechados curvos, lábios grossos lilás e gota de néctar branca
      - Flor volumosa de 4 bulbos vermelho-ferrugem no topo com pintinhas creme e miolo laranja
      - 5 folhas grandes laranja-ferrugem arqueadas ao redor da cabeça (esquerda enrolada, direita erguida)
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Nectar_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Nectar_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Nectar_Norm"

    parts = []

    # 1. CORPO ARREDONDADO + BRACINHOS CAÍDOS + PERNAS E PÉS CHATOS EM Z = 0.0
    _add_part(
        parts,
        create_icosphere("_tmp_body", 2, 0.68, (0.0, 0.0, 0.90), scale=(1.04, 0.96, 0.92)),
        mat_prefix,
        "body_blue",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Bracinho caído fofo
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_arm_{tag}",
                2,
                0.18,
                (side * 0.74, -0.10, 0.66),
                rotation=(0.0, math.radians(side * 42.0), math.radians(side * -14.0)),
                scale=(1.46, 0.66, 0.68),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Tornozelo fino
        _add_part(
            parts,
            create_cone(
                f"_tmp_ankle_{tag}",
                6,
                0.085,
                0.12,
                0.34,
                (side * 0.30, 0.0, 0.24),
                rotation=(0.0, math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Pé longo achatado para fora
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.22,
                (side * 0.48, -0.06, 0.10),
                rotation=(0.0, 0.0, math.radians(side * -24.0)),
                scale=(1.42, 0.88, 0.46),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    # 2. ROSTO SONOLENTO ICÔNICO (OLHOS FECHADOS + LÁBIOS LILÁS + GOTA DE NÉCTAR)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_eyelid_{tag}",
                (0.28, 0.08, 0.042),
                (side * 0.26, -0.60, 1.04),
                rotation=(0.0, math.radians(side * -18.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "dark_line",
            pal,
        )
    # Lábios grossos lilás
    _add_part(
        parts,
        create_icosphere(
            "_tmp_lips",
            2,
            0.22,
            (0.0, -0.62, 0.80),
            scale=(1.54, 0.46, 0.56),
        ),
        mat_prefix,
        "lip_lavender",
        pal,
    )
    # Fenda interna da boca
    _add_part(
        parts,
        create_cube(
            "_tmp_mouth_slit",
            (0.42, 0.08, 0.045),
            (0.0, -0.69, 0.80),
        ),
        mat_prefix,
        "dark_line",
        pal,
    )
    # Gota de néctar branca grossa escorrendo do canto direito da boca (marca registrada!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_drool_main",
            2,
            0.095,
            (0.14, -0.70, 0.62),
            scale=(0.76, 0.62, 2.38),
        ),
        mat_prefix,
        "drool_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_drool_drop",
            1,
            0.072,
            (0.22, -0.68, 0.68),
            scale=(0.82, 0.60, 1.48),
        ),
        mat_prefix,
        "drool_white",
        pal,
    )

    # 3. FLOR VOLUMOSA DE 4 BULBOS FERRUGEM PINTALGADOS + MIOLO LARANJA
    _add_part(
        parts,
        create_icosphere("_tmp_stigma", 2, 0.22, (0.0, 0.0, 1.78), scale=(1.08, 1.08, 0.84)),
        mat_prefix,
        "stigma_orange",
        pal,
    )
    bulb_specs = [
        ("F", (0.0, -0.36, 1.62), 0.38, [(-0.14, -0.32, 0.14), (0.12, -0.34, 0.10), (0.04, -0.34, -0.10)]),
        ("L", (-0.42, -0.02, 1.74), 0.36, [(-0.22, -0.26, 0.14), (-0.08, -0.30, 0.22), (-0.30, -0.14, 0.04)]),
        ("R", (0.42, -0.02, 1.74), 0.36, [(0.22, -0.26, 0.14), (0.08, -0.30, 0.22), (0.30, -0.14, 0.04)]),
        ("B", (0.0, 0.36, 1.84), 0.34, [(-0.12, -0.18, 0.28), (0.12, -0.18, 0.28)]),
    ]
    for btag, bloc, brad, spots in bulb_specs:
        _add_part(
            parts,
            create_icosphere(f"_tmp_bulb_{btag}", 2, brad, bloc, scale=(1.02, 1.00, 0.96)),
            mat_prefix,
            "bulb_rust",
            pal,
        )
        for s_idx, (dx, dy, dz) in enumerate(spots):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_spot_{btag}_{s_idx}",
                    1,
                    0.068,
                    (bloc[0] + dx, bloc[1] + dy, bloc[2] + dz),
                    scale=(1.0, 0.65, 1.0),
                ),
                mat_prefix,
                "spot_cream",
                pal,
            )

    # 4. 5 FOLHAS GRANDES LARANJA-FERRUGEM ARQUEADAS EM CURVA SUAVE (SEM DEGRAUS!)
    def _add_curved_leaf(tag_name, pts, radii):
        for i in range(len(pts) - 1):
            p0, p1 = pts[i], pts[i + 1]
            r0, r1 = radii[i], radii[i + 1]
            _add_part(
                parts,
                _segment_between(f"_tmp_{tag_name}_{i}", p0, p1, r0, r1, verts=6, flat_y=0.36),
                mat_prefix,
                "leaf_orange",
                pal,
            )
            if i < len(pts) - 2:
                _add_part(
                    parts,
                    create_icosphere(
                        f"_tmp_{tag_name}_j{i}",
                        1,
                        r1 * 1.02,
                        p1,
                        scale=(1.02, 0.38, 1.02),
                    ),
                    mat_prefix,
                    "leaf_orange",
                    pal,
                )

    # Folha longa esquerda curvando para baixo e enrolando suavemente na ponta
    _add_curved_leaf(
        "leaf_L",
        [(-0.30, 0.04, 1.48), (-0.72, 0.03, 1.56), (-1.14, 0.01, 1.44), (-1.38, -0.02, 1.14), (-1.24, -0.04, 0.84)],
        [0.24, 0.23, 0.20, 0.13, 0.022],
    )
    # Folha frontal esquerda caindo perto da bochecha
    _add_curved_leaf(
        "leaf_FL",
        [(-0.26, -0.14, 1.44), (-0.64, -0.18, 1.32), (-0.88, -0.18, 1.02), (-0.94, -0.16, 0.68)],
        [0.23, 0.20, 0.14, 0.024],
    )
    # Folha frontal direita caindo perto da bochecha direita
    _add_curved_leaf(
        "leaf_FR",
        [(0.26, -0.14, 1.44), (0.66, -0.18, 1.30), (0.92, -0.17, 1.00), (0.98, -0.15, 0.66)],
        [0.23, 0.20, 0.14, 0.024],
    )
    # Folha longa direita varrendo graciosamente PARA CIMA (silhueta idêntica à referência!)
    _add_curved_leaf(
        "leaf_R",
        [(0.30, 0.04, 1.48), (0.76, 0.04, 1.50), (1.18, 0.02, 1.66), (1.42, 0.00, 1.96), (1.36, -0.02, 2.28)],
        [0.24, 0.22, 0.19, 0.12, 0.022],
    )
    # Folha traseira equilibrando o volume atrás
    _add_curved_leaf(
        "leaf_B",
        [(0.0, 0.28, 1.48), (0.0, 0.72, 1.42), (0.0, 1.04, 1.18), (0.0, 1.12, 0.88)],
        [0.22, 0.19, 0.13, 0.024],
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 044. Nectarbloom lado a lado."""
    specs = [
        ("Nectarbloom_Shiny", (-10.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Nectarbloom_Normal", (-5.9, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Nectarbloom_Grande", (-0.7, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Nectarbloom_Gigante", (5.7, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Nectarbloom_Dourada_SuperRara", (13.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_nectarbloom(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
