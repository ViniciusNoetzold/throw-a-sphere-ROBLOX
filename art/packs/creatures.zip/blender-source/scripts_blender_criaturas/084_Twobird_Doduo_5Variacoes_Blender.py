"""
084_Twobird_Doduo_5Variacoes_Blender.py
=======================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "084. Twobird — Avestruz Bífida (Ref: Doduo)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Twobird_Shiny (1.0x - Paleta Shiny Verde-Lima Vibrante + Pescoços Carvão + Bicos Creme)
  2. Twobird_Normal (1.0x - Corpo Fofo Marrom-Canela + 2 Pescoços Escuros + 2 Cabeças com Bicos Longos)
  3. Twobird_Grande (1.35x - Normal)
  4. Twobird_Gigante (1.85x - Normal)
  5. Twobird_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Pescoços e Garras Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + tufos de plumagem + pernas de avestruz articuladas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Garras e pés de avestruz apoiados exatamente em `Z = 0.0` e frente apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_brown": (0.76, 0.56, 0.40, 1.0),
        "body_shade": (0.62, 0.44, 0.30, 1.0),
        "neck_black": (0.24, 0.24, 0.27, 1.0),
        "beak_tan": (0.86, 0.77, 0.64, 1.0),
        "leg_tan": (0.82, 0.74, 0.64, 1.0),
        "eye_dark": (0.10, 0.10, 0.13, 1.0),
        "claw_white": (0.96, 0.97, 0.99, 1.0),
    },
    "shiny_palette": {
        "body_brown": (0.58, 0.78, 0.26, 1.0),
        "body_shade": (0.44, 0.62, 0.18, 1.0),
        "neck_black": (0.22, 0.24, 0.22, 1.0),
        "beak_tan": (0.92, 0.86, 0.62, 1.0),
        "leg_tan": (0.88, 0.82, 0.60, 1.0),
        "eye_dark": (0.10, 0.10, 0.13, 1.0),
        "claw_white": (0.96, 0.97, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "body_brown": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.62, 0.10, 1.0),
        "neck_black": (0.10, 0.92, 1.00, 1.0),
        "beak_tan": (1.00, 0.92, 0.48, 1.0),
        "leg_tan": (0.94, 0.76, 0.22, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "claw_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel angular e Flat Shading."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_curved_neck(parts: list, tag: str, pts: list, radius: float, mat_key: str, mat_prefix: str, pal: dict):
    """Constrói um pescoço curvo contínuo a partir de uma lista de pontos 3D."""
    for i in range(len(pts) - 1):
        p0, p1 = pts[i], pts[i + 1]
        dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
        length = math.sqrt(dx * dx + dy * dy + dz * dz)
        mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
        horiz = math.sqrt(dx * dx + dy * dy)
        rx = -math.atan2(dy, dz) if abs(dy) > 1e-5 or abs(dz) > 1e-5 else 0.0
        # Cálculo exato de alinhamento do eixo Z local para o vetor (dx, dy, dz)
        pitch = math.atan2(horiz, dz)
        yaw = math.atan2(dx, -dy)
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_neck_{tag}_{i}",
                8,
                radius,
                length + 0.06,
                mid,
                rotation=(pitch, 0.0, yaw),
            ),
            mat_prefix,
            mat_key,
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_neck_j_{tag}_{i}", 1, radius * 1.02, p1),
            mat_prefix,
            mat_key,
            pal,
        )


def _add_doduo_head(
    parts: list,
    tag: str,
    center: tuple,
    yaw_deg: float,
    pitch_deg: float,
    mat_prefix: str,
    pal: dict,
):
    """Constrói uma cabeça redonda fofa de Doduo com olhos brilhantes e bico longo pontiagudo."""
    cx, cy, cz = center
    rz = math.radians(yaw_deg)
    rx = math.radians(pitch_deg)

    def to_world(lx, ly, lz):
        # Pitch em X depois Yaw em Z
        c_x, s_x = math.cos(rx), math.sin(rx)
        y1, z1 = ly * c_x - lz * s_x, ly * s_x + lz * c_x
        c_z, s_z = math.cos(rz), math.sin(rz)
        x2, y2 = lx * c_z - y1 * s_z, lx * s_z + y1 * c_z
        return (cx + x2, cy + y2, cz + z1)

    # Cabeça fofa redonda
    _add_part(
        parts,
        create_icosphere(f"_tmp_head_{tag}", 2, 0.34, center, scale=(1.02, 1.04, 0.98)),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Tufos de penugem ao redor da cabeça
    for f_idx, (fx, fy, fz, fry) in enumerate([
        (0.0, 0.06, 0.32, 0.0),
        (-0.28, 0.06, 0.14, -55.0),
        (0.28, 0.06, 0.14, 55.0),
        (0.0, 0.28, -0.06, 0.0),
    ]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_hfluff_{tag}_{f_idx}",
                5,
                0.11,
                0.02,
                0.18,
                to_world(fx, fy, fz),
                rotation=(rx, math.radians(fry), rz),
            ),
            mat_prefix,
            "body_brown",
            pal,
        )

    # Bico longo afiado (mandíbula superior + inferior) apontando para frente (-Y local, ponta fina à frente!)
    _add_part(
        parts,
        create_cone(
            f"_tmp_beak_up_{tag}",
            6,
            0.125,
            0.018,
            0.70,
            to_world(0.0, -0.58, 0.02),
            rotation=(math.radians(90.0) + rx, 0.0, rz),
            scale=(0.86, 0.72, 1.0),
        ),
        mat_prefix,
        "beak_tan",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            f"_tmp_beak_lo_{tag}",
            6,
            0.10,
            0.015,
            0.58,
            to_world(0.0, -0.52, -0.045),
            rotation=(math.radians(94.0) + rx, 0.0, rz),
            scale=(0.80, 0.56, 1.0),
        ),
        mat_prefix,
        "beak_tan",
        pal,
    )

    # Dois olhos redondos escuros brilhantes com ponto de luz branco
    for side in (-1.0, 1.0):
        etag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}_{etag}",
                2,
                0.088,
                to_world(side * 0.21, -0.24, 0.08),
                scale=(0.85, 0.85, 1.08),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eyesh_{tag}_{etag}",
                1,
                0.032,
                to_world(side * 0.23, -0.31, 0.12),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )


def _add_ostrich_leg(
    parts: list,
    tag: str,
    hip: tuple,
    knee: tuple,
    ankle: tuple,
    yaw_deg: float,
    mat_prefix: str,
    pal: dict,
):
    """Constrói perna articulada de avestruz + pé com 3 dedos frontais, esporão traseiro e garras."""
    _add_curved_neck(parts, f"leg_{tag}", [hip, knee, ankle], 0.085, "leg_tan", mat_prefix, pal)
    ax, ay, az = ankle
    rz = math.radians(yaw_deg)

    # Base do pé
    _add_part(
        parts,
        create_icosphere(f"_tmp_foot_hub_{tag}", 1, 0.11, (ax, ay, az), scale=(1.1, 1.2, 0.65)),
        mat_prefix,
        "leg_tan",
        pal,
    )
    # 3 dedos frontais + garras brancas
    for t_idx, (ang_d, t_len) in enumerate([(-34.0, 0.36), (0.0, 0.42), (34.0, 0.36)]):
        rad = math.radians(ang_d) + rz
        dx = math.sin(rad)
        dy = -math.cos(rad)
        mid_x = ax + dx * (t_len * 0.50)
        mid_y = ay + dy * (t_len * 0.50)
        tip_x = ax + dx * (t_len + 0.05)
        tip_y = ay + dy * (t_len + 0.05)
        _add_part(
            parts,
            create_cone(
                f"_tmp_toe_{tag}_{t_idx}",
                6,
                0.068,
                0.036,
                t_len,
                (mid_x, mid_y, az),
                rotation=(math.radians(90.0), 0.0, rad),
                scale=(1.0, 0.72, 1.0),
            ),
            mat_prefix,
            "leg_tan",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_claw_{tag}_{t_idx}",
                5,
                0.042,
                0.010,
                0.15,
                (tip_x, tip_y, az - 0.01),
                rotation=(math.radians(96.0), 0.0, rad),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )
    # Esporão traseiro
    rad_b = rz + math.pi
    bx = ax + math.sin(rad_b) * 0.16
    by = ay - math.cos(rad_b) * 0.16
    _add_part(
        parts,
        create_cone(
            f"_tmp_spur_{tag}",
            5,
            0.055,
            0.015,
            0.22,
            (bx, by, az + 0.01),
            rotation=(math.radians(90.0), 0.0, rad_b),
        ),
        mat_prefix,
        "leg_tan",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            f"_tmp_spur_cl_{tag}",
            4,
            0.030,
            0.008,
            0.10,
            (ax + math.sin(rad_b) * 0.28, ay - math.cos(rad_b) * 0.28, az),
            rotation=(math.radians(96.0), 0.0, rad_b),
        ),
        mat_prefix,
        "claw_white",
        pal,
    )


def build_twobird(
    name: str = "Twobird_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 084. Twobird (Ref: Doduo):
      - Corpo fofo redondo marrom-canela sem asas com tufos de plumagem facetados
      - Dois pescoços longos curvos em cinza-carvão escuro (como na arte oficial)
      - Duas cabeças redondas fofas em alturas distintas com olhos brilhantes e bicos longos afiados
      - Duas pernas longas esbeltas de avestruz com pés de 3 dedos e garras brancas em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Two_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Two_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Two_Norm"

    parts = []

    # 1. CORPO REDONDO FOFO SEM ASAS + TUFOS DE PLUMAGEM
    _add_part(
        parts,
        create_icosphere("_tmp_body", 2, 0.62, (0.0, 0.06, 1.30), scale=(0.98, 1.06, 0.96)),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Tufos discretos ao redor do corpo para textura fofa fiel à referência
    for idx in range(8):
        ang = math.radians(idx * 45.0)
        tx = math.cos(ang) * 0.54
        ty = 0.06 + math.sin(ang) * 0.56
        _add_part(
            parts,
            create_cone(
                f"_tmp_fluff_{idx}",
                5,
                0.18,
                0.03,
                0.24,
                (tx, ty, 1.18 + (0.08 if idx % 2 == 0 else -0.06)),
                rotation=(math.radians(120.0), 0.0, ang - math.pi * 0.5),
            ),
            mat_prefix,
            "body_brown" if idx % 2 == 0 else "body_shade",
            pal,
        )

    # 2. DOIS PESCOÇOS LONGOS CURVOS ESCUROS (ESQUERDO MAIS BAIXO, DIREITO MAIS ALTO)
    _add_curved_neck(
        parts,
        "L",
        [(-0.22, -0.10, 1.72), (-0.42, -0.22, 2.08), (-0.54, -0.32, 2.40)],
        0.095,
        "neck_black",
        mat_prefix,
        pal,
    )
    _add_curved_neck(
        parts,
        "R",
        [(0.20, -0.06, 1.74), (0.36, -0.14, 2.22), (0.44, -0.20, 2.68)],
        0.095,
        "neck_black",
        mat_prefix,
        pal,
    )
    # Colares de penugem onde os pescoços nascem no corpo
    _add_part(parts, create_cone("_tmp_col_L", 6, 0.19, 0.09, 0.18, (-0.24, -0.12, 1.82)), mat_prefix, "body_brown", pal)
    _add_part(parts, create_cone("_tmp_col_R", 6, 0.19, 0.09, 0.18, (0.22, -0.08, 1.84)), mat_prefix, "body_brown", pal)

    # 3. DUAS CABEÇAS EXPRESSIVAS COM BICOS LONGOS
    _add_doduo_head(parts, "L", (-0.58, -0.34, 2.52), yaw_deg=-32.0, pitch_deg=4.0, mat_prefix=mat_prefix, pal=pal)
    _add_doduo_head(parts, "R", (0.46, -0.22, 2.84), yaw_deg=18.0, pitch_deg=32.0, mat_prefix=mat_prefix, pal=pal)

    # 4. DUAS PERNAS LONGAS DE AVESTRUZ APOIADAS EM Z = 0.0
    _add_ostrich_leg(
        parts,
        tag="L",
        hip=(-0.24, 0.06, 0.86),
        knee=(-0.28, 0.24, 0.48),
        ankle=(-0.26, -0.06, 0.07),
        yaw_deg=-10.0,
        mat_prefix=mat_prefix,
        pal=pal,
    )
    _add_ostrich_leg(
        parts,
        tag="R",
        hip=(0.24, 0.08, 0.86),
        knee=(0.28, 0.26, 0.48),
        ankle=(0.26, 0.06, 0.07),
        yaw_deg=12.0,
        mat_prefix=mat_prefix,
        pal=pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 084. Twobird lado a lado."""
    specs = [
        ("Twobird_Shiny", (-9.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Twobird_Normal", (-5.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Twobird_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Twobird_Gigante", (5.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Twobird_Dourada_SuperRara", (13.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_twobird(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
