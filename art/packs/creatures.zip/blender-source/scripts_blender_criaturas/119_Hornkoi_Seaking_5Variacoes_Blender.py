"""
119_Hornkoi_Seaking_5Variacoes_Blender.py
=========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "119. Hornkoi — Carpa Chifruda (Ref: Seaking)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Hornkoi_Shiny (1.0x - Paleta Shiny Laranja-Ouro / Tangerina + Manchas Pretas + Véus Pérola)
  2. Hornkoi_Normal (1.0x - Carpa Laranja-Coral + Manchas Pretas e Brancas + Chifre Marfim + Véus Pintados)
  3. Hornkoi_Grande (1.35x - Normal)
  4. Hornkoi_Gigante (1.85x - Normal)
  5. Hornkoi_Dourada_SuperRara (2.25x - Ouro Reluzente + Chifre e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para corpo robusto e barbatanas em véu; cones 6-8 lados para chifre e presinhas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base das nadadeiras alinhada em `Z = 0.0` e rosto/lábios apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_orange": (0.93, 0.42, 0.24, 1.0),
        "body_white": (0.96, 0.96, 0.98, 1.0),
        "fin_pearl": (0.91, 0.92, 0.96, 1.0),
        "koi_black": (0.11, 0.12, 0.14, 1.0),
        "horn_ivory": (0.92, 0.88, 0.78, 1.0),
        "lip_pink": (0.90, 0.64, 0.74, 1.0),
        "fang_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.08, 0.09, 0.12, 1.0),
    },
    "shiny_palette": {
        "body_orange": (0.98, 0.68, 0.16, 1.0),
        "body_white": (0.99, 0.98, 0.95, 1.0),
        "fin_pearl": (0.95, 0.93, 0.88, 1.0),
        "koi_black": (0.14, 0.12, 0.10, 1.0),
        "horn_ivory": (0.96, 0.92, 0.78, 1.0),
        "lip_pink": (0.94, 0.68, 0.72, 1.0),
        "fang_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.08, 0.09, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "body_orange": (0.98, 0.78, 0.14, 1.0),
        "body_white": (1.00, 0.92, 0.46, 1.0),
        "fin_pearl": (0.96, 0.86, 0.34, 1.0),
        "koi_black": (0.10, 0.92, 1.00, 1.0),
        "horn_ivory": (0.10, 0.92, 1.00, 1.0),
        "lip_pink": (1.00, 0.88, 0.42, 1.0),
        "fang_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.04, 0.46, 0.62, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_hornkoi(
    name: str = "Hornkoi_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de 119. Hornkoi (Ref: Seaking):
      - Corpo robusto de carpa laranja-coral com queixo/peito branco e faixa preta koi marcante no dorso
      - Chifre cônico robusto marfim projetado para frente/cima na testa
      - Olhos grandes redondos brilhantes com anel branco + pupila escura e brilho + risco preto nas bochechas
      - Lábios rosados grossos com 2 presinhas brancas pontiagudas
      - Grande barbatana dorsal alta em forma de leque branco
      - Barbatanas peitorais, pélvicas e enorme cauda bifurcada em véu branco salpicadas de manchas pretas koi
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Hnk_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Hnk_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Hnk_Norm"

    parts = []

    # 1. CORPO ROBUSTO DE CARPA KOI (LARANJA + QUEIXO/VENTRE BRANCO + FAIXA PRETA KOI)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_body_main",
            2,
            0.80,
            (0.0, -0.02, 1.04),
            scale=(0.94, 1.16, 0.96),
        ),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Mancha branca no queixo/peito frontal (fiel à arte do Seaking!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_chin_white",
            2,
            0.54,
            (0.0, -0.44, 0.72),
            scale=(0.86, 0.92, 0.74),
        ),
        mat_prefix,
        "body_white",
        pal,
    )
    # Ventre inferior branco
    _add_part(
        parts,
        create_icosphere(
            "_tmp_belly_white",
            2,
            0.56,
            (0.0, 0.16, 0.64),
            scale=(0.88, 1.06, 0.68),
        ),
        mat_prefix,
        "body_white",
        pal,
    )
    # Faixa preta arqueada icônica sobre o dorso/flancos (estilo carpa Koi)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_koi_saddle",
            2,
            0.76,
            (0.0, 0.20, 1.14),
            scale=(0.98, 0.42, 0.96),
        ),
        mat_prefix,
        "koi_black",
        pal,
    )
    # Manchas pretas koi nos flancos traseiros
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        for m_idx, (dy, dz, rad) in enumerate([(0.44, 1.14, 0.14), (0.54, 0.94, 0.12), (0.34, 0.84, 0.10)]):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_flank_spot_{tag}_{m_idx}",
                    1,
                    rad,
                    (side * 0.64, dy, dz),
                    scale=(0.45, 1.0, 1.0),
                ),
                mat_prefix,
                "koi_black",
                pal,
            )

    # 2. CHIFRE CÔNICO LONGO NA TESTA
    _add_part(
        parts,
        create_cone(
            "_tmp_horn",
            8,
            0.20,
            0.018,
            0.84,
            (0.0, -0.58, 1.88),
            rotation=(math.radians(34.0), 0.0, 0.0),
        ),
        mat_prefix,
        "horn_ivory",
        pal,
    )

    # 3. ROSTO EXPRESSIVO: OLHOS GRANDES REDONDOS + MARCAS PRETAS + LÁBIOS COM 2 PRESAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Anel branco do olho
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_ring_{tag}",
                2,
                0.23,
                (side * 0.48, -0.60, 1.24),
                rotation=(0.0, 0.0, math.radians(side * -28.0)),
                scale=(0.76, 0.50, 0.98),
            ),
            mat_prefix,
            "body_white",
            pal,
        )
        # Íris/pupila preta grande brilhante
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                2,
                0.175,
                (side * 0.51, -0.66, 1.24),
                rotation=(0.0, 0.0, math.radians(side * -28.0)),
                scale=(0.74, 0.44, 0.96),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Brilho branco grande no olho
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.056,
                (side * 0.50, -0.73, 1.31),
            ),
            mat_prefix,
            "fang_white",
            pal,
        )
        # 2 riscos pretos tipo guelra/bigode abaixo do olho
        for g_idx, gz in enumerate([0.98, 0.88]):
            _add_part(
                parts,
                create_cube(
                    f"_tmp_cheek_mark_{tag}_{g_idx}",
                    (0.06, 0.24, 0.055),
                    (side * 0.65, -0.34, gz),
                    rotation=(math.radians(-10.0), 0.0, math.radians(side * 22.0)),
                ),
                mat_prefix,
                "koi_black",
                pal,
            )

    # Lábios rosados + 2 presinhas brancas frontais (-Y)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_lip_upper",
            2,
            0.20,
            (0.0, -0.92, 1.06),
            scale=(1.28, 0.60, 0.54),
        ),
        mat_prefix,
        "lip_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_lip_lower",
            2,
            0.18,
            (0.0, -0.90, 0.93),
            scale=(1.18, 0.58, 0.48),
        ),
        mat_prefix,
        "lip_pink",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.042,
                0.008,
                0.10,
                (side * 0.11, -0.99, 0.99),
                rotation=(math.radians(180.0), 0.0, 0.0),
            ),
            mat_prefix,
            "fang_white",
            pal,
        )

    # 4. BARBATANA DORSAL ALTA BRANCA EM LEQUE NO TOPO
    _add_part(
        parts,
        create_cone(
            "_tmp_dorsal_main",
            6,
            0.46,
            0.24,
            0.86,
            (0.0, 0.18, 2.04),
            rotation=(math.radians(-18.0), 0.0, 0.0),
            scale=(0.24, 1.0, 1.0),
        ),
        mat_prefix,
        "body_white",
        pal,
    )

    # 5. NADADEIRAS PEITORAIS E PÉLVICAS BRANCAS COM PINTAS PRETAS KOI
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Peitoral em véu orgânico de dois lobos suaves
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pec_fin_a_{tag}",
                2,
                0.38,
                (side * 0.92, -0.14, 0.68),
                rotation=(math.radians(14.0), math.radians(side * 124.0), math.radians(side * -18.0)),
                scale=(0.24, 0.86, 1.32),
            ),
            mat_prefix,
            "fin_pearl",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pec_fin_b_{tag}",
                2,
                0.32,
                (side * 0.98, 0.04, 0.62),
                rotation=(math.radians(8.0), math.radians(side * 116.0), math.radians(side * 6.0)),
                scale=(0.22, 0.82, 1.24),
            ),
            mat_prefix,
            "body_white",
            pal,
        )
        # Pintas pretas koi na nadadeira peitoral
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pec_spot_{tag}",
                1,
                0.095,
                (side * 0.96, -0.22, 0.66),
                scale=(0.95, 0.42, 0.85),
            ),
            mat_prefix,
            "koi_black",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pec_spot2_{tag}",
                1,
                0.062,
                (side * 1.08, -0.16, 0.56),
                scale=(0.90, 0.42, 0.85),
            ),
            mat_prefix,
            "koi_black",
            pal,
        )
        # Nadadeira pélvica inferior apoiando o equilíbrio visual em Z baixo
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pelvic_fin_{tag}",
                2,
                0.28,
                (side * 0.42, 0.16, 0.34),
                rotation=(math.radians(16.0), math.radians(side * 24.0), 0.0),
                scale=(0.40, 0.92, 1.24),
            ),
            mat_prefix,
            "fin_pearl",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pelvic_spot_{tag}",
                1,
                0.08,
                (side * 0.44, 0.06, 0.30),
            ),
            mat_prefix,
            "koi_black",
            pal,
        )

    # 6. ENORME CAUDA BIFURCADA EM VÉU BRANCO COM MANCHAS PRETAS KOI (VISÍVEL DE FRENTE)
    tail_parts = [
        # (x, y, z, rx, ry, rz, rad, sc)
        (-0.56, 1.26, 1.66, -24.0, -30.0, -28.0, 0.56, (0.30, 1.28, 1.32)),
        (0.56, 1.26, 1.66, -24.0, 30.0, 28.0, 0.56, (0.30, 1.28, 1.32)),
        (-0.62, 1.24, 0.66, 22.0, -26.0, -22.0, 0.52, (0.30, 1.22, 1.24)),
        (0.62, 1.24, 0.66, 22.0, 26.0, 22.0, 0.52, (0.30, 1.22, 1.24)),
        (0.0, 1.04, 1.12, 0.0, 0.0, 0.0, 0.46, (0.48, 1.10, 1.12)),
    ]
    for t_idx, (tx, ty, tz, rx, ry, rz, rad, sc) in enumerate(tail_parts):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_tail_lobe_{t_idx}",
                2,
                rad,
                (tx, ty, tz),
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
                scale=sc,
            ),
            mat_prefix,
            "body_white",
            pal,
        )
    # Manchas pretas koi na cauda branca
    tail_spots = [
        (-0.76, 1.18, 1.88, 0.12),
        (0.76, 1.18, 1.88, 0.12),
        (-0.78, 1.18, 0.58, 0.11),
        (0.78, 1.18, 0.58, 0.11),
        (-0.62, 1.14, 1.48, 0.09),
        (0.62, 1.14, 1.48, 0.09),
    ]
    for s_idx, (sx, sy, sz, rad) in enumerate(tail_spots):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tail_spot_{s_idx}", 1, rad, (sx, sy, sz)),
            mat_prefix,
            "koi_black",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 119. Hornkoi lado a lado."""
    specs = [
        ("Hornkoi_Shiny", (-11.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Hornkoi_Normal", (-6.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Hornkoi_Grande", (-1.9, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Hornkoi_Gigante", (4.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Hornkoi_Dourada_SuperRara", (12.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_hornkoi(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
