"""
005_Flareclaw_Charmeleon_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "005. Flareclaw — Lagarto Chamejante (Ref: Charmeleon)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Flareclaw_Shiny (1.0x - Paleta Shiny / Shyne Amarelo-Ouro Luminoso + Olhos Turquesa)
  2. Flareclaw_Normal (1.0x - Corpo Vermelho-Brasa + Chifre Traseiro Único + 3 Garras)
  3. Flareclaw_Grande (1.35x - Normal)
  4. Flareclaw_Gigante (1.85x - Normal)
  5. Flareclaw_Dourada_SuperRara (2.25x - Ouro Reluzente + Chama Solar Platina + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cilindros 8 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.017`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base dos pés e garras alinhada exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Flareclaw_Shiny`, `Flareclaw_Normal`, `Flareclaw_Grande`,
     `Flareclaw_Gigante`, `Flareclaw_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.017,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_red": (0.88, 0.22, 0.16, 1.0),
        "belly_cream": (0.98, 0.86, 0.56, 1.0),
        "flame_outer": (1.00, 0.36, 0.08, 1.0),
        "flame_core": (1.00, 0.88, 0.16, 1.0),
        "eyes_blue": (0.10, 0.36, 0.52, 1.0),
        "brow_dark": (0.58, 0.12, 0.10, 1.0),
        "claws_white": (0.96, 0.96, 0.97, 1.0),
    },
    "shiny_palette": {
        "body_red": (0.96, 0.76, 0.18, 1.0),
        "belly_cream": (1.00, 0.94, 0.70, 1.0),
        "flame_outer": (1.00, 0.50, 0.10, 1.0),
        "flame_core": (1.00, 0.94, 0.38, 1.0),
        "eyes_blue": (0.12, 0.64, 0.50, 1.0),
        "brow_dark": (0.72, 0.52, 0.10, 1.0),
        "claws_white": (0.98, 0.98, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "body_red": (0.98, 0.76, 0.12, 1.0),
        "belly_cream": (1.00, 0.92, 0.48, 1.0),
        "flame_outer": (1.00, 0.86, 0.22, 1.0),
        "flame_core": (1.00, 0.98, 0.84, 1.0),
        "eyes_blue": (0.10, 0.92, 1.00, 1.0),
        "brow_dark": (0.74, 0.50, 0.06, 1.0),
        "claws_white": (1.00, 0.97, 0.84, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_flareclaw(
    name: str = "Flareclaw_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 005. Flareclaw (Ref: Charmeleon):
      - Frente apontando para -Y e base dos pés e garras em Z = 0.0
      - Torso bípede atlético com barriga creme-ouro e braços dobrados com 3 garras grandes
      - Cabeça angular com focinho alongado, olhos ferozes e 1 crista/chifre traseiro único
      - Cauda forte curvada para cima com chama bicolor vibrante na ponta
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Flare_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Flare_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Flare"

    parts = []

    # 1. TORSO BÍPEDE ATLÉTICO + BARRIGA CREME-OURO + PESCOÇO FORTE
    _add_part(
        parts,
        create_cube("_tmp_torso", (1.02, 0.88, 1.24), (0.0, 0.0, 1.22)),
        mat_prefix,
        "body_red",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_pelvis", (1.08, 0.94, 0.72), (0.0, 0.08, 0.80)),
        mat_prefix,
        "body_red",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_belly", (0.76, 0.14, 1.18), (0.0, -0.44, 1.12)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_neck", 6, 0.34, 0.28, 0.46, (0.0, -0.06, 1.94)),
        mat_prefix,
        "body_red",
        pal,
    )

    # 2. PERNAS MUSCULOSAS (Z = 0) + BRAÇOS DOBRADOS COM 3 GARRAS GRANDES
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_thigh_{side_idx}",
                (0.50, 0.58, 0.68),
                (sx * 0.50, 0.04, 0.66),
                (math.radians(10), 0.0, math.radians(sx * -8)),
            ),
            mat_prefix,
            "body_red",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{side_idx}", (0.44, 0.62, 0.36), (sx * 0.54, -0.08, 0.20)),
            mat_prefix,
            "body_red",
            pal,
        )
        for claw_i, cx_off in enumerate([-0.13, 0.0, 0.13]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_claw_{side_idx}_{claw_i}",
                    4,
                    0.068,
                    0.012,
                    0.26,
                    (sx * 0.54 + cx_off, -0.46, 0.09),
                    (math.radians(86), 0.0, 0.0),
                ),
                mat_prefix,
                "claws_white",
                pal,
            )

        # Ombro/braço superior + antebraço dobrado + 3 garras grandes nas mãos
        _add_part(
            parts,
            create_cone(
                f"_tmp_upper_arm_{side_idx}",
                6,
                0.20,
                0.16,
                0.56,
                (sx * 0.68, -0.04, 1.62),
                (math.radians(12), math.radians(sx * 116), 0.0),
            ),
            mat_prefix,
            "body_red",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_forearm_{side_idx}",
                6,
                0.17,
                0.14,
                0.58,
                (sx * 0.92, -0.26, 1.32),
                (math.radians(132), math.radians(sx * 6), 0.0),
            ),
            mat_prefix,
            "body_red",
            pal,
        )
        for hx_i, hx_off in enumerate([-0.09, 0.0, 0.09]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{side_idx}_{hx_i}",
                    4,
                    0.058,
                    0.010,
                    0.24,
                    (sx * 0.92 + hx_off, -0.54, 1.03),
                    (math.radians(135), 0.0, 0.0),
                ),
                mat_prefix,
                "claws_white",
                pal,
            )

    # 3. CABEÇA ANGULAR (-Y), CHIFRE TRASEIRO ÚNICO (+Y/+Z) E OLHOS FEROZES
    _add_part(
        parts,
        create_cube("_tmp_head", (0.96, 1.02, 0.82), (0.0, -0.16, 2.34)),
        mat_prefix,
        "body_red",
        pal,
    )
    # Crista / chifre traseiro angular único na parte posterior da cabeça
    _add_part(
        parts,
        create_cone("_tmp_head_horn", 4, 0.26, 0.06, 0.72, (0.0, 0.38, 2.74), (math.radians(-48), 0.0, 0.0)),
        mat_prefix,
        "body_red",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout", (0.76, 0.58, 0.42), (0.0, -0.74, 2.18)),
        mat_prefix,
        "body_red",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_nose_tip", (0.62, 0.24, 0.34), (0.0, -1.04, 2.18)),
        mat_prefix,
        "body_red",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_lower_jaw", (0.68, 0.48, 0.14), (0.0, -0.70, 1.96)),
        mat_prefix,
        "body_red",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth_line", (0.70, 0.42, 0.06), (0.0, -0.82, 2.04)),
        mat_prefix,
        "brow_dark",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{side_idx}",
                (0.26, 0.12, 0.07),
                (sx * 0.34, -0.70, 2.48),
                (0.0, math.radians(sx * 18), math.radians(sx * -18)),
            ),
            mat_prefix,
            "brow_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_sclera_{side_idx}",
                (0.24, 0.10, 0.20),
                (sx * 0.35, -0.68, 2.37),
                (0.0, 0.0, math.radians(sx * -20)),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_iris_{side_idx}",
                (0.15, 0.08, 0.16),
                (sx * 0.34, -0.71, 2.36),
                (0.0, 0.0, math.radians(sx * -20)),
            ),
            mat_prefix,
            "eyes_blue",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{side_idx}",
                4,
                0.044,
                0.008,
                0.11,
                (sx * 0.26, -1.00, 2.02),
                (math.radians(180), 0.0, 0.0),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )

    # 4. CAUDA LONGA FORTE CURVADA (+Y) + GRANDE CHAMA BICOLOR
    _add_part(
        parts,
        create_cone("_tmp_tail_base", 6, 0.32, 0.22, 0.78, (0.0, 0.74, 0.70), (math.radians(-70), 0.0, 0.0)),
        mat_prefix,
        "body_red",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_tail_cream", (0.30, 0.62, 0.14), (0.0, 0.78, 0.56), (math.radians(-20), 0.0, 0.0)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_tail_mid", 6, 0.22, 0.14, 0.74, (0.0, 1.32, 0.94), (math.radians(-42), 0.0, 0.0)),
        mat_prefix,
        "body_red",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_tail_tip", 6, 0.14, 0.08, 0.64, (0.0, 1.68, 1.40), (math.radians(-16), 0.0, 0.0)),
        mat_prefix,
        "body_red",
        pal,
    )

    _add_part(
        parts,
        create_icosphere("_tmp_flame_orb", 1, 0.28, (0.0, 1.76, 1.78)),
        mat_prefix,
        "flame_outer",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_flame_main", 5, 0.28, 0.02, 0.78, (0.0, 1.78, 2.08)),
        mat_prefix,
        "flame_outer",
        pal,
    )
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_flame_side_{side_idx}",
                4,
                0.14,
                0.01,
                0.48,
                (sx * 0.16, 1.80, 1.94),
                (math.radians(10), math.radians(sx * 24), 0.0),
            ),
            mat_prefix,
            "flame_outer",
            pal,
        )
    _add_part(
        parts,
        create_cone("_tmp_flame_core", 4, 0.18, 0.02, 0.56, (0.0, 1.72, 1.98)),
        mat_prefix,
        "flame_core",
        pal,
    )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """
    Gera lado a lado os 5 modelos do 005. Flareclaw (Charmeleon):
      1. Shiny (1.0x) | 2. Normal (1.0x) | 3. Grande (1.35x) | 4. Gigante (1.85x) | 5. Dourada Super Rara (2.25x)
    """
    build_flareclaw("Flareclaw_Shiny", location=(-7.0, 0.0, 0.0), scale=CONFIG["scales"]["Shiny"], variant="Shiny")
    build_flareclaw("Flareclaw_Normal", location=(-4.1, 0.0, 0.0), scale=CONFIG["scales"]["Normal"], variant="Normal")
    build_flareclaw("Flareclaw_Grande", location=(-0.9, 0.0, 0.0), scale=CONFIG["scales"]["Grande"], variant="Normal")
    build_flareclaw("Flareclaw_Gigante", location=(3.1, 0.0, 0.0), scale=CONFIG["scales"]["Gigante"], variant="Normal")
    build_flareclaw(
        "Flareclaw_Dourada_SuperRara",
        location=(8.5, 0.0, 0.0),
        scale=CONFIG["scales"]["DouradaSuperRara"],
        variant="DouradaSuperRara",
    )


if __name__ == "__main__":
    generate_variations()
    print("005. Flareclaw (5 variações: Shiny, Normal, Grande, Gigante e Dourada Super Rara) gerado com sucesso!")
