"""
014_Ambercocoon_Kakuna_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "014. Ambercocoon — Casulo Âmbar (Ref: Kakuna)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Ambercocoon_Shiny (1.0x - Paleta Shiny / Shyne Verde-Lima Luminoso)
  2. Ambercocoon_Normal (1.0x - Armadura Âmbar-Dourada + Braços-Foice Cruzados + Gravata Vermelha)
  3. Ambercocoon_Grande (1.35x - Normal)
  4. Ambercocoon_Gigante (1.85x - Normal)
  5. Ambercocoon_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 6 lados, cilindros 6 lados)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Ponta inferior alinhada exatamente em `Z = 0.0` e frente do escudo apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Ambercocoon_Shiny`, `Ambercocoon_Normal`, `Ambercocoon_Grande`,
     `Ambercocoon_Gigante`, `Ambercocoon_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "shell_amber": (0.94, 0.78, 0.24, 1.0),
        "shield_ochre": (0.76, 0.56, 0.14, 1.0),
        "tie_crimson": (0.82, 0.22, 0.26, 1.0),
        "eye_dark": (0.10, 0.10, 0.14, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
    },
    "shiny_palette": {
        "shell_amber": (0.48, 0.88, 0.26, 1.0),
        "shield_ochre": (0.34, 0.68, 0.16, 1.0),
        "tie_crimson": (0.92, 0.28, 0.34, 1.0),
        "eye_dark": (0.08, 0.12, 0.10, 1.0),
        "eye_white": (0.98, 0.99, 0.97, 1.0),
    },
    "golden_super_rare_palette": {
        "shell_amber": (1.00, 0.84, 0.16, 1.0),
        "shield_ochre": (0.82, 0.58, 0.08, 1.0),
        "tie_crimson": (1.00, 0.95, 0.56, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.90, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base do cone inferior em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_ambercocoon(
    name: str = "Ambercocoon_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 014. Ambercocoon (Ref: Kakuna):
      - Frente apontando para -Y e base da cauda em Z = 0.0
      - Corpo torpedo blindado em âmbar dourado com placas dorsais escalonadas
      - Dois braços-foice cruzados em diagonal no escudo frontal (-Y) e "gravata" rubi
      - Capacete pontiagudo com visor escuro angular e olhos brancos estreitos
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Amber_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Amber_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Amber"

    parts = []

    # 1. CAUDA AFUNILADA + CORPO TORPEDO BLINDADO
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_cone",
            6,
            0.14,
            0.46,
            0.78,
            (0.0, 0.06, 0.39),
            rotation=(math.radians(8.0), 0.0, 0.0),
        ),
        mat_prefix,
        "shell_amber",
        pal,
    )
    _add_part(parts, create_cube("_tmp_lower_body", (0.88, 0.80, 0.54), (0.0, 0.04, 0.92)), mat_prefix, "shell_amber", pal)
    _add_part(parts, create_cube("_tmp_upper_body", (0.98, 0.86, 0.62), (0.0, 0.00, 1.44)), mat_prefix, "shell_amber", pal)

    # Placas de armadura dorsal (+Y) com juntas ocre
    for idx, (dz, dy, sx, sz) in enumerate([(0.66, 0.38, 0.72, 0.24), (1.06, 0.42, 0.84, 0.30), (1.50, 0.42, 0.88, 0.32)]):
        _add_part(
            parts,
            create_cube(f"_tmp_dorsal_seam_{idx}", (sx, 0.20, 0.07), (0.0, dy, dz)),
            mat_prefix,
            "shield_ochre",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_dorsal_plate_{idx}", (sx * 0.94, 0.18, sz), (0.0, dy + 0.03, dz + sz * 0.5)),
            mat_prefix,
            "shell_amber",
            pal,
        )

    # 2. ESCUDO PEITORAL, GRAVATA RUBI E BRAÇOS-FOICE CRUZADOS EM -Y
    _add_part(parts, create_cube("_tmp_chest_shield", (0.68, 0.26, 0.68), (0.0, -0.36, 1.24)), mat_prefix, "shield_ochre", pal)
    _add_part(parts, create_cube("_tmp_chest_tie_top", (0.20, 0.12, 0.20), (0.0, -0.49, 1.44)), mat_prefix, "tie_crimson", pal)
    _add_part(parts, create_cube("_tmp_chest_tie_mid", (0.14, 0.14, 0.34), (0.0, -0.50, 1.24)), mat_prefix, "tie_crimson", pal)

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_arm_upper_{tag}",
                (0.24, 0.32, 0.48),
                (side * 0.44, -0.26, 1.32),
                rotation=(math.radians(-16.0), math.radians(side * -18.0), 0.0),
            ),
            mat_prefix,
            "shield_ochre",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_scythe_blade_{tag}",
                4,
                0.15,
                0.03,
                0.56,
                (side * 0.26, -0.46, 0.98),
                rotation=(math.radians(-22.0), math.radians(side * 44.0), math.radians(side * -18.0)),
            ),
            mat_prefix,
            "shell_amber",
            pal,
        )

    # 3. CABEÇA PONTIAGUDA + OLHOS SEVEROS COM MOLDURA ESCURA
    _add_part(
        parts,
        create_cone("_tmp_head_dome", 6, 0.56, 0.30, 0.58, (0.0, -0.06, 1.98), rotation=(math.radians(-10.0), 0.0, 0.0)),
        mat_prefix,
        "shell_amber",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_head_apex", 6, 0.28, 0.05, 0.36, (0.0, -0.10, 2.38), rotation=(math.radians(-14.0), 0.0, 0.0)),
        mat_prefix,
        "shell_amber",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_brow_ridge", (0.78, 0.30, 0.14), (0.0, -0.44, 1.88), rotation=(math.radians(-16.0), 0.0, 0.0)),
        mat_prefix,
        "shield_ochre",
        pal,
    )

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_frame_{tag}",
                (0.26, 0.12, 0.22),
                (side * 0.22, -0.48, 1.72),
                rotation=(0.0, math.radians(side * 16.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_white_{tag}",
                (0.14, 0.12, 0.11),
                (side * 0.24, -0.51, 1.72),
                rotation=(0.0, math.radians(side * 16.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 014. Ambercocoon lado a lado."""
    specs = [
        ("Ambercocoon_Shiny", (-5.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Ambercocoon_Normal", (-3.3, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Ambercocoon_Grande", (-0.7, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Ambercocoon_Gigante", (2.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Ambercocoon_Dourada_SuperRara", (6.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_ambercocoon(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
