"""
074_Bouldefist_Geodude_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "074. Bouldefist — Rocha Flutuante (Ref: Geodude)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Bouldefist_Shiny (1.0x - Paleta Shiny Rocha Âmbar-Ocre Metálico)
  2. Bouldefist_Normal (1.0x - Rocha Cinza-Pedra + Sobrancelhas em V + 2 Braços Musculosos com Punhos)
  3. Bouldefist_Grande (1.35x - Normal)
  4. Bouldefist_Gigante (1.85x - Normal)
  5. Bouldefist_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Juntas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada rochosa (icospheres subdiv=1 e 2 para rocha angular, cones/cilindros musculosos)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base rochosa alinhada exatamente em `Z = 0.0` e rosto/punhos apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "rock_main": (0.64, 0.62, 0.58, 1.0),
        "rock_light": (0.74, 0.72, 0.68, 1.0),
        "rock_dark": (0.46, 0.44, 0.42, 1.0),
        "mouth_line": (0.24, 0.22, 0.22, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "iris_brown": (0.38, 0.24, 0.14, 1.0),
        "pupil_dark": (0.10, 0.10, 0.12, 1.0),
    },
    "shiny_palette": {
        "rock_main": (0.86, 0.66, 0.22, 1.0),
        "rock_light": (0.96, 0.78, 0.34, 1.0),
        "rock_dark": (0.62, 0.44, 0.12, 1.0),
        "mouth_line": (0.28, 0.18, 0.06, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "iris_brown": (0.38, 0.24, 0.14, 1.0),
        "pupil_dark": (0.10, 0.10, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "rock_main": (0.98, 0.78, 0.14, 1.0),
        "rock_light": (1.00, 0.90, 0.38, 1.0),
        "rock_dark": (0.80, 0.58, 0.08, 1.0),
        "mouth_line": (0.44, 0.30, 0.04, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "iris_brown": (0.06, 0.68, 0.84, 1.0),
        "pupil_dark": (0.04, 0.32, 0.48, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_segment(parts: list, name: str, p0: tuple, p1: tuple, r0: float, r1: float, mat_prefix: str, mat_key: str, pal: dict, verts: int = 7):
    dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    if length < 1e-5:
        return None
    mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
    phi = math.atan2(dx, -dy)
    theta = math.acos(max(-1.0, min(1.0, dz / length)))
    obj = create_cone(name, verts, r0, r1, length + 0.05, mid, rotation=(theta, 0.0, phi))
    return _add_part(parts, obj, mat_prefix, mat_key, pal)


def build_bouldefist(
    name: str = "Bouldefist_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 074. Bouldefist (Ref: Geodude):
      - Corpo-cabeça esférico rochoso irregular e facetado com arestas minerais proeminentes
      - Sobrancelhas grossas de pedra em V feroz sobre olhos brancos decididos e boca serrada
      - Dois longos braços rochosos musculosos (bíceps + antebraços) erguidos em pose de força
      - Dois punhos cerrados grandes com 4 dedos + polegar destacados em cada mão
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Bould_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Bould_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Bould_Norm"

    parts = []

    # 1. CORPO ROCHOSO IRREGULAR FACETADO (PEDREGULHO ANGULAR FIEL À REFERÊNCIA)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_boulder_core",
            2,
            0.70,
            (0.0, 0.04, 0.72),
            rotation=(math.radians(8.0), math.radians(12.0), math.radians(15.0)),
            scale=(1.08, 0.96, 0.94),
        ),
        mat_prefix,
        "rock_main",
        pal,
    )
    # Facetas angulares extras de rocha (crânio, queixo e laterais)
    rock_facets = [
        (0.42, (0.34, 0.08, 1.06), (1.08, 0.92, 0.86), "rock_light"),
        (0.38, (-0.36, 0.12, 1.00), (0.98, 0.90, 0.88), "rock_main"),
        (0.36, (0.02, 0.24, 1.12), (1.16, 0.84, 0.76), "rock_light"),
        (0.46, (0.00, -0.06, 0.48), (1.24, 0.98, 0.60), "rock_dark"),
        (0.34, (-0.48, -0.04, 0.62), (0.86, 0.88, 0.94), "rock_dark"),
        (0.36, (0.48, -0.02, 0.66), (0.88, 0.86, 0.92), "rock_dark"),
    ]
    for r_idx, (rad, loc, sc, m_key) in enumerate(rock_facets):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_rock_chunk_{r_idx}",
                1,
                rad,
                loc,
                rotation=(math.radians(r_idx * 22.0), math.radians(r_idx * 17.0), 0.0),
                scale=sc,
            ),
            mat_prefix,
            m_key,
            pal,
        )

    # 2. ROSTO DETERMINADO (SOBRANCELHAS DE PEDRA EM V + OLHOS BRANCOS + MANDÍBULA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Sobrancelha rochosa grossa descendo em V para o centro
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.40, 0.22, 0.14),
                (side * 0.24, -0.58, 0.94),
                rotation=(math.radians(10.0), math.radians(side * -24.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "rock_light",
            pal,
        )
        # Esclera branca firme
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_white_{tag}",
                (0.28, 0.12, 0.17),
                (side * 0.25, -0.60, 0.78),
                rotation=(0.0, math.radians(side * -10.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Íris marrom + pupila escura
        _add_part(
            parts,
            create_cube(
                f"_tmp_iris_{tag}",
                (0.10, 0.08, 0.15),
                (side * 0.21, -0.64, 0.78),
                rotation=(0.0, 0.0, math.radians(side * -12.0)),
            ),
            mat_prefix,
            "iris_brown",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_pupil_{tag}",
                (0.055, 0.07, 0.11),
                (side * 0.20, -0.66, 0.78),
                rotation=(0.0, 0.0, math.radians(side * -12.0)),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # Linha firme da boca fechada / fenda rochosa do queixo
    _add_part(
        parts,
        create_cube(
            "_tmp_mouth_crevice_L",
            (0.32, 0.10, 0.055),
            (-0.15, -0.64, 0.56),
            rotation=(0.0, math.radians(-10.0), math.radians(-10.0)),
        ),
        mat_prefix,
        "mouth_line",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_mouth_crevice_R",
            (0.32, 0.10, 0.055),
            (0.15, -0.64, 0.56),
            rotation=(0.0, math.radians(10.0), math.radians(10.0)),
        ),
        mat_prefix,
        "mouth_line",
        pal,
    )

    # 3. DOIS BRAÇOS ROCHOSOS MUSCULOSOS ERGUIDOS COM PUNHOS CERRADOS GRANDES
    arm_configs = [
        # (tag, side, shoulder, elbow, wrist, fist_center)
        ("L", -1.0, (-0.64, 0.02, 0.66), (-1.22, -0.06, 0.52), (-1.56, -0.22, 1.02), (-1.50, -0.26, 1.18)),
        ("R", 1.0, (0.64, 0.02, 0.68), (1.26, -0.04, 0.66), (1.58, -0.22, 1.06), (1.50, -0.26, 1.22)),
    ]
    for tag, side, sh, el, wr, fist in arm_configs:
        # Ombro rochoso
        _add_part(parts, create_icosphere(f"_tmp_shoulder_{tag}", 1, 0.19, sh, scale=(1.15, 0.95, 0.92)), mat_prefix, "rock_main", pal)
        # Bíceps musculoso
        _add_segment(parts, f"_tmp_upper_arm_{tag}", sh, el, 0.14, 0.16, mat_prefix, "rock_main", pal, verts=7)
        bicep_mid = ((sh[0] + el[0]) * 0.5, (sh[1] + el[1]) * 0.5 - 0.02, (sh[2] + el[2]) * 0.5 + 0.08)
        _add_part(parts, create_icosphere(f"_tmp_bicep_{tag}", 1, 0.19, bicep_mid, scale=(1.16, 0.90, 0.94)), mat_prefix, "rock_light", pal)
        # Cotovelo
        _add_part(parts, create_icosphere(f"_tmp_elbow_{tag}", 1, 0.16, el), mat_prefix, "rock_dark", pal)
        # Antebraço robusto alargando até o punho
        _add_segment(parts, f"_tmp_forearm_{tag}", el, wr, 0.15, 0.22, mat_prefix, "rock_main", pal, verts=7)
        # Palma do punho cerrado
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_fist_palm_{tag}",
                2,
                0.28,
                fist,
                rotation=(math.radians(10.0), math.radians(side * -14.0), 0.0),
                scale=(1.12, 0.96, 1.04),
            ),
            mat_prefix,
            "rock_light",
            pal,
        )
        # 4 dedos dobrados em bloco no topo do punho
        for f_i, offset_x in enumerate([-0.15, -0.05, 0.05, 0.15]):
            _add_part(
                parts,
                create_cube(
                    f"_tmp_knuckle_{tag}_{f_i}",
                    (0.11, 0.24, 0.20),
                    (fist[0] + side * offset_x, fist[1] - 0.14, fist[2] + 0.11 - abs(offset_x) * 0.18),
                    rotation=(math.radians(14.0), 0.0, math.radians(side * -10.0)),
                ),
                mat_prefix,
                "rock_main",
                pal,
            )
        # Polegar dobrado na lateral interna do punho
        _add_part(
            parts,
            create_cube(
                f"_tmp_thumb_{tag}",
                (0.18, 0.16, 0.14),
                (fist[0] - side * 0.20, fist[1] - 0.18, fist[2] - 0.04),
                rotation=(math.radians(10.0), math.radians(side * 18.0), math.radians(side * 16.0)),
            ),
            mat_prefix,
            "rock_light",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 074. Bouldefist lado a lado."""
    specs = [
        ("Bouldefist_Shiny", (-11.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Bouldefist_Normal", (-6.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Bouldefist_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Bouldefist_Gigante", (6.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Bouldefist_Dourada_SuperRara", (16.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_bouldefist(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
