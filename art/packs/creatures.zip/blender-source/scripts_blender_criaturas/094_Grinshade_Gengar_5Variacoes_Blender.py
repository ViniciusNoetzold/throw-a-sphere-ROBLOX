"""
094_Grinshade_Gengar_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "094. Grinshade — Sombra Sorridente (Ref: Gengar)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Grinshade_Shiny (1.0x - Paleta Shiny Cinza-Carvão Espectral + Olhos Carmesim-Vivo)
  2. Grinshade_Normal (1.0x - Corpo Roxo-Ameixa Arredondado + Olhos Vermelhos + Enorme Sorriso Branco)
  3. Grinshade_Grande (1.35x - Normal)
  4. Grinshade_Gigante (1.85x - Normal)
  5. Grinshade_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante + Sorriso Reluzente)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para silhueta atarracada arredondada; cones para orelhas e cristas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas apoiadas exatamente em `Z = 0.0` e enorme sorriso apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_plum": (0.45, 0.35, 0.64, 1.0),
        "body_shade": (0.31, 0.23, 0.48, 1.0),
        "eye_red": (0.94, 0.34, 0.34, 1.0),
        "pupil_dark": (0.08, 0.06, 0.10, 1.0),
        "grin_white": (0.97, 0.98, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_plum": (0.28, 0.29, 0.36, 1.0),
        "body_shade": (0.18, 0.19, 0.25, 1.0),
        "eye_red": (0.98, 0.18, 0.34, 1.0),
        "pupil_dark": (0.05, 0.05, 0.08, 1.0),
        "grin_white": (0.98, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_plum": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.80, 0.56, 0.08, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.26, 0.42, 1.0),
        "grin_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_grinshade(
    name: str = "Grinshade_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 094. Grinshade (Ref: Gengar):
      - Corpo atarracado arredondado roxo-ameixa unindo cabeça e barriga numa silhueta icônica
      - 2 grandes orelhas pontudas triangulares + topete espetado no alto da cabeça + crista dorsal nas costas
      - Olhos vermelhos malignos inclinados com pupilas verticais finas
      - Enorme sorriso branco largo em meia-lua com linhas verticais de dentes
      - Braços curtos com 3 dedinhos espetados, pernas robustas com 3 garras em Z=0 e cauda cônica curta
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Gri_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Gri_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Gri_Norm"

    parts = []

    # 1. CORPO UNIFICADO ATARRACADO E ARREDONDADO (SILHUETA CLÁSSICA DO GENGAR)
    _add_part(
        parts,
        create_icosphere("_tmp_body_main", 2, 0.90, (0.0, 0.02, 1.12), scale=(1.08, 0.96, 1.02)),
        mat_prefix,
        "body_plum",
        pal,
    )
    # Barriga inferior mais larga e arredondada
    _add_part(
        parts,
        create_icosphere("_tmp_belly_wide", 2, 0.80, (0.0, -0.04, 0.86), scale=(1.14, 0.98, 0.84)),
        mat_prefix,
        "body_plum",
        pal,
    )

    # 2. GRANDES ORELHAS PONTUDAS + TOPETE ESPETADO + CRISTA DORSAL NAS COSTAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{tag}",
                6,
                0.38,
                0.028,
                0.92,
                (side * 0.78, 0.02, 1.94),
                rotation=(math.radians(-6.0), math.radians(side * 38.0), 0.0),
                scale=(1.0, 0.68, 1.0),
            ),
            mat_prefix,
            "body_plum",
            pal,
        )

    # Topete espetado entre as orelhas (5 pontas irregulares como na referência)
    crest_specs = [
        ((-0.24, 0.04, 2.04), 0.14, 0.34, -18.0),
        ((-0.08, 0.04, 2.12), 0.16, 0.42, -8.0),
        ((0.08, 0.05, 2.16), 0.18, 0.48, 8.0),
        ((0.24, 0.05, 2.06), 0.14, 0.36, 20.0),
    ]
    for c_idx, (loc, r1, dp, ry_deg) in enumerate(crest_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_tuft_{c_idx}",
                5,
                r1,
                0.02,
                dp,
                loc,
                rotation=(math.radians(-10.0), math.radians(ry_deg), 0.0),
                scale=(1.0, 0.72, 1.0),
            ),
            mat_prefix,
            "body_plum",
            pal,
        )

    # Espinhos dorsais descendo pelas costas
    for b_idx, (by, bz, dp) in enumerate([(0.72, 1.72, 0.42), (0.86, 1.38, 0.46), (0.88, 1.04, 0.42), (0.80, 0.72, 0.34)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_back_spike_{b_idx}",
                5,
                0.18,
                0.022,
                dp,
                (0.0, by, bz),
                rotation=(math.radians(-68.0 - b_idx * 10.0), 0.0, 0.0),
                scale=(0.76, 1.0, 1.0),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )

    # 3. OLHOS VERMELHOS MALIGNOS INCLINADOS + PUPILAS VERTICAIS FINAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.23,
                (side * 0.34, -0.78, 1.34),
                rotation=(math.radians(4.0), math.radians(side * -24.0), math.radians(side * -20.0)),
                scale=(1.14, 0.40, 0.74),
            ),
            mat_prefix,
            "eye_red",
            pal,
        )
        # Sobrancelha furiosa cortando o topo interno do olho
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.46, 0.22, 0.14),
                (side * 0.32, -0.79, 1.47),
                rotation=(math.radians(4.0), math.radians(side * -26.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "body_plum",
            pal,
        )
        # Pupila vertical fina
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.045,
                (side * 0.28, -0.88, 1.33),
                scale=(0.50, 0.45, 1.48),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 4. ENORME SORRISO BRANCO LARGO EM MEIA-LUA COM LINHAS DE DENTES (BEM DESTACADO À FRENTE!)
    # Base branca contínua em arco crescente abraçando a frente do rosto
    tooth_arc = [
        (-0.50, -0.74, 1.08, 0.0, 38.0, 0.16, 0.16),
        (-0.35, -0.84, 0.99, 0.0, 26.0, 0.18, 0.21),
        (-0.18, -0.90, 0.94, 0.0, 12.0, 0.19, 0.24),
        (0.00, -0.92, 0.92, 0.0, 0.0, 0.20, 0.25),
        (0.18, -0.90, 0.94, 0.0, -12.0, 0.19, 0.24),
        (0.35, -0.84, 0.99, 0.0, -26.0, 0.18, 0.21),
        (0.50, -0.74, 1.08, 0.0, -38.0, 0.16, 0.16),
    ]
    for t_idx, (tx, ty, tz, rx_deg, rz_deg, tw, th) in enumerate(tooth_arc):
        _add_part(
            parts,
            create_cube(
                f"_tmp_grin_tooth_{t_idx}",
                (tw, 0.12, th),
                (tx, ty, tz),
                rotation=(math.radians(8.0 + rx_deg), 0.0, math.radians(rz_deg)),
            ),
            mat_prefix,
            "grin_white",
            pal,
        )
    # Linhas verticais finas escuras separando os dentes largos do sorriso
    div_arc = [
        (-0.42, -0.81, 1.03, 32.0, 0.19),
        (-0.26, -0.89, 0.96, 18.0, 0.23),
        (-0.09, -0.93, 0.93, 6.0, 0.25),
        (0.09, -0.93, 0.93, -6.0, 0.25),
        (0.26, -0.89, 0.96, -18.0, 0.23),
        (0.42, -0.81, 1.03, -32.0, 0.19),
    ]
    for d_idx, (dx, dy, dz, rz_deg, dh) in enumerate(div_arc):
        _add_part(
            parts,
            create_cube(
                f"_tmp_grin_div_{d_idx}",
                (0.022, 0.135, dh),
                (dx, dy, dz),
                rotation=(math.radians(8.0), 0.0, math.radians(rz_deg)),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )
    # Borda inferior fina escura acompanhando a base do sorriso
    for b_idx, (bx, by, bz, rz_deg) in enumerate([(-0.34, -0.84, 0.88, 24.0), (0.0, -0.93, 0.80, 0.0), (0.34, -0.84, 0.88, -24.0)]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_grin_bot_line_{b_idx}",
                (0.36, 0.12, 0.028),
                (bx, by, bz),
                rotation=(math.radians(8.0), 0.0, math.radians(rz_deg)),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )
    # Lábio superior curvo roxo modelando o topo em arco do sorriso
    _add_part(
        parts,
        create_icosphere(
            "_tmp_upper_lip_mask",
            2,
            0.46,
            (0.0, -0.82, 1.18),
            scale=(1.22, 0.34, 0.30),
        ),
        mat_prefix,
        "body_plum",
        pal,
    )

    # 5. BRAÇOS CURTOS E ABERTOS COM 3 DEDINHOS ESPETADOS
    arm_specs = [
        ("L", -1.0, (-1.04, -0.06, 1.28), (-8.0, -54.0, 0.0), (-1.28, -0.10, 1.46)),
        ("R", 1.0, (1.04, -0.06, 1.08), (-8.0, 74.0, 0.0), (1.30, -0.10, 1.16)),
    ]
    for tag, side, a_loc, a_rot, h_loc in arm_specs:
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_{tag}",
                8,
                0.30,
                0.18,
                0.68,
                a_loc,
                rotation=tuple(math.radians(a) for a in a_rot),
                scale=(1.0, 0.88, 1.0),
            ),
            mat_prefix,
            "body_plum",
            pal,
        )
        hx, hy, hz = h_loc
        for f_idx, (dfz, dfy_rot) in enumerate([(0.12, side * 42.0), (0.0, side * 66.0), (-0.11, side * 90.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_finger_{tag}_{f_idx}",
                    5,
                    0.072,
                    0.015,
                    0.24,
                    (hx + side * 0.06, hy, hz + dfz),
                    rotation=(0.0, math.radians(dfy_rot), 0.0),
                ),
                mat_prefix,
                "body_plum",
                pal,
            )

    # 6. PERNAS ROBUSTAS CURTAS COM 3 DEDINHOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.36,
                (side * 0.54, -0.12, 0.42),
                scale=(0.94, 1.12, 0.96),
            ),
            mat_prefix,
            "body_plum",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_foot_{tag}",
                8,
                0.22,
                0.28,
                0.30,
                (side * 0.56, -0.18, 0.16),
                scale=(1.0, 1.24, 1.0),
            ),
            mat_prefix,
            "body_plum",
            pal,
        )
        for t_idx, tx_off in enumerate([-0.12, 0.0, 0.12]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_toe_{tag}_{t_idx}",
                    5,
                    0.072,
                    0.018,
                    0.18,
                    (side * 0.56 + tx_off, -0.40, 0.08),
                    rotation=(math.radians(84.0), 0.0, math.radians(-tx_off * 90.0)),
                ),
                mat_prefix,
                "body_shade",
                pal,
            )

    # 7. CAUDA CURTA PONTUDA NA TRASEIRA INFERIOR
    _add_part(
        parts,
        create_cone(
            "_tmp_tail",
            7,
            0.28,
            0.032,
            0.64,
            (0.0, 0.90, 0.36),
            rotation=(math.radians(-108.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 094. Grinshade lado a lado."""
    specs = [
        ("Grinshade_Shiny", (-11.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Grinshade_Normal", (-6.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Grinshade_Grande", (-2.0, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Grinshade_Gigante", (3.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Grinshade_Dourada_SuperRara", (11.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_grinshade(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
