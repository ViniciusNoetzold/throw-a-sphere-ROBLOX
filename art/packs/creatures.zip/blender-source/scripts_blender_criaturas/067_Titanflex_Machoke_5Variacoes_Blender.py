"""
067_Titanflex_Machoke_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "067. Titanflex — Lutador Cinturão (Ref: Machoke)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Titanflex_Shiny (1.0x - Paleta Shiny Verde-Hulk + Listras Vermelhas + Cinturão Ouro)
  2. Titanflex_Normal (1.0x - Cinza-Azulado Musculoso + Listras Vermelhas nos Braços + Cinturão Campeão)
  3. Titanflex_Grande (1.35x - Normal)
  4. Titanflex_Gigante (1.85x - Normal)
  5. Titanflex_Dourada_SuperRara (2.25x - Ouro Reluzente + Listras, Cristas e Emblema Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2, cones/cilindros 6-8 lados)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés largos de 5 dedos alinhados exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_skin": (0.64, 0.68, 0.78, 1.0),
        "body_shade": (0.50, 0.54, 0.64, 1.0),
        "crest_tan": (0.74, 0.72, 0.70, 1.0),
        "stripe_red": (0.88, 0.32, 0.34, 1.0),
        "trunks_black": (0.18, 0.17, 0.22, 1.0),
        "belt_gold": (0.94, 0.82, 0.30, 1.0),
        "mouth_pink": (0.78, 0.54, 0.62, 1.0),
        "white": (0.98, 0.98, 0.99, 1.0),
        "dark": (0.12, 0.12, 0.15, 1.0),
    },
    "shiny_palette": {
        "body_skin": (0.46, 0.72, 0.36, 1.0),
        "body_shade": (0.34, 0.56, 0.26, 1.0),
        "crest_tan": (0.66, 0.70, 0.50, 1.0),
        "stripe_red": (0.90, 0.30, 0.32, 1.0),
        "trunks_black": (0.16, 0.18, 0.20, 1.0),
        "belt_gold": (0.96, 0.84, 0.30, 1.0),
        "mouth_pink": (0.82, 0.54, 0.60, 1.0),
        "white": (0.98, 0.98, 0.99, 1.0),
        "dark": (0.12, 0.14, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "body_skin": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.62, 0.10, 1.0),
        "crest_tan": (0.10, 0.92, 1.00, 1.0),
        "stripe_red": (0.10, 0.92, 1.00, 1.0),
        "trunks_black": (0.12, 0.14, 0.20, 1.0),
        "belt_gold": (1.00, 0.92, 0.44, 1.0),
        "mouth_pink": (0.92, 0.74, 0.24, 1.0),
        "white": (1.00, 0.99, 0.92, 1.0),
        "dark": (0.06, 0.56, 0.72, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_segment(
    name: str,
    p1: tuple,
    p2: tuple,
    r1: float,
    r2: float,
    vertices: int = 8,
    extend: float = 1.05,
):
    """Cria um cone/segmento conectando exatamente p1 -> p2 sem folgas."""
    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    dz = p2[2] - p1[2]
    dist = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dist < 1e-6:
        dist = 1e-6
    mid = ((p1[0] + p2[0]) * 0.5, (p1[1] + p2[1]) * 0.5, (p1[2] + p2[2]) * 0.5)
    theta = math.acos(max(-1.0, min(1.0, dz / dist)))
    phi = math.atan2(dy, dx)
    return create_cone(
        name=name,
        vertices=vertices,
        radius1=r1,
        radius2=r2,
        depth=dist * extend,
        location=mid,
        rotation=(0.0, theta, phi),
    )


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha os pés em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_titanflex(
    name: str = "Titanflex_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 067. Titanflex (Ref: Machoke):
      - Fisiculturista reptiliano hiper-musculoso em pose de flexão de bíceps/peitoral
      - Calção preto de lutador + cinturão de campeão preto com grande fivela redonda dourada
        e emblema vermelho 'P' bem visível no centro
      - Braços colossais com 3 listras vermelhas musculares nos bíceps e nos antebraços
      - Cabeça reptiliana com focinho robusto, presinhas brancas, olhos rubi cerrados e 3 cristas
      - Pernas grossas em base de luta firme com pés largos em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Titanflex_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Titanflex_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Titanflex_Norm"

    parts = []

    # 1. CALÇÃO PRETO + CINTURÃO DE CAMPEÃO COM FIVELA DOURADA E EMBLEMA 'P'
    _add_part(
        parts,
        create_icosphere("_tmp_trunks", 2, 0.44, (0.0, 0.00, 1.02), scale=(1.08, 0.88, 0.88)),
        mat_prefix,
        "trunks_black",
        pal,
    )
    # Faixa preta do cinturão
    _add_part(
        parts,
        create_cylinder("_tmp_belt_strap", 10, 0.46, 0.24, (0.0, -0.01, 1.24), scale=(1.06, 0.86, 1.0)),
        mat_prefix,
        "trunks_black",
        pal,
    )
    # Grande fivela redonda dourada frontal + anel interno
    _add_part(
        parts,
        create_cylinder(
            "_tmp_belt_buckle_outer",
            10,
            0.26,
            0.09,
            (0.0, -0.39, 1.24),
            rotation=(math.radians(90.0), 0.0, 0.0),
        ),
        mat_prefix,
        "belt_gold",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_belt_buckle_mid",
            10,
            0.16,
            0.11,
            (0.0, -0.40, 1.24),
            rotation=(math.radians(90.0), 0.0, 0.0),
        ),
        mat_prefix,
        "belt_gold",
        pal,
    )
    # Emblema vermelho 'P' na fivela (haste + arco)
    _add_part(
        parts,
        create_cube("_tmp_emblem_p_stem", (0.045, 0.05, 0.14), (-0.03, -0.45, 1.26)),
        mat_prefix,
        "stripe_red",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_emblem_p_loop", 1, 0.055, (0.015, -0.45, 1.30), scale=(1.05, 0.60, 0.85)),
        mat_prefix,
        "stripe_red",
        pal,
    )
    # Tachas douradas laterais do cinturão
    for side in (-1.0, 1.0):
        _add_part(
            parts,
            create_icosphere(f"_tmp_belt_stud_{'L' if side < 0 else 'R'}", 1, 0.09, (side * 0.42, -0.24, 1.24)),
            mat_prefix,
            "belt_gold",
            pal,
        )

    # 2. TRONCO HIPER-MUSCULOSO EM 'V' (PEITORAIS, TRAPÉZIO E PESCOÇO GROSSO)
    _add_part(
        parts,
        create_icosphere("_tmp_torso_core", 2, 0.56, (0.0, 0.02, 1.66), scale=(1.22, 0.84, 1.00)),
        mat_prefix,
        "body_skin",
        pal,
    )
    # Peitorais esculpidos proeminentes
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pec_{tag}",
                2,
                0.36,
                (side * 0.32, -0.24, 1.72),
                scale=(1.12, 0.84, 0.86),
            ),
            mat_prefix,
            "body_skin",
            pal,
        )
        # Trapézio conectando ombros ao pescoço
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_trap_{tag}",
                2,
                0.28,
                (side * 0.34, 0.06, 2.02),
                scale=(1.18, 0.88, 0.78),
            ),
            mat_prefix,
            "body_skin",
            pal,
        )
    # Pescoço largo musculoso
    _add_part(
        parts,
        create_cylinder("_tmp_neck", 8, 0.34, 0.42, (0.0, 0.00, 2.16), scale=(1.08, 0.96, 1.0)),
        mat_prefix,
        "body_skin",
        pal,
    )

    # 3. CABEÇA REPTILIANA FEROZ + 3 CRISTAS + PRESAS BRANCAS + OLHOS RUBI
    _add_part(
        parts,
        create_icosphere("_tmp_head_cranium", 2, 0.38, (0.0, -0.04, 2.48), scale=(1.04, 1.10, 0.96)),
        mat_prefix,
        "body_skin",
        pal,
    )
    # Focinho superior e mandíbula inferior
    _add_part(
        parts,
        create_icosphere("_tmp_snout_upper", 2, 0.28, (0.0, -0.36, 2.46), scale=(1.08, 1.18, 0.64)),
        mat_prefix,
        "body_skin",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_jaw_lower", 2, 0.25, (0.0, -0.30, 2.26), scale=(1.04, 1.12, 0.56)),
        mat_prefix,
        "body_skin",
        pal,
    )
    # Boca semiaberta rosa + 2 pares de presas brancas
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_in", 1, 0.22, (0.0, -0.38, 2.35), scale=(1.10, 0.80, 0.32)),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    for f_idx, fx in enumerate((-0.14, 0.14)):
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_up_{f_idx}",
                4,
                0.036,
                0.008,
                0.09,
                (fx, -0.54, 2.36),
                rotation=(math.radians(180.0), 0.0, 0.0),
            ),
            mat_prefix,
            "white",
            pal,
        )
    # Sobrancelha severa + olhos rubi cerrados
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_brow_{tag}",
                1,
                0.13,
                (side * 0.22, -0.34, 2.62),
                rotation=(0.0, math.radians(side * 16.0), math.radians(side * -14.0)),
                scale=(1.25, 0.72, 0.44),
            ),
            mat_prefix,
            "body_skin",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_w_{tag}",
                1,
                0.095,
                (side * 0.22, -0.36, 2.55),
                scale=(1.15, 0.55, 0.62),
            ),
            mat_prefix,
            "white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_red_{tag}",
                1,
                0.068,
                (side * 0.22, -0.40, 2.55),
                scale=(0.86, 0.50, 0.88),
            ),
            mat_prefix,
            "stripe_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.032,
                (side * 0.22, -0.43, 2.55),
            ),
            mat_prefix,
            "dark",
            pal,
        )

    # 3 CRISTAS CINZA-BEGE NO TOPO DA CABEÇA
    for c_tag, cx, rad, cz in (("L", -0.14, 0.24, 2.82), ("C", 0.0, 0.28, 2.88), ("R", 0.14, 0.24, 2.82)):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_crest_{c_tag}",
                2,
                rad,
                (cx, 0.02, cz),
                rotation=(math.radians(-14.0), 0.0, 0.0),
                scale=(0.28, 1.38, 0.82),
            ),
            mat_prefix,
            "crest_tan",
            pal,
        )

    # 4. BRAÇOS GIGANTESCOS FLEXIONADOS COM 3 LISTRAS VERMELHAS NOS BÍCEPS E ANTEBRAÇOS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        p_sh = (side * 0.72, -0.02, 1.90)
        p_el = (side * 1.18, -0.14, 1.62)
        p_wr = (side * 0.96, -0.48, 1.32)
        # Deltoide volumoso
        _add_part(
            parts,
            create_icosphere(f"_tmp_delt_{tag}", 2, 0.34, p_sh, scale=(1.14, 0.98, 0.96)),
            mat_prefix,
            "body_skin",
            pal,
        )
        # Bíceps massivo
        _add_part(parts, create_segment(f"_tmp_bicep_{tag}", p_sh, p_el, 0.26, 0.24, vertices=8), mat_prefix, "body_skin", pal)
        _add_part(parts, create_icosphere(f"_tmp_elbow_{tag}", 2, 0.25, p_el), mat_prefix, "body_skin", pal)
        # Antebraço gigante
        _add_part(parts, create_segment(f"_tmp_forearm_{tag}", p_el, p_wr, 0.26, 0.22, vertices=8), mat_prefix, "body_skin", pal)

        # 3 LISTRAS VERMELHAS NO BÍCEPS (visíveis frontalmente)
        for s_idx, dz_off in enumerate((-0.09, 0.0, 0.09)):
            sp1 = (p_sh[0] + side * 0.08, p_sh[1] - 0.24, p_sh[2] - 0.04 + dz_off)
            sp2 = (p_el[0] - side * 0.04, p_el[1] - 0.24, p_el[2] + 0.06 + dz_off)
            _add_part(
                parts,
                create_segment(f"_tmp_bicep_stripe_{tag}_{s_idx}", sp1, sp2, 0.032, 0.022, vertices=5),
                mat_prefix,
                "stripe_red",
                pal,
            )
        # 3 LISTRAS VERMELHAS NO ANTEBRAÇO
        for s_idx, dx_off in enumerate((-0.10, 0.0, 0.10)):
            fp1 = (p_el[0] + dx_off, p_el[1] - 0.22, p_el[2] - 0.02)
            fp2 = (p_wr[0] + dx_off * 0.8, p_wr[1] - 0.18, p_wr[2] + 0.08)
            _add_part(
                parts,
                create_segment(f"_tmp_fore_stripe_{tag}_{s_idx}", fp1, fp2, 0.034, 0.020, vertices=5),
                mat_prefix,
                "stripe_red",
                pal,
            )

        # Punho gigante cerrado em flexão
        fist_c = (p_wr[0] - side * 0.08, p_wr[1] - 0.12, p_wr[2] - 0.08)
        _add_part(
            parts,
            create_icosphere(f"_tmp_fist_{tag}", 2, 0.26, fist_c, scale=(1.12, 1.02, 0.96)),
            mat_prefix,
            "body_skin",
            pal,
        )
        for k_idx, kx in enumerate((-0.14, -0.05, 0.05, 0.14)):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_knuckle_{tag}_{k_idx}",
                    1,
                    0.075,
                    (fist_c[0] + kx, fist_c[1] - 0.20, fist_c[2] - 0.06),
                ),
                mat_prefix,
                "body_skin",
                pal,
            )

    # 5. PERNAS COLOSSAIS EM BASE DE AGACHAMENTO FORTE E PÉS DE 5 DEDOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        p_hip = (side * 0.34, 0.00, 0.96)
        p_knee = (side * 0.72, -0.14, 0.56)
        p_ankle = (side * 0.76, -0.02, 0.16)
        _add_part(parts, create_segment(f"_tmp_thigh_{tag}", p_hip, p_knee, 0.28, 0.24, vertices=8), mat_prefix, "body_skin", pal)
        _add_part(parts, create_icosphere(f"_tmp_knee_{tag}", 2, 0.24, p_knee), mat_prefix, "body_skin", pal)
        _add_part(parts, create_segment(f"_tmp_calf_{tag}", p_knee, p_ankle, 0.23, 0.18, vertices=8), mat_prefix, "body_skin", pal)
        foot_c = (p_ankle[0] + side * 0.04, p_ankle[1] - 0.16, 0.11)
        _add_part(
            parts,
            create_icosphere(f"_tmp_foot_{tag}", 2, 0.22, foot_c, scale=(1.22, 1.44, 0.52)),
            mat_prefix,
            "body_skin",
            pal,
        )
        # 5 dedos curtos alinhados na frente do pé
        for t_idx, tx in enumerate((-0.18, -0.09, 0.0, 0.09, 0.18)):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_toe_{tag}_{t_idx}",
                    1,
                    0.064,
                    (foot_c[0] + tx, foot_c[1] - 0.28, 0.07),
                    scale=(0.88, 1.25, 0.78),
                ),
                mat_prefix,
                "body_skin",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 067. Titanflex lado a lado."""
    specs = [
        ("Titanflex_Shiny", (-12.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Titanflex_Normal", (-7.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Titanflex_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Titanflex_Gigante", (6.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Titanflex_Dourada_SuperRara", (16.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_titanflex(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
