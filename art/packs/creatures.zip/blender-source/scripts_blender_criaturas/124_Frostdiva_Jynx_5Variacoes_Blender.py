"""
124_Frostdiva_Jynx_5Variacoes_Blender.py
========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "124. Frostdiva — Diva Glacial (Ref: Jynx)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Frostdiva_Shiny (1.0x - Paleta Shiny Vestido Rosa-Choque / Magenta + Rosto Lilás + Cabelo Platina)
  2. Frostdiva_Normal (1.0x - Vestido Vermelho-Rubi + Busto Dourado + Rosto Roxo + Lábios Rosa + Cabelo Loiro)
  3. Frostdiva_Grande (1.35x - Normal)
  4. Frostdiva_Gigante (1.85x - Normal)
  5. Frostdiva_Dourada_SuperRara (2.25x - Ouro Reluzente + Cabelo e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para rosto, lábios, ombros e saia esvoaçante; cones 6-8 lados para vestido longo e mechas onduladas do cabelo loiro)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Barra do vestido alinhada exatamente em `Z = 0.0` e rosto/lábios apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "dress_red": (0.86, 0.24, 0.28, 1.0),
        "dress_shade": (0.68, 0.16, 0.22, 1.0),
        "trim_gold": (0.94, 0.84, 0.42, 1.0),
        "hair_blonde": (0.96, 0.90, 0.56, 1.0),
        "skin_purple": (0.44, 0.32, 0.56, 1.0),
        "lip_pink": (0.96, 0.62, 0.72, 1.0),
        "mouth_dark": (0.36, 0.16, 0.28, 1.0),
        "sleeve_white": (0.94, 0.95, 0.98, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.08, 0.08, 0.12, 1.0),
    },
    "shiny_palette": {
        "dress_red": (0.94, 0.30, 0.68, 1.0),
        "dress_shade": (0.76, 0.20, 0.54, 1.0),
        "trim_gold": (0.98, 0.88, 0.46, 1.0),
        "hair_blonde": (0.97, 0.95, 0.82, 1.0),
        "skin_purple": (0.64, 0.44, 0.78, 1.0),
        "lip_pink": (0.98, 0.64, 0.78, 1.0),
        "mouth_dark": (0.42, 0.16, 0.34, 1.0),
        "sleeve_white": (0.96, 0.96, 0.99, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.08, 0.08, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "dress_red": (0.98, 0.78, 0.14, 1.0),
        "dress_shade": (0.84, 0.60, 0.08, 1.0),
        "trim_gold": (1.00, 0.92, 0.52, 1.0),
        "hair_blonde": (0.10, 0.92, 1.00, 1.0),
        "skin_purple": (0.88, 0.66, 0.10, 1.0),
        "lip_pink": (1.00, 0.88, 0.42, 1.0),
        "mouth_dark": (0.44, 0.28, 0.04, 1.0),
        "sleeve_white": (1.00, 0.96, 0.72, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.04, 0.46, 0.64, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_frostdiva(
    name: str = "Frostdiva_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de 124. Frostdiva (Ref: Jynx):
      - Vestido longo de ópera vermelho-rubi largo na base com dobras esvoaçantes em Z = 0.0
      - Faixa dourada esculpida no busto com 2 medalhões rubi arredondados
      - Rosto oval roxo-violeta com olhos redondos brancos expressivos e grandes lábios rosados em "O"
      - Cabelo loiro-ouro volumoso partido ao meio caindo em longas camadas sobre os ombros e costas
      - Braços com mangas bufantes brancas abertos para os lados terminando em mãos roxas de 5 dedos
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Fdv_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Fdv_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Fdv_Norm"

    parts = []

    # 1. VESTIDO LONGO VERMELHO-RUBI ESCAÇADO COM BARRA ONDULADA EM Z = 0.0
    _add_part(
        parts,
        create_cone(
            "_tmp_dress_core",
            8,
            1.02,
            0.52,
            1.34,
            (0.0, 0.04, 0.67),
            scale=(1.14, 0.90, 1.0),
        ),
        mat_prefix,
        "dress_red",
        pal,
    )
    # Pregas frontais e laterais fluidas fluindo da cintura até a barra em Z = 0.0
    skirt_pleats = [
        # (x, y, z, rx, ry, r1_bot, r2_top, dep)
        (0.0, -0.40, 0.58, -14.0, 0.0, 0.36, 0.16, 1.14),
        (-0.56, -0.14, 0.56, -6.0, 18.0, 0.42, 0.16, 1.12),
        (0.56, -0.14, 0.56, -6.0, -18.0, 0.42, 0.16, 1.12),
        (-0.52, 0.28, 0.56, 12.0, 16.0, 0.40, 0.18, 1.12),
        (0.52, 0.28, 0.56, 12.0, -16.0, 0.40, 0.18, 1.12),
    ]
    for p_idx, (px, py, pz, rx, ry, r1, r2, dep) in enumerate(skirt_pleats):
        _add_part(
            parts,
            create_cone(
                f"_tmp_dress_pleat_{p_idx}",
                6,
                r1,
                r2,
                dep,
                (px, py, pz),
                rotation=(math.radians(rx), math.radians(ry), 0.0),
                scale=(1.0, 0.78, 1.0),
            ),
            mat_prefix,
            "dress_red",
            pal,
        )
    # Babado volumoso da barra frontal tocando o chão
    for h_idx, (hx, hy, rad) in enumerate([(-0.82, -0.14, 0.22), (-0.36, -0.46, 0.22), (0.0, -0.60, 0.24), (0.36, -0.46, 0.22), (0.82, -0.14, 0.22)]):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_dress_hem_{h_idx}",
                2,
                rad,
                (hx, hy, 0.14),
                scale=(1.32, 1.05, 0.62),
            ),
            mat_prefix,
            "dress_red",
            pal,
        )

    # 2. CORPETE DOURADO NO PEITO COM 2 MEDALHÕES RUBI (DETALHE ICÔNICO DA ÓPERA)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_bodice_gold_center",
            2,
            0.34,
            (0.0, -0.34, 1.32),
            scale=(1.42, 0.56, 0.82),
        ),
        mat_prefix,
        "trim_gold",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_bodice_ring_{tag}",
                2,
                0.28,
                (side * 0.28, -0.36, 1.32),
                scale=(1.04, 0.62, 0.96),
            ),
            mat_prefix,
            "trim_gold",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_bodice_medallion_{tag}",
                2,
                0.23,
                (side * 0.28, -0.44, 1.32),
                scale=(1.00, 0.52, 0.90),
            ),
            mat_prefix,
            "dress_red",
            pal,
        )

    # 3. CABEÇA ROXA OVAL + OLHOS REDONDOS EXPRESSIVOS + LÁBIOS GRANDES ROSADOS EM "O"
    _add_part(
        parts,
        create_icosphere(
            "_tmp_head_main",
            2,
            0.54,
            (0.0, -0.04, 1.88),
            scale=(1.00, 0.88, 1.08),
        ),
        mat_prefix,
        "skin_purple",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Olho branco grande bem redondo
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.13,
                (side * 0.20, -0.46, 2.02),
                scale=(0.94, 0.46, 1.02),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pupila preta central nítida
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.042,
                (side * 0.20, -0.52, 2.02),
                scale=(0.88, 0.42, 0.96),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Grandes lábios rosados ovais verticais + boca em "O" de cantora lírica
    _add_part(
        parts,
        create_icosphere(
            "_tmp_lips_outer",
            2,
            0.22,
            (0.0, -0.48, 1.76),
            scale=(0.82, 0.56, 1.12),
        ),
        mat_prefix,
        "lip_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_lips_center_o",
            1,
            0.095,
            (0.0, -0.58, 1.76),
            scale=(0.56, 0.42, 1.14),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )

    # 4. LONGOS CABELOS LOIROS ONDULADOS PARTIDOS AO MEIO EM CAMADAS VOLUMOSAS
    # Topo volumoso partido ao meio (2 arcos de cabelo sobre a testa)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hair_crown_{tag}",
                2,
                0.38,
                (side * 0.34, -0.02, 2.34),
                rotation=(0.0, math.radians(side * 22.0), 0.0),
                scale=(1.12, 1.02, 0.78),
            ),
            mat_prefix,
            "hair_blonde",
            pal,
        )
        # Longa mecha frontal enquadrando o rosto e o busto (larga no topo, afinando nas pontas!)
        _add_part(
            parts,
            create_cone(
                f"_tmp_hair_front_lock_{tag}",
                6,
                0.08,
                0.28,
                1.38,
                (side * 0.62, -0.12, 1.68),
                rotation=(math.radians(6.0), math.radians(side * 10.0), 0.0),
                scale=(0.82, 0.68, 1.0),
            ),
            mat_prefix,
            "hair_blonde",
            pal,
        )
        # Mecha externa mais larga caindo sobre os ombros e afinando em ponta delicada
        _add_part(
            parts,
            create_cone(
                f"_tmp_hair_outer_lock_{tag}",
                6,
                0.06,
                0.28,
                1.48,
                (side * 0.76, 0.06, 1.64),
                rotation=(math.radians(-6.0), math.radians(side * 14.0), 0.0),
                scale=(0.86, 0.78, 1.0),
            ),
            mat_prefix,
            "hair_blonde",
            pal,
        )
        # Ponta curvada para dentro perto do busto (como na arte!)
        _add_part(
            parts,
            create_cone(
                f"_tmp_hair_tip_{tag}",
                5,
                0.025,
                0.15,
                0.42,
                (side * 0.48, -0.20, 0.98),
                rotation=(math.radians(12.0), math.radians(side * -24.0), 0.0),
                scale=(0.80, 0.56, 1.0),
            ),
            mat_prefix,
            "hair_blonde",
            pal,
        )
    # Cortina densa de cabelo loiro nas costas
    _add_part(
        parts,
        create_cone(
            "_tmp_hair_back",
            8,
            0.78,
            0.46,
            1.60,
            (0.0, 0.34, 1.62),
            rotation=(math.radians(-10.0), 0.0, 0.0),
            scale=(1.08, 0.62, 1.0),
        ),
        mat_prefix,
        "hair_blonde",
        pal,
    )

    # 5. BRAÇOS COM MANGAS BRANCAS BUFANTES + MÃOS ROXAS ABERTAS DE 5 DEDOS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Manga bufante branca
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_sleeve_puff_{tag}",
                2,
                0.20,
                (side * 0.88, -0.06, 1.18),
                scale=(1.32, 0.82, 0.86),
            ),
            mat_prefix,
            "sleeve_white",
            pal,
        )
        # Palma roxa aberta para frente (-Y)
        palm_loc = (side * 1.24, -0.14, 1.32)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hand_palm_{tag}",
                2,
                0.19,
                palm_loc,
                scale=(1.06, 0.48, 0.94),
            ),
            mat_prefix,
            "skin_purple",
            pal,
        )
        # 5 dedos roxos abertos em leque expressivo
        finger_angles = [
            (0.22, 0.16, 42.0),
            (0.12, 0.24, 18.0),
            (-0.02, 0.26, -6.0),
            (-0.14, 0.20, -34.0),
            (-0.22, 0.02, -74.0),
        ]
        for f_idx, (fx_r, fz_r, ang_y) in enumerate(finger_angles):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_finger_{tag}_{f_idx}",
                    6,
                    0.048,
                    0.036,
                    0.22,
                    (palm_loc[0] + side * (-fx_r), palm_loc[1] - 0.02, palm_loc[2] + fz_r),
                    rotation=(0.0, math.radians(side * (-ang_y)), 0.0),
                ),
                mat_prefix,
                "skin_purple",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 124. Frostdiva lado a lado."""
    specs = [
        ("Frostdiva_Shiny", (-12.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Frostdiva_Normal", (-7.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Frostdiva_Grande", (-2.1, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Frostdiva_Gigante", (4.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Frostdiva_Dourada_SuperRara", (13.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_frostdiva(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
