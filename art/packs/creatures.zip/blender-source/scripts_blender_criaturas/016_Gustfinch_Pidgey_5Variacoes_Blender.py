"""
016_Gustfinch_Pidgey_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "016. Gustfinch — Pardal Veloz (Ref: Pidgey)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Gustfinch_Shiny (1.0x - Paleta Shiny / Shyne Oliva-Dourado + Crista/Peito Creme-Ouro)
  2. Gustfinch_Normal (1.0x - Dorso Marrom-Avelã + Peito Creme + Máscara Preta + Bico Rosa)
  3. Gustfinch_Grande (1.35x - Normal)
  4. Gustfinch_Gigante (1.85x - Normal)
  5. Gustfinch_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Garras/pés alinhados exatamente em `Z = 0.0` e frente/bico apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Gustfinch_Shiny`, `Gustfinch_Normal`, `Gustfinch_Grande`,
     `Gustfinch_Gigante`, `Gustfinch_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "back_brown": (0.64, 0.46, 0.30, 1.0),
        "chest_cream": (0.95, 0.89, 0.70, 1.0),
        "mask_black": (0.14, 0.12, 0.12, 1.0),
        "beak_pink": (0.90, 0.68, 0.64, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "claw_white": (0.96, 0.96, 0.98, 1.0),
    },
    "shiny_palette": {
        "back_brown": (0.80, 0.72, 0.24, 1.0),
        "chest_cream": (0.98, 0.95, 0.62, 1.0),
        "mask_black": (0.16, 0.14, 0.10, 1.0),
        "beak_pink": (0.94, 0.76, 0.36, 1.0),
        "eye_white": (0.99, 0.99, 0.96, 1.0),
        "claw_white": (0.98, 0.98, 0.92, 1.0),
    },
    "golden_super_rare_palette": {
        "back_brown": (0.98, 0.78, 0.14, 1.0),
        "chest_cream": (1.00, 0.94, 0.56, 1.0),
        "mask_black": (0.10, 0.92, 1.00, 1.0),
        "beak_pink": (0.88, 0.62, 0.12, 1.0),
        "eye_white": (1.00, 0.99, 0.90, 1.0),
        "claw_white": (1.00, 0.99, 0.88, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha as garras dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_gustfinch(
    name: str = "Gustfinch_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 016. Gustfinch (Ref: Pidgey):
      - Frente/bico apontando para -Y e garras/patas tocando Z = 0.0
      - Corpo compacto marrom-avelã com peito/papo creme em plumas chanfradas
      - Cabeça com crista de 3 pontas (central marrom + 2 plumas creme laterais),
        máscara facial preta nos olhos e bico rosa-pálido bipartido
      - Asas dobradas bicolores (marrom em cima, creme em baixo) e cauda em leque
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Gust_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Gust_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Gust"

    parts = []

    # 1. TRONCO ROLIÇO MARROM + PEITO/BARRIGA CREME COM PENUGEM FRONTAL
    _add_part(
        parts,
        create_icosphere("_tmp_torso_back", 1, 0.56, (0.0, 0.14, 0.78), scale=(0.94, 1.18, 0.96)),
        mat_prefix,
        "back_brown",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_torso_block", (0.86, 0.94, 0.72), (0.0, 0.10, 0.80), rotation=(math.radians(-10.0), 0.0, 0.0)),
        mat_prefix,
        "back_brown",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_belly_cream", 1, 0.50, (0.0, -0.14, 0.70), scale=(0.92, 1.02, 0.92)),
        mat_prefix,
        "chest_cream",
        pal,
    )
    # Jabot de penas creme escalonadas no peito (-Y)
    _add_part(
        parts,
        create_cube("_tmp_bib_main", (0.76, 0.42, 0.64), (0.0, -0.34, 0.92), rotation=(math.radians(8.0), 0.0, 0.0)),
        mat_prefix,
        "chest_cream",
        pal,
    )
    for idx, (fx, fz, fh) in enumerate([(-0.24, 0.54, 0.24), (0.0, 0.50, 0.28), (0.24, 0.54, 0.24)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_bib_tip_{idx}",
                4,
                0.13,
                0.02,
                fh,
                (fx, -0.48, fz),
                rotation=(math.radians(176.0), 0.0, 0.0),
            ),
            mat_prefix,
            "chest_cream",
            pal,
        )

    # 2. CABEÇA + CRISTA DE 3 PONTAS + MÁSCARA PRETA + OLHOS + BICO BIPARTIDO
    _add_part(parts, create_cube("_tmp_head_base", (0.78, 0.76, 0.68), (0.0, -0.22, 1.38)), mat_prefix, "back_brown", pal)
    _add_part(parts, create_cube("_tmp_cheek_cream", (0.70, 0.34, 0.42), (0.0, -0.48, 1.24)), mat_prefix, "chest_cream", pal)

    # Crista central marrom inclinada para trás (+Y) e 2 plumas laterais creme
    _add_part(
        parts,
        create_cone("_tmp_crest_mid", 4, 0.22, 0.03, 0.54, (0.0, -0.14, 1.84), rotation=(math.radians(-48.0), 0.0, 0.0)),
        mat_prefix,
        "back_brown",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_crest_sub", 4, 0.16, 0.03, 0.40, (0.0, 0.06, 1.76), rotation=(math.radians(-58.0), 0.0, 0.0)),
        mat_prefix,
        "back_brown",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_crest_brow_{tag}",
                4,
                0.14,
                0.02,
                0.48,
                (side * 0.28, -0.24, 1.66),
                rotation=(math.radians(-46.0), math.radians(side * -22.0), math.radians(side * 16.0)),
            ),
            mat_prefix,
            "chest_cream",
            pal,
        )

    # Bico superior e inferior rosa-pálido apontando para -Y
    _add_part(
        parts,
        create_cone(
            "_tmp_beak_upper",
            5,
            0.16,
            0.03,
            0.38,
            (0.0, -0.74, 1.36),
            rotation=(math.radians(96.0), 0.0, 0.0),
            scale=(1.0, 0.85, 1.0),
        ),
        mat_prefix,
        "beak_pink",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_beak_lower",
            4,
            0.12,
            0.03,
            0.28,
            (0.0, -0.70, 1.24),
            rotation=(math.radians(114.0), 0.0, 0.0),
        ),
        mat_prefix,
        "beak_pink",
        pal,
    )

    # Máscara preta lateral ao redor dos olhos + olhos expressivos
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_mask_{tag}",
                (0.16, 0.44, 0.24),
                (side * 0.36, -0.34, 1.44),
                rotation=(math.radians(12.0), 0.0, math.radians(side * -8.0)),
            ),
            mat_prefix,
            "mask_black",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_white_{tag}", (0.12, 0.20, 0.14), (side * 0.38, -0.46, 1.47)),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_pupil_{tag}", (0.13, 0.12, 0.13), (side * 0.39, -0.49, 1.47)),
            mat_prefix,
            "mask_black",
            pal,
        )

    # 3. ASAS DOBRADAS BICOLORES (MARROM + PONTA CREME) E CAUDA EM LEQUE (+Y)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_upper_{tag}",
                (0.24, 0.78, 0.56),
                (side * 0.52, 0.18, 0.86),
                rotation=(math.radians(18.0), math.radians(side * 10.0), math.radians(side * 12.0)),
            ),
            mat_prefix,
            "back_brown",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_tip_{tag}",
                4,
                0.22,
                0.04,
                0.56,
                (side * 0.58, 0.62, 0.62),
                rotation=(math.radians(-116.0), math.radians(side * 12.0), math.radians(side * 14.0)),
                scale=(0.56, 1.0, 1.0),
            ),
            mat_prefix,
            "chest_cream",
            pal,
        )

    # Cauda em leque de 3 penas marrons apontando para trás e cima (+Y, +Z)
    for idx, (tx, tz_rot) in enumerate([(-0.18, -16.0), (0.0, 0.0), (0.18, 16.0)]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_tail_feather_{idx}",
                (0.20, 0.64, 0.10),
                (tx, 0.82, 0.86),
                rotation=(math.radians(24.0), 0.0, math.radians(tz_rot)),
            ),
            mat_prefix,
            "back_brown",
            pal,
        )

    # 4. PATAS ROSA-PÁLIDO COM DEDOS E GARRAS BRANCAS TOCANDO Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_leg_{tag}",
                6,
                0.075,
                0.34,
                (side * 0.24, -0.02, 0.22),
                rotation=(math.radians(-8.0), 0.0, 0.0),
            ),
            mat_prefix,
            "beak_pink",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_pad_{tag}", (0.24, 0.28, 0.09), (side * 0.24, -0.08, 0.045)),
            mat_prefix,
            "beak_pink",
            pal,
        )
        for t_idx, (dx, dy) in enumerate([(-0.09, -0.22), (0.0, -0.25), (0.09, -0.22)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_claw_{tag}_{t_idx}",
                    4,
                    0.04,
                    0.01,
                    0.14,
                    (side * 0.24 + dx, dy - 0.04, 0.045),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 016. Gustfinch lado a lado."""
    specs = [
        ("Gustfinch_Shiny", (-5.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Gustfinch_Normal", (-3.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Gustfinch_Grande", (-0.7, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Gustfinch_Gigante", (2.5, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Gustfinch_Dourada_SuperRara", (6.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_gustfinch(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
