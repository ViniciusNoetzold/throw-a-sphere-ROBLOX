"""
07_Sproutling_Tatuzinho_Folha_Blender.py
========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera o modelo 3D
da criatura "07. Sproutling — Tatuzinho Folha (Inicial de Planta - Estágio 1)"
no estilo Low-Poly / Voxel Blocky para o jogo Roblox "Jogue uma Orbe / Throw a Sphere".

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no modelo final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cilindros 6-8 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Variações automáticas (`Normal`, `Dourado`, `Huge`) geradas lado a lado
  - Base das 4 patinhas alinhada exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione um modelo (ex: `Sproutling_Normal`) e exporte via `File > Export > FBX (.fbx)`
     com `Selected Objects` marcado e `Apply Transform` para importar como `MeshPart` no Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "huge_scale": 1.85,
    "palette": {
        "body_lime": (0.35, 0.85, 0.28, 1.0),      # Corpo Verde Lima (#59D947)
        "shell_moss": (0.14, 0.52, 0.20, 1.0),     # 3 Placas de Carapaça Verde-Musgo (#248533)
        "sprout_bright": (0.62, 1.00, 0.32, 1.0),  # Broto e 2 Folhas em Hélice Verde Claro (#9EFF52)
        "belly_cream": (0.88, 0.96, 0.72, 1.0),    # Barriga e Focinho Verde-Creme (#E0F5B8)
        "eyes_dark": (0.10, 0.14, 0.10, 1.0),      # Olhos Redondos Escuros
        "eye_shine": (0.96, 1.00, 0.96, 1.0),      # Brilho nos Olhos
    },
    "golden_palette": {
        "body_lime": (0.98, 0.78, 0.14, 1.0),
        "shell_moss": (0.72, 0.50, 0.08, 1.0),
        "sprout_bright": (1.00, 0.94, 0.42, 1.0),
        "belly_cream": (1.00, 0.96, 0.72, 1.0),
        "eyes_dark": (0.12, 0.92, 0.98, 1.0),
        "eye_shine": (1.00, 1.00, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (ideal para acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, zera a origem na base das patas (Z = 0.0),
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_sproutling(
    name: str = "Sproutling_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    is_golden: bool = False,
):
    """
    Constrói o modelo 3D completo do Tatuzinho Folha (07. Sproutling):
      - Frente apontando para -Y e base das 4 patinhas em Z = 0.0
      - Corpo oval/cúbico baixo com 3 placas de carapaça verde-musgo nas costas
      - Grande broto com 2 folhas em formato de hélice no topo da cabeça
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    pal = CONFIG["golden_palette"] if is_golden else CONFIG["palette"]
    mat_prefix = "Mat_Sprout_Gold" if is_golden else "Mat_Sprout"
    parts = []

    # 1. TORSO BAIXO, BARRIGA E CAUDA DE TATU
    _add_part(
        parts,
        create_cube("_tmp_torso", (1.28, 1.56, 0.88), (0.0, 0.08, 0.68)),
        mat_prefix,
        "body_lime",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_belly", (1.00, 1.28, 0.22), (0.0, 0.06, 0.30)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_tail", 6, 0.22, 0.05, 0.64, (0.0, 1.02, 0.56), (math.radians(-78), 0.0, 0.0)),
        mat_prefix,
        "shell_moss",
        pal,
    )

    # 2. TRÊS PLACAS DE CARAPAÇA VERDE-MUSGO NAS COSTAS
    shell_plates = [
        ((0.0, -0.28, 1.12), (1.42, 0.52, 0.34), (math.radians(14), 0.0, 0.0)),
        ((0.0, 0.16, 1.18), (1.48, 0.54, 0.36), (0.0, 0.0, 0.0)),
        ((0.0, 0.58, 1.06), (1.36, 0.52, 0.34), (math.radians(-18), 0.0, 0.0)),
    ]
    for idx, (loc, sz, rot) in enumerate(shell_plates):
        _add_part(
            parts,
            create_cube(f"_tmp_shell_{idx}", sz, loc, rot),
            mat_prefix,
            "shell_moss",
            pal,
        )

    # 3. QUATRO PATINHAS CURTAS CÔNICAS (6 LADOS, TOCANDO Z = 0)
    leg_coords = [
        (-0.44, -0.44, 0.19, 0.18, 0.15),
        (0.44, -0.44, 0.19, 0.18, 0.15),
        (-0.46, 0.52, 0.19, 0.19, 0.16),
        (0.46, 0.52, 0.19, 0.19, 0.16),
    ]
    for idx, (lx, ly, lz, r1, r2) in enumerate(leg_coords):
        _add_part(
            parts,
            create_cone(f"_tmp_leg_{idx}", 6, r1, r2, 0.38, (lx, ly, lz)),
            mat_prefix,
            "body_lime",
            pal,
        )

    # 4. CABEÇA FOFA, FOCINHO, ORELHINHAS E OLHOS REDONDOS BRILHANTES
    _add_part(
        parts,
        create_cube("_tmp_head", (1.06, 0.94, 0.86), (0.0, -0.82, 0.88), (math.radians(-6), 0.0, 0.0)),
        mat_prefix,
        "body_lime",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            6,
            0.28,
            0.16,
            0.36,
            (0.0, -1.32, 0.78),
            (math.radians(82), 0.0, 0.0),
            scale=(1.15, 0.78, 1.0),
        ),
        mat_prefix,
        "belly_cream",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        # Olho redondo escuro + ponto de brilho
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_eye_{side_idx}",
                8,
                0.12,
                0.08,
                (sx * 0.28, -1.28, 0.98),
                (math.radians(90), 0.0, 0.0),
            ),
            mat_prefix,
            "eyes_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eyeshine_{side_idx}",
                (0.055, 0.05, 0.055),
                (sx * 0.25, -1.32, 1.02),
            ),
            mat_prefix,
            "eye_shine",
            pal,
        )
        # Orelhinha curta facetada
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{side_idx}",
                4,
                0.14,
                0.03,
                0.28,
                (sx * 0.38, -0.70, 1.32),
                (0.0, math.radians(sx * 24), 0.0),
            ),
            mat_prefix,
            "body_lime",
            pal,
        )

    # 5. GRANDE BROTO COM 2 FOLHAS EM HÉLICE NO TOPO DA CABEÇA (ALVO CRÍTICO 1.5X)
    _add_part(
        parts,
        create_cylinder("_tmp_sprout_stem", 6, 0.065, 0.44, (0.0, -0.82, 1.48)),
        mat_prefix,
        "sprout_bright",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_sprout_bud", 1, 0.11, (0.0, -0.82, 1.72)),
        mat_prefix,
        "sprout_bright",
        pal,
    )
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_leaf_{side_idx}",
                4,
                0.28,
                0.04,
                0.86,
                (sx * 0.42, -0.82, 1.76),
                (math.radians(sx * 16), math.radians(sx * 78), 0.0),
                scale=(1.0, 0.22, 1.0),
            ),
            mat_prefix,
            "sprout_bright",
            pal,
        )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """Gera lado a lado as versões Normal, Dourada (Mutação 2x) e Enorme (Huge 1.85x)."""
    build_sproutling("Sproutling_Normal", location=(0.0, 0.0, 0.0), scale=1.0, is_golden=False)
    build_sproutling("Sproutling_Dourado", location=(3.2, 0.0, 0.0), scale=1.0, is_golden=True)
    build_sproutling("Sproutling_Huge", location=(-4.2, 0.0, 0.0), scale=CONFIG["huge_scale"], is_golden=False)


if __name__ == "__main__":
    generate_variations()
    print("Sproutling (Tatuzinho Folha) gerado com sucesso! Pronto para exportar em .FBX para o Roblox Studio.")
