"""
111_Ironrhino_Rhyhorn_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "111. Ironrhino — Rinoceronte Blindado (Ref: Rhyhorn)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Ironrhino_Shiny (1.0x - Paleta Shiny Armadura Terracota-Bronze + Placas Ocre + Olhos Rubi)
  2. Ironrhino_Normal (1.0x - Placas de Rocha Cinza-Ardósia + Crista Dorsal Dupla + Chifre Frontal)
  3. Ironrhino_Grande (1.35x - Normal)
  4. Ironrhino_Gigante (1.85x - Normal)
  5. Ironrhino_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Cristas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada blindada (placas angulares sobrepostas + núcleo orgânico + cones 6 lados)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Quatro patas com garras alinhadas em `Z = 0.0` e cabeça/chifre apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "armor_gray": (0.56, 0.60, 0.66, 1.0),
        "armor_light": (0.72, 0.76, 0.82, 1.0),
        "armor_dark": (0.30, 0.32, 0.38, 1.0),
        "eye_red": (0.82, 0.22, 0.22, 1.0),
        "eye_dark": (0.10, 0.10, 0.12, 1.0),
        "claw_white": (0.96, 0.97, 0.99, 1.0),
    },
    "shiny_palette": {
        "armor_gray": (0.72, 0.48, 0.34, 1.0),
        "armor_light": (0.86, 0.66, 0.48, 1.0),
        "armor_dark": (0.42, 0.26, 0.18, 1.0),
        "eye_red": (0.86, 0.20, 0.20, 1.0),
        "eye_dark": (0.10, 0.10, 0.12, 1.0),
        "claw_white": (0.97, 0.97, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "armor_gray": (0.98, 0.78, 0.14, 1.0),
        "armor_light": (1.00, 0.92, 0.44, 1.0),
        "armor_dark": (0.64, 0.44, 0.06, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.06, 0.56, 0.72, 1.0),
        "claw_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_ironrhino(
    name: str = "Ironrhino_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 111. Ironrhino (Ref: Rhyhorn):
      - Quadrúpede blindado baixo com núcleo de rocha escura e placas cinza-ardósia sobrepostas
      - Cabeça-escudo maciça com 2 cristas/orelhas erguidas em V, cavidades auriculares e chifre cônico
      - Crista dorsal rochosa alta com entalhe central em U formando dois picos verticais
      - Escudos laterais nos ombros com pontas angulares e 4 patas robustas com 2 garras brancas cada
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_IronR_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_IronR_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_IronR_Norm"

    parts = []

    # 1. NÚCLEO ESCURO DO TRONCO + PLACAS DE ARMADURA SOBREPOSTAS NO DORSO
    _add_part(
        parts,
        create_icosphere("_tmp_body_core", 2, 0.64, (0.0, 0.24, 0.72), scale=(1.04, 1.48, 0.84)),
        mat_prefix,
        "armor_dark",
        pal,
    )
    # Placa frontal do dorso
    _add_part(
        parts,
        create_icosphere("_tmp_back_plate_front", 2, 0.58, (0.0, 0.14, 0.94), scale=(1.18, 0.96, 0.74)),
        mat_prefix,
        "armor_gray",
        pal,
    )
    # Placa traseira do dorso + garupa blindada
    _add_part(
        parts,
        create_icosphere("_tmp_back_plate_rear", 2, 0.56, (0.0, 0.64, 0.90), scale=(1.14, 0.98, 0.76)),
        mat_prefix,
        "armor_gray",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_rump_plate", 1, 0.44, (0.0, 1.02, 0.74), scale=(1.02, 0.86, 0.84)),
        mat_prefix,
        "armor_dark",
        pal,
    )

    # 2. CRISTA DORSAL ALTA COM ENTALHE EM U (ASSINATURA DA SILHUETA DO RHYHORN)
    _add_part(
        parts,
        create_cone(
            "_tmp_fin_front",
            6,
            0.28,
            0.14,
            0.76,
            (0.0, 0.22, 1.50),
            rotation=(math.radians(-6.0), 0.0, 0.0),
            scale=(0.42, 1.00, 1.00),
        ),
        mat_prefix,
        "armor_light",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_fin_saddle",
            (0.18, 0.44, 0.36),
            (0.0, 0.46, 1.32),
        ),
        mat_prefix,
        "armor_gray",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_fin_rear",
            6,
            0.26,
            0.12,
            0.72,
            (0.0, 0.68, 1.48),
            rotation=(math.radians(8.0), 0.0, 0.0),
            scale=(0.40, 0.96, 1.00),
        ),
        mat_prefix,
        "armor_light",
        pal,
    )

    # 3. ESCUDOS LATERAIS DE ROCHA NOS OMBROS COM PONTAS ABERTAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_flank_shield_{tag}",
                (0.28, 0.76, 0.56),
                (side * 0.78, 0.36, 0.72),
                rotation=(math.radians(8.0), math.radians(side * 16.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "armor_gray",
            pal,
        )
        # Espigão superior e inferior do escudo lateral
        _add_part(
            parts,
            create_cone(
                f"_tmp_flank_spike_up_{tag}",
                4,
                0.18,
                0.04,
                0.48,
                (side * 0.92, 0.34, 0.96),
                rotation=(math.radians(24.0), math.radians(side * 46.0), 0.0),
                scale=(0.65, 1.10, 1.00),
            ),
            mat_prefix,
            "armor_light",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_flank_spike_back_{tag}",
                4,
                0.18,
                0.04,
                0.50,
                (side * 0.98, 0.64, 0.72),
                rotation=(math.radians(66.0), math.radians(side * 38.0), 0.0),
                scale=(0.65, 1.00, 1.00),
            ),
            mat_prefix,
            "armor_gray",
            pal,
        )

    # 4. CABEÇA-ESCUDO MACIÇA + 2 CRISTAS AURICULARES EM V + CHIFRE NO FOCINHO
    # Bloco principal do escudo facial inclinado para frente
    _add_part(
        parts,
        create_icosphere(
            "_tmp_head_shield",
            2,
            0.58,
            (0.0, -0.56, 0.88),
            rotation=(math.radians(16.0), 0.0, 0.0),
            scale=(1.12, 0.94, 0.92),
        ),
        mat_prefix,
        "armor_gray",
        pal,
    )
    # Focinho blindado afunilado
    _add_part(
        parts,
        create_cone(
            "_tmp_snout_wedge",
            6,
            0.44,
            0.22,
            0.54,
            (0.0, -0.94, 0.62),
            rotation=(math.radians(-68.0), 0.0, 0.0),
            scale=(1.12, 0.78, 1.00),
        ),
        mat_prefix,
        "armor_gray",
        pal,
    )
    # Mandíbula inferior escura + 2 pequenas presas brancas
    _add_part(
        parts,
        create_icosphere("_tmp_jaw_lower", 1, 0.34, (0.0, -0.82, 0.44), scale=(1.14, 0.96, 0.46)),
        mat_prefix,
        "armor_dark",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Crista/orelha frontal erguida de cada lado da testa
        _add_part(
            parts,
            create_cone(
                f"_tmp_brow_crest_{tag}",
                5,
                0.22,
                0.11,
                0.68,
                (side * 0.46, -0.46, 1.18),
                rotation=(math.radians(-22.0), math.radians(side * 16.0), math.radians(side * -10.0)),
                scale=(0.82, 1.12, 1.00),
            ),
            mat_prefix,
            "armor_light",
            pal,
        )
        # Cavidade auricular escura na lateral da crista
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_hollow_{tag}",
                4,
                0.10,
                0.03,
                0.24,
                (side * 0.56, -0.44, 1.24),
                rotation=(math.radians(-18.0), math.radians(side * 22.0), 0.0),
                scale=(0.45, 0.85, 1.00),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Placa lateral da bochecha blindada
        _add_part(
            parts,
            create_cube(
                f"_tmp_cheek_plate_{tag}",
                (0.24, 0.52, 0.48),
                (side * 0.62, -0.60, 0.74),
                rotation=(math.radians(14.0), math.radians(side * -14.0), math.radians(side * 18.0)),
            ),
            mat_prefix,
            "armor_gray",
            pal,
        )
        # Olho feroz branco com íris rubi e pupila sob a sobrancelha blindada
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.12,
                (side * 0.34, -0.92, 0.72),
                rotation=(0.0, math.radians(side * -18.0), math.radians(side * 24.0)),
                scale=(1.14, 0.44, 0.72),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.068,
                (side * 0.33, -0.965, 0.71),
                scale=(0.86, 0.48, 1.00),
            ),
            mat_prefix,
            "eye_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.034,
                (side * 0.325, -0.995, 0.71),
                scale=(0.70, 0.48, 1.05),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Presinha lateral da mandíbula
        _add_part(
            parts,
            create_cone(
                f"_tmp_jaw_fang_{tag}",
                4,
                0.048,
                0.010,
                0.12,
                (side * 0.28, -0.92, 0.52),
                rotation=(math.radians(168.0), 0.0, 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # Chifre cônico central no focinho
    _add_part(
        parts,
        create_cone(
            "_tmp_nose_horn",
            6,
            0.16,
            0.03,
            0.46,
            (0.0, -0.98, 0.84),
            rotation=(math.radians(-32.0), 0.0, 0.0),
        ),
        mat_prefix,
        "armor_light",
        pal,
    )

    # 5. QUATRO PATAS COLUNARES PESADAS COM 2 GARRAS BRANCAS CADA (Z = 0.0)
    leg_specs = [
        ("FL", -0.52, -0.44, 0.26, 0.28, True),
        ("FR", 0.52, -0.44, 0.26, 0.28, True),
        ("BL", -0.62, 0.74, 0.25, 0.26, False),
        ("BR", 0.62, 0.74, 0.25, 0.26, False),
    ]
    for tag, lx, ly, r_top, r_bot, is_front in leg_specs:
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_{tag}",
                8,
                r_bot,
                r_top,
                0.56,
                (lx, ly, 0.30),
                rotation=(math.radians(-8.0 if is_front else 6.0), 0.0, 0.0),
                scale=(1.04, 1.12, 1.00),
            ),
            mat_prefix,
            "armor_gray" if is_front else "armor_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                r_bot * 0.98,
                (lx, ly - 0.06, 0.16),
                scale=(1.08, 1.24, 0.66),
            ),
            mat_prefix,
            "armor_gray" if is_front else "armor_dark",
            pal,
        )
        for c_idx, dx in enumerate((-0.12, 0.12)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_claw_{tag}_{c_idx}",
                    5,
                    0.078,
                    0.014,
                    0.20,
                    (lx + dx, ly - 0.32, 0.10),
                    rotation=(math.radians(-78.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 6. CAUDA CURTA DE ROCHA
    _add_part(
        parts,
        create_cone(
            "_tmp_tail",
            6,
            0.18,
            0.04,
            0.44,
            (0.0, 1.28, 0.62),
            rotation=(math.radians(102.0), 0.0, 0.0),
        ),
        mat_prefix,
        "armor_dark",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 111. Ironrhino lado a lado."""
    specs = [
        ("Ironrhino_Shiny", (-9.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Ironrhino_Normal", (-5.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Ironrhino_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Ironrhino_Gigante", (5.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Ironrhino_Dourada_SuperRara", (13.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_ironrhino(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
