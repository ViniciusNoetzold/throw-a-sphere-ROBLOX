"""
069_Vinebell_Bellsprout_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "069. Vinebell — Broto Sino (Ref: Bellsprout)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Vinebell_Shiny (1.0x - Paleta Shiny Cabeça Amarelo-Ouro + Folhas Dourado-Limão)
  2. Vinebell_Normal (1.0x - Cabeça Amarela Bulbosa + Lábios Rosa + Caule Marrom + 2 Folhas Verdes)
  3. Vinebell_Grande (1.35x - Normal)
  4. Vinebell_Gigante (1.85x - Normal)
  5. Vinebell_Dourada_SuperRara (2.25x - Ouro Reluzente + Lábios, Nervuras e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2, cones/cilindros 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Raízes alinhadas exatamente em `Z = 0.0` e rosto/boca apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "head_yellow": (0.96, 0.92, 0.36, 1.0),
        "lip_pink": (0.90, 0.64, 0.68, 1.0),
        "mouth_dark": (0.11, 0.10, 0.12, 1.0),
        "stem_brown": (0.58, 0.50, 0.40, 1.0),
        "leaf_green": (0.44, 0.80, 0.48, 1.0),
        "leaf_vein": (0.26, 0.58, 0.30, 1.0),
        "eye_dark": (0.10, 0.10, 0.12, 1.0),
        "shine_white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "head_yellow": (0.98, 0.84, 0.24, 1.0),
        "lip_pink": (0.94, 0.60, 0.68, 1.0),
        "mouth_dark": (0.12, 0.10, 0.12, 1.0),
        "stem_brown": (0.54, 0.46, 0.34, 1.0),
        "leaf_green": (0.86, 0.86, 0.26, 1.0),
        "leaf_vein": (0.64, 0.64, 0.16, 1.0),
        "eye_dark": (0.10, 0.10, 0.12, 1.0),
        "shine_white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "head_yellow": (0.98, 0.78, 0.14, 1.0),
        "lip_pink": (0.10, 0.92, 1.00, 1.0),
        "mouth_dark": (0.06, 0.34, 0.48, 1.0),
        "stem_brown": (0.82, 0.60, 0.10, 1.0),
        "leaf_green": (0.98, 0.84, 0.22, 1.0),
        "leaf_vein": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "shine_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_segment(
    name: str,
    p1: tuple,
    p2: tuple,
    r1: float,
    r2: float,
    vertices: int = 8,
    extend: float = 1.08,
):
    """Cria um cone/segmento conectando exatamente p1 -> p2 sem folgas."""
    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    dz = p2[2] - p1[2]
    dist = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dist < 1e-6:
        dist = 1e-6
    mid = ((p1[0] + p2[0]) * 0.5, (p1[1] + p2[1]) * 0.5, (p1[2] + p2[2]) * 0.5)
    theta = math.acos(max(-1.0, min(1.0, dz / dist)))
    phi = math.atan2(dy, dx)
    return create_cone(
        name=name,
        vertices=vertices,
        radius1=r1,
        radius2=r2,
        depth=dist * extend,
        location=mid,
        rotation=(0.0, theta, phi),
    )


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha as raízes em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_vinebell(
    name: str = "Vinebell_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 069. Vinebell (Ref: Bellsprout):
      - Cabeça bulbosa amarela em formato de sino inclinado para frente (-Y)
      - Boca tubular com anel labial rosa contínuo e cavidade bucal escura profunda
      - Olhinhos pretos redondos simétricos com brilho branco
      - Caule fino marrom-oliva curvado em 'S' suave sustentando a cabeça
      - 2 folhas largas verdes em formato de gota com nervura central atuando como braços
      - 2 perninhas de raízes curvadas ramificando em 3 pontinhas apoiadas em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Vinebell_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Vinebell_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Vinebell_Norm"

    parts = []

    # 1. RAÍZES-PERNAS CURVADAS APOIADAS EM Z = 0.0
    root_fork = (0.0, 0.02, 0.42)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        r_mid = (side * 0.40, -0.04, 0.34)
        r_foot = (side * 0.66, -0.08, 0.14)
        _add_part(parts, create_segment(f"_tmp_root_up_{tag}", root_fork, r_mid, 0.072, 0.056, vertices=7), mat_prefix, "stem_brown", pal)
        _add_part(parts, create_icosphere(f"_tmp_root_j_{tag}", 1, 0.058, r_mid), mat_prefix, "stem_brown", pal)
        _add_part(parts, create_segment(f"_tmp_root_lo_{tag}", r_mid, r_foot, 0.056, 0.044, vertices=7), mat_prefix, "stem_brown", pal)
        for t_idx, (dx, dy) in enumerate([(side * 0.24, -0.14), (side * 0.20, 0.04), (side * 0.06, -0.22)]):
            _add_part(
                parts,
                create_segment(
                    f"_tmp_root_toe_{tag}_{t_idx}",
                    r_foot,
                    (r_foot[0] + dx, r_foot[1] + dy, 0.03),
                    0.036,
                    0.012,
                    vertices=5,
                ),
                mat_prefix,
                "stem_brown",
                pal,
            )

    # 2. CAULE CURVADO ELEGANTE SUSTENTANDO AS FOLHAS E A CABEÇA
    stem_pts = [
        (0.00, 0.02, 0.42, 0.085),
        (-0.04, 0.06, 0.78, 0.088),
        (0.00, 0.12, 1.14, 0.082),
        (0.04, 0.20, 1.48, 0.070),
        (0.02, 0.24, 1.82, 0.064),
    ]
    for i in range(len(stem_pts) - 1):
        p1 = stem_pts[i][:3]
        p2 = stem_pts[i + 1][:3]
        r1 = stem_pts[i][3]
        r2 = stem_pts[i + 1][3]
        _add_part(parts, create_segment(f"_tmp_stem_{i}", p1, p2, r1, r2, vertices=8, extend=1.08), mat_prefix, "stem_brown", pal)
        _add_part(parts, create_icosphere(f"_tmp_stem_j_{i}", 1, r2 * 0.96, p2), mat_prefix, "stem_brown", pal)

    # 3. DUAS FOLHAS LARGAS VERDES EM FORMATO DE GOTA (BRAÇOS)
    leaf_anchor = (0.00, 0.10, 1.06)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        l_base = (side * 0.20, 0.06, 1.10)
        l_mid = (side * 0.62, 0.00, 1.14)
        l_tip = (side * 1.18, 0.04, 1.10)
        _add_part(parts, create_segment(f"_tmp_petiole_{tag}", leaf_anchor, l_base, 0.052, 0.065, vertices=6), mat_prefix, "leaf_vein", pal)
        # Lâmina principal orgânica em gota + ponta fluida
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_leaf_body_{tag}",
                2,
                0.36,
                l_mid,
                rotation=(math.radians(18.0), math.radians(side * -8.0), math.radians(side * -6.0)),
                scale=(1.32, 0.24, 0.96),
            ),
            mat_prefix,
            "leaf_green",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_leaf_tip_{tag}",
                8,
                0.34,
                0.02,
                0.56,
                (side * 0.98, 0.02, 1.12),
                rotation=(math.radians(18.0), math.radians(side * 94.0), 0.0),
                scale=(0.92, 0.24, 1.0),
            ),
            mat_prefix,
            "leaf_green",
            pal,
        )
        _add_part(
            parts,
            create_segment(
                f"_tmp_leaf_vein_{tag}",
                (l_base[0], l_base[1] - 0.06, l_base[2] + 0.02),
                (l_tip[0] - side * 0.14, l_tip[1] - 0.05, l_tip[2] + 0.02),
                0.030,
                0.014,
                vertices=5,
            ),
            mat_prefix,
            "leaf_vein",
            pal,
        )

    # 4. CABEÇA BULBOSA AMARELA SIMÉTRICA + TROMBA + ANEL LABIAL ROSA SUAVE + OLHOS SIMÉTRICOS
    _add_part(
        parts,
        create_icosphere("_tmp_head_bulb", 2, 0.44, (0.0, 0.12, 1.98), scale=(1.02, 1.06, 1.04)),
        mat_prefix,
        "head_yellow",
        pal,
    )
    snout_start = (0.0, 0.02, 1.92)
    snout_end = (0.0, -0.58, 1.54)
    _add_part(
        parts,
        create_segment("_tmp_head_tube", snout_start, snout_end, 0.40, 0.24, vertices=10, extend=1.02),
        mat_prefix,
        "head_yellow",
        pal,
    )

    # Anel labial rosa tubular suave (segmentos conectados em torno da elipse da boca)
    mouth_c = (0.0, -0.62, 1.52)
    tilt = math.radians(32.0)
    n_lip = 12
    lip_pts = []
    for i in range(n_lip):
        ang = 2.0 * math.pi * i / n_lip
        lx = mouth_c[0] + math.cos(ang) * 0.24
        ly = mouth_c[1] - math.sin(ang) * 0.20 * math.sin(tilt)
        lz = mouth_c[2] + math.sin(ang) * 0.20 * math.cos(tilt)
        lip_pts.append((lx, ly, lz))
    for i in range(n_lip):
        p1 = lip_pts[i]
        p2 = lip_pts[(i + 1) % n_lip]
        _add_part(parts, create_segment(f"_tmp_lip_seg_{i}", p1, p2, 0.088, 0.088, vertices=8, extend=1.24), mat_prefix, "lip_pink", pal)

    # Cavidade bucal escura profunda dentro do anel labial
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_hole",
            2,
            0.22,
            (mouth_c[0], mouth_c[1] + 0.04, mouth_c[2] + 0.02),
            rotation=(tilt, 0.0, 0.0),
            scale=(1.02, 0.34, 0.88),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )

    # Olhinhos pretos redondos simétricos e bem visíveis com brilho branco
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(f"_tmp_eye_{tag}", 2, 0.075, (side * 0.26, -0.32, 1.92), scale=(0.88, 0.70, 1.05)),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_eye_shine_{tag}", 1, 0.030, (side * 0.25, -0.37, 1.95)),
            mat_prefix,
            "shine_white",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 069. Vinebell lado a lado."""
    specs = [
        ("Vinebell_Shiny", (-10.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Vinebell_Normal", (-6.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Vinebell_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Vinebell_Gigante", (5.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Vinebell_Dourada_SuperRara", (14.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_vinebell(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
