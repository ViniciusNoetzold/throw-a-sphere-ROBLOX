"""
079_Dazepig_Slowpoke_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "079. Dazepig — Hipopótamo Preguiçoso (Ref: Slowpoke)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Dazepig_Shiny (1.0x - Paleta Shiny Lavanda-Pastel + Focinho Marfim)
  2. Dazepig_Normal (1.0x - Rosa-Chiclete Roliço + Focinho Creme + Olhos Sonolentos + Cauda Ponta Branca)
  3. Dazepig_Grande (1.35x - Normal)
  4. Dazepig_Gigante (1.85x - Normal)
  5. Dazepig_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Garras e Ponta da Cauda Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para corpo roliço e focinho largo + cauda em arco)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas e barriga baixa alinhadas em `Z = 0.0` e rosto sonolento apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_pink": (0.94, 0.60, 0.70, 1.0),
        "body_shade": (0.80, 0.46, 0.56, 1.0),
        "muzzle_cream": (0.92, 0.88, 0.78, 1.0),
        "tail_tip": (0.97, 0.94, 0.91, 1.0),
        "mouth_deep": (0.52, 0.30, 0.38, 1.0),
        "tongue_pink": (0.88, 0.58, 0.68, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "pupil_dark": (0.10, 0.10, 0.12, 1.0),
        "claw_white": (0.98, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_pink": (0.84, 0.72, 0.90, 1.0),
        "body_shade": (0.70, 0.56, 0.78, 1.0),
        "muzzle_cream": (0.96, 0.94, 0.88, 1.0),
        "tail_tip": (0.98, 0.97, 0.98, 1.0),
        "mouth_deep": (0.48, 0.30, 0.42, 1.0),
        "tongue_pink": (0.84, 0.58, 0.74, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "pupil_dark": (0.10, 0.10, 0.12, 1.0),
        "claw_white": (0.98, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_pink": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.62, 0.10, 1.0),
        "muzzle_cream": (1.00, 0.90, 0.44, 1.0),
        "tail_tip": (0.10, 0.92, 1.00, 1.0),
        "mouth_deep": (0.56, 0.36, 0.06, 1.0),
        "tongue_pink": (0.98, 0.84, 0.32, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.32, 0.48, 1.0),
        "claw_white": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_segment(parts: list, name: str, p0: tuple, p1: tuple, r0: float, r1: float, mat_prefix: str, mat_key: str, pal: dict, verts: int = 8):
    dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    if length < 1e-5:
        return None
    mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
    phi = math.atan2(dx, -dy)
    theta = math.acos(max(-1.0, min(1.0, dz / length)))
    obj = create_cone(name, verts, r0, r1, length + 0.05, mid, rotation=(theta, 0.0, phi))
    return _add_part(parts, obj, mat_prefix, mat_key, pal)


def build_dazepig(
    name: str = "Dazepig_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 079. Dazepig (Ref: Slowpoke):
      - Corpo quadrúpede roliço e relaxado rosa-chiclete descansando próximo ao chão
      - Cabeça grande redonda com orelhinhas enroladas em espiral no topo
      - Olhos grandes brancos redondos distantes com pupilas pontuais minúsculas (olhar sonolento)
      - Focinho largo creme-bege com narinas, boca aberta sorridente e 2 dentinhos superiores
      - 4 patinhas curtas espalhadas cada uma com 1 grande garra branca arredondada
      - Cauda longa rosa curvando-se alto sobre o dorso com a icônica ponta branca/creme
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Slow_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Slow_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Slow_Norm"

    parts = []

    # 1. CORPO ROLIÇO BAIXO E RELAXADO
    _add_part(
        parts,
        create_icosphere("_tmp_body_main", 2, 0.64, (0.0, 0.24, 0.54), scale=(1.04, 1.32, 0.80)),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Volume traseiro rechonchudo
    _add_part(
        parts,
        create_icosphere("_tmp_rump", 2, 0.56, (0.0, 0.68, 0.52), scale=(1.04, 0.96, 0.82)),
        mat_prefix,
        "body_pink",
        pal,
    )

    # 2. CABEÇA REDONDA GRANDE + ORELHAS ENROLADAS + ROSTO SONOLENTO ICÔNICO
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.52, (0.0, -0.58, 0.72), scale=(1.06, 0.96, 0.88)),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Focinho largo achatado creme-bege
    _add_part(
        parts,
        create_icosphere(
            "_tmp_snout_upper",
            2,
            0.38,
            (0.0, -1.04, 0.64),
            rotation=(math.radians(8.0), 0.0, 0.0),
            scale=(1.28, 0.82, 0.52),
        ),
        mat_prefix,
        "muzzle_cream",
        pal,
    )
    # Mandíbula creme inferior aberta
    _add_part(
        parts,
        create_icosphere(
            "_tmp_jaw_lower",
            2,
            0.32,
            (0.0, -0.96, 0.40),
            scale=(1.18, 0.78, 0.42),
        ),
        mat_prefix,
        "muzzle_cream",
        pal,
    )
    # Boca aberta feliz + língua rosa + 2 dentinhos brancos
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_cav", 2, 0.28, (0.0, -1.04, 0.50), scale=(1.10, 0.52, 0.54)),
        mat_prefix,
        "mouth_deep",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_tongue", 1, 0.20, (0.0, -1.10, 0.44), scale=(1.04, 0.48, 0.36)),
        mat_prefix,
        "tongue_pink",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Dentinho superior pequeno
        _add_part(
            parts,
            create_cone(
                f"_tmp_tooth_{tag}",
                4,
                0.036,
                0.008,
                0.09,
                (side * 0.20, -1.20, 0.56),
                rotation=(math.radians(180.0), 0.0, 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )
        # Narina pequena
        _add_part(
            parts,
            create_cube(
                f"_tmp_nostril_{tag}",
                (0.036, 0.04, 0.025),
                (side * 0.12, -1.33, 0.66),
                rotation=(0.0, 0.0, math.radians(side * 24.0)),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # Olhos brancos grandes redondos distantes + pupilas pontuais minúsculas
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.19,
                (side * 0.34, -0.92, 0.86),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(0.94, 0.58, 1.06),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.036,
                (side * 0.35, -1.03, 0.87),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )
        # Orelha arredondada enrolada no topo da cabeça + espiral interna sombreada
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ear_{tag}",
                2,
                0.22,
                (side * 0.42, -0.58, 1.12),
                rotation=(0.0, math.radians(side * 16.0), 0.0),
                scale=(1.04, 0.64, 1.00),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ear_swirl_{tag}",
                8,
                0.10,
                0.06,
                (side * 0.44, -0.71, 1.12),
                rotation=(math.radians(90.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )

    # 3. QUATRO PATINHAS CURTAS RECHONCHUDAS COM 1 GARRA BRANCA ARREDONDADA CADA
    paw_specs = [
        # (tag, leg_loc, leg_rot, claw_loc)
        ("FL", (-0.54, -0.52, 0.24), (math.radians(18.0), math.radians(-22.0), math.radians(24.0)), (-0.58, -0.82, 0.12)),
        ("FR", (0.54, -0.52, 0.24), (math.radians(18.0), math.radians(22.0), math.radians(-24.0)), (0.58, -0.82, 0.12)),
        ("BL", (-0.58, 0.66, 0.22), (math.radians(12.0), math.radians(-18.0), math.radians(18.0)), (-0.64, 0.40, 0.11)),
        ("BR", (0.58, 0.66, 0.22), (math.radians(12.0), math.radians(18.0), math.radians(-18.0)), (0.64, 0.40, 0.11)),
    ]
    for tag, l_loc, l_rot, c_loc in paw_specs:
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_paw_{tag}",
                2,
                0.28,
                l_loc,
                rotation=l_rot,
                scale=(0.94, 1.32, 0.72),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_claw_{tag}",
                1,
                0.12,
                c_loc,
                scale=(1.10, 1.24, 0.62),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 4. CAUDA LONGA EM ARCO ALTO SOBRE O DORSO COM PONTA BRANCA/CREME (VISÍVEL DE FRENTE!)
    tail_pts = [
        (0.00, 0.98, 0.56),
        (0.14, 1.26, 0.92),
        (0.24, 1.24, 1.42),
        (0.20, 0.88, 1.78),
        (0.14, 0.34, 1.88),
        (0.10, -0.14, 1.76),
    ]
    tail_radii = [0.24, 0.22, 0.20, 0.17, 0.12, 0.03]
    for i in range(len(tail_pts) - 1):
        # Últimos dois segmentos recebem a ponta creme-branca característica do Slowpoke!
        m_key = "tail_tip" if i >= 3 else "body_pink"
        _add_segment(parts, f"_tmp_tail_{i}", tail_pts[i], tail_pts[i + 1], tail_radii[i], tail_radii[i + 1], mat_prefix, m_key, pal, verts=8)
        if i < len(tail_pts) - 2:
            _add_part(
                parts,
                create_icosphere(f"_tmp_tail_j_{i}", 1, tail_radii[i + 1] * 0.98, tail_pts[i + 1]),
                mat_prefix,
                m_key,
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 079. Dazepig lado a lado."""
    specs = [
        ("Dazepig_Shiny", (-9.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Dazepig_Normal", (-5.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Dazepig_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Dazepig_Gigante", (5.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Dazepig_Dourada_SuperRara", (13.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_dazepig(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
