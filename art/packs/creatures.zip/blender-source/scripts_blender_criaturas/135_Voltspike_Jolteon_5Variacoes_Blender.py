"""
135_Voltspike_Jolteon_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "135. Voltspike — Lobo de Raios (Ref: Jolteon)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Voltspike_Shiny (1.0x - Paleta Shiny Verde-Limão Elétrico + Colar Branco)
  2. Voltspike_Normal (1.0x - Amarelo-Elétrico + Colar de Espinhos Brancos + Traseira Eriçada)
  3. Voltspike_Grande (1.35x - Normal)
  4. Voltspike_Gigante (1.85x - Normal)
  5. Voltspike_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Espinhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para tronco/cabeça/patas + cones afiados para colar, orelhas e traseira)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e focinho/rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_yellow": (0.98, 0.84, 0.22, 1.0),
        "body_shade": (0.86, 0.70, 0.14, 1.0),
        "collar_white": (0.97, 0.98, 1.00, 1.0),
        "collar_shade": (0.84, 0.88, 0.94, 1.0),
        "ear_inner": (0.18, 0.08, 0.24, 1.0),
        "eye_dark": (0.10, 0.08, 0.14, 1.0),
        "eye_violet": (0.34, 0.18, 0.48, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "nose_black": (0.10, 0.10, 0.12, 1.0),
    },
    "shiny_palette": {
        "body_yellow": (0.60, 0.88, 0.24, 1.0),
        "body_shade": (0.46, 0.72, 0.16, 1.0),
        "collar_white": (0.97, 0.99, 0.98, 1.0),
        "collar_shade": (0.82, 0.90, 0.84, 1.0),
        "ear_inner": (0.16, 0.10, 0.22, 1.0),
        "eye_dark": (0.10, 0.08, 0.14, 1.0),
        "eye_violet": (0.38, 0.20, 0.54, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "nose_black": (0.10, 0.10, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "body_yellow": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.62, 0.08, 1.0),
        "collar_white": (0.10, 0.92, 1.00, 1.0),
        "collar_shade": (0.06, 0.66, 0.82, 1.0),
        "ear_inner": (0.08, 0.56, 0.70, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "eye_violet": (0.42, 0.96, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.94, 1.0),
        "nose_black": (0.56, 0.38, 0.06, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une primitivas, normaliza a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_voltspike(
    name: str = "Voltspike_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 135. Voltspike (Ref: Jolteon):
      - Tronco quadrúpede atlético amarelo-elétrico sem cauda longa (leque de espinhos na traseira)
      - Grande colarinho branco de espinhos afiados em raio ao redor do pescoço e peito
      - Cabeça de raposa/lobo alerta com focinho pontudo, nariz preto, olhos amendoados violeta com brilho
      - Orelhas muito longas e pontudas voltadas para trás com interior roxo-escuro
      - Quatro patas esguias e ágeis apoiadas em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Volt_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Volt_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Volt_Norm"

    parts = []

    # 1. TRONCO ATLÉTICO QUADRÚPEDE (PEITO -> CINTURA -> QUADRIL)
    _add_part(
        parts,
        create_icosphere("_tmp_chest", 2, 0.44, (0.0, -0.20, 0.96), scale=(0.88, 1.18, 0.94)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_waist", 2, 0.36, (0.0, 0.14, 0.92), scale=(0.86, 1.24, 0.84)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_rump", 2, 0.40, (0.0, 0.44, 0.95), scale=(0.94, 1.08, 0.92)),
        mat_prefix,
        "body_yellow",
        pal,
    )

    # 2. LEQUE DE ESPINHOS AMARELOS NA TRASEIRA (SEM CAUDA LONGA — ASSINATURA DO JOLTEON)
    rump_spikes = [
        # (loc, rot_deg, r1, depth, mat_key)
        ((0.0, 0.78, 1.18), (48.0, 0.0, 0.0), 0.19, 0.66, "body_yellow"),
        ((0.0, 0.84, 0.98), (74.0, 0.0, 0.0), 0.21, 0.72, "body_yellow"),
        ((0.0, 0.76, 0.78), (102.0, 0.0, 0.0), 0.18, 0.56, "body_shade"),
        ((-0.24, 0.70, 1.16), (44.0, -24.0, 0.0), 0.16, 0.56, "body_yellow"),
        ((0.24, 0.70, 1.16), (44.0, 24.0, 0.0), 0.16, 0.56, "body_yellow"),
        ((-0.34, 0.74, 0.96), (72.0, -34.0, 0.0), 0.18, 0.62, "body_yellow"),
        ((0.34, 0.74, 0.96), (72.0, 34.0, 0.0), 0.18, 0.62, "body_yellow"),
        ((-0.28, 0.66, 0.78), (96.0, -28.0, 0.0), 0.15, 0.48, "body_shade"),
        ((0.28, 0.66, 0.78), (96.0, 28.0, 0.0), 0.15, 0.48, "body_shade"),
        ((-0.14, 0.46, 1.24), (24.0, -14.0, 0.0), 0.14, 0.44, "body_yellow"),
        ((0.14, 0.46, 1.24), (24.0, 14.0, 0.0), 0.14, 0.44, "body_yellow"),
    ]
    for idx, (loc, (rx, ry, rz), r1, dep, mkey) in enumerate(rump_spikes):
        _add_part(
            parts,
            create_cone(
                f"_tmp_rump_spike_{idx}",
                5,
                r1,
                0.014,
                dep,
                loc,
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
                scale=(1.0, 0.78, 1.0),
            ),
            mat_prefix,
            mkey,
            pal,
        )

    # 3. COLARINHO DE ESPINHOS BRANCOS AFIADOS AO REDOR DO PESCOÇO E PEITO
    # Base fofa do colarinho unindo os espinhos sem lacunas
    _add_part(
        parts,
        create_icosphere("_tmp_collar_core", 2, 0.44, (0.0, -0.34, 1.14), scale=(1.12, 0.98, 0.84)),
        mat_prefix,
        "collar_white",
        pal,
    )
    collar_spikes = [
        # Frente (apontando para baixo e para frente em raio)
        ((0.0, -0.72, 0.90), (-148.0, 0.0, 0.0), 0.18, 0.56, "collar_white"),
        ((-0.24, -0.68, 0.94), (-142.0, -24.0, 0.0), 0.16, 0.52, "collar_white"),
        ((0.24, -0.68, 0.94), (-142.0, 24.0, 0.0), 0.16, 0.52, "collar_white"),
        ((-0.44, -0.52, 1.04), (-124.0, -52.0, 0.0), 0.16, 0.54, "collar_white"),
        ((0.44, -0.52, 1.04), (-124.0, 52.0, 0.0), 0.16, 0.54, "collar_white"),
        # Laterais largas
        ((-0.56, -0.30, 1.14), (108.0, -76.0, 0.0), 0.16, 0.54, "collar_white"),
        ((0.56, -0.30, 1.14), (108.0, 76.0, 0.0), 0.16, 0.54, "collar_white"),
        ((-0.52, -0.06, 1.24), (72.0, -64.0, 0.0), 0.16, 0.56, "collar_shade"),
        ((0.52, -0.06, 1.24), (72.0, 64.0, 0.0), 0.16, 0.56, "collar_shade"),
        # Costas (varrendo para trás sobre o dorso)
        ((-0.26, 0.12, 1.32), (62.0, -26.0, 0.0), 0.18, 0.62, "collar_white"),
        ((0.26, 0.12, 1.32), (62.0, 26.0, 0.0), 0.18, 0.62, "collar_white"),
        ((0.0, 0.18, 1.34), (66.0, 0.0, 0.0), 0.20, 0.66, "collar_white"),
        # Pontas superiores sob o queixo
        ((-0.34, -0.58, 1.20), (-82.0, -40.0, 0.0), 0.12, 0.36, "collar_white"),
        ((0.34, -0.58, 1.20), (-82.0, 40.0, 0.0), 0.12, 0.36, "collar_white"),
    ]
    for idx, (loc, (rx, ry, rz), r1, dep, mkey) in enumerate(collar_spikes):
        _add_part(
            parts,
            create_cone(
                f"_tmp_collar_spike_{idx}",
                5,
                r1,
                0.012,
                dep,
                loc,
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
                scale=(1.0, 0.72, 1.0),
            ),
            mat_prefix,
            mkey,
            pal,
        )

    # 4. PESCOÇO, CABEÇA DE RAPOSA ELÉTRICA E ROSTO EXPRESSIVO
    _add_part(
        parts,
        create_cone(
            "_tmp_neck",
            8,
            0.28,
            0.22,
            0.44,
            (0.0, -0.44, 1.30),
            rotation=(math.radians(-18.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Crânio arredondado
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.42, (0.0, -0.56, 1.54), scale=(0.94, 1.04, 0.90)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Focinho pontudo de raposa voltado para -Y
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            8,
            0.24,
            0.10,
            0.38,
            (0.0, -0.92, 1.46),
            rotation=(math.radians(-82.0), 0.0, 0.0),
            scale=(1.04, 0.86, 1.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_snout_tip", 2, 0.11, (0.0, -1.07, 1.44), scale=(0.94, 0.92, 0.78)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Narizinho preto na ponta do focinho
    _add_part(
        parts,
        create_icosphere("_tmp_nose", 1, 0.048, (0.0, -1.16, 1.47), scale=(1.10, 0.80, 0.72)),
        mat_prefix,
        "nose_black",
        pal,
    )
    # Sorriso fino e determinado sob o focinho
    _add_part(
        parts,
        create_cube("_tmp_mouth", (0.18, 0.04, 0.025), (0.0, -1.06, 1.37)),
        mat_prefix,
        "nose_black",
        pal,
    )

    # Tufos pontiagudos nas bochechas e no topo da testa
    head_tufts = [
        ((-0.34, -0.44, 1.42), (72.0, -56.0, 0.0), 0.11, 0.30),
        ((0.34, -0.44, 1.42), (72.0, 56.0, 0.0), 0.11, 0.30),
        ((-0.26, -0.42, 1.28), (112.0, -48.0, 0.0), 0.10, 0.28),
        ((0.26, -0.42, 1.28), (112.0, 48.0, 0.0), 0.10, 0.28),
        ((0.0, -0.48, 1.92), (18.0, 0.0, 0.0), 0.11, 0.28),
        ((-0.12, -0.52, 1.88), (10.0, -18.0, 0.0), 0.09, 0.24),
        ((0.12, -0.52, 1.88), (10.0, 18.0, 0.0), 0.09, 0.24),
    ]
    for idx, (loc, (rx, ry, rz), r1, dep) in enumerate(head_tufts):
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_tuft_{idx}",
                5,
                r1,
                0.012,
                dep,
                loc,
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )

    # Olhos amendoados expressivos com íris violeta e brilho branco
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_dark_{tag}",
                2,
                0.115,
                (side * 0.22, -0.84, 1.56),
                rotation=(0.0, math.radians(side * -14.0), math.radians(side * -24.0)),
                scale=(0.88, 0.48, 1.08),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.072,
                (side * 0.23, -0.89, 1.54),
                rotation=(0.0, 0.0, math.radians(side * -22.0)),
                scale=(0.82, 0.40, 0.94),
            ),
            mat_prefix,
            "eye_violet",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.036,
                (side * 0.20, -0.92, 1.60),
                scale=(0.85, 0.45, 0.95),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # 5. ORELHAS MUITO LONGAS E PONTUDAS VOLTADAS PARA TRÁS COM INTERIOR ESCURO
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Lâmina externa amarela
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_outer_{tag}",
                6,
                0.22,
                0.02,
                1.02,
                (side * 0.42, -0.22, 2.02),
                rotation=(math.radians(38.0), math.radians(side * 28.0), math.radians(side * -12.0)),
                scale=(1.0, 0.44, 1.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # Interior roxo-escuro profundo voltado para frente
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_inner_{tag}",
                5,
                0.145,
                0.015,
                0.76,
                (side * 0.41, -0.27, 2.00),
                rotation=(math.radians(38.0), math.radians(side * 28.0), math.radians(side * -12.0)),
                scale=(0.94, 0.34, 1.0),
            ),
            mat_prefix,
            "ear_inner",
            pal,
        )
        # Entalhe lateral característico da orelha do Jolteon
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_notch_{tag}",
                4,
                0.09,
                0.012,
                0.28,
                (side * 0.56, -0.18, 2.04),
                rotation=(math.radians(48.0), math.radians(side * 54.0), 0.0),
                scale=(0.85, 0.45, 1.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )

    # 6. QUATRO PATAS ESGUIAS E ÁGEIS APOIADAS EXATAMENTE EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Patas dianteiras
        _add_part(
            parts,
            create_cone(
                f"_tmp_fleg_upper_{tag}",
                8,
                0.12,
                0.18,
                0.48,
                (side * 0.25, -0.32, 0.62),
                rotation=(math.radians(-6.0), math.radians(side * -4.0), 0.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fleg_lower_{tag}",
                8,
                0.095,
                0.125,
                0.44,
                (side * 0.25, -0.36, 0.25),
                rotation=(math.radians(4.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_fpaw_{tag}",
                2,
                0.12,
                (side * 0.25, -0.43, 0.075),
                scale=(0.94, 1.24, 0.64),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )

        # Patas traseiras anguladas (coxa -> canela -> pata)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.22,
                (side * 0.26, 0.44, 0.72),
                rotation=(math.radians(-22.0), 0.0, 0.0),
                scale=(0.82, 1.18, 1.28),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_hleg_shin_{tag}",
                8,
                0.10,
                0.145,
                0.42,
                (side * 0.27, 0.56, 0.40),
                rotation=(math.radians(-26.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_hleg_ankle_{tag}",
                8,
                0.095,
                0.11,
                0.32,
                (side * 0.27, 0.54, 0.18),
                rotation=(math.radians(24.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hpaw_{tag}",
                2,
                0.12,
                (side * 0.27, 0.44, 0.075),
                scale=(0.94, 1.26, 0.64),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 135. Voltspike lado a lado."""
    specs = [
        ("Voltspike_Shiny", (-8.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Voltspike_Normal", (-5.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Voltspike_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Voltspike_Gigante", (4.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Voltspike_Dourada_SuperRara", (11.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_voltspike(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
