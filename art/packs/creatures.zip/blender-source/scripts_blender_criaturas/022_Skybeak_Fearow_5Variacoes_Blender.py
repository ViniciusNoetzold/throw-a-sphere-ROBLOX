"""
022_Skybeak_Fearow_5Variacoes_Blender.py
========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "022. Skybeak — Condor de Bico Longo (Ref: Fearow)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Skybeak_Shiny (1.0x - Paleta Shiny / Shyne Oliva-Dourado + Crista Rubi + Pontas Creme)
  2. Skybeak_Normal (1.0x - Corpo Marrom-Escuro + Crista Vermelha + Gola Creme + Bico Longo)
  3. Skybeak_Grande (1.35x - Normal)
  4. Skybeak_Gigante (1.85x - Normal)
  5. Skybeak_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Garras/pés alinhados exatamente em `Z = 0.0` e frente/bico apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Skybeak_Shiny`, `Skybeak_Normal`, `Skybeak_Grande`,
     `Skybeak_Gigante`, `Skybeak_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_brown": (0.58, 0.38, 0.24, 1.0),
        "crest_red": (0.86, 0.22, 0.24, 1.0),
        "collar_cream": (0.95, 0.88, 0.68, 1.0),
        "beak_beige": (0.92, 0.76, 0.64, 1.0),
        "eye_dark": (0.12, 0.10, 0.12, 1.0),
        "claw_white": (0.98, 0.98, 0.99, 1.0),
    },
    "shiny_palette": {
        "body_brown": (0.68, 0.66, 0.22, 1.0),
        "crest_red": (0.88, 0.28, 0.22, 1.0),
        "collar_cream": (0.98, 0.95, 0.68, 1.0),
        "beak_beige": (0.94, 0.80, 0.48, 1.0),
        "eye_dark": (0.14, 0.12, 0.10, 1.0),
        "claw_white": (0.99, 0.99, 0.94, 1.0),
    },
    "golden_super_rare_palette": {
        "body_brown": (0.98, 0.78, 0.14, 1.0),
        "crest_red": (0.96, 0.56, 0.08, 1.0),
        "collar_cream": (1.00, 0.95, 0.58, 1.0),
        "beak_beige": (0.92, 0.72, 0.20, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "claw_white": (1.00, 0.99, 0.90, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha as garras em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_skybeak(
    name: str = "Skybeak_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 022. Skybeak (Ref: Fearow):
      - Frente/bico longo apontando para -Y e garras tocando Z = 0.0
      - Grande ave de rapina marrom-escura com colarinho creme eriçado no dorso/pescoço
      - Pescoço longo estendido, crista vermelha de 4 picos pontiagudos e bico muito longo em lança
      - Grande envergadura de asas marrons com pontas das penas em creme + cauda em leque
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_SkyB_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_SkyB_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_SkyB_Norm"

    parts = []

    # 1. TORSO MARROM + COLARINHO CREME ERIÇADO
    _add_part(
        parts,
        create_icosphere("_tmp_torso_main", 1, 0.56, (0.0, 0.14, 0.96), scale=(0.94, 1.24, 0.90)),
        mat_prefix,
        "body_brown",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_chest_tuft", (0.80, 0.52, 0.52), (0.0, -0.26, 0.96), rotation=(math.radians(12.0), 0.0, 0.0)),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Colarinho creme eriçado na base do pescoço/costas
    collar_spikes = [
        (-0.34, -0.02, 1.38, -22.0, -24.0),
        (0.0, 0.04, 1.46, -28.0, 0.0),
        (0.34, -0.02, 1.38, -22.0, 24.0),
        (-0.24, 0.24, 1.42, -38.0, -16.0),
        (0.24, 0.24, 1.42, -38.0, 16.0),
    ]
    for idx, (cx, cy, cz, rx, ry) in enumerate(collar_spikes):
        _add_part(
            parts,
            create_cone(
                f"_tmp_collar_{idx}",
                4,
                0.20,
                0.025,
                0.44,
                (cx, cy, cz),
                rotation=(math.radians(rx), math.radians(ry), math.radians(45.0)),
            ),
            mat_prefix,
            "collar_cream",
            pal,
        )

    # 2. PESCOÇO LONGO, CABEÇA, CRISTA VERMELHA DE 4 PICOS E BICO MUITO LONGO
    _add_part(
        parts,
        create_cylinder(
            "_tmp_neck_lower",
            6,
            0.18,
            0.54,
            (0.0, -0.44, 1.36),
            rotation=(math.radians(42.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_neck_upper",
            6,
            0.15,
            0.48,
            (0.0, -0.78, 1.56),
            rotation=(math.radians(68.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_head_main", (0.56, 0.64, 0.46), (0.0, -1.04, 1.62)),
        mat_prefix,
        "body_brown",
        pal,
    )

    # Crista vermelha pontiaguda de 4 picos (assinatura do Fearow)
    crest_specs = [
        ((0.0, -1.24, 1.98), (12.0, 0.0, 45.0), 0.11, 0.42),
        ((0.0, -1.04, 2.08), (-8.0, 0.0, 45.0), 0.13, 0.52),
        ((0.0, -0.84, 2.02), (-26.0, 0.0, 45.0), 0.12, 0.46),
        ((0.0, -0.68, 1.90), (-44.0, 0.0, 45.0), 0.10, 0.36),
    ]
    for idx, (loc, rot, rad, depth) in enumerate(crest_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_crest_red_{idx}",
                4,
                rad,
                0.018,
                depth,
                loc,
                rotation=tuple(math.radians(a) for a in rot),
                scale=(0.65, 1.0, 1.0),
            ),
            mat_prefix,
            "crest_red",
            pal,
        )

    # Bico muito longo e afiado em lança
    _add_part(
        parts,
        create_cone(
            "_tmp_beak_long_upper",
            4,
            0.15,
            0.02,
            1.02,
            (0.0, -1.78, 1.56),
            rotation=(math.radians(96.0), 0.0, math.radians(45.0)),
            scale=(0.82, 1.0, 1.0),
        ),
        mat_prefix,
        "beak_beige",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_beak_long_lower",
            4,
            0.11,
            0.02,
            0.66,
            (0.0, -1.58, 1.40),
            rotation=(math.radians(108.0), 0.0, math.radians(45.0)),
            scale=(0.78, 1.0, 1.0),
        ),
        mat_prefix,
        "beak_beige",
        pal,
    )

    # Olhos ferozes
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_eye_white_{tag}", (0.12, 0.22, 0.15), (side * 0.25, -1.16, 1.66)),
            mat_prefix,
            "claw_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_pupil_{tag}", (0.12, 0.10, 0.12), (side * 0.27, -1.20, 1.66)),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # 3. GRANDES ASAS MARRONS EM LEQUE COM PONTAS CREME + CAUDA EM LEQUE
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_inner_{tag}",
                (1.10, 0.36, 0.72),
                (side * 0.90, 0.16, 1.38),
                rotation=(math.radians(14.0), math.radians(side * -24.0), math.radians(side * 10.0)),
            ),
            mat_prefix,
            "body_brown",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_outer_{tag}",
                (0.96, 0.28, 0.84),
                (side * 1.58, 0.24, 1.76),
                rotation=(math.radians(12.0), math.radians(side * -34.0), math.radians(side * 12.0)),
            ),
            mat_prefix,
            "body_brown",
            pal,
        )
        for p_idx, (dx, dz, rot_y) in enumerate([(0.0, 0.26, 44.0), (0.08, 0.02, 56.0), (0.02, -0.22, 68.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_wing_tip_{tag}_{p_idx}",
                    4,
                    0.18,
                    0.03,
                    0.66,
                    (side * (2.10 + dx), 0.28, 2.02 + dz),
                    rotation=(math.radians(10.0), math.radians(side * rot_y), math.radians(side * 12.0)),
                    scale=(0.55, 0.65, 1.0),
                ),
                mat_prefix,
                "collar_cream",
                pal,
            )

    for t_idx, (tx, rz) in enumerate([(-0.30, -24.0), (-0.10, -8.0), (0.10, 8.0), (0.30, 24.0)]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_tail_{t_idx}",
                (0.20, 0.92, 0.10),
                (tx, 1.06, 0.88),
                rotation=(math.radians(16.0), 0.0, math.radians(rz)),
            ),
            mat_prefix,
            "body_brown",
            pal,
        )

    # 4. PERNAS E GARRAS PODEROSAS TOCANDO Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_thigh_{tag}", (0.28, 0.30, 0.32), (side * 0.32, 0.06, 0.56)),
            mat_prefix,
            "body_brown",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(f"_tmp_leg_{tag}", 6, 0.09, 0.44, (side * 0.32, 0.02, 0.28)),
            mat_prefix,
            "beak_beige",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{tag}", (0.30, 0.36, 0.10), (side * 0.32, -0.06, 0.05)),
            mat_prefix,
            "beak_beige",
            pal,
        )
        for c_idx, (dx, dy) in enumerate([(-0.11, -0.26), (0.0, -0.32), (0.11, -0.26)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_claw_{tag}_{c_idx}",
                    4,
                    0.048,
                    0.012,
                    0.18,
                    (side * 0.32 + dx, dy, 0.05),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 022. Skybeak lado a lado."""
    specs = [
        ("Skybeak_Shiny", (-12.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Skybeak_Normal", (-6.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Skybeak_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Skybeak_Gigante", (6.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Skybeak_Dourada_SuperRara", (17.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_skybeak(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
