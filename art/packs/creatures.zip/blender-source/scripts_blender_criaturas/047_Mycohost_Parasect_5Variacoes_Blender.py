"""
047_Mycohost_Parasect_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "047. Mycohost — Caranguejo Fúngico (Ref: Parasect)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Mycohost_Shiny (1.0x - Corpo Laranja-Rubi + Chapéu Gigante Âmbar-Dourado com Pintas Creme)
  2. Mycohost_Normal (1.0x - Corpo Laranja-Ocre + Olhos Brancos Vazios + Enorme Cogumelo Rosa-Rubi Pintalgado)
  3. Mycohost_Grande (1.35x - Normal)
  4. Mycohost_Gigante (1.85x - Normal)
  5. Mycohost_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Pintas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para a cúpula gigante do cogumelo + garras em foice)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Garras e patas alinhadas exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_orange": (0.91, 0.53, 0.28, 1.0),
        "body_shade": (0.76, 0.42, 0.22, 1.0),
        "cap_rose": (0.83, 0.37, 0.51, 1.0),
        "cap_spot": (0.98, 0.80, 0.22, 1.0),
        "under_dark": (0.14, 0.11, 0.12, 1.0),
        "eye_blank": (0.95, 0.96, 1.00, 1.0),
        "eye_rim": (0.20, 0.18, 0.22, 1.0),
    },
    "shiny_palette": {
        "body_orange": (0.90, 0.36, 0.18, 1.0),
        "body_shade": (0.72, 0.26, 0.14, 1.0),
        "cap_rose": (0.94, 0.62, 0.16, 1.0),
        "cap_spot": (0.99, 0.93, 0.58, 1.0),
        "under_dark": (0.18, 0.12, 0.10, 1.0),
        "eye_blank": (0.96, 0.97, 1.00, 1.0),
        "eye_rim": (0.24, 0.16, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "body_orange": (0.94, 0.72, 0.12, 1.0),
        "body_shade": (0.78, 0.56, 0.08, 1.0),
        "cap_rose": (0.98, 0.78, 0.14, 1.0),
        "cap_spot": (0.10, 0.92, 1.00, 1.0),
        "under_dark": (0.42, 0.28, 0.06, 1.0),
        "eye_blank": (0.10, 0.92, 1.00, 1.0),
        "eye_rim": (0.06, 0.52, 0.68, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_mycohost(
    name: str = "Mycohost_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 047. Mycohost (Ref: Parasect):
      - Gigantesca cúpula de cogumelo em forma de sino cobrindo todo o dorso (base larga + topo alto)
      - Grandes manchas ovais horizontais amarelo-vivo por toda a cúpula
      - Interior escuro sob a aba do cogumelo de onde sai o corpo laranja do inseto
      - Cabeça larga com 2 olhos grandes totalmente brancos vazios (sem pupila!) e boca larga
      - 2 enormes pinças/garras dianteiras em foice com dente interno + 4 patas longas articuladas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Myco_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Myco_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Myco_Norm"

    parts = []

    # 1. GIGANTESCA CÚPULA DE COGUMELO EM FORMA DE SINO
    # Aba inferior larga do sino (levemente elevada na frente para revelar os olhos brancos inteiros!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_cap_skirt",
            2,
            1.14,
            (0.0, 0.22, 1.26),
            rotation=(math.radians(-6.0), 0.0, 0.0),
            scale=(1.14, 1.06, 0.54),
        ),
        mat_prefix,
        "cap_rose",
        pal,
    )
    # Corpo intermediário do cogumelo afunilando para cima
    _add_part(
        parts,
        create_cone(
            "_tmp_cap_mid",
            10,
            1.12,
            0.70,
            0.88,
            (0.0, 0.24, 1.60),
            rotation=(math.radians(-4.0), 0.0, 0.0),
            scale=(1.06, 1.04, 1.0),
        ),
        mat_prefix,
        "cap_rose",
        pal,
    )
    # Cúpula superior arredondada bem alta (assinatura do Parasect!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_cap_dome",
            2,
            0.74,
            (0.0, 0.28, 1.98),
            rotation=(math.radians(-4.0), 0.0, 0.0),
            scale=(1.02, 1.02, 0.88),
        ),
        mat_prefix,
        "cap_rose",
        pal,
    )
    # Sombra/cavidade escura por baixo da aba do cogumelo
    _add_part(
        parts,
        create_icosphere(
            "_tmp_under_shadow",
            2,
            0.86,
            (0.0, 0.14, 0.94),
            scale=(1.10, 1.02, 0.44),
        ),
        mat_prefix,
        "under_dark",
        pal,
    )

    # Manchas amarelas horizontais largas distribuídas ao redor de toda a cúpula
    cap_spots = [
        # (loc, rot_deg, scale)
        ((-0.08, -0.78, 1.56), (26.0, 0.0, -6.0), (0.34, 0.14, 0.14)),
        ((-0.78, -0.66, 1.24), (24.0, -24.0, -34.0), (0.28, 0.14, 0.13)),
        ((0.68, -0.68, 1.24), (24.0, 22.0, 32.0), (0.28, 0.14, 0.13)),
        ((0.52, -0.44, 1.88), (18.0, 26.0, 22.0), (0.26, 0.14, 0.13)),
        ((-0.56, -0.26, 1.92), (16.0, -32.0, -24.0), (0.24, 0.14, 0.13)),
        ((-0.02, -0.14, 2.46), (-8.0, 0.0, 0.0), (0.26, 0.22, 0.11)),
        ((0.96, 0.18, 1.38), (8.0, 42.0, 74.0), (0.28, 0.14, 0.14)),
        ((-0.98, 0.16, 1.38), (8.0, -42.0, -74.0), (0.28, 0.14, 0.14)),
        ((0.72, 0.68, 1.72), (-22.0, 28.0, 40.0), (0.26, 0.14, 0.13)),
        ((-0.68, 0.72, 1.68), (-22.0, -28.0, -40.0), (0.26, 0.14, 0.13)),
        ((0.0, 0.94, 1.36), (-28.0, 0.0, 0.0), (0.32, 0.14, 0.14)),
    ]
    for s_i, (loc, rot_d, sc) in enumerate(cap_spots):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_cspot_{s_i}",
                1,
                1.0,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
                scale=sc,
            ),
            mat_prefix,
            "cap_spot",
            pal,
        )

    # 2. CORPO E CABEÇA LARANJA DO INSETO SOB A ABA FRONTAL
    _add_part(
        parts,
        create_icosphere("_tmp_body_belly", 2, 0.56, (0.0, -0.12, 0.66), scale=(1.04, 1.06, 0.64)),
        mat_prefix,
        "body_shade",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_head_jaw", 2, 0.42, (0.0, -0.58, 0.78), scale=(1.18, 0.92, 0.62)),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Linha sutil da boca curva
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_line", 1, 0.34, (0.0, -0.76, 0.70), scale=(1.12, 0.48, 0.16)),
        mat_prefix,
        "under_dark",
        pal,
    )
    # Lábio inferior laranja para dar o sorriso largo do Parasect
    _add_part(
        parts,
        create_icosphere("_tmp_chin", 2, 0.34, (0.0, -0.72, 0.66), scale=(1.10, 0.74, 0.34)),
        mat_prefix,
        "body_orange",
        pal,
    )

    # DOIS OLHOS GRANDES TOTALMENTE BRANCOS VAZIOS (MARCA REGISTRADA DO PARASECT)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_rim_{tag}",
                1,
                0.225,
                (side * 0.23, -0.84, 0.94),
                scale=(1.00, 0.82, 1.04),
            ),
            mat_prefix,
            "eye_rim",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_blank_{tag}",
                2,
                0.215,
                (side * 0.23, -0.88, 0.94),
                scale=(0.98, 0.86, 1.02),
            ),
            mat_prefix,
            "eye_blank",
            pal,
        )

    # 3. DUAS ENORMES PINÇAS/GARRAS EM FOICE COM ESPORÃO INTERNO (APOIADAS EM Z = 0.0)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Articulação do braço saindo da cavidade
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_joint_{tag}",
                6,
                0.14,
                0.18,
                0.38,
                (side * 0.62, -0.44, 0.82),
                rotation=(math.radians(22.0), math.radians(side * 58.0), 0.0),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )
        # Lâmina superior larga e curva da pinça
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pincer_main_{tag}",
                2,
                0.36,
                (side * 0.90, -0.78, 0.56),
                rotation=(math.radians(28.0), math.radians(side * 12.0), math.radians(side * -14.0)),
                scale=(0.76, 1.02, 1.48),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        # Ponta inferior da foice descendo até Z = 0.0
        _add_part(
            parts,
            create_cone(
                f"_tmp_pincer_tip_{tag}",
                6,
                0.20,
                0.025,
                0.56,
                (side * 0.92, -0.96, 0.22),
                rotation=(math.radians(156.0), math.radians(side * -8.0), 0.0),
                scale=(0.82, 1.06, 1.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        # Dente/esporão interno da garra (detalhe fiel à referência)
        _add_part(
            parts,
            create_cone(
                f"_tmp_pincer_spur_{tag}",
                5,
                0.11,
                0.02,
                0.30,
                (side * 0.72, -0.84, 0.34),
                rotation=(math.radians(152.0), math.radians(side * 24.0), 0.0),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )

    # 4. QUATRO PATAS LONGAS ARTICULADAS SAINDO DEBAIXO DO COGUMELO ATÉ Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        for l_idx, (ly_hip, ly_knee, ly_foot, x_out) in enumerate([
            (0.06, 0.02, -0.04, 1.06),
            (0.46, 0.54, 0.62, 1.12),
        ]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_leg_u_{tag}_{l_idx}",
                    6,
                    0.10,
                    0.08,
                    0.56,
                    (side * 0.76, ly_hip, 0.66),
                    rotation=(0.0, math.radians(side * 76.0), 0.0),
                ),
                mat_prefix,
                "body_orange",
                pal,
            )
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_knee_{tag}_{l_idx}",
                    1,
                    0.09,
                    (side * x_out, ly_knee, 0.68),
                ),
                mat_prefix,
                "body_orange",
                pal,
            )
            _add_part(
                parts,
                create_cone(
                    f"_tmp_leg_d_{tag}_{l_idx}",
                    6,
                    0.03,
                    0.085,
                    0.72,
                    (side * (x_out + 0.10), ly_foot, 0.34),
                    rotation=(math.radians(6.0), math.radians(side * -14.0), 0.0),
                ),
                mat_prefix,
                "body_orange",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 047. Mycohost lado a lado."""
    specs = [
        ("Mycohost_Shiny", (-10.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Mycohost_Normal", (-6.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Mycohost_Grande", (-1.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Mycohost_Gigante", (4.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Mycohost_Dourada_SuperRara", (12.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_mycohost(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
