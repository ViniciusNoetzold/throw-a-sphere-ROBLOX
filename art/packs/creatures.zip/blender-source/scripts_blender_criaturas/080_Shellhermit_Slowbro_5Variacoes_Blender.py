"""
080_Shellhermit_Slowbro_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "080. Shellhermit — Eremita da Concha (Ref: Slowbro)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Shellhermit_Shiny (1.0x - Paleta Shiny Corpo Roxo-Violeta + Concha Dourada/Castanha!)
  2. Shellhermit_Normal (1.0x - Bípede Rosa + Barriga Listrada Creme + Concha Espiral com Olhos na Cauda)
  3. Shellhermit_Grande (1.35x - Normal)
  4. Shellhermit_Gigante (1.85x - Normal)
  5. Shellhermit_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Garras e Espinhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (corpo bípede em pêra + concha espiral espinhosa mordendo a cauda)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e rosto/concha visíveis apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_pink": (0.94, 0.60, 0.70, 1.0),
        "body_shade": (0.80, 0.46, 0.56, 1.0),
        "belly_cream": (0.94, 0.90, 0.78, 1.0),
        "belly_stripe": (0.76, 0.70, 0.56, 1.0),
        "mouth_deep": (0.52, 0.30, 0.38, 1.0),
        "tongue_pink": (0.88, 0.58, 0.68, 1.0),
        "shell_grey": (0.68, 0.76, 0.82, 1.0),
        "shell_spot": (0.48, 0.56, 0.64, 1.0),
        "shell_inside": (0.28, 0.22, 0.28, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "pupil_dark": (0.10, 0.10, 0.12, 1.0),
        "claw_white": (0.98, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_pink": (0.58, 0.42, 0.78, 1.0),
        "body_shade": (0.44, 0.30, 0.64, 1.0),
        "belly_cream": (0.94, 0.90, 0.78, 1.0),
        "belly_stripe": (0.76, 0.70, 0.56, 1.0),
        "mouth_deep": (0.44, 0.26, 0.40, 1.0),
        "tongue_pink": (0.84, 0.54, 0.68, 1.0),
        "shell_grey": (0.76, 0.66, 0.46, 1.0),
        "shell_spot": (0.56, 0.46, 0.28, 1.0),
        "shell_inside": (0.28, 0.22, 0.18, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "pupil_dark": (0.10, 0.10, 0.12, 1.0),
        "claw_white": (0.98, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_pink": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.62, 0.10, 1.0),
        "belly_cream": (1.00, 0.92, 0.48, 1.0),
        "belly_stripe": (0.86, 0.68, 0.18, 1.0),
        "mouth_deep": (0.56, 0.36, 0.06, 1.0),
        "tongue_pink": (0.98, 0.84, 0.32, 1.0),
        "shell_grey": (0.90, 0.68, 0.12, 1.0),
        "shell_spot": (0.10, 0.92, 1.00, 1.0),
        "shell_inside": (0.36, 0.24, 0.04, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.32, 0.48, 1.0),
        "claw_white": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha os pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_shellhermit(
    name: str = "Shellhermit_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 080. Shellhermit (Ref: Slowbro):
      - Corpo bípede robusto em formato de pêra rosa com barriga larga listrada creme
      - Rosto bobo amigável: olhos ovais verticais brancos com pupilas pontuais, focinho creme e sorriso aberto
      - Orelhinhas redondas no topo, braços rechonchudos com 3 garras e patas fortes com 2 garras em Z = 0.0
      - ENORME concha espiral cinza-azulada com espinhos, manchas, dentes e olhos carrancudos mordendo a cauda à direita!
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Sbro_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Sbro_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Sbro_Norm"

    parts = []
    # Ligeiro deslocamento do corpo para a esquerda (-X = -0.26) para equilibrar a concha gigante à direita (+X)
    bx = -0.26

    # 1. CORPO BÍPEDE ROBUSTO EM FORMATO DE PÊRA + BARRIGA LISTRADA CREME
    _add_part(
        parts,
        create_icosphere("_tmp_belly_body", 2, 0.74, (bx, 0.04, 0.88), scale=(1.04, 0.92, 1.06)),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Tronco superior / pescoço grosso unificado com a cabeça
    _add_part(
        parts,
        create_cone("_tmp_torso_upper", 8, 0.62, 0.46, 0.96, (bx, 0.02, 1.62), scale=(1.00, 0.88, 1.0)),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Placa da barriga creme arredondada
    _add_part(
        parts,
        create_icosphere("_tmp_belly_cream", 2, 0.62, (bx, -0.22, 0.84), scale=(0.98, 0.76, 0.94)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # 4 listras horizontais da barriga
    for s_i, (sz, sx) in enumerate([(1.12, 0.48), (0.94, 0.56), (0.76, 0.56), (0.58, 0.46)]):
        _add_part(
            parts,
            create_icosphere(f"_tmp_belly_stripe_{s_i}", 1, 0.06, (bx, -0.64 + abs(sz - 0.85) * 0.24, sz), scale=(sx / 0.06, 0.78, 0.52)),
            mat_prefix,
            "belly_stripe",
            pal,
        )

    # 2. CABEÇA ARREDONDADA + ORELHAS + ROSTO SONOLENTO SORRIDENTE
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.48, (bx, -0.02, 2.08), scale=(1.02, 0.94, 0.94)),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Focinho largo creme
    _add_part(
        parts,
        create_icosphere("_tmp_snout_top", 2, 0.34, (bx, -0.44, 1.98), scale=(1.24, 0.78, 0.52)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_snout_jaw", 2, 0.28, (bx, -0.40, 1.76), scale=(1.14, 0.72, 0.40)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # Boca aberta + língua rosa + 2 dentinhos brancos
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_cav", 2, 0.24, (bx, -0.48, 1.86), scale=(1.06, 0.46, 0.48)),
        mat_prefix,
        "mouth_deep",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_tongue", 1, 0.17, (bx, -0.52, 1.81), scale=(1.00, 0.42, 0.34)),
        mat_prefix,
        "tongue_pink",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(f"_tmp_fang_{tag}", 4, 0.034, 0.008, 0.08, (bx + side * 0.20, -0.60, 1.91), rotation=(math.radians(180.0), 0.0, 0.0)),
            mat_prefix,
            "claw_white",
            pal,
        )
        # Narinas
        _add_part(
            parts,
            create_cube(f"_tmp_nostril_{tag}", (0.032, 0.04, 0.024), (bx + side * 0.09, -0.69, 2.02)),
            mat_prefix,
            "pupil_dark",
            pal,
        )
        # Olhos ovais verticais brancos + pupilas pontuais
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.15,
                (bx + side * 0.24, -0.40, 2.22),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(0.76, 0.56, 1.24),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_pupil_{tag}", 1, 0.028, (bx + side * 0.25, -0.48, 2.24)),
            mat_prefix,
            "pupil_dark",
            pal,
        )
        # Orelha redonda enrolada
        _add_part(
            parts,
            create_icosphere(f"_tmp_ear_{tag}", 2, 0.20, (bx + side * 0.38, -0.02, 2.46), scale=(1.00, 0.58, 1.00)),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(f"_tmp_ear_in_{tag}", 8, 0.09, 0.05, (bx + side * 0.38, -0.13, 2.46), rotation=(math.radians(90.0), 0.0, 0.0)),
            mat_prefix,
            "body_shade",
            pal,
        )

    # 3. BRAÇOS RECHONCHUDOS NA FRENTE DA BARRIGA + 3 GARRAS BRANCAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_{tag}",
                8,
                0.20,
                0.16,
                0.68,
                (bx + side * 0.44, -0.42, 1.28),
                rotation=(math.radians(24.0), math.radians(side * -14.0), 0.0),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_hand_{tag}", 2, 0.16, (bx + side * 0.38, -0.58, 0.98)),
            mat_prefix,
            "body_pink",
            pal,
        )
        for c_i, dx in enumerate([-0.08, 0.0, 0.08]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hclaw_{tag}_{c_i}",
                    4,
                    0.036,
                    0.008,
                    0.11,
                    (bx + side * 0.38 + dx, -0.68, 0.90),
                    rotation=(math.radians(152.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 4. PERNAS GROSSAS + PÉS LARGOS COM 2 GARRAS BRANCAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(f"_tmp_thigh_{tag}", 2, 0.36, (bx + side * 0.50, -0.10, 0.56), scale=(0.94, 1.02, 1.12)),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_foot_{tag}", 2, 0.28, (bx + side * 0.52, -0.24, 0.16), scale=(1.04, 1.28, 0.56)),
            mat_prefix,
            "body_pink",
            pal,
        )
        for c_i, (dx, rz_d) in enumerate([(-0.11, -12.0), (0.11, 12.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_fclaw_{tag}_{c_i}",
                    5,
                    0.075,
                    0.012,
                    0.22,
                    (bx + side * 0.52 + dx, -0.54, 0.10),
                    rotation=(math.radians(-82.0), 0.0, math.radians(rz_d)),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 5. CAUDA ROSA + ENORME CONCHA ESPIRAL ESPINHOSA COM OLHOS MORDENDO A CAUDA À DIREITA (+X)!
    # Base grossa da cauda rosa entrando na boca da concha à direita
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_base",
            8,
            0.34,
            0.24,
            0.72,
            (bx + 0.66, 0.24, 0.64),
            rotation=(math.radians(-12.0), math.radians(78.0), math.radians(16.0)),
        ),
        mat_prefix,
        "body_pink",
        pal,
    )

    # Boca/cavidade escura da concha mordendo a cauda
    shell_x, shell_y = bx + 1.06, 0.30
    _add_part(
        parts,
        create_icosphere("_tmp_shell_mouth", 2, 0.44, (shell_x - 0.14, shell_y - 0.06, 0.68), scale=(0.90, 0.96, 0.92)),
        mat_prefix,
        "shell_inside",
        pal,
    )
    # Mandíbula inferior curva da concha
    _add_part(
        parts,
        create_icosphere("_tmp_shell_jaw", 2, 0.48, (shell_x, shell_y + 0.04, 0.46), scale=(1.12, 1.04, 0.58)),
        mat_prefix,
        "shell_grey",
        pal,
    )
    # Dentes brancos da concha cravados na cauda
    for t_i, (tx, ty, tz) in enumerate([
        (shell_x - 0.32, shell_y - 0.28, 0.80),
        (shell_x - 0.14, shell_y - 0.36, 0.78),
        (shell_x + 0.06, shell_y - 0.34, 0.80),
    ]):
        _add_part(
            parts,
            create_cone(f"_tmp_shell_tooth_{t_i}", 4, 0.055, 0.012, 0.14, (tx, ty, tz), rotation=(math.radians(180.0), 0.0, 0.0)),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 3 andares espiralados da concha gigante subindo atrás/à direita
    # Andar 1 (rosto da concha)
    _add_part(
        parts,
        create_icosphere("_tmp_shell_tier1", 2, 0.58, (shell_x + 0.02, shell_y + 0.06, 1.02), scale=(1.08, 1.04, 0.88)),
        mat_prefix,
        "shell_grey",
        pal,
    )
    # Andar 2 (espiral média)
    _add_part(
        parts,
        create_icosphere("_tmp_shell_tier2", 2, 0.48, (shell_x + 0.10, shell_y + 0.12, 1.48), scale=(1.04, 1.00, 0.86)),
        mat_prefix,
        "shell_grey",
        pal,
    )
    # Andar 3 (ponta cônica espiral no topo)
    _add_part(
        parts,
        create_cone(
            "_tmp_shell_tier3",
            7,
            0.34,
            0.06,
            0.64,
            (shell_x + 0.14, shell_y + 0.14, 1.98),
            rotation=(math.radians(-6.0), math.radians(12.0), 0.0),
        ),
        mat_prefix,
        "shell_grey",
        pal,
    )

    # Olhos carrancudos da concha olhando para a frente (-Y) com sobrancelha rígida
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_shell_brow_{tag}",
                (0.26, 0.12, 0.08),
                (shell_x - 0.06 + side * 0.19, shell_y - 0.56, 1.13),
                rotation=(math.radians(8.0), math.radians(side * -22.0), math.radians(-10.0)),
            ),
            mat_prefix,
            "shell_grey",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_shell_eye_{tag}",
                (0.24, 0.10, 0.12),
                (shell_x - 0.06 + side * 0.19, shell_y - 0.55, 1.04),
                rotation=(0.0, math.radians(side * -16.0), math.radians(-10.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_shell_pupil_{tag}",
                (0.06, 0.08, 0.065),
                (shell_x - 0.06 + side * 0.17, shell_y - 0.60, 1.03),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # Espinhos cônicos e manchas cinza-escuro na concha espiral
    shell_spikes = [
        ((shell_x + 0.04, shell_y - 0.36, 1.42), 0.11, 0.34, 24.0, 0.0),
        ((shell_x + 0.56, shell_y + 0.04, 1.10), 0.11, 0.36, 0.0, 74.0),
        ((shell_x + 0.48, shell_y + 0.10, 1.62), 0.10, 0.32, 0.0, 56.0),
        ((shell_x - 0.24, shell_y + 0.12, 1.88), 0.10, 0.34, 0.0, -36.0),
        ((shell_x + 0.24, shell_y + 0.20, 2.26), 0.09, 0.32, -10.0, 22.0),
    ]
    for sp_i, (loc, r1, dep, rx_d, ry_d) in enumerate(shell_spikes):
        _add_part(
            parts,
            create_cone(f"_tmp_shell_spike_{sp_i}", 6, r1, 0.014, dep, loc, rotation=(math.radians(rx_d), math.radians(ry_d), 0.0)),
            mat_prefix,
            "shell_grey",
            pal,
        )

    shell_spots = [
        ((shell_x + 0.26, shell_y - 0.38, 0.88), 0.12),
        ((shell_x + 0.28, shell_y - 0.26, 1.38), 0.10),
        ((shell_x + 0.16, shell_y - 0.18, 1.72), 0.09),
    ]
    for st_i, (loc, rad) in enumerate(shell_spots):
        _add_part(
            parts,
            create_icosphere(f"_tmp_shell_spot_{st_i}", 1, rad, loc, scale=(1.1, 0.45, 0.85)),
            mat_prefix,
            "shell_spot",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 080. Shellhermit lado a lado."""
    specs = [
        ("Shellhermit_Shiny", (-11.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Shellhermit_Normal", (-6.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Shellhermit_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Shellhermit_Gigante", (6.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Shellhermit_Dourada_SuperRara", (15.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_shellhermit(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
