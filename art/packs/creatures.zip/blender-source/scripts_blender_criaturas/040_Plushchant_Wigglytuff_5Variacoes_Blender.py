"""
040_Plushchant_Wigglytuff_5Variacoes_Blender.py
===============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "040. Plushchant — Coelho Balão (Ref: Wigglytuff)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Plushchant_Shiny (1.0x - Paleta Shiny Rosa-Lilás + Barriga Branca + Olhos Verde-Esmeralda)
  2. Plushchant_Normal (1.0x - Corpo Oval Rosa + Barriga Branca + Orelhas Longas de Coelho)
  3. Plushchant_Grande (1.35x - Normal)
  4. Plushchant_Gigante (1.85x - Normal)
  5. Plushchant_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + cones 6 lados para as longas orelhas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_pink": (0.98, 0.78, 0.86, 1.0),
        "body_shade": (0.86, 0.62, 0.74, 1.0),
        "belly_white": (0.99, 0.97, 0.98, 1.0),
        "ear_dark": (0.16, 0.16, 0.18, 1.0),
        "eye_iris": (0.08, 0.60, 0.74, 1.0),
        "eye_glow": (0.28, 0.82, 0.92, 1.0),
        "mouth_pink": (0.86, 0.44, 0.58, 1.0),
        "white": (1.00, 1.00, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_pink": (0.90, 0.76, 0.96, 1.0),
        "body_shade": (0.76, 0.60, 0.84, 1.0),
        "belly_white": (0.99, 0.98, 1.00, 1.0),
        "ear_dark": (0.16, 0.16, 0.20, 1.0),
        "eye_iris": (0.16, 0.76, 0.40, 1.0),
        "eye_glow": (0.44, 0.94, 0.60, 1.0),
        "mouth_pink": (0.84, 0.44, 0.64, 1.0),
        "white": (1.00, 1.00, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_pink": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.86, 0.62, 0.08, 1.0),
        "belly_white": (1.00, 0.96, 0.72, 1.0),
        "ear_dark": (0.08, 0.56, 0.72, 1.0),
        "eye_iris": (0.10, 0.92, 1.00, 1.0),
        "eye_glow": (0.64, 0.98, 1.00, 1.0),
        "mouth_pink": (0.82, 0.48, 0.08, 1.0),
        "white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_plushchant(
    name: str = "Plushchant_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de alta fidelidade do 040. Plushchant (Ref: Wigglytuff):
      - Corpo alto e fofo em formato de ovo-pelúcia rosa com grande barriga oval branca
      - Orelhas de coelho muito longas em V com interior preto/grafite alongado
      - Topete fofo em espiral no centro superior da cabeça
      - Enormes olhos azul-turquesa brilhantes e sorriso aberto fofo
      - Bracinhos curtos nas laterais e pezinhos ovais alinhados em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Plushchant_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Plushchant_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Plushchant_Norm"

    parts = []

    # 1. CORPO ALTO EM FORMATO OVO-PELÚCIA + BARRIGA BRANCA GRANDE
    _add_part(
        parts,
        create_icosphere("_tmp_body_top", 2, 0.88, (0.0, 0.02, 1.30), scale=(0.94, 0.86, 1.12)),
        mat_prefix,
        "body_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_body_bot", 2, 0.92, (0.0, 0.02, 0.86), scale=(1.04, 0.90, 0.84)),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Grande barriga oval branca bem proeminente na frente do tronco (marca registrada da Wigglytuff!)
    _add_part(
        parts,
        create_icosphere("_tmp_belly_white", 2, 0.76, (0.0, -0.34, 0.86), scale=(0.88, 0.72, 0.94)),
        mat_prefix,
        "belly_white",
        pal,
    )

    # 2. TOPETE ESPIRALADO NO TOPO DA TESTA
    tuft_nodes = [
        (0.34, (0.04, -0.26, 2.12), (1.06, 0.86, 0.98)),
        (0.28, (-0.12, -0.40, 2.02), (0.98, 0.84, 0.96)),
        (0.24, (0.06, -0.46, 1.92), (1.04, 0.78, 0.88)),
        (0.18, (0.14, -0.44, 2.04), (0.94, 0.76, 0.88)),
    ]
    for idx, (rad, loc, sc) in enumerate(tuft_nodes):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tuft_{idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "body_pink",
            pal,
        )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_tuft_shade",
            8,
            0.08,
            0.06,
            (0.02, -0.58, 2.00),
            rotation=(math.radians(90.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    # 3. ORELHAS LONGAS DE COELHO EM V COM INTERIOR ESCURO ALONGADO
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_base_{tag}",
                6,
                0.28,
                0.17,
                0.76,
                (side * 0.66, 0.02, 2.34),
                rotation=(math.radians(-6.0), math.radians(side * 34.0), math.radians(side * -8.0)),
                scale=(1.0, 0.44, 1.0),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_tip_{tag}",
                6,
                0.175,
                0.03,
                0.48,
                (side * 0.98, -0.01, 2.84),
                rotation=(math.radians(-6.0), math.radians(side * 34.0), math.radians(side * -8.0)),
                scale=(1.0, 0.42, 1.0),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        # Interior escuro alongado da orelha de coelho
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_in_{tag}",
                5,
                0.17,
                0.025,
                0.96,
                (side * 0.76, -0.09, 2.48),
                rotation=(math.radians(-6.0), math.radians(side * 34.0), math.radians(side * -8.0)),
                scale=(0.88, 0.24, 1.0),
            ),
            mat_prefix,
            "ear_dark",
            pal,
        )

    # 4. GRANDES OLHOS AZUL-TURQUESA BRILHANTES + SORRISO ALEGRE
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        ex = side * 0.34
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_sclera_{tag}",
                2,
                0.245,
                (ex, -0.68, 1.62),
                rotation=(0.0, 0.0, math.radians(side * -16.0)),
                scale=(0.98, 0.44, 1.08),
            ),
            mat_prefix,
            "white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_iris_{tag}",
                2,
                0.185,
                (ex * 0.96, -0.75, 1.62),
                rotation=(0.0, 0.0, math.radians(side * -16.0)),
                scale=(0.94, 0.38, 1.06),
            ),
            mat_prefix,
            "eye_iris",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_iris_glow_{tag}",
                1,
                0.09,
                (ex * 0.96, -0.80, 1.52),
                scale=(1.08, 0.28, 0.52),
            ),
            mat_prefix,
            "eye_glow",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.064,
                (ex * 0.88, -0.81, 1.70),
                scale=(0.92, 0.42, 0.92),
            ),
            mat_prefix,
            "white",
            pal,
        )

    # Sorriso aberto fofo logo acima da barriga branca
    _add_part(
        parts,
        create_icosphere(
            "_tmp_smile",
            1,
            0.135,
            (0.0, -0.80, 1.38),
            scale=(1.24, 0.32, 0.56),
        ),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # 5. BRACINHOS CURTOS DE PELÚCIA NAS LATERAIS
    _add_part(
        parts,
        create_icosphere(
            "_tmp_arm_L",
            2,
            0.22,
            (-0.88, -0.22, 1.16),
            rotation=(math.radians(-10.0), math.radians(18.0), math.radians(-14.0)),
            scale=(1.42, 0.72, 0.68),
        ),
        mat_prefix,
        "body_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_arm_R",
            2,
            0.22,
            (0.92, -0.14, 1.18),
            rotation=(math.radians(-10.0), math.radians(-22.0), math.radians(16.0)),
            scale=(1.42, 0.72, 0.68),
        ),
        mat_prefix,
        "body_pink",
        pal,
    )

    # 6. PEZINHOS DE COELHO OVAIS ALINHADOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.25,
                (side * 0.44, -0.16, 0.16),
                rotation=(0.0, 0.0, math.radians(side * -22.0)),
                scale=(0.88, 1.48, 0.64),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 040. Plushchant lado a lado."""
    specs = [
        ("Plushchant_Shiny", (-8.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Plushchant_Normal", (-4.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Plushchant_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Plushchant_Gigante", (4.5, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Plushchant_Dourada_SuperRara", (11.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_plushchant(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
