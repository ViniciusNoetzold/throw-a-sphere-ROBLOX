"""
105_Skullknight_Marowak_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "105. Skullknight — Guerreiro Ósseo (Ref: Marowak)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Skullknight_Shiny (1.0x - Corpo Verde-Esmeralda + Barriga Creme + Crânio e Osso Marfim)
  2. Skullknight_Normal (1.0x - Corpo Marrom-Terra + Crânio Dinossauro Fundido + Grande Osso Erguido)
  3. Skullknight_Grande (1.35x - Normal)
  4. Skullknight_Gigante (1.85x - Normal)
  5. Skullknight_Dourada_SuperRara (2.25x - Ouro Reluzente + Crânio Platina + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (crânio aerodinâmico de predador, barriga listrada, osso erguido em combate)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés alinhados exatamente em `Z = 0.0` e focinho apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_tan": (0.74, 0.56, 0.36, 1.0),
        "body_shade": (0.58, 0.42, 0.26, 1.0),
        "belly_cream": (0.95, 0.90, 0.76, 1.0),
        "belly_stripe": (0.42, 0.32, 0.22, 1.0),
        "bone_white": (0.94, 0.94, 0.96, 1.0),
        "bone_shade": (0.78, 0.78, 0.84, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_iris": (0.46, 0.30, 0.24, 1.0),
        "eye_dark": (0.12, 0.11, 0.14, 1.0),
    },
    "shiny_palette": {
        "body_tan": (0.46, 0.68, 0.28, 1.0),
        "body_shade": (0.34, 0.54, 0.18, 1.0),
        "belly_cream": (0.94, 0.93, 0.72, 1.0),
        "belly_stripe": (0.28, 0.42, 0.16, 1.0),
        "bone_white": (0.95, 0.95, 0.97, 1.0),
        "bone_shade": (0.80, 0.82, 0.86, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_iris": (0.44, 0.28, 0.22, 1.0),
        "eye_dark": (0.12, 0.11, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "body_tan": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.80, 0.58, 0.08, 1.0),
        "belly_cream": (1.00, 0.94, 0.64, 1.0),
        "belly_stripe": (0.64, 0.44, 0.06, 1.0),
        "bone_white": (1.00, 0.98, 0.88, 1.0),
        "bone_shade": (0.90, 0.80, 0.44, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "eye_iris": (0.06, 0.68, 0.84, 1.0),
        "eye_dark": (0.04, 0.36, 0.52, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_skullknight(
    name: str = "Skullknight_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel do 105. Skullknight (Ref: Marowak):
      - Corpo atlético bípede marrom-terra (verde na Shiny) com barriga creme segmentada por 3 listras
      - Crânio de dinossauro fundido à cabeça, focinho longo e afilado, 2 chifres afiados para trás
      - Olhos estreitos ferozes com íris marrom sob sobrancelhas angulares do crânio
      - Braço direito (-X) erguido acima da cabeça brandindo um GRANDE osso de batalha branco
      - Braço esquerdo (+X) estendido para equilíbrio com garra branca + cauda com pico na ponta
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Skullknight_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Skullknight_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Skullknight_Norm"

    parts = []

    # 1. TRONCO ATLÉTICO + BARRIGA CREME COM 3 LISTRAS HORIZONTAIS
    _add_part(
        parts,
        create_icosphere(
            "_tmp_torso",
            2,
            0.56,
            (0.0, 0.08, 0.80),
            rotation=(math.radians(-10.0), 0.0, 0.0),
            scale=(0.98, 0.90, 1.24),
        ),
        mat_prefix,
        "body_tan",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_belly",
            2,
            0.46,
            (0.0, -0.14, 0.76),
            rotation=(math.radians(-10.0), 0.0, 0.0),
            scale=(0.88, 0.68, 1.18),
        ),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # 3 linhas/faixas horizontais segmentadas da barriga (fiel ao Marowak!)
    for idx, (bz, bw) in enumerate([(0.98, 0.34), (0.76, 0.38), (0.54, 0.34)]):
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_belly_stripe_{idx}",
                10,
                bw,
                0.032,
                (0.0, -0.16, bz),
                rotation=(math.radians(-8.0), 0.0, 0.0),
                scale=(1.04, 0.76, 1.0),
            ),
            mat_prefix,
            "belly_stripe",
            pal,
        )

    # Pescoço inclinado para frente em postura de combate
    _add_part(
        parts,
        create_cone(
            "_tmp_neck",
            8,
            0.30,
            0.24,
            0.36,
            (0.0, -0.02, 1.38),
            rotation=(math.radians(-18.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    # 2. CRÂNIO AERODINÂMICO DE DINOSSAURO FUNDIDO À CABEÇA
    # Crânio principal mais alongado e agressivo que o do Cubone
    _add_part(
        parts,
        create_icosphere(
            "_tmp_skull_main",
            2,
            0.52,
            (0.0, -0.06, 1.66),
            rotation=(math.radians(14.0), 0.0, 0.0),
            scale=(1.00, 1.12, 0.88),
        ),
        mat_prefix,
        "bone_white",
        pal,
    )
    # Focinho longo e afilado de dinossauro apontando para frente-baixo (-Y)
    _add_part(
        parts,
        create_cone(
            "_tmp_skull_snout",
            6,
            0.38,
            0.18,
            0.84,
            (0.0, -0.60, 1.44),
            rotation=(math.radians(-68.0), 0.0, 0.0),
            scale=(0.86, 0.72, 1.0),
        ),
        mat_prefix,
        "bone_white",
        pal,
    )
    # Ponta arredondada do focinho + 2 fendas nasais sutis
    _add_part(
        parts,
        create_icosphere(
            "_tmp_snout_tip",
            2,
            0.20,
            (0.0, -0.94, 1.28),
            scale=(0.94, 0.96, 0.74),
        ),
        mat_prefix,
        "bone_white",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_nostril_slit_{tag}",
                (0.032, 0.14, 0.045),
                (side * 0.10, -0.92, 1.33),
                rotation=(math.radians(24.0), 0.0, math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Dois chifres pontiagudos inclinados para trás e cima
        _add_part(
            parts,
            create_cone(
                f"_tmp_horn_{tag}",
                6,
                0.17,
                0.025,
                0.56,
                (side * 0.40, 0.24, 2.04),
                rotation=(math.radians(34.0), math.radians(side * 38.0), 0.0),
            ),
            mat_prefix,
            "bone_white",
            pal,
        )
        # Placa angular da bochecha/mandíbula traseira do crânio
        _add_part(
            parts,
            create_cone(
                f"_tmp_jaw_plate_{tag}",
                5,
                0.24,
                0.06,
                0.42,
                (side * 0.44, 0.14, 1.44),
                rotation=(math.radians(48.0), math.radians(side * 56.0), 0.0),
                scale=(0.82, 0.70, 1.0),
            ),
            mat_prefix,
            "bone_shade",
            pal,
        )

    # 3. OLHOS FEROZES TRIANGULARES COM SOBRANCELHA DE CRÂNIO + ÍRIS MARROM
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Linha escura angular de sobrancelha (inclinada para o centro: olhar guerreiro!)
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.36, 0.055, 0.048),
                (side * 0.34, -0.44, 1.66),
                rotation=(math.radians(10.0), math.radians(-side * 22.0), math.radians(-side * 34.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Esclera branca estreita feroz
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_w_{tag}",
                (0.28, 0.06, 0.12),
                (side * 0.35, -0.44, 1.58),
                rotation=(math.radians(8.0), math.radians(-side * 16.0), math.radians(-side * 36.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Íris marrom-guerreiro
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.068,
                (side * 0.37, -0.48, 1.57),
                rotation=(0.0, 0.0, math.radians(-side * 36.0)),
                scale=(0.84, 0.42, 1.08),
            ),
            mat_prefix,
            "eye_iris",
            pal,
        )
        # Pupila preta
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.036,
                (side * 0.38, -0.50, 1.57),
                scale=(0.70, 0.38, 1.05),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # 4. BRAÇO DIREITO (-X) ERGUIDO COM GRANDE OSSO DE BATALHA ACIMA DA CABEÇA!
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R_up",
            7,
            0.16,
            0.13,
            0.54,
            (-0.46, 0.16, 1.52),
            rotation=(math.radians(18.0), math.radians(-18.0), 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R_fore",
            7,
            0.14,
            0.12,
            0.44,
            (-0.28, 0.22, 1.94),
            rotation=(math.radians(8.0), math.radians(24.0), 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hand_R", 1, 0.15, (-0.16, 0.24, 2.16)),
        mat_prefix,
        "body_shade",
        pal,
    )

    # GRANDE OSSO DE GUERREIRO SEGURADO DIAGONALMENTE ACIMA DA CABEÇA (100% UNIDO NAS EXTREMIDADES!)
    bone_c = (-0.10, 0.24, 2.18)
    bone_tilt_y = math.radians(-50.0)  # +Z aponta para (-X, +Z) = topo esquerdo; -Z aponta para (+X, -Z) = baixo direito
    bone_len = 1.44
    half_l = bone_len * 0.48
    ux = math.sin(bone_tilt_y)
    uz = math.cos(bone_tilt_y)
    top_end = (bone_c[0] + ux * half_l, bone_c[1], bone_c[2] + uz * half_l)
    bot_end = (bone_c[0] - ux * half_l, bone_c[1], bone_c[2] - uz * half_l)

    _add_part(
        parts,
        create_cylinder("_tmp_warbone_shaft", 8, 0.092, bone_len, bone_c, rotation=(0.0, bone_tilt_y, 0.0)),
        mat_prefix,
        "bone_white",
        pal,
    )
    # Cabeça esquerda superior do osso (duplo côndilo encaixado diretamente em top_end)
    _add_part(
        parts,
        create_icosphere("_tmp_warbone_L1", 2, 0.155, (top_end[0] + 0.06, top_end[1], top_end[2] + 0.07)),
        mat_prefix,
        "bone_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_warbone_L2", 2, 0.145, (top_end[0] - 0.07, top_end[1], top_end[2] - 0.06)),
        mat_prefix,
        "bone_white",
        pal,
    )
    # Cabeça direita inferior do osso (duplo côndilo encaixado diretamente em bot_end)
    _add_part(
        parts,
        create_icosphere("_tmp_warbone_R1", 2, 0.155, (bot_end[0] + 0.06, bot_end[1], bot_end[2] + 0.07)),
        mat_prefix,
        "bone_shade",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_warbone_R2", 2, 0.145, (bot_end[0] - 0.07, bot_end[1], bot_end[2] - 0.06)),
        mat_prefix,
        "bone_shade",
        pal,
    )

    # 5. BRAÇO ESQUERDO (+X) ESTENDIDO PARA EQUILÍBRIO COM GARRA BRANCA
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_L",
            7,
            0.16,
            0.12,
            0.66,
            (0.76, -0.02, 1.18),
            rotation=(math.radians(-12.0), math.radians(66.0), 0.0),
        ),
        mat_prefix,
        "body_tan",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hand_L", 2, 0.15, (1.08, -0.08, 1.30), scale=(1.15, 0.85, 0.72)),
        mat_prefix,
        "body_tan",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_thumb_claw_L",
            4,
            0.055,
            0.015,
            0.14,
            (0.92, -0.18, 1.24),
            rotation=(math.radians(-80.0), 0.0, 0.0),
        ),
        mat_prefix,
        "bone_white",
        pal,
    )

    # 6. PERNAS MUSCULOSAS EM BASE LARGA DE COMBATE + UNHAS BRANCAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.34,
                (side * 0.44, -0.02, 0.44),
                rotation=(0.0, math.radians(side * 14.0), 0.0),
                scale=(0.86, 1.02, 1.24),
            ),
            mat_prefix,
            "body_tan",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.24,
                (side * 0.56, -0.14, 0.14),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(0.94, 1.32, 0.58),
            ),
            mat_prefix,
            "body_tan",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_claw_foot_{tag}",
                1,
                0.15,
                (side * 0.60, -0.34, 0.08),
                scale=(0.98, 0.96, 0.46),
            ),
            mat_prefix,
            "bone_white",
            pal,
        )

    # 7. CAUDA DE DINOSSAURO COM ESPINHO CARACTERÍSTICO PERTO DA PONTA
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_base",
            7,
            0.28,
            0.12,
            0.76,
            (0.24, 0.64, 0.42),
            rotation=(math.radians(74.0), math.radians(24.0), 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_tip",
            6,
            0.12,
            0.025,
            0.42,
            (0.42, 1.02, 0.56),
            rotation=(math.radians(56.0), math.radians(32.0), 0.0),
        ),
        mat_prefix,
        "body_tan",
        pal,
    )
    # Pequeno pico dorsal na ponta da cauda (detalhe icônico do Marowak na arte!)
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_notch",
            5,
            0.075,
            0.015,
            0.22,
            (0.38, 0.92, 0.68),
            rotation=(math.radians(-10.0), math.radians(18.0), 0.0),
        ),
        mat_prefix,
        "body_tan",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 105. Skullknight lado a lado."""
    specs = [
        ("Skullknight_Shiny", (-10.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Skullknight_Normal", (-5.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Skullknight_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Skullknight_Gigante", (5.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Skullknight_Dourada_SuperRara", (13.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_skullknight(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
