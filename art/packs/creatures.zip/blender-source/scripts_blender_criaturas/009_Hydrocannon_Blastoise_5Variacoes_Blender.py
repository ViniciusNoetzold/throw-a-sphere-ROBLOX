"""
009_Hydrocannon_Blastoise_5Variacoes_Blender.py
===============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "009. Hydrocannon — Titã dos Canhões (Ref: Blastoise)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Hydrocannon_Shiny (1.0x - Paleta Shiny / Shyne Azul-Violeta + Casco Esmeralda + Canhões Prata)
  2. Hydrocannon_Normal (1.0x - Corpo Azul-Real + Casco Marrom + 2 Canhões de Aço nos Ombros)
  3. Hydrocannon_Grande (1.35x - Normal)
  4. Hydrocannon_Gigante (1.85x - Normal)
  5. Hydrocannon_Dourada_SuperRara (2.25x - Ouro Reluzente + Canhões Platina-Ouro + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cilindros 8 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.019`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base dos pés e garras alinhada exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Hydrocannon_Shiny`, `Hydrocannon_Normal`, `Hydrocannon_Grande`,
     `Hydrocannon_Gigante`, `Hydrocannon_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.019,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_royal": (0.22, 0.48, 0.84, 1.0),
        "shell_brown": (0.52, 0.30, 0.16, 1.0),
        "shell_rim": (0.95, 0.96, 0.98, 1.0),
        "plastron_cream": (0.95, 0.86, 0.56, 1.0),
        "cannon_steel": (0.78, 0.82, 0.88, 1.0),
        "cannon_bore": (0.12, 0.14, 0.18, 1.0),
        "eyes_brown": (0.48, 0.22, 0.14, 1.0),
        "claws_white": (0.97, 0.98, 0.99, 1.0),
    },
    "shiny_palette": {
        "body_royal": (0.48, 0.42, 0.86, 1.0),
        "shell_brown": (0.18, 0.66, 0.32, 1.0),
        "shell_rim": (0.96, 0.98, 0.97, 1.0),
        "plastron_cream": (0.98, 0.90, 0.60, 1.0),
        "cannon_steel": (0.84, 0.88, 0.94, 1.0),
        "cannon_bore": (0.14, 0.14, 0.22, 1.0),
        "eyes_brown": (0.72, 0.20, 0.26, 1.0),
        "claws_white": (0.98, 0.98, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "body_royal": (0.98, 0.78, 0.14, 1.0),
        "shell_brown": (0.74, 0.48, 0.08, 1.0),
        "shell_rim": (1.00, 0.97, 0.84, 1.0),
        "plastron_cream": (1.00, 0.92, 0.50, 1.0),
        "cannon_steel": (1.00, 0.96, 0.74, 1.0),
        "cannon_bore": (0.42, 0.28, 0.04, 1.0),
        "eyes_brown": (0.10, 0.92, 1.00, 1.0),
        "claws_white": (1.00, 0.98, 0.88, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_hydrocannon(
    name: str = "Hydrocannon_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 009. Hydrocannon (Ref: Blastoise):
      - Frente apontando para -Y e base dos pés e garras em Z = 0.0
      - Casco dorsal pesado com aro branco espesso e plastrão peitoral creme
      - Dois grandes canhões hidráulicos cilíndricos saindo das capotas superiores do casco
      - Cabeça robusta com mandíbula creme larga, 2 orelhas triangulares e olhos ferozes
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Hydro_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Hydro_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Hydro"

    parts = []

    # 1. CASCO COLOSSAL DE TITÃ (PLASTRÃO + ARO BRANCO + CARAPAÇA + CAPOTAS)
    _add_part(
        parts,
        create_cube("_tmp_torso_core", (1.58, 1.18, 1.62), (0.0, 0.0, 1.34)),
        mat_prefix,
        "plastron_cream",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_plastron_front", (1.32, 0.20, 1.46), (0.0, -0.58, 1.32)),
        mat_prefix,
        "plastron_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_shell_rim", 1, 1.02, (0.0, 0.10, 1.36), scale=(0.90, 0.56, 0.98)),
        mat_prefix,
        "shell_rim",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_shell_back", 1, 1.04, (0.0, 0.34, 1.36), scale=(0.86, 0.64, 0.96)),
        mat_prefix,
        "shell_brown",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_shell_ridge", (0.96, 0.34, 1.12), (0.0, 0.74, 1.36)),
        mat_prefix,
        "shell_brown",
        pal,
    )

    # 2. CANHÕES HIDRÁULICOS NOS OMBROS, PERNAS PESADAS (Z = 0) E BRAÇOS
    for side_idx, sx in enumerate([-1.0, 1.0]):
        # Capota superior do casco + grande canhão hidráulico cilíndrico de aço
        _add_part(
            parts,
            create_cube(
                f"_tmp_cannon_hood_{side_idx}",
                (0.48, 0.52, 0.44),
                (sx * 0.64, 0.22, 2.02),
                (math.radians(24), 0.0, math.radians(sx * -18)),
            ),
            mat_prefix,
            "shell_brown",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_cannon_base_{side_idx}",
                8,
                0.18,
                0.78,
                (sx * 0.68, -0.10, 2.26),
                (math.radians(52), 0.0, math.radians(sx * 14)),
            ),
            mat_prefix,
            "cannon_steel",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_cannon_muzzle_{side_idx}",
                8,
                0.23,
                0.46,
                (sx * 0.76, -0.42, 2.50),
                (math.radians(52), 0.0, math.radians(sx * 14)),
            ),
            mat_prefix,
            "cannon_steel",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_cannon_bore_{side_idx}",
                8,
                0.15,
                0.14,
                (sx * 0.80, -0.60, 2.64),
                (math.radians(52), 0.0, math.radians(sx * 14)),
            ),
            mat_prefix,
            "cannon_bore",
            pal,
        )

        # Pernas pesadas e 3 garras grandes brancas nos pés
        _add_part(
            parts,
            create_cube(
                f"_tmp_thigh_{side_idx}",
                (0.68, 0.72, 0.74),
                (sx * 0.74, -0.02, 0.68),
                (math.radians(6), 0.0, math.radians(sx * -8)),
            ),
            mat_prefix,
            "body_royal",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{side_idx}", (0.64, 0.74, 0.38), (sx * 0.78, -0.10, 0.21)),
            mat_prefix,
            "body_royal",
            pal,
        )
        for claw_i, cx_off in enumerate([-0.17, 0.0, 0.17]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_claw_{side_idx}_{claw_i}",
                    4,
                    0.082,
                    0.016,
                    0.28,
                    (sx * 0.78 + cx_off, -0.54, 0.10),
                    (math.radians(86), 0.0, 0.0),
                ),
                mat_prefix,
                "claws_white",
                pal,
            )

        # Braços segmentados em gomos + 3 garras brancas nas mãos
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_upper_{side_idx}",
                6,
                0.30,
                0.26,
                0.52,
                (sx * 0.94, -0.16, 1.56),
                (math.radians(18), math.radians(sx * 70), 0.0),
            ),
            mat_prefix,
            "body_royal",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_lower_{side_idx}",
                6,
                0.26,
                0.20,
                0.48,
                (sx * 1.32, -0.26, 1.46),
                (math.radians(22), math.radians(sx * 76), 0.0),
            ),
            mat_prefix,
            "body_royal",
            pal,
        )
        for hx_i, fy_off in enumerate([-0.08, 0.0, 0.08]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{side_idx}_{hx_i}",
                    4,
                    0.056,
                    0.012,
                    0.20,
                    (sx * 1.58, -0.34 + fy_off, 1.42),
                    (math.radians(22), math.radians(sx * 78), 0.0),
                ),
                mat_prefix,
                "claws_white",
                pal,
            )

    # Cauda cônica curta e grossa (+Y)
    _add_part(
        parts,
        create_cone("_tmp_tail", 6, 0.32, 0.08, 0.68, (0.0, 0.84, 0.56), (math.radians(-78), 0.0, 0.0)),
        mat_prefix,
        "body_royal",
        pal,
    )

    # 3. CABEÇA ROBUSTA (-Y), MANDÍBULA CREME LARGA, ORELHAS TRIANGULARES E OLHOS
    _add_part(
        parts,
        create_cube("_tmp_head", (1.06, 0.96, 0.76), (0.0, -0.26, 2.38)),
        mat_prefix,
        "body_royal",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout_upper", (0.92, 0.48, 0.32), (0.0, -0.78, 2.28)),
        mat_prefix,
        "body_royal",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_cream_jaw", (1.02, 0.64, 0.36), (0.0, -0.68, 2.02)),
        mat_prefix,
        "plastron_cream",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_outer_{side_idx}",
                4,
                0.18,
                0.03,
                0.36,
                (sx * 0.46, -0.14, 2.82),
                (math.radians(-8), math.radians(sx * 22), 0.0),
            ),
            mat_prefix,
            "body_royal",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_inner_{side_idx}",
                4,
                0.11,
                0.02,
                0.22,
                (sx * 0.45, -0.20, 2.80),
                (math.radians(-8), math.radians(sx * 22), 0.0),
            ),
            mat_prefix,
            "cannon_bore",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{side_idx}",
                (0.28, 0.14, 0.09),
                (sx * 0.34, -0.78, 2.56),
                (0.0, math.radians(sx * 16), math.radians(sx * -14)),
            ),
            mat_prefix,
            "body_royal",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_sclera_{side_idx}",
                (0.24, 0.10, 0.18),
                (sx * 0.34, -0.76, 2.45),
                (0.0, 0.0, math.radians(sx * -12)),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_iris_{side_idx}",
                (0.15, 0.08, 0.15),
                (sx * 0.33, -0.79, 2.45),
                (0.0, 0.0, math.radians(sx * -12)),
            ),
            mat_prefix,
            "eyes_brown",
            pal,
        )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """
    Gera lado a lado os 5 modelos do 009. Hydrocannon (Blastoise):
      1. Shiny (1.0x) | 2. Normal (1.0x) | 3. Grande (1.35x) | 4. Gigante (1.85x) | 5. Dourada Super Rara (2.25x)
    """
    build_hydrocannon("Hydrocannon_Shiny", location=(-8.6, 0.0, 0.0), scale=CONFIG["scales"]["Shiny"], variant="Shiny")
    build_hydrocannon("Hydrocannon_Normal", location=(-5.1, 0.0, 0.0), scale=CONFIG["scales"]["Normal"], variant="Normal")
    build_hydrocannon("Hydrocannon_Grande", location=(-1.1, 0.0, 0.0), scale=CONFIG["scales"]["Grande"], variant="Normal")
    build_hydrocannon("Hydrocannon_Gigante", location=(3.9, 0.0, 0.0), scale=CONFIG["scales"]["Gigante"], variant="Normal")
    build_hydrocannon(
        "Hydrocannon_Dourada_SuperRara",
        location=(10.5, 0.0, 0.0),
        scale=CONFIG["scales"]["DouradaSuperRara"],
        variant="DouradaSuperRara",
    )


if __name__ == "__main__":
    generate_variations()
    print("009. Hydrocannon (5 variações: Shiny, Normal, Grande, Gigante e Dourada Super Rara) gerado com sucesso!")
