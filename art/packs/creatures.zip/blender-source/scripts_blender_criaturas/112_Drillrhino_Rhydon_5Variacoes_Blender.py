"""
112_Drillrhino_Rhydon_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "112. Drillrhino — Colosso Perfurador (Ref: Rhydon)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Drillrhino_Shiny (1.0x - Paleta Shiny Pedra-Cáqui + Barriga Creme-Ouro + Broca Espiral)
  2. Drillrhino_Normal (1.0x - Armadura Cinza-Rocha + Barriga Segmentada Creme + Broca Espiral)
  3. Drillrhino_Grande (1.35x - Normal)
  4. Drillrhino_Gigante (1.85x - Normal)
  5. Drillrhino_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Broca Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para tronco/membros/cauda, cones 6-8 lados para broca)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e focinho/broca apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "armor_gray": (0.58, 0.62, 0.68, 1.0),
        "armor_dark": (0.40, 0.44, 0.50, 1.0),
        "belly_cream": (0.86, 0.82, 0.70, 1.0),
        "groove_tan": (0.60, 0.54, 0.44, 1.0),
        "mouth_pink": (0.76, 0.54, 0.58, 1.0),
        "eye_red": (0.86, 0.22, 0.22, 1.0),
        "eye_dark": (0.10, 0.10, 0.12, 1.0),
        "claw_white": (0.97, 0.97, 0.99, 1.0),
    },
    "shiny_palette": {
        "armor_gray": (0.74, 0.70, 0.56, 1.0),
        "armor_dark": (0.52, 0.48, 0.36, 1.0),
        "belly_cream": (0.94, 0.88, 0.68, 1.0),
        "groove_tan": (0.66, 0.58, 0.40, 1.0),
        "mouth_pink": (0.78, 0.52, 0.56, 1.0),
        "eye_red": (0.86, 0.22, 0.22, 1.0),
        "eye_dark": (0.10, 0.10, 0.12, 1.0),
        "claw_white": (0.98, 0.98, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "armor_gray": (0.98, 0.78, 0.14, 1.0),
        "armor_dark": (0.76, 0.54, 0.08, 1.0),
        "belly_cream": (1.00, 0.94, 0.56, 1.0),
        "groove_tan": (0.10, 0.92, 1.00, 1.0),
        "mouth_pink": (0.86, 0.56, 0.14, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.06, 0.56, 0.72, 1.0),
        "claw_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_drillrhino(
    name: str = "Drillrhino_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 112. Drillrhino (Ref: Rhydon):
      - Colosso bípede cinza-rocha com peitoral blindado em V e barriga segmentada creme
      - Cabeça feroz com broca espiralada creme no focinho, chifre secundário na testa e orelhas pontudas
      - Boca aberta rugindo com presas superiores + olhos rubi sob sobrancelha blindada
      - Braços musculosos abertos com 3 garras brancas, crista dorsal e cauda segmentada curvada à direita
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_DrillR_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_DrillR_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_DrillR_Norm"

    parts = []

    # 1. TRONCO BÍPEDE ROBUSTO + PEITORAL EM V + BARRIGA CREME SEGMENTADA
    _add_part(
        parts,
        create_icosphere("_tmp_torso_main", 2, 0.72, (0.0, 0.14, 1.04), scale=(1.04, 0.94, 1.18)),
        mat_prefix,
        "armor_gray",
        pal,
    )
    # Peitoral blindado largo nos ombros
    _add_part(
        parts,
        create_icosphere("_tmp_chest_plate", 2, 0.56, (0.0, -0.08, 1.54), scale=(1.26, 0.88, 0.56)),
        mat_prefix,
        "armor_gray",
        pal,
    )
    # Barriga creme saliente em 4 segmentos horizontais bem marcados
    belly_segs = [
        (0.46, (0.0, -0.26, 1.24), (1.06, 0.76, 0.34)),
        (0.52, (0.0, -0.32, 1.02), (1.08, 0.78, 0.32)),
        (0.50, (0.0, -0.30, 0.80), (1.04, 0.78, 0.30)),
        (0.42, (0.0, -0.22, 0.60), (0.98, 0.76, 0.28)),
    ]
    for s_idx, (rad, loc, sc) in enumerate(belly_segs):
        _add_part(
            parts,
            create_icosphere(f"_tmp_belly_seg_{s_idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "belly_cream",
            pal,
        )
        if s_idx < 3:
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_belly_groove_{s_idx}",
                    1,
                    rad * 0.96,
                    (0.0, loc[1] - 0.01, loc[2] - 0.11),
                    scale=(sc[0] * 1.02, sc[1] * 1.02, 0.08),
                ),
                mat_prefix,
                "groove_tan",
                pal,
            )

    # 2. CABEÇA FEROZ + BROCA ESPIRALADA NO FOCINHO + ORELHAS + ESPINHOS NA BOCHECHA
    _add_part(
        parts,
        create_icosphere("_tmp_head_cranium", 2, 0.48, (0.0, -0.18, 2.00), scale=(0.98, 1.12, 0.86)),
        mat_prefix,
        "armor_gray",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            6,
            0.34,
            0.20,
            0.52,
            (0.0, -0.62, 1.98),
            rotation=(math.radians(-78.0), 0.0, 0.0),
            scale=(1.08, 0.82, 1.00),
        ),
        mat_prefix,
        "armor_gray",
        pal,
    )
    # BROCA ESPIRALADA CREME (4 ANÉIS CÔNICOS EMPILHADOS COM SULCOS MARRONS)
    drill_segs = [
        ((0.0, -0.82, 2.04), 0.175, 0.135, 0.15, "belly_cream"),
        ((0.0, -0.89, 2.08), 0.145, 0.135, 0.04, "groove_tan"),
        ((0.0, -0.96, 2.12), 0.132, 0.092, 0.16, "belly_cream"),
        ((0.0, -1.03, 2.16), 0.100, 0.090, 0.036, "groove_tan"),
        ((0.0, -1.11, 2.20), 0.088, 0.048, 0.16, "belly_cream"),
        ((0.0, -1.21, 2.26), 0.048, 0.010, 0.14, "belly_cream"),
    ]
    for d_idx, (dloc, r1, r2, dp, mkey) in enumerate(drill_segs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_drill_{d_idx}",
                8,
                r1,
                r2,
                dp,
                dloc,
                rotation=(math.radians(-62.0), 0.0, 0.0),
            ),
            mat_prefix,
            mkey,
            pal,
        )

    # Chifre secundário suave na testa apontando para frente
    _add_part(
        parts,
        create_cone(
            "_tmp_forehead_horn",
            5,
            0.13,
            0.025,
            0.44,
            (0.0, -0.34, 2.36),
            rotation=(math.radians(-76.0), 0.0, 0.0),
            scale=(0.82, 0.72, 1.00),
        ),
        mat_prefix,
        "armor_gray",
        pal,
    )

    # Orelhas pontudas erguidas, espinhos laterais da bochecha e olhos rubi ferozes
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{tag}",
                5,
                0.15,
                0.03,
                0.52,
                (side * 0.36, 0.02, 2.46),
                rotation=(math.radians(16.0), math.radians(side * 22.0), 0.0),
                scale=(0.76, 1.04, 1.00),
            ),
            mat_prefix,
            "armor_gray",
            pal,
        )
        # Dois espinhos de bochecha lateral
        for sp_i, (dz, ry) in enumerate([(0.02, 82.0), (-0.12, 104.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_cheek_sp_{tag}_{sp_i}",
                    4,
                    0.09,
                    0.015,
                    0.26,
                    (side * 0.50, -0.14, 1.96 + dz),
                    rotation=(0.0, math.radians(side * ry), 0.0),
                ),
                mat_prefix,
                "armor_gray",
                pal,
            )
        # Olho branco + íris rubi + pupila
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_w_{tag}",
                2,
                0.11,
                (side * 0.30, -0.58, 2.08),
                rotation=(0.0, math.radians(side * -14.0), math.radians(side * 24.0)),
                scale=(1.10, 0.44, 0.76),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_eye_r_{tag}", 1, 0.062, (side * 0.30, -0.625, 2.07), scale=(0.82, 0.46, 1.04)),
            mat_prefix,
            "eye_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_eye_p_{tag}", 1, 0.030, (side * 0.30, -0.65, 2.07), scale=(0.70, 0.46, 1.08)),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Boca aberta rugindo + língua rosa + 2 presas brancas superiores
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_open", 2, 0.30, (0.0, -0.56, 1.76), scale=(1.12, 0.88, 0.66)),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_jaw_bot", 2, 0.30, (0.0, -0.52, 1.66), scale=(1.10, 0.94, 0.42)),
        mat_prefix,
        "armor_gray",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.055,
                0.010,
                0.14,
                (side * 0.24, -0.68, 1.84),
                rotation=(math.radians(174.0), 0.0, 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 3. CRISTA DORSAL RECORTADA NA NUCA E ESPINHOS NAS COSTAS
    _add_part(
        parts,
        create_cone(
            "_tmp_neck_fin",
            5,
            0.22,
            0.05,
            0.54,
            (0.0, 0.46, 2.04),
            rotation=(math.radians(38.0), 0.0, 0.0),
            scale=(0.36, 1.00, 1.00),
        ),
        mat_prefix,
        "armor_dark",
        pal,
    )
    for sp_i, (sy, sz) in enumerate([(0.72, 1.54), (0.82, 1.24), (0.84, 0.94)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_spine_{sp_i}",
                4,
                0.13,
                0.025,
                0.30,
                (0.0, sy, sz),
                rotation=(math.radians(74.0), 0.0, 0.0),
                scale=(0.48, 1.00, 1.00),
            ),
            mat_prefix,
            "armor_dark",
            pal,
        )

    # 4. BRAÇOS MUSCULOSOS ERGUIDOS E ABERTOS COM 3 GARRAS BRANCAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(f"_tmp_shoulder_{tag}", 2, 0.34, (side * 0.78, -0.04, 1.54), scale=(1.10, 0.96, 0.96)),
            mat_prefix,
            "armor_gray",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_forearm_{tag}",
                8,
                0.28,
                0.22,
                0.68,
                (side * 1.14, -0.16, 1.78),
                rotation=(math.radians(-16.0), math.radians(side * 54.0), 0.0),
            ),
            mat_prefix,
            "armor_gray",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_hand_{tag}", 2, 0.24, (side * 1.38, -0.26, 1.94), scale=(1.04, 0.92, 0.96)),
            mat_prefix,
            "armor_gray",
            pal,
        )
        for c_idx, (dx, dz, ry) in enumerate([
            (0.04, 0.20, 18.0),
            (0.18, 0.12, 54.0),
            (0.20, -0.04, 88.0),
        ]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hclaw_{tag}_{c_idx}",
                    5,
                    0.064,
                    0.012,
                    0.18,
                    (side * (1.38 + dx), -0.28, 1.94 + dz),
                    rotation=(math.radians(-12.0), math.radians(side * ry), 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 5. PERNAS COLOSSAIS E PATAS FIRMES EM Z = 0.0 COM GARRAS BRANCAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(f"_tmp_thigh_{tag}", 2, 0.44, (side * 0.62, -0.04, 0.62), scale=(0.94, 1.10, 1.12)),
            mat_prefix,
            "armor_gray",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_shin_{tag}",
                8,
                0.28,
                0.32,
                0.42,
                (side * 0.66, -0.10, 0.28),
            ),
            mat_prefix,
            "armor_gray",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_foot_{tag}", 2, 0.28, (side * 0.68, -0.22, 0.16), scale=(1.08, 1.34, 0.62)),
            mat_prefix,
            "armor_gray",
            pal,
        )
        for c_idx, dx in enumerate((-0.14, 0.0, 0.14)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_fclaw_{tag}_{c_idx}",
                    5,
                    0.072,
                    0.014,
                    0.22,
                    (side * 0.68 + dx, -0.52, 0.10),
                    rotation=(math.radians(-80.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 6. CAUDA GROSSA SEGMENTADA CURVADA PARA A DIREITA (+X)
    tail_nodes = [
        (0.46, (0.14, 0.68, 0.56), (1.00, 1.00, 0.96)),
        (0.40, (0.62, 0.86, 0.54), (1.02, 0.96, 0.94)),
        (0.34, (1.10, 0.92, 0.60), (1.04, 0.92, 0.92)),
        (0.27, (1.52, 0.86, 0.72), (1.06, 0.88, 0.88)),
        (0.20, (1.84, 0.76, 0.88), (1.08, 0.84, 0.84)),
    ]
    for tl_i, (rad, loc, sc) in enumerate(tail_nodes):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tail_{tl_i}", 2, rad, loc, scale=sc),
            mat_prefix,
            "armor_gray" if tl_i % 2 == 0 else "armor_dark",
            pal,
        )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_tip",
            6,
            0.16,
            0.03,
            0.40,
            (2.10, 0.68, 1.00),
            rotation=(math.radians(-16.0), math.radians(66.0), 0.0),
        ),
        mat_prefix,
        "armor_gray",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 112. Drillrhino lado a lado."""
    specs = [
        ("Drillrhino_Shiny", (-13.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Drillrhino_Normal", (-7.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Drillrhino_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Drillrhino_Gigante", (7.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Drillrhino_Dourada_SuperRara", (17.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_drillrhino(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
