"""
114_Vineball_Tangela_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "114. Vineball — Novelo de Cipós (Ref: Tangela)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Vineball_Shiny (1.0x - Paleta Shiny Cipós Verde-Esmeralda + Núcleo Preto + Botas Vermelhas)
  2. Vineball_Normal (1.0x - Novelo Denso de Cipós Azul-Índigo + Olhos Brancos + Botas Coral)
  3. Vineball_Grande (1.35x - Normal)
  4. Vineball_Gigante (1.85x - Normal)
  5. Vineball_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Botas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (enovelado 3D real de cipós entrelaçados em torno do núcleo escuro)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Botinhas alinhadas exatamente em `Z = 0.0` e olhos espiando na direção `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "vine_blue": (0.36, 0.58, 0.78, 1.0),
        "vine_deep": (0.24, 0.38, 0.56, 1.0),
        "core_black": (0.07, 0.07, 0.09, 1.0),
        "boot_red": (0.90, 0.44, 0.36, 1.0),
        "boot_sole": (0.72, 0.30, 0.24, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "eye_black": (0.06, 0.06, 0.08, 1.0),
    },
    "shiny_palette": {
        "vine_blue": (0.26, 0.76, 0.36, 1.0),
        "vine_deep": (0.14, 0.50, 0.24, 1.0),
        "core_black": (0.07, 0.07, 0.09, 1.0),
        "boot_red": (0.90, 0.42, 0.34, 1.0),
        "boot_sole": (0.72, 0.28, 0.22, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "eye_black": (0.06, 0.06, 0.08, 1.0),
    },
    "golden_super_rare_palette": {
        "vine_blue": (0.98, 0.78, 0.14, 1.0),
        "vine_deep": (0.78, 0.56, 0.08, 1.0),
        "core_black": (0.20, 0.14, 0.04, 1.0),
        "boot_red": (0.10, 0.92, 1.00, 1.0),
        "boot_sole": (0.06, 0.64, 0.78, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_black": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_vine_strand(parts: list, tag: str, points: list, radius: float, mat_key: str, mat_prefix: str, pal: dict):
    """Constrói um cipó 3D contínuo e arredondado conectando uma sequência de pontos."""
    for i in range(len(points) - 1):
        p0 = points[i]
        p1 = points[i + 1]
        mx = (p0[0] + p1[0]) * 0.5
        my = (p0[1] + p1[1]) * 0.5
        mz = (p0[2] + p1[2]) * 0.5
        dx = p1[0] - p0[0]
        dy = p1[1] - p0[1]
        dz = p1[2] - p0[2]
        seg_len = math.sqrt(dx * dx + dy * dy + dz * dz)
        if seg_len < 1e-4:
            continue
        # Orientar eixo +Z do cilindro ao longo do vetor (dx, dy, dz)
        # Primeiro rotação em X/Y para alinhar Z com a direção
        horiz = math.sqrt(dx * dx + dy * dy)
        rot_x = math.atan2(-dy, dz) if horiz < 1e-6 else 0.0
        if horiz >= 1e-6:
            phi = math.atan2(dy, dx)
            theta = math.acos(max(-1.0, min(1.0, dz / seg_len)))
            # Rz(phi) @ Ry(theta) leva (0,0,1) para (sin(theta)cos(phi), sin(theta)sin(phi), cos(theta))
            rot = (0.0, theta, phi)
        else:
            rot = (rot_x, 0.0, 0.0)
        _add_part(
            parts,
            create_cylinder(f"_tmp_vseg_{tag}_{i}", 7, radius, seg_len + radius * 0.4, (mx, my, mz), rotation=rot),
            mat_prefix,
            mat_key,
            pal,
        )
    # Juntas arredondadas nos vértices para curvas orgânicas limpas
    for j, pt in enumerate(points):
        r_j = radius * (0.72 if j == len(points) - 1 else 1.04)
        _add_part(
            parts,
            create_icosphere(f"_tmp_vnode_{tag}_{j}", 1, r_j, pt),
            mat_prefix,
            mat_key,
            pal,
        )


def build_vineball(
    name: str = "Vineball_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 114. Vineball (Ref: Tangela):
      - Núcleo esférico preto-sombra revelando dois grandes olhos brancos expressivos com pupilas
      - Massa densa 3D de dezenas de cipós azul-índigo entrelaçados em camadas com pontas soltas
      - Enquadramento frontal aberto para os olhos com laços ondulados em cima e embaixo do rosto
      - Duas botinhas arredondadas vermelho-coral firmes em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Vine_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Vine_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Vine_Norm"

    parts = []

    # 1. NÚCLEO SOMBRIO PRETO + DOIS OLHOS GRANDES REDONDOS BRANCOS
    _add_part(
        parts,
        create_icosphere("_tmp_dark_core", 2, 0.66, (0.0, 0.04, 1.02), scale=(1.02, 0.96, 1.00)),
        mat_prefix,
        "core_black",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.185,
                (side * 0.22, -0.58, 1.08),
                scale=(0.94, 0.44, 1.12),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.036,
                (side * 0.19, -0.66, 1.14),
                scale=(0.86, 0.50, 1.05),
            ),
            mat_prefix,
            "eye_black",
            pal,
        )

    # 2. CAMADA INTERNA VOLUMOSA DE CIPÓS ESCUROS ENVOLVENDO TOPO, LATERAIS E COSTAS
    back_ring = [
        (0.32, (0.00, 0.48, 1.54)),
        (0.32, (-0.48, 0.32, 1.48)),
        (0.32, (0.48, 0.32, 1.48)),
        (0.34, (-0.74, 0.10, 1.12)),
        (0.34, (0.74, 0.10, 1.12)),
        (0.32, (-0.68, 0.20, 0.68)),
        (0.32, (0.68, 0.20, 0.68)),
        (0.34, (0.00, 0.62, 1.04)),
        (0.32, (-0.38, 0.56, 0.72)),
        (0.32, (0.38, 0.56, 0.72)),
        (0.30, (0.00, 0.14, 0.44)),
        (0.30, (-0.40, -0.10, 1.62)),
        (0.30, (0.40, -0.10, 1.62)),
        (0.28, (0.00, -0.14, 1.68)),
    ]
    for br_i, (rad, loc) in enumerate(back_ring):
        _add_part(
            parts,
            create_icosphere(f"_tmp_vine_bulk_{br_i}", 2, rad, loc),
            mat_prefix,
            "vine_deep",
            pal,
        )

    # 3. CIPÓS ENTRELAÇADOS EM 3D EMOLDURANDO O ROSTO (SEM COBRIR OS OLHOS!)
    # Arco superior esquerdo descendo pela lateral esquerda
    _add_vine_strand(
        parts,
        "UL_arch",
        [
            (-0.12, -0.44, 1.64),
            (-0.46, -0.48, 1.54),
            (-0.76, -0.34, 1.24),
            (-0.84, -0.14, 0.84),
            (-0.62, -0.30, 0.48),
        ],
        0.135,
        "vine_blue",
        mat_prefix,
        pal,
    )
    # Arco superior direito ondulando acima do olho direito e saindo para a direita
    _add_vine_strand(
        parts,
        "UR_arch",
        [
            (0.14, -0.44, 1.62),
            (0.52, -0.48, 1.52),
            (0.80, -0.32, 1.24),
            (0.86, -0.10, 0.84),
            (0.64, -0.28, 0.50),
        ],
        0.135,
        "vine_blue",
        mat_prefix,
        pal,
    )
    # Franja encaracolada sobre a testa (deixando olhos 100% visíveis)
    _add_vine_strand(
        parts,
        "brow_curl_L",
        [
            (-0.74, -0.24, 1.38),
            (-0.44, -0.56, 1.38),
            (-0.08, -0.58, 1.44),
            (-0.18, -0.46, 1.66),
        ],
        0.115,
        "vine_blue",
        mat_prefix,
        pal,
    )
    _add_vine_strand(
        parts,
        "brow_curl_R",
        [
            (0.24, -0.56, 1.50),
            (0.46, -0.60, 1.36),
            (0.76, -0.44, 1.36),
            (0.98, -0.24, 1.18),
            (1.06, -0.12, 0.96),
        ],
        0.110,
        "vine_blue",
        mat_prefix,
        pal,
    )
    # Laços inferiores cruzados estilo "bigode de cipós" logo abaixo dos olhos
    _add_vine_strand(
        parts,
        "chin_wave_1",
        [
            (-0.70, -0.42, 0.84),
            (-0.42, -0.68, 0.78),
            (-0.04, -0.74, 0.72),
            (0.32, -0.72, 0.80),
            (0.68, -0.46, 0.72),
        ],
        0.125,
        "vine_blue",
        mat_prefix,
        pal,
    )
    _add_vine_strand(
        parts,
        "chin_wave_2",
        [
            (-0.52, -0.54, 0.54),
            (-0.14, -0.70, 0.50),
            (0.24, -0.68, 0.54),
            (0.56, -0.52, 0.62),
        ],
        0.120,
        "vine_blue",
        mat_prefix,
        pal,
    )
    _add_vine_strand(
        parts,
        "chin_knot",
        [
            (-0.28, -0.68, 0.78),
            (0.02, -0.78, 0.62),
            (0.34, -0.70, 0.52),
            (0.52, -0.52, 0.82),
        ],
        0.105,
        "vine_blue",
        mat_prefix,
        pal,
    )

    # Pontinhas soltas de cipó arrepiadas na silhueta (detalhe icônico da arte!)
    loose_tips = [
        ((-0.68, -0.16, 1.56), (0.0, -24.0, 0.0), 0.11, 0.42),
        ((-0.94, -0.06, 1.24), (0.0, -76.0, 0.0), 0.10, 0.40),
        ((0.94, -0.10, 1.38), (0.0, 68.0, 0.0), 0.10, 0.42),
        ((0.88, -0.20, 0.62), (0.0, 118.0, 0.0), 0.10, 0.36),
        ((-0.10, -0.48, 0.36), (0.0, -162.0, 0.0), 0.09, 0.30),
    ]
    for lt_i, (loc, rot_d, rb, dp) in enumerate(loose_tips):
        _add_part(
            parts,
            create_cone(
                f"_tmp_vtip_{lt_i}",
                6,
                rb,
                0.022,
                dp,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
            ),
            mat_prefix,
            "vine_blue",
            pal,
        )

    # 4. DUAS BOTINHAS ARREDONDADAS VERMELHO-CORAL EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Tornozelo/cano da bota saindo debaixo dos cipós
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_boot_ankle_{tag}",
                8,
                0.17,
                0.30,
                (side * 0.44, -0.18, 0.32),
                rotation=(math.radians(10.0), math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "boot_red",
            pal,
        )
        # Bico arredondado fofo da botinha
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_boot_toe_{tag}",
                2,
                0.24,
                (side * 0.48, -0.34, 0.22),
                rotation=(0.0, 0.0, math.radians(side * -22.0)),
                scale=(1.02, 1.38, 0.84),
            ),
            mat_prefix,
            "boot_red",
            pal,
        )
        # Sola firme nivelada em Z = 0.0
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_boot_sole_{tag}",
                2,
                0.22,
                (side * 0.48, -0.34, 0.12),
                rotation=(0.0, 0.0, math.radians(side * -22.0)),
                scale=(1.00, 1.34, 0.42),
            ),
            mat_prefix,
            "boot_sole",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 114. Vineball lado a lado."""
    specs = [
        ("Vineball_Shiny", (-8.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Vineball_Normal", (-4.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Vineball_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Vineball_Gigante", (5.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Vineball_Dourada_SuperRara", (12.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_vineball(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
