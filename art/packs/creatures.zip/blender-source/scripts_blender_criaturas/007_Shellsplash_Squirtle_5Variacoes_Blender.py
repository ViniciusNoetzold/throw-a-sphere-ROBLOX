"""
007_Shellsplash_Squirtle_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "007. Shellsplash — Tartaruga Marinha (Ref: Squirtle)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Shellsplash_Shiny (1.0x - Paleta Shiny / Shyne Azul-Ciano + Casco Esmeralda)
  2. Shellsplash_Normal (1.0x - Pele Azul-Celeste + Casco Marrom + Cauda Espiral)
  3. Shellsplash_Grande (1.35x - Normal)
  4. Shellsplash_Gigante (1.85x - Normal)
  5. Shellsplash_Dourada_SuperRara (2.25x - Ouro Reluzente + Casco Âmbar-Ouro + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cilindros 6-8 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base dos pés alinhada exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Shellsplash_Shiny`, `Shellsplash_Normal`, `Shellsplash_Grande`,
     `Shellsplash_Gigante`, `Shellsplash_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.36, 0.76, 0.92, 1.0),
        "shell_brown": (0.66, 0.40, 0.22, 1.0),
        "shell_rim": (0.95, 0.96, 0.97, 1.0),
        "plastron_cream": (0.96, 0.88, 0.56, 1.0),
        "eyes_ruby": (0.76, 0.18, 0.22, 1.0),
        "eye_dark": (0.20, 0.06, 0.10, 1.0),
        "white_shine": (0.98, 0.98, 0.99, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.48, 0.88, 0.96, 1.0),
        "shell_brown": (0.20, 0.72, 0.34, 1.0),
        "shell_rim": (0.96, 0.98, 0.97, 1.0),
        "plastron_cream": (0.98, 0.92, 0.62, 1.0),
        "eyes_ruby": (0.84, 0.22, 0.30, 1.0),
        "eye_dark": (0.22, 0.06, 0.12, 1.0),
        "white_shine": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.98, 0.78, 0.14, 1.0),
        "shell_brown": (0.76, 0.50, 0.08, 1.0),
        "shell_rim": (1.00, 0.97, 0.82, 1.0),
        "plastron_cream": (1.00, 0.92, 0.50, 1.0),
        "eyes_ruby": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.05, 0.46, 0.60, 1.0),
        "white_shine": (1.00, 0.99, 0.90, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_shellsplash(
    name: str = "Shellsplash_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 007. Shellsplash (Ref: Squirtle):
      - Frente apontando para -Y e base dos pés em Z = 0.0
      - Casco dorsal abaulado com aro lateral branco e plastrão frontal amarelo-creme
      - Cabeça redonda lisa sem orelhas, leve bico de tartaruga e olhos grandes castanho-rubi
      - Cauda grossa enrolada em espiral facetada
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Shell_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Shell_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Shell"

    parts = []

    # 1. CASCO COMPLETO (PLASTRÃO CREME + ARO BRANCO + CARAPAÇA DORSAL)
    _add_part(
        parts,
        create_cube("_tmp_torso_core", (0.96, 0.74, 1.06), (0.0, 0.0, 0.96)),
        mat_prefix,
        "plastron_cream",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_plastron_front", (0.80, 0.16, 0.96), (0.0, -0.38, 0.96)),
        mat_prefix,
        "plastron_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_shell_rim", 1, 0.64, (0.0, 0.08, 0.96), scale=(0.88, 0.52, 0.98)),
        mat_prefix,
        "shell_rim",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_shell_back", 1, 0.66, (0.0, 0.24, 0.96), scale=(0.84, 0.58, 0.96)),
        mat_prefix,
        "shell_brown",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_shell_ridge", (0.62, 0.24, 0.74), (0.0, 0.48, 0.96)),
        mat_prefix,
        "shell_brown",
        pal,
    )

    # 2. PERNAS CURTAS COM 3 DEDINHOS (Z = 0) E BRAÇOS ABERTOS
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_thigh_{side_idx}",
                (0.44, 0.50, 0.52),
                (sx * 0.44, -0.02, 0.50),
                (math.radians(6), 0.0, math.radians(sx * -8)),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{side_idx}", (0.42, 0.54, 0.28), (sx * 0.46, -0.10, 0.16)),
            mat_prefix,
            "body_blue",
            pal,
        )
        for toe_i, cx_off in enumerate([-0.11, 0.0, 0.11]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_toe_{side_idx}_{toe_i}",
                    4,
                    0.055,
                    0.012,
                    0.18,
                    (sx * 0.46 + cx_off, -0.40, 0.08),
                    (math.radians(86), 0.0, 0.0),
                ),
                mat_prefix,
                "body_blue",
                pal,
            )

        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_{side_idx}",
                6,
                0.20,
                0.15,
                0.62,
                (sx * 0.66, -0.12, 1.20),
                (math.radians(16), math.radians(sx * 72), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        for fin_i, fy_off in enumerate([-0.05, 0.0, 0.05]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_finger_{side_idx}_{fin_i}",
                    4,
                    0.036,
                    0.010,
                    0.12,
                    (sx * 0.96, -0.20 + fy_off, 1.32),
                    (math.radians(16), math.radians(sx * 74), 0.0),
                ),
                mat_prefix,
                "body_blue",
                pal,
            )

    # 3. CABEÇA REDONDA LISA (-Y) + BICO SUAVE + OLHOS GRANDES RUBI
    _add_part(
        parts,
        create_icosphere("_tmp_cranium", 1, 0.60, (0.0, -0.08, 1.88), scale=(0.98, 0.96, 0.96)),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_face_block", (0.98, 0.88, 0.76), (0.0, -0.10, 1.82)),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout", (0.84, 0.36, 0.34), (0.0, -0.48, 1.68)),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_beak_tip", 4, 0.16, 0.04, 0.18, (0.0, -0.66, 1.66), (math.radians(95), 0.0, 0.0)),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_smile_line", (0.68, 0.08, 0.05), (0.0, -0.65, 1.64)),
        mat_prefix,
        "eye_dark",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_dark_{side_idx}",
                (0.22, 0.10, 0.30),
                (sx * 0.28, -0.53, 1.88),
                (0.0, 0.0, math.radians(sx * -14)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_iris_{side_idx}",
                (0.18, 0.08, 0.23),
                (sx * 0.28, -0.55, 1.86),
                (0.0, 0.0, math.radians(sx * -14)),
            ),
            mat_prefix,
            "eyes_ruby",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_shine_{side_idx}",
                (0.09, 0.06, 0.10),
                (sx * 0.26, -0.57, 1.95),
                (0.0, 0.0, math.radians(sx * -14)),
            ),
            mat_prefix,
            "white_shine",
            pal,
        )

    # 4. CAUDA GROSSA ENROLADA EM ESPIRAL (+Y)
    _add_part(
        parts,
        create_cone("_tmp_tail_stem", 6, 0.24, 0.28, 0.58, (0.0, 0.58, 0.54), (math.radians(-78), 0.0, 0.0)),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_cylinder("_tmp_tail_curl", 8, 0.38, 0.34, (0.0, 0.98, 0.68), (0.0, math.radians(90), 0.0)),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_cylinder("_tmp_tail_spiral_ridge", 6, 0.22, 0.38, (0.0, 1.02, 0.66), (0.0, math.radians(90), 0.0)),
        mat_prefix,
        "body_blue",
        pal,
    )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """
    Gera lado a lado os 5 modelos do 007. Shellsplash (Squirtle):
      1. Shiny (1.0x) | 2. Normal (1.0x) | 3. Grande (1.35x) | 4. Gigante (1.85x) | 5. Dourada Super Rara (2.25x)
    """
    build_shellsplash("Shellsplash_Shiny", location=(-6.6, 0.0, 0.0), scale=CONFIG["scales"]["Shiny"], variant="Shiny")
    build_shellsplash("Shellsplash_Normal", location=(-3.9, 0.0, 0.0), scale=CONFIG["scales"]["Normal"], variant="Normal")
    build_shellsplash("Shellsplash_Grande", location=(-0.9, 0.0, 0.0), scale=CONFIG["scales"]["Grande"], variant="Normal")
    build_shellsplash("Shellsplash_Gigante", location=(2.8, 0.0, 0.0), scale=CONFIG["scales"]["Gigante"], variant="Normal")
    build_shellsplash(
        "Shellsplash_Dourada_SuperRara",
        location=(7.8, 0.0, 0.0),
        scale=CONFIG["scales"]["DouradaSuperRara"],
        variant="DouradaSuperRara",
    )


if __name__ == "__main__":
    generate_variations()
    print("007. Shellsplash (5 variações: Shiny, Normal, Grande, Gigante e Dourada Super Rara) gerado com sucesso!")
