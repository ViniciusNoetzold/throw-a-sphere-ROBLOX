"""
099_Clawking_Kingler_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "099. Clawking — Rei das Pinças (Ref: Kingler)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Clawking_Shiny (1.0x - Carapaça Verde-Oliva Dourada + Barriga Creme-Areia)
  2. Clawking_Normal (1.0x - Carapaça Laranja-Coral + Coroa de 5 Picos + Pinça Esquerda Colossal)
  3. Clawking_Grande (1.35x - Normal)
  4. Clawking_Gigante (1.85x - Normal)
  5. Clawking_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Serra Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2, cones/cilindros 6-8 lados)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pontas das patas alinhadas exatamente em `Z = 0.0` e frente apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_orange": (0.91, 0.44, 0.24, 1.0),
        "body_shade": (0.76, 0.34, 0.18, 1.0),
        "belly_cream": (0.94, 0.90, 0.84, 1.0),
        "belly_shade": (0.80, 0.75, 0.70, 1.0),
        "claw_inner": (0.24, 0.20, 0.20, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
        "tooth_white": (0.98, 0.97, 0.94, 1.0),
    },
    "shiny_palette": {
        "body_orange": (0.58, 0.68, 0.24, 1.0),
        "body_shade": (0.44, 0.54, 0.18, 1.0),
        "belly_cream": (0.93, 0.90, 0.76, 1.0),
        "belly_shade": (0.78, 0.74, 0.60, 1.0),
        "claw_inner": (0.22, 0.24, 0.18, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
        "tooth_white": (0.98, 0.98, 0.92, 1.0),
    },
    "golden_super_rare_palette": {
        "body_orange": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.60, 0.08, 1.0),
        "belly_cream": (1.00, 0.94, 0.64, 1.0),
        "belly_shade": (0.88, 0.74, 0.32, 1.0),
        "claw_inner": (0.48, 0.34, 0.06, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.04, 0.42, 0.58, 1.0),
        "tooth_white": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_clawking(
    name: str = "Clawking_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel do 099. Clawking (Ref: Kingler):
      - Carapaça superior laranja-coral com coroa de 5 picos esguios em leque
      - Casco inferior / mandíbula creme com borda serrilhada e duas pontas laterais altas
      - Olhos brancos determinados com pupilas verticais finas sob sobrancelhas angulares
      - 4 patas articuladas de caranguejo (2 por lado) firmes em Z = 0.0
      - Pinça direita (-X) média erguida + pinça esquerda (+X) COLOSSAL muito maior que o corpo!
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Clawking_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Clawking_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Clawking_Norm"

    parts = []

    # 1. CARAPAÇA SUPERIOR LARANJA-CORAL (ROSTO/CABEÇA EM DOMO)
    _add_part(
        parts,
        create_icosphere("_tmp_carapace_top", 2, 0.66, (0.0, 0.04, 0.78), scale=(1.18, 0.94, 0.88)),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Crista central frontal ligeiramente elevada entre os olhos
    _add_part(
        parts,
        create_icosphere("_tmp_forehead_ridge", 2, 0.34, (0.0, -0.34, 0.88), scale=(0.82, 0.75, 0.72)),
        mat_prefix,
        "body_orange",
        pal,
    )

    # 2. COROA DE 5 PICOS EM LEQUE NO TOPO DA CABEÇA (ASSINATURA DO KINGLER)
    crown_specs = [
        # (x, y, z, r_base, r_tip, depth, rx_deg, ry_deg)
        (-0.56, 0.10, 1.24, 0.085, 0.024, 0.56, 12.0, -48.0),
        (-0.30, 0.12, 1.44, 0.095, 0.026, 0.66, 10.0, -24.0),
        (0.00, 0.14, 1.50, 0.100, 0.028, 0.68, 8.0, 0.0),
        (0.30, 0.12, 1.44, 0.095, 0.026, 0.66, 10.0, 24.0),
        (0.56, 0.10, 1.24, 0.085, 0.024, 0.56, 12.0, 48.0),
    ]
    for idx, (cx, cy, cz, r1, r2, dep, rx_d, ry_d) in enumerate(crown_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_crown_spike_{idx}",
                6,
                r1,
                r2,
                dep,
                (cx, cy, cz),
                rotation=(math.radians(rx_d), math.radians(ry_d), 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )

    # 3. MANDÍBULA / BARRIGA INFERIOR CREME COM COLARINHO SERRILHADO
    _add_part(
        parts,
        create_icosphere("_tmp_belly_shell", 2, 0.68, (0.0, -0.02, 0.44), scale=(1.22, 1.00, 0.66)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # Duas abas/bochechas laterais pontudas subindo pelas laterais da mandíbula
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_jaw_cheek_{tag}",
                6,
                0.24,
                0.04,
                0.62,
                (side * 0.72, -0.32, 0.72),
                rotation=(math.radians(-14.0), math.radians(side * 10.0), 0.0),
                scale=(0.82, 0.65, 1.0),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )
        # Almofadinhas inferiores arredondadas na base frontal do casco creme
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_belly_pad_{tag}",
                2,
                0.26,
                (side * 0.42, -0.26, 0.24),
                scale=(1.12, 0.90, 0.64),
            ),
            mat_prefix,
            "belly_shade",
            pal,
        )

    # Dentes serrilhados creme ao longo da linha da boca frontal
    serr_specs = [
        (-0.46, -0.58, 0.63, 0.11, 0.24, -12.0),
        (-0.26, -0.64, 0.61, 0.10, 0.20, -4.0),
        (0.00, -0.66, 0.58, 0.11, 0.16, 0.0),
        (0.26, -0.64, 0.61, 0.10, 0.20, 4.0),
        (0.46, -0.58, 0.63, 0.11, 0.24, 12.0),
    ]
    for idx, (sx, sy, sz, rad, dep, ry_d) in enumerate(serr_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_jaw_tooth_{idx}",
                5,
                rad,
                0.018,
                dep,
                (sx, sy, sz),
                rotation=(math.radians(-16.0), math.radians(ry_d), 0.0),
                scale=(1.0, 0.55, 1.0),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )

    # 4. OLHOS BRANCOS EXPRESSIVOS COM PUPILAS VERTICAIS FINAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.20,
                (side * 0.34, -0.54, 0.78),
                rotation=(0.0, math.radians(side * -18.0), math.radians(side * -16.0)),
                scale=(1.18, 0.44, 0.72),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pupila vertical fina escura
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_pupil_{tag}",
                (0.042, 0.06, 0.13),
                (side * 0.33, -0.63, 0.77),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Sobrancelha superior laranja acentuando o olhar feroz
        _add_part(
            parts,
            create_cone(
                f"_tmp_brow_{tag}",
                6,
                0.09,
                0.05,
                0.38,
                (side * 0.34, -0.54, 0.90),
                rotation=(math.radians(8.0), math.radians(side * 68.0), math.radians(side * -14.0)),
                scale=(0.8, 0.65, 1.0),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )

    # 5. QUATRO PATAS ARTICULADAS DE CARANGUEJO APOIADAS EM Z = 0.0
    leg_configs = [
        # (tag, side, y_off, knee_x, knee_y, knee_z, foot_x, foot_y)
        ("FL", -1.0, -0.10, -1.16, -0.18, 0.44, -1.68, -0.26),
        ("BL", -1.0, 0.30, -1.04, 0.36, 0.48, -1.42, 0.48),
        ("FR", 1.0, -0.10, 1.16, -0.18, 0.44, 1.68, -0.26),
        ("BR", 1.0, 0.30, 1.04, 0.36, 0.48, 1.42, 0.48),
    ]
    for tag, side, y_off, kx, ky, kz, fx, fy in leg_configs:
        # Segmento superior (corpo -> joelho)
        sx0, sy0, sz0 = side * 0.62, y_off, 0.36
        mx1, my1, mz1 = (sx0 + kx) * 0.5, (sy0 + ky) * 0.5, (sz0 + kz) * 0.5
        dx1, dy1, dz1 = kx - sx0, ky - sy0, kz - sz0
        len1 = math.sqrt(dx1 * dx1 + dy1 * dy1 + dz1 * dz1)
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_up_{tag}",
                6,
                0.085,
                0.070,
                len1 * 1.06,
                (mx1, my1, mz1),
                rotation=(
                    math.radians(-math.degrees(math.atan2(dy1, abs(dx1) + 1e-5)) * 0.25),
                    math.radians(side * (90.0 - math.degrees(math.atan2(dz1, abs(dx1))))),
                    math.radians(math.degrees(math.atan2(dy1, dx1)) - (0.0 if side > 0 else 180.0)),
                ),
            ),
            mat_prefix,
            "belly_shade" if "B" in tag else "belly_cream",
            pal,
        )
        # Joelho arredondado
        _add_part(
            parts,
            create_icosphere(f"_tmp_knee_{tag}", 1, 0.088, (kx, ky, kz)),
            mat_prefix,
            "belly_shade" if "B" in tag else "belly_cream",
            pal,
        )
        # Segmento inferior (joelho -> ponta do pé em Z=0.06)
        fz = 0.07
        mx2, my2, mz2 = (kx + fx) * 0.5, (ky + fy) * 0.5, (kz + fz) * 0.5
        dx2, dy2, dz2 = fx - kx, fy - ky, fz - kz
        len2 = math.sqrt(dx2 * dx2 + dy2 * dy2 + dz2 * dz2)
        pitch_y = math.degrees(math.atan2(abs(dx2), abs(dz2)))
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_lo_{tag}",
                6,
                0.055,
                0.078,
                len2 * 1.04,
                (mx2, my2, mz2),
                rotation=(
                    math.radians(math.degrees(math.atan2(dy2, abs(dz2))) * 0.5),
                    math.radians(side * -pitch_y),
                    0.0,
                ),
            ),
            mat_prefix,
            "belly_shade" if "B" in tag else "belly_cream",
            pal,
        )
        # Pontinha da pata tocando o solo
        _add_part(
            parts,
            create_cone(
                f"_tmp_foot_{tag}",
                5,
                0.075,
                0.022,
                0.20,
                (fx + side * 0.06, fy, 0.045),
                rotation=(0.0, math.radians(side * 82.0), 0.0),
                scale=(1.0, 0.75, 0.72),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )

    # 6. PINÇA DIREITA (-X) MÉDIA ERGUIDA (BRAÇO MENOR DO KINGLER)
    # Haste do braço direito saindo da lateral esquerda da vista
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R_stalk1",
            6,
            0.095,
            0.080,
            0.52,
            (-0.92, -0.08, 0.46),
            rotation=(0.0, math.radians(-78.0), math.radians(-12.0)),
        ),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R_stalk2",
            6,
            0.085,
            0.105,
            0.38,
            (-1.18, -0.14, 0.62),
            rotation=(math.radians(10.0), math.radians(-28.0), 0.0),
        ),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # Palma da pinça média
    _add_part(
        parts,
        create_icosphere(
            "_tmp_claw_R_palm",
            2,
            0.32,
            (-1.32, -0.18, 0.96),
            rotation=(0.0, math.radians(-16.0), 0.0),
            scale=(0.82, 0.78, 1.12),
        ),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Mandíbula superior curvada da pinça média
    _add_part(
        parts,
        create_cone(
            "_tmp_claw_R_upper",
            7,
            0.28,
            0.05,
            0.66,
            (-1.36, -0.22, 1.42),
            rotation=(math.radians(-10.0), math.radians(38.0), 0.0),
            scale=(0.90, 0.68, 1.0),
        ),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Polegar interno da pinça média
    _add_part(
        parts,
        create_cone(
            "_tmp_claw_R_lower",
            6,
            0.18,
            0.04,
            0.44,
            (-1.10, -0.24, 1.18),
            rotation=(math.radians(-12.0), math.radians(-22.0), 0.0),
            scale=(0.84, 0.65, 1.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )
    # Fundo escuro interno da abertura da pinça média
    _add_part(
        parts,
        create_icosphere(
            "_tmp_claw_R_hollow",
            1,
            0.14,
            (-1.18, -0.22, 1.24),
            scale=(0.70, 0.55, 1.10),
        ),
        mat_prefix,
        "claw_inner",
        pal,
    )

    # 7. PINÇA ESQUERDA (+X) COLOSSAL (MUITO MAIOR QUE O CORPO INTEIRO!)
    # Haste robusta conectando o corpo à pinça gigante
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_L_stalk",
            7,
            0.15,
            0.22,
            0.64,
            (0.86, -0.02, 0.94),
            rotation=(math.radians(-12.0), math.radians(52.0), 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )
    # Corpo principal massivo (palma traseira) da pinça colossal
    _add_part(
        parts,
        create_icosphere(
            "_tmp_bigclaw_back",
            2,
            0.54,
            (1.38, -0.10, 1.12),
            rotation=(0.0, math.radians(18.0), 0.0),
            scale=(0.86, 0.88, 1.26),
        ),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Mandíbula superior GIGANTE (larga, alta e volumosa curvando para frente/cima)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_bigclaw_top1",
            2,
            0.56,
            (1.06, -0.24, 1.66),
            rotation=(math.radians(-10.0), math.radians(-28.0), math.radians(12.0)),
            scale=(0.84, 0.80, 1.28),
        ),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_bigclaw_top_tip",
            7,
            0.40,
            0.10,
            0.62,
            (0.76, -0.34, 1.56),
            rotation=(math.radians(-14.0), math.radians(-128.0), 0.0),
            scale=(0.90, 0.76, 1.0),
        ),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Mandíbula inferior curva da pinça colossal
    _add_part(
        parts,
        create_icosphere(
            "_tmp_bigclaw_bot1",
            2,
            0.36,
            (1.16, -0.26, 0.56),
            rotation=(0.0, math.radians(24.0), 0.0),
            scale=(1.12, 0.78, 0.78),
        ),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_bigclaw_bot_tip",
            7,
            0.26,
            0.07,
            0.48,
            (0.84, -0.34, 0.70),
            rotation=(math.radians(-10.0), math.radians(-46.0), 0.0),
            scale=(0.88, 0.74, 1.0),
        ),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Cavidade escura profunda dentro da pinça gigante (dá contraste imediato!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_bigclaw_hollow",
            2,
            0.34,
            (1.04, -0.20, 1.06),
            scale=(0.76, 0.62, 1.14),
        ),
        mat_prefix,
        "claw_inner",
        pal,
    )
    # Dentes serrilhados brancos no interior da pinça colossal
    claw_teeth = [
        (0.88, -0.36, 1.24, 165.0),
        (1.06, -0.34, 1.32, 160.0),
        (0.92, -0.36, 0.80, 15.0),
        (1.08, -0.34, 0.74, 20.0),
    ]
    for t_idx, (tx, ty, tz, rx_d) in enumerate(claw_teeth):
        _add_part(
            parts,
            create_cone(
                f"_tmp_bigclaw_tooth_{t_idx}",
                4,
                0.065,
                0.014,
                0.15,
                (tx, ty, tz),
                rotation=(math.radians(rx_d), 0.0, 0.0),
            ),
            mat_prefix,
            "tooth_white",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 099. Clawking lado a lado."""
    specs = [
        ("Clawking_Shiny", (-12.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Clawking_Normal", (-7.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Clawking_Grande", (-1.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Clawking_Gigante", (6.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Clawking_Dourada_SuperRara", (15.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_clawking(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
