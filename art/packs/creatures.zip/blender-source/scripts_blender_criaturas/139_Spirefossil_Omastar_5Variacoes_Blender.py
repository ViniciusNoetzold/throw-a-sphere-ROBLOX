"""
139_Spirefossil_Omastar_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "139. Spirefossil — Nautilo Espinhoso (Ref: Omastar)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Spirefossil_Shiny (1.0x - Paleta Shiny Tentáculos Roxo-Ametista + Concha Bege Espinhosa)
  2. Spirefossil_Normal (1.0x - Concha Espiral Bege + 5 Espinhos Marfim + Bico Cruzado + Tentáculos Azuis)
  3. Spirefossil_Grande (1.35x - Normal)
  4. Spirefossil_Gigante (1.85x - Normal)
  5. Spirefossil_Dourada_SuperRara (2.25x - Concha Ouro Reluzente + Espinhos, Olhos e Tentáculos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para concha e rosto + cones para os 5 espinhos e tentáculos)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base alinhada exatamente em `Z = 0.0` e rosto/bico apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "shell_beige": (0.91, 0.85, 0.68, 1.0),
        "shell_shade": (0.74, 0.68, 0.54, 1.0),
        "shell_rib": (0.46, 0.40, 0.32, 1.0),
        "spike_ivory": (0.96, 0.94, 0.86, 1.0),
        "body_blue": (0.36, 0.76, 0.88, 1.0),
        "body_blue_shade": (0.22, 0.58, 0.74, 1.0),
        "eye_yellow": (0.96, 0.92, 0.64, 1.0),
        "eye_dark": (0.09, 0.09, 0.12, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "beak_ivory": (0.96, 0.93, 0.82, 1.0),
        "mouth_maroon": (0.42, 0.12, 0.22, 1.0),
    },
    "shiny_palette": {
        "shell_beige": (0.94, 0.88, 0.72, 1.0),
        "shell_shade": (0.76, 0.70, 0.56, 1.0),
        "shell_rib": (0.48, 0.42, 0.34, 1.0),
        "spike_ivory": (0.97, 0.95, 0.88, 1.0),
        "body_blue": (0.58, 0.36, 0.82, 1.0),
        "body_blue_shade": (0.42, 0.24, 0.64, 1.0),
        "eye_yellow": (0.96, 0.90, 0.58, 1.0),
        "eye_dark": (0.09, 0.09, 0.12, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "beak_ivory": (0.96, 0.93, 0.82, 1.0),
        "mouth_maroon": (0.46, 0.12, 0.24, 1.0),
    },
    "golden_super_rare_palette": {
        "shell_beige": (0.98, 0.78, 0.14, 1.0),
        "shell_shade": (0.82, 0.60, 0.08, 1.0),
        "shell_rib": (0.58, 0.40, 0.04, 1.0),
        "spike_ivory": (0.10, 0.92, 1.00, 1.0),
        "body_blue": (0.96, 0.76, 0.18, 1.0),
        "body_blue_shade": (0.78, 0.56, 0.08, 1.0),
        "eye_yellow": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.04, 0.40, 0.54, 1.0),
        "eye_white": (1.00, 0.99, 0.94, 1.0),
        "beak_ivory": (1.00, 0.96, 0.78, 1.0),
        "mouth_maroon": (0.08, 0.64, 0.78, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une primitivas, normaliza a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_spirefossil(
    name: str = "Spirefossil_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 139. Spirefossil (Ref: Omastar):
      - Grande concha espiralada bege-fóssil com gomos, espiral lateral e 5 espinhos cônicos duros marfim
      - Rosto feroz azul-oceano sob a aba ondulada da concha, com olhos amarelados de pupila vertical
      - Bico redondo marfim dividido em cruz escura com boca vinácea no centro do rosto
      - Tentáculos frontais altos erguidos + tentáculos laterais sinuosos e base firme em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Spire_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Spire_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Spire_Norm"

    parts = []

    # 1. CONCHA ESPIRALADA GRANDE COM ABAS E ESPIRAL LATERAL
    shell_arc = [
        (0.58, (0.0, -0.18, 0.96), (1.06, 0.88, 0.84), "shell_beige"),
        (0.58, (0.0, -0.06, 1.30), (1.02, 0.94, 0.90), "shell_beige"),
        (0.56, (0.0, 0.16, 1.56), (0.98, 0.98, 0.94), "shell_beige"),
        (0.52, (0.0, 0.44, 1.58), (0.94, 0.98, 0.94), "shell_beige"),
        (0.48, (0.0, 0.68, 1.36), (0.90, 0.96, 0.92), "shell_shade"),
        (0.44, (0.0, 0.76, 1.06), (0.86, 0.94, 0.92), "shell_shade"),
        (0.40, (0.0, 0.62, 0.78), (0.84, 0.90, 0.88), "shell_shade"),
    ]
    for idx, (rad, loc, sc, mkey) in enumerate(shell_arc):
        _add_part(
            parts,
            create_icosphere(f"_tmp_shell_seg_{idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            mkey,
            pal,
        )

    # Frisos transversais da concha
    rib_specs = [
        ((0.0, -0.14, 1.14), (70.0, 0.0, 0.0), 0.58, 0.04),
        ((0.0, 0.04, 1.44), (42.0, 0.0, 0.0), 0.56, 0.04),
        ((0.0, 0.30, 1.60), (6.0, 0.0, 0.0), 0.53, 0.04),
        ((0.0, 0.58, 1.50), (-34.0, 0.0, 0.0), 0.48, 0.04),
        ((0.0, 0.74, 1.22), (-68.0, 0.0, 0.0), 0.44, 0.04),
    ]
    for idx, (loc, (rx, ry, rz), rad, dep) in enumerate(rib_specs):
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_shell_rib_{idx}",
                10,
                rad,
                dep,
                loc,
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
                scale=(1.02, 0.88, 1.0),
            ),
            mat_prefix,
            "shell_rib",
            pal,
        )

    # Espiral lateral visível nos dois lados
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_spiral_outer_{tag}",
                10,
                0.38,
                0.12,
                (side * 0.44, 0.38, 1.14),
                rotation=(0.0, math.radians(90.0), 0.0),
            ),
            mat_prefix,
            "shell_shade",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_spiral_ring_{tag}",
                10,
                0.24,
                0.14,
                (side * 0.46, 0.40, 1.12),
                rotation=(0.0, math.radians(90.0), 0.0),
            ),
            mat_prefix,
            "shell_rib",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_spiral_core_{tag}",
                8,
                0.14,
                0.16,
                (side * 0.47, 0.38, 1.10),
                rotation=(0.0, math.radians(90.0), 0.0),
            ),
            mat_prefix,
            "shell_beige",
            pal,
        )

    # Borda ondulada sobre a testa (sobrancelha da concha)
    _add_part(
        parts,
        create_icosphere("_tmp_shell_brow_mid", 2, 0.22, (0.0, -0.58, 0.84), scale=(0.90, 0.82, 0.72)),
        mat_prefix,
        "shell_beige",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_shell_brow_{tag}",
                2,
                0.22,
                (side * 0.36, -0.46, 0.94),
                scale=(1.04, 0.88, 0.76),
            ),
            mat_prefix,
            "shell_beige",
            pal,
        )

    # 2. CINCO ESPINHOS CÔNICOS MARFIM NA CRISTA DA CONCHA (ASSINATURA DO OMASTAR)
    shell_spikes = [
        # (loc, rx_deg, r1, depth)
        ((0.0, -0.68, 1.10), -64.0, 0.14, 0.42),
        ((0.0, -0.42, 1.66), -36.0, 0.16, 0.50),
        ((0.0, 0.06, 2.08), -4.0, 0.17, 0.52),
        ((0.0, 0.54, 2.04), 26.0, 0.15, 0.46),
        ((0.0, 0.98, 1.66), 56.0, 0.13, 0.40),
    ]
    for idx, (loc, rx_deg, r1, dep) in enumerate(shell_spikes):
        _add_part(
            parts,
            create_cone(
                f"_tmp_shell_spike_{idx}",
                6,
                r1,
                0.018,
                dep,
                loc,
                rotation=(math.radians(rx_deg), 0.0, 0.0),
            ),
            mat_prefix,
            "spike_ivory",
            pal,
        )

    # 3. ROSTO FEROZ AZUL-OCEANO, OLHOS AMARELADOS COM FENDA VERTICAL E BICO EM CRUZ
    _add_part(
        parts,
        create_icosphere("_tmp_face_core", 2, 0.52, (0.0, -0.24, 0.50), scale=(1.12, 0.92, 0.88)),
        mat_prefix,
        "body_blue",
        pal,
    )
    # Dois lobos/pés inferiores curtos dando apoio firme no chão (Z = 0.0)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_foot_lobe_{tag}",
                8,
                0.20,
                0.10,
                0.34,
                (side * 0.36, -0.34, 0.14),
                rotation=(math.radians(-118.0), math.radians(side * 24.0), 0.0),
                scale=(1.0, 0.84, 1.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    # Olhos grandes amarelo-claros com pupila em fenda vertical preta
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_yellow_{tag}",
                2,
                0.175,
                (side * 0.24, -0.64, 0.72),
                scale=(0.96, 0.64, 1.06),
            ),
            mat_prefix,
            "eye_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_slit_{tag}",
                (0.055, 0.06, 0.24),
                (side * 0.24, -0.74, 0.72),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.036,
                (side * 0.20, -0.77, 0.78),
                scale=(0.82, 0.50, 0.92),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # Bico redondo marfim com cruz preta e interior vináceo
    _add_part(
        parts,
        create_icosphere("_tmp_beak_dome", 2, 0.22, (0.0, -0.68, 0.40), scale=(1.18, 0.72, 0.94)),
        mat_prefix,
        "beak_ivory",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_beak_cross_v", (0.075, 0.09, 0.40), (0.0, -0.80, 0.40)),
        mat_prefix,
        "eye_dark",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_beak_cross_h", (0.48, 0.09, 0.075), (0.0, -0.80, 0.40)),
        mat_prefix,
        "eye_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_inner", 1, 0.08, (0.0, -0.82, 0.36), scale=(1.05, 0.55, 0.85)),
        mat_prefix,
        "mouth_maroon",
        pal,
    )

    # 4. TENTÁCULOS FRONTAIS ALTOS + TENTÁCULOS LATERAIS SINUOSOS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Tentáculo frontal grosso erguido em arco ao lado dos olhos
        _add_part(
            parts,
            create_cone(
                f"_tmp_front_tent_base_{tag}",
                8,
                0.19,
                0.14,
                0.48,
                (side * 0.56, -0.44, 0.66),
                rotation=(math.radians(-10.0), math.radians(side * 22.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_front_tent_tip_{tag}",
                8,
                0.13,
                0.02,
                0.50,
                (side * 0.62, -0.46, 1.10),
                rotation=(math.radians(-6.0), math.radians(side * -10.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

        # Tentáculo lateral longo superior (ondulando para fora e para cima)
        _add_part(
            parts,
            create_cone(
                f"_tmp_side_tent_up1_{tag}",
                7,
                0.12,
                0.085,
                0.54,
                (side * 0.78, -0.22, 0.56),
                rotation=(0.0, math.radians(side * 66.0), 0.0),
            ),
            mat_prefix,
            "body_blue_shade",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_side_tent_up2_{tag}",
                7,
                0.082,
                0.016,
                0.56,
                (side * 0.98, -0.24, 0.96),
                rotation=(math.radians(-8.0), math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

        # Tentáculo lateral inferior sinuoso
        _add_part(
            parts,
            create_cone(
                f"_tmp_side_tent_lo1_{tag}",
                7,
                0.11,
                0.075,
                0.52,
                (side * 0.72, -0.14, 0.26),
                rotation=(0.0, math.radians(side * 86.0), 0.0),
            ),
            mat_prefix,
            "body_blue_shade",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_side_tent_lo2_{tag}",
                7,
                0.072,
                0.016,
                0.42,
                (side * 1.02, -0.18, 0.34),
                rotation=(0.0, math.radians(side * 46.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 139. Spirefossil lado a lado."""
    specs = [
        ("Spirefossil_Shiny", (-10.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Spirefossil_Normal", (-6.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Spirefossil_Grande", (-1.2, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Spirefossil_Gigante", (4.9, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Spirefossil_Dourada_SuperRara", (12.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_spirefossil(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
