"""
113_Nurseegg_Chansey_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "113. Nurseegg — Guardiã do Ovo (Ref: Chansey)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Nurseegg_Shiny (1.0x - Paleta Shiny Verde-Menta Pastel + Pontas e Bolsa Verde-Folha + Ovo Branco)
  2. Nurseegg_Normal (1.0x - Rosa-Pastel + 3 Mechas Laterais + Bolsa Coral com Grande Ovo Branco)
  3. Nurseegg_Grande (1.35x - Normal)
  4. Nurseegg_Gigante (1.85x - Normal)
  5. Nurseegg_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Ovo Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para corpo oval e ovo, cones 8 lados para mechas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés em pá alinhados exatamente em `Z = 0.0` e rosto/ovo apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_pink": (0.98, 0.78, 0.86, 1.0),
        "accent_pink": (0.90, 0.56, 0.64, 1.0),
        "tail_pink": (0.86, 0.66, 0.78, 1.0),
        "egg_white": (0.98, 0.97, 0.95, 1.0),
        "smile_dark": (0.48, 0.26, 0.34, 1.0),
        "eye_dark": (0.12, 0.16, 0.24, 1.0),
        "shine_white": (1.00, 1.00, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_pink": (0.72, 0.90, 0.66, 1.0),
        "accent_pink": (0.42, 0.74, 0.42, 1.0),
        "tail_pink": (0.58, 0.80, 0.56, 1.0),
        "egg_white": (0.98, 0.98, 0.95, 1.0),
        "smile_dark": (0.24, 0.46, 0.26, 1.0),
        "eye_dark": (0.12, 0.16, 0.24, 1.0),
        "shine_white": (1.00, 1.00, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_pink": (0.98, 0.78, 0.14, 1.0),
        "accent_pink": (0.84, 0.58, 0.08, 1.0),
        "tail_pink": (0.90, 0.68, 0.12, 1.0),
        "egg_white": (0.10, 0.92, 1.00, 1.0),
        "smile_dark": (0.56, 0.36, 0.04, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "shine_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_nurseegg(
    name: str = "Nurseegg_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 113. Nurseegg (Ref: Chansey):
      - Grande corpo oval em forma de ovo rosa-pastel suave e harmonioso
      - 3 mechas laterais fluidas com pontas rosa-coral em cada lado da cabeça (6 no total)
      - Rosto gentil no topo frontal com olhos ovais delicados e sorriso acolhedor
      - Bolsa frontal coral abrigando um grande ovo branco liso abraçado pelos bracinhos curtos
      - Pés achatados em pá alinhados em Z = 0.0 e pequena cauda afilada atrás à direita
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Nurse_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Nurse_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Nurse_Norm"

    parts = []

    # 1. CORPO GRANDE EM FORMA DE OVO (BASE LARGA + TOPO ARREDONDADO)
    _add_part(
        parts,
        create_icosphere("_tmp_body_lower", 2, 0.88, (0.0, 0.02, 0.88), scale=(1.06, 0.96, 0.94)),
        mat_prefix,
        "body_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_body_upper", 2, 0.72, (0.0, 0.00, 1.38), scale=(0.94, 0.90, 0.98)),
        mat_prefix,
        "body_pink",
        pal,
    )

    # 2. 3 MECHAS LATERAIS FLUIDAS EM CADA LADO DA CABEÇA COM PONTAS CORAL
    tendril_specs = [
        # (z_base, z_tip, x_mid, x_tip, rot_y_deg, length, r_base)
        (1.66, 1.72, 0.88, 1.18, 82.0, 0.56, 0.14),
        (1.50, 1.48, 0.98, 1.34, 92.0, 0.64, 0.15),
        (1.34, 1.24, 0.94, 1.26, 106.0, 0.58, 0.14),
    ]
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        for t_idx, (zb, zt, xm, xt, ry_deg, length, rb) in enumerate(tendril_specs):
            # Haste rosa-pastel
            _add_part(
                parts,
                create_cone(
                    f"_tmp_tendril_base_{tag}_{t_idx}",
                    8,
                    rb,
                    rb * 0.76,
                    length,
                    (side * xm, 0.02 - t_idx * 0.02, (zb + zt) * 0.5),
                    rotation=(0.0, math.radians(side * ry_deg), 0.0),
                    scale=(1.00, 0.56, 1.00),
                ),
                mat_prefix,
                "body_pink",
                pal,
            )
            # Ponta arredondada em rosa-coral
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_tendril_tip_{tag}_{t_idx}",
                    2,
                    rb * 0.84,
                    (side * xt, 0.02 - t_idx * 0.02, zt),
                    rotation=(0.0, math.radians(side * (ry_deg - 90.0)), 0.0),
                    scale=(1.55, 0.56, 0.88),
                ),
                mat_prefix,
                "accent_pink",
                pal,
            )

    # 3. ROSTO GENTIL: OLHOS OVAIS DELICADOS + SORRISO SERENO
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.068,
                (side * 0.20, -0.62, 1.66),
                scale=(0.56, 0.45, 1.28),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.024,
                (side * 0.195, -0.652, 1.70),
                scale=(0.70, 0.50, 1.05),
            ),
            mat_prefix,
            "shine_white",
            pal,
        )

    # Sorriso fino gentil em 3 pequenos segmentos curvados
    for s_idx, (sx, sz, ry_deg) in enumerate([(-0.08, 1.54, 24.0), (0.0, 1.51, 0.0), (0.08, 1.54, -24.0)]):
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_smile_{s_idx}",
                6,
                0.018,
                0.11,
                (sx, -0.665, sz),
                rotation=(0.0, math.radians(90.0 + ry_deg), 0.0),
            ),
            mat_prefix,
            "smile_dark",
            pal,
        )

    # 4. BOLSA FRONTAL CORAL + GRANDE OVO BRANCO LISO
    _add_part(
        parts,
        create_icosphere(
            "_tmp_egg",
            2,
            0.36,
            (0.0, -0.76, 0.78),
            scale=(0.94, 0.78, 1.16),
        ),
        mat_prefix,
        "egg_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_pouch_cup",
            2,
            0.39,
            (0.0, -0.76, 0.56),
            scale=(0.98, 0.84, 0.76),
        ),
        mat_prefix,
        "accent_pink",
        pal,
    )
    # Borda suave da bolsa abraçando o meio do ovo
    _add_part(
        parts,
        create_icosphere(
            "_tmp_pouch_rim",
            2,
            0.38,
            (0.0, -0.78, 0.68),
            scale=(1.02, 0.84, 0.24),
        ),
        mat_prefix,
        "accent_pink",
        pal,
    )

    # 5. BRACINHOS CURTOS EM GOTA ABRAÇANDO O OVO CARINHOSAMENTE
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_{tag}",
                8,
                0.16,
                0.08,
                0.44,
                (side * 0.42, -0.76, 1.06),
                rotation=(math.radians(-26.0), math.radians(side * -138.0), 0.0),
                scale=(1.00, 0.74, 1.00),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hand_{tag}",
                2,
                0.095,
                (side * 0.30, -0.92, 0.94),
                scale=(1.12, 0.72, 0.86),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )

    # 6. PÉS EM PÁ CORAL APOIADOS EM Z = 0.0 + CAUDA CURTA ATRÁS À DIREITA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.24,
                (side * 0.54, -0.18, 0.12),
                rotation=(0.0, 0.0, math.radians(side * -28.0)),
                scale=(0.94, 1.48, 0.48),
            ),
            mat_prefix,
            "accent_pink",
            pal,
        )

    _add_part(
        parts,
        create_cone(
            "_tmp_tail",
            6,
            0.16,
            0.03,
            0.52,
            (0.62, 0.72, 0.34),
            rotation=(math.radians(72.0), math.radians(48.0), 0.0),
            scale=(1.00, 0.72, 1.00),
        ),
        mat_prefix,
        "tail_pink",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 113. Nurseegg lado a lado."""
    specs = [
        ("Nurseegg_Shiny", (-11.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Nurseegg_Normal", (-6.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Nurseegg_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Nurseegg_Gigante", (6.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Nurseegg_Dourada_SuperRara", (15.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_nurseegg(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
