"""
015_Lancewasp_Beedrill_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "015. Lancewasp — Vespa Lanceira (Ref: Beedrill)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Lancewasp_Shiny (1.0x - Paleta Shiny / Shyne Vespa Verde-Neon + Olhos Azul-Safira)
  2. Lancewasp_Normal (1.0x - Amarelo Vespa + Listras Pretas + Twin Lanças Brancas + Olhos Rubi)
  3. Lancewasp_Grande (1.35x - Normal)
  4. Lancewasp_Gigante (1.85x - Normal)
  5. Lancewasp_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Garras inferiores das pernas de vespa alinhadas em `Z = 0.0` e twin lanças apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Lancewasp_Shiny`, `Lancewasp_Normal`, `Lancewasp_Grande`,
     `Lancewasp_Gigante`, `Lancewasp_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "wasp_yellow": (0.98, 0.82, 0.16, 1.0),
        "stripe_black": (0.14, 0.14, 0.18, 1.0),
        "lance_white": (0.96, 0.97, 0.99, 1.0),
        "eye_ruby": (0.92, 0.16, 0.22, 1.0),
        "wing_ice": (0.90, 0.96, 1.00, 1.0),
        "wing_vein": (0.24, 0.28, 0.34, 1.0),
    },
    "shiny_palette": {
        "wasp_yellow": (0.36, 0.88, 0.24, 1.0),
        "stripe_black": (0.14, 0.16, 0.16, 1.0),
        "lance_white": (0.97, 0.99, 0.97, 1.0),
        "eye_ruby": (0.14, 0.56, 0.96, 1.0),
        "wing_ice": (0.90, 0.98, 0.92, 1.0),
        "wing_vein": (0.20, 0.30, 0.24, 1.0),
    },
    "golden_super_rare_palette": {
        "wasp_yellow": (0.98, 0.78, 0.12, 1.0),
        "stripe_black": (0.64, 0.42, 0.06, 1.0),
        "lance_white": (1.00, 0.98, 0.90, 1.0),
        "eye_ruby": (0.10, 0.92, 1.00, 1.0),
        "wing_ice": (1.00, 0.96, 0.68, 1.0),
        "wing_vein": (0.76, 0.54, 0.10, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha as patas em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_lancewasp(
    name: str = "Lancewasp_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 015. Lancewasp (Ref: Beedrill):
      - Frente apontando para -Y e pernas inferiores tocando Z = 0.0
      - Tórax preto/amarelo esguio + grande abdômen listrado de vespa terminando em ferrão
      - Cabeça triangular angular com olhos grandes vermelhos e antenas quebradas em ângulo
      - Braços segurando duas enormes lanças/furadeiras brancas para -Y + 4 asas com nervuras
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Wasp_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Wasp_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Wasp"

    parts = []

    # 1. TÓRAX ESGUIO, PESCOÇO E CINTURA FINA DE VESPA
    _add_part(parts, create_cube("_tmp_thorax", (0.64, 0.62, 0.72), (0.0, -0.02, 1.32)), mat_prefix, "stripe_black", pal)
    _add_part(parts, create_cube("_tmp_chest_plate", (0.56, 0.24, 0.48), (0.0, -0.28, 1.34)), mat_prefix, "wasp_yellow", pal)
    _add_part(parts, create_cylinder("_tmp_waist", 6, 0.16, 0.34, (0.0, 0.26, 0.96), rotation=(math.radians(42.0), 0.0, 0.0)), mat_prefix, "stripe_black", pal)

    # 2. ABDÔMEN LISTRADO DE VESPA + FERRÃO TRASEIRO (+Y)
    _add_part(parts, create_icosphere("_tmp_abd_front", 1, 0.42, (0.0, 0.56, 0.76)), mat_prefix, "wasp_yellow", pal)
    _add_part(
        parts,
        create_cylinder("_tmp_abd_stripe1", 6, 0.43, 0.20, (0.0, 0.68, 0.70), rotation=(math.radians(74.0), 0.0, 0.0)),
        mat_prefix,
        "stripe_black",
        pal,
    )
    _add_part(parts, create_icosphere("_tmp_abd_mid", 1, 0.44, (0.0, 0.84, 0.64)), mat_prefix, "wasp_yellow", pal)
    _add_part(
        parts,
        create_cylinder("_tmp_abd_stripe2", 6, 0.36, 0.18, (0.0, 0.98, 0.56), rotation=(math.radians(74.0), 0.0, 0.0)),
        mat_prefix,
        "stripe_black",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_abd_stinger",
            6,
            0.22,
            0.02,
            0.56,
            (0.0, 1.24, 0.46),
            rotation=(math.radians(-108.0), 0.0, 0.0),
        ),
        mat_prefix,
        "lance_white",
        pal,
    )

    # 3. CABEÇA TRIANGULAR + MANDÍBULA + GRANDES OLHOS + ANTENAS QUEBRADAS
    _add_part(
        parts,
        create_cone("_tmp_head_tri", 6, 0.46, 0.20, 0.60, (0.0, -0.22, 1.94), rotation=(math.radians(164.0), 0.0, 0.0)),
        mat_prefix,
        "wasp_yellow",
        pal,
    )
    _add_part(parts, create_cube("_tmp_jaw_snout", (0.28, 0.36, 0.24), (0.0, -0.44, 1.72)), mat_prefix, "wasp_yellow", pal)

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_{tag}",
                (0.22, 0.28, 0.34),
                (side * 0.26, -0.40, 1.98),
                rotation=(math.radians(12.0), math.radians(side * 16.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_ruby",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_glint_{tag}", (0.08, 0.08, 0.10), (side * 0.31, -0.52, 2.08)),
            mat_prefix,
            "lance_white",
            pal,
        )
        # Antenas em dois segmentos (haste vertical + ponta inclinada para trás/fora)
        _add_part(
            parts,
            create_cube(f"_tmp_ant_base_{tag}", (0.07, 0.07, 0.32), (side * 0.18, -0.18, 2.34), rotation=(math.radians(-10.0), math.radians(side * 12.0), 0.0)),
            mat_prefix,
            "stripe_black",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_ant_tip_{tag}",
                (0.06, 0.46, 0.06),
                (side * 0.28, 0.04, 2.48),
                rotation=(math.radians(-14.0), 0.0, math.radians(side * -18.0)),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )

    # 4. TWIN BRAÇOS + ENORMES LANÇAS / FURADEIRAS BRANCAS APONTANDO PARA -Y
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_shoulder_{tag}",
                (0.24, 0.24, 0.46),
                (side * 0.44, -0.14, 1.38),
                rotation=(math.radians(24.0), math.radians(side * -14.0), 0.0),
            ),
            mat_prefix,
            "wasp_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_lance_guard_{tag}",
                6,
                0.20,
                0.14,
                (side * 0.54, -0.44, 1.24),
                rotation=(math.radians(78.0), 0.0, math.radians(side * -10.0)),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_lance_{tag}",
                6,
                0.24,
                0.02,
                1.04,
                (side * 0.62, -0.98, 1.14),
                rotation=(math.radians(78.0), 0.0, math.radians(side * -10.0)),
            ),
            mat_prefix,
            "lance_white",
            pal,
        )

    # 5. PAR DE PERNAS DE VESPA ARTICULADAS TOCANDO Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_leg_upper_{tag}",
                (0.14, 0.16, 0.56),
                (side * 0.26, -0.06, 0.78),
                rotation=(math.radians(16.0), math.radians(side * 10.0), 0.0),
            ),
            mat_prefix,
            "wasp_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_leg_lower_{tag}",
                (0.12, 0.14, 0.54),
                (side * 0.34, -0.18, 0.32),
                rotation=(math.radians(-18.0), math.radians(side * 8.0), 0.0),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_leg_claw_{tag}",
                (0.16, 0.28, 0.12),
                (side * 0.36, -0.28, 0.06),
            ),
            mat_prefix,
            "lance_white",
            pal,
        )

    # 6. QUATRO ASAS DE VESPA TRANSLÚCIDO-OPALINAS COM BORDAS ESCURAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        yaw_w = math.radians(side * 24.0)
        # Asa superior longa
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_up_{tag}",
                (1.22, 0.07, 0.44),
                (side * 0.88, 0.38, 1.66),
                rotation=(math.radians(-12.0), math.radians(side * -18.0), yaw_w),
            ),
            mat_prefix,
            "wing_ice",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_up_rim_{tag}",
                (1.26, 0.10, 0.09),
                (side * 0.90, 0.39, 1.86),
                rotation=(math.radians(-12.0), math.radians(side * -18.0), yaw_w),
            ),
            mat_prefix,
            "wing_vein",
            pal,
        )
        # Asa inferior média
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_low_{tag}",
                (0.86, 0.07, 0.32),
                (side * 0.72, 0.40, 1.24),
                rotation=(math.radians(8.0), math.radians(side * 12.0), yaw_w),
            ),
            mat_prefix,
            "wing_ice",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_low_rim_{tag}",
                (0.88, 0.10, 0.07),
                (side * 0.72, 0.41, 1.38),
                rotation=(math.radians(8.0), math.radians(side * 12.0), yaw_w),
            ),
            mat_prefix,
            "wing_vein",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 015. Lancewasp lado a lado."""
    specs = [
        ("Lancewasp_Shiny", (-8.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Lancewasp_Normal", (-5.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Lancewasp_Grande", (-1.0, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Lancewasp_Gigante", (3.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Lancewasp_Dourada_SuperRara", (10.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_lancewasp(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
