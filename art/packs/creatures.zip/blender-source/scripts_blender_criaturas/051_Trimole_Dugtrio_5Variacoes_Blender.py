"""
051_Trimole_Dugtrio_5Variacoes_Blender.py
=========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "051. Trimole — Trio Subterrâneo (Ref: Dugtrio)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Trimole_Shiny (1.0x - Três Toupeiras Marrom-Terra + Três Icônicos Narizes Azul-Céu)
  2. Trimole_Normal (1.0x - Trio de Toupeiras em Alturas Diferentes + Narizes Rosa + Base Rochosa Única)
  3. Trimole_Grande (1.35x - Normal)
  4. Trimole_Gigante (1.85x - Normal)
  5. Trimole_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Narizes Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (3 cápsulas com alturas e inclinações fiéis à arte + anel rochoso)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base rochosa alinhada exatamente em `Z = 0.0` e rostos apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_brown": (0.68, 0.54, 0.44, 1.0),
        "nose_pink": (0.91, 0.54, 0.72, 1.0),
        "nose_shine": (0.98, 0.84, 0.92, 1.0),
        "soil_gray": (0.52, 0.53, 0.57, 1.0),
        "rock_light": (0.76, 0.78, 0.82, 1.0),
        "rock_dark": (0.38, 0.40, 0.44, 1.0),
        "eye_dark": (0.10, 0.10, 0.13, 1.0),
        "eye_shine": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_brown": (0.71, 0.56, 0.42, 1.0),
        "nose_pink": (0.20, 0.66, 0.98, 1.0),
        "nose_shine": (0.74, 0.92, 1.00, 1.0),
        "soil_gray": (0.52, 0.53, 0.57, 1.0),
        "rock_light": (0.76, 0.78, 0.82, 1.0),
        "rock_dark": (0.38, 0.40, 0.44, 1.0),
        "eye_dark": (0.10, 0.10, 0.13, 1.0),
        "eye_shine": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_brown": (0.98, 0.78, 0.14, 1.0),
        "nose_pink": (0.10, 0.92, 1.00, 1.0),
        "nose_shine": (0.78, 0.98, 1.00, 1.0),
        "soil_gray": (0.82, 0.60, 0.10, 1.0),
        "rock_light": (1.00, 0.88, 0.34, 1.0),
        "rock_dark": (0.68, 0.46, 0.08, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "eye_shine": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_mole_head(parts, tag, base_x, base_y, cyl_h, radius, tilt_y_deg, mat_prefix, pal):
    """Adiciona uma das três toupeiras com altura, posição e inclinação personalizadas."""
    ry = math.radians(tilt_y_deg)
    sin_y = math.sin(ry)
    cos_y = math.cos(ry)

    def local_to_world(lx, ly, lz):
        # Rotação ao redor do eixo Y (pivô na base z=0.20)
        wx = base_x + lx * cos_y + lz * sin_y
        wy = base_y + ly
        wz = 0.20 - lx * sin_y + lz * cos_y
        return (wx, wy, wz)

    # Cilindro do corpo
    _add_part(
        parts,
        create_cylinder(
            f"_tmp_cyl_{tag}",
            12,
            radius,
            cyl_h,
            local_to_world(0.0, 0.0, cyl_h * 0.5),
            rotation=(0.0, ry, 0.0),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Cúpula arredondada
    _add_part(
        parts,
        create_icosphere(
            f"_tmp_dome_{tag}",
            2,
            radius,
            local_to_world(0.0, 0.0, cyl_h),
            rotation=(0.0, ry, 0.0),
            scale=(1.00, 1.00, 0.96),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )

    # Olhos ovais verticais + brilho
    for side in (-1.0, 1.0):
        etag = f"{tag}_{'L' if side < 0 else 'R'}"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{etag}",
                2,
                radius * 0.16,
                local_to_world(side * radius * 0.28, -radius * 0.92, cyl_h + radius * 0.22),
                rotation=(0.0, ry, 0.0),
                scale=(0.54, 0.44, 1.38),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_shine_{etag}",
                1,
                radius * 0.06,
                local_to_world(side * radius * 0.27, -radius * 1.00, cyl_h + radius * 0.31),
                rotation=(0.0, ry, 0.0),
                scale=(0.72, 0.45, 1.05),
            ),
            mat_prefix,
            "eye_shine",
            pal,
        )

    # Nariz oval rosa (azul na Shiny!)
    _add_part(
        parts,
        create_icosphere(
            f"_tmp_nose_{tag}",
            2,
            radius * 0.38,
            local_to_world(0.0, -radius * 1.02, cyl_h - radius * 0.16),
            rotation=(0.0, ry, 0.0),
            scale=(1.22, 0.72, 0.74),
        ),
        mat_prefix,
        "nose_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            f"_tmp_nshine_{tag}",
            1,
            radius * 0.13,
            local_to_world(-radius * 0.12, -radius * 1.24, cyl_h - radius * 0.06),
            rotation=(0.0, ry, 0.0),
            scale=(1.35, 0.40, 0.65),
        ),
        mat_prefix,
        "nose_shine",
        pal,
    )


def build_trimole(
    name: str = "Trimole_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 051. Trimole (Ref: Dugtrio):
      - Trio de toupeiras emergindo juntas de uma única cratera rochosa:
        * Toupeira traseira alta (atrás à direita-centro)
        * Toupeira frontal esquerda média (ereta)
        * Toupeira frontal direita mais baixa (inclinada ~12° para o lado, fiel à arte!)
      - Cada uma com olhos brilhantes e nariz oval rosa (azul na Shiny)
      - Base ampla e irregular de terra cinza e pedras facetadas em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Tri_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Tri_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Tri_Norm"

    parts = []

    # 1. AS TRÊS TOUPEIRAS (ALTURAS E POSIÇÕES IDÊNTICAS À ARTE OFICIAL DO DUGTRIO)
    # Traseira alta
    _add_mole_head(parts, "Top", 0.16, 0.36, 1.44, 0.45, 2.0, mat_prefix, pal)
    # Frontal esquerda média
    _add_mole_head(parts, "Left", -0.44, -0.22, 0.98, 0.44, -2.0, mat_prefix, pal)
    # Frontal direita baixa inclinada com charme
    _add_mole_head(parts, "Right", 0.46, -0.24, 0.68, 0.42, 13.0, mat_prefix, pal)

    # 2. BASE ROCHOSA AMPLA UNIFICADA EM Z = 0.0
    _add_part(
        parts,
        create_cone("_tmp_soil_main", 12, 1.38, 1.04, 0.32, (0.0, 0.02, 0.16), scale=(1.12, 0.94, 1.0)),
        mat_prefix,
        "soil_gray",
        pal,
    )
    rock_specs = [
        (-1.02, -0.46, 0.20, 0.25, (14.0, 16.0, 22.0), (1.30, 0.90, 0.78), "rock_light"),
        (-0.56, -0.78, 0.19, 0.24, (10.0, -14.0, 12.0), (1.34, 0.88, 0.74), "rock_light"),
        (-0.08, -0.84, 0.18, 0.22, (-12.0, 18.0, -18.0), (1.28, 0.90, 0.76), "rock_light"),
        (0.46, -0.82, 0.18, 0.24, (12.0, -20.0, 24.0), (1.32, 0.86, 0.72), "soil_gray"),
        (0.96, -0.56, 0.19, 0.23, (-14.0, 14.0, -30.0), (1.26, 0.92, 0.76), "rock_light"),
        (1.18, -0.04, 0.18, 0.24, (10.0, 18.0, 12.0), (1.22, 0.94, 0.72), "rock_light"),
        (-1.18, 0.02, 0.20, 0.26, (-14.0, -16.0, 18.0), (1.18, 0.96, 0.80), "soil_gray"),
        (-0.88, 0.62, 0.20, 0.26, (18.0, 12.0, -26.0), (1.24, 0.92, 0.78), "rock_light"),
        (0.86, 0.64, 0.19, 0.26, (-16.0, -14.0, 22.0), (1.26, 0.92, 0.76), "rock_light"),
        (0.06, 0.92, 0.21, 0.28, (12.0, 8.0, 0.0), (1.40, 0.88, 0.80), "soil_gray"),
        (0.18, -0.94, 0.12, 0.16, (10.0, -10.0, 14.0), (1.28, 0.86, 0.66), "rock_light"),
        (-0.80, -0.68, 0.13, 0.15, (18.0, 14.0, 32.0), (1.16, 0.88, 0.68), "rock_dark"),
        (0.76, -0.74, 0.13, 0.16, (-16.0, 12.0, -24.0), (1.24, 0.84, 0.66), "rock_light"),
    ]
    for r_i, (rx, ry, rz, rad, rot_d, sc, key) in enumerate(rock_specs):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_rock_{r_i}",
                1,
                rad,
                (rx, ry, rz),
                rotation=tuple(math.radians(a) for a in rot_d),
                scale=sc,
            ),
            mat_prefix,
            key,
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 051. Trimole lado a lado."""
    specs = [
        ("Trimole_Shiny", (-10.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Trimole_Normal", (-6.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Trimole_Grande", (-1.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Trimole_Gigante", (4.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Trimole_Dourada_SuperRara", (12.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_trimole(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
