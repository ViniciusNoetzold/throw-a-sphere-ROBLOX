"""
134_Aquavulp_Vaporeon_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "134. Aquavulp — Sereia Lupina (Ref: Vaporeon)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Aquavulp_Shiny (1.0x - Paleta Shiny Clássica Orquídea-Púrpura + Crista Violeta + Gola Branca)
  2. Aquavulp_Normal (1.0x - Corpo Azul-Água + Gola em Leque Branca + Orelhas Barbatanas + Cauda de Sereia)
  3. Aquavulp_Grande (1.35x - Normal)
  4. Aquavulp_Gigante (1.85x - Normal)
  5. Aquavulp_Dourada_SuperRara (2.25x - Ouro Reluzente + Crista Dorsal, Barbatana Central e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para silhueta elegante sentada, cones 5-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas e curva da cauda alinhadas exatamente em `Z = 0.0` e rosto sorridente apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_aqua": (0.36, 0.77, 0.90, 1.0),
        "fin_yellow": (0.95, 0.92, 0.70, 1.0),
        "ruff_white": (0.94, 0.96, 0.99, 1.0),
        "crest_navy": (0.17, 0.43, 0.62, 1.0),
        "eye_dark": (0.09, 0.09, 0.13, 1.0),
        "eye_purple": (0.48, 0.24, 0.58, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "mouth_pink": (0.72, 0.42, 0.52, 1.0),
        "tongue_pink": (0.92, 0.62, 0.70, 1.0),
    },
    "shiny_palette": {
        "body_aqua": (0.76, 0.34, 0.78, 1.0),
        "fin_yellow": (0.95, 0.92, 0.68, 1.0),
        "ruff_white": (0.96, 0.95, 0.99, 1.0),
        "crest_navy": (0.44, 0.15, 0.54, 1.0),
        "eye_dark": (0.09, 0.08, 0.13, 1.0),
        "eye_purple": (0.28, 0.62, 0.86, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "mouth_pink": (0.72, 0.34, 0.52, 1.0),
        "tongue_pink": (0.94, 0.58, 0.70, 1.0),
    },
    "golden_super_rare_palette": {
        "body_aqua": (0.98, 0.78, 0.14, 1.0),
        "fin_yellow": (1.00, 0.94, 0.58, 1.0),
        "ruff_white": (1.00, 0.97, 0.80, 1.0),
        "crest_navy": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.06, 0.46, 0.64, 1.0),
        "eye_purple": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "mouth_pink": (0.82, 0.52, 0.08, 1.0),
        "tongue_pink": (0.98, 0.80, 0.30, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_aquavulp(
    name: str = "Aquavulp_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 134. Aquavulp (Ref: Vaporeon):
      - Pose sentada elegante com 2 patas dianteiras juntas apoiadas em Z = 0.0
      - Grande colarinho branco plissado em leque envolvendo todo o pescoço
      - Cabeça felina-aquática com topo azul-marinho, barbatana central alta e 2 orelhas-barbatanas amarelas largas
      - Rosto sorridente feliz com olhos escuros/violeta brilhantes e boca aberta rosada
      - Longa cauda sinuosa de sereia curvando ao redor do corpo até a direita com barbatana caudal bifurcada
      - Crista dorsal azul-marinho serrilhada percorrendo das costas até a ponta da cauda
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Aqua_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Aqua_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Aqua_Norm"

    parts = []

    # 1. CORPO SENTADO ELEGANTE + 2 PATAS DIANTEIRAS JUNTAS (Z = 0.0)
    _add_part(
        parts,
        create_icosphere("_tmp_chest", 2, 0.42, (0.0, -0.10, 0.88), scale=(0.86, 0.92, 1.12)),
        mat_prefix,
        "body_aqua",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hips", 2, 0.46, (-0.28, 0.24, 0.56), scale=(1.04, 1.18, 0.90)),
        mat_prefix,
        "body_aqua",
        pal,
    )
    # 2 patas dianteiras esguias juntas apoiadas limpo em Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_front_leg_{tag}",
                7,
                0.095,
                0.145,
                0.76,
                (side * 0.14, -0.26, 0.44),
                rotation=(math.radians(4.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_aqua",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_front_paw_{tag}",
                2,
                0.12,
                (side * 0.14, -0.34, 0.09),
                scale=(0.90, 1.32, 0.62),
            ),
            mat_prefix,
            "body_aqua",
            pal,
        )

    # 2. LONGA CAUDA SINUOSA DE SEREIA CURVANDO DA ESQUERDA PARA A DIREITA + BARBATANA BIFURCADA
    tail_nodes = [
        # (x, y, z, rad, has_spine, spine_rot_y)
        (-0.62, 0.32, 0.52, 0.38, True, -42.0),
        (-0.88, 0.12, 0.40, 0.33, True, -54.0),
        (-0.92, -0.20, 0.30, 0.28, True, -36.0),
        (-0.64, -0.44, 0.28, 0.24, True, -12.0),
        (-0.24, -0.52, 0.34, 0.21, True, 0.0),
        (0.18, -0.48, 0.42, 0.18, True, 10.0),
        (0.56, -0.38, 0.46, 0.15, True, 14.0),
        (0.88, -0.28, 0.46, 0.12, False, 0.0),
    ]
    for t_idx, (tx, ty, tz, rad, has_sp, sry) in enumerate(tail_nodes):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tail_seg_{t_idx}", 2, rad, (tx, ty, tz), scale=(1.12, 0.96, 0.92)),
            mat_prefix,
            "body_aqua",
            pal,
        )
        if has_sp:
            _add_part(
                parts,
                create_cone(
                    f"_tmp_tail_ridge_{t_idx}",
                    4,
                    0.09,
                    0.015,
                    0.24,
                    (tx, ty, tz + rad * 0.92),
                    rotation=(0.0, math.radians(sry), 0.0),
                    scale=(0.55, 1.05, 1.0),
                ),
                mat_prefix,
                "crest_navy",
                pal,
            )

    # Crista dorsal nas costas conectando o pescoço à cauda
    back_ridges = [
        (-0.18, 0.26, 1.06),
        (-0.34, 0.34, 0.92),
        (-0.50, 0.38, 0.78),
    ]
    for b_idx, (bx, by, bz) in enumerate(back_ridges):
        _add_part(
            parts,
            create_cone(
                f"_tmp_back_ridge_{b_idx}",
                4,
                0.095,
                0.016,
                0.26,
                (bx, by, bz),
                rotation=(math.radians(24.0), math.radians(-26.0), 0.0),
                scale=(0.55, 1.05, 1.0),
            ),
            mat_prefix,
            "crest_navy",
            pal,
        )

    # Grande barbatana caudal de sereia bifurcada (2 lóbulos largos a +X bem visíveis!)
    fluke_specs = [
        ("top", (1.28, -0.22, 0.64), (10.0, 56.0, 0.0)),
        ("bot", (1.22, -0.24, 0.24), (-10.0, 128.0, 0.0)),
    ]
    for ftag, floc, (rx, ry, rz) in fluke_specs:
        _add_part(
            parts,
            create_cone(
                f"_tmp_fluke_{ftag}",
                6,
                0.28,
                0.02,
                0.86,
                floc,
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
                scale=(1.05, 0.32, 1.0),
            ),
            mat_prefix,
            "body_aqua",
            pal,
        )

    # 3. GRANDE COLARINHO BRANCO PLISSADO EM LEQUE AO REDOR DO PESCOÇO
    num_petals = 10
    for p_idx in range(num_petals):
        ang = (2.0 * math.pi * p_idx) / num_petals
        px = math.sin(ang) * 0.44
        py = -0.10 - math.cos(ang) * 0.34
        pz = 1.24 + math.cos(ang) * -0.06
        _add_part(
            parts,
            create_cone(
                f"_tmp_frill_{p_idx}",
                5,
                0.22,
                0.10,
                0.38,
                (px, py, pz),
                rotation=(math.radians(-68.0 * math.cos(ang)), math.radians(74.0 * math.sin(ang)), 0.0),
                scale=(1.02, 0.34, 1.0),
            ),
            mat_prefix,
            "ruff_white",
            pal,
        )
    # Disco central suave da gola para fechar quaisquer frestas entre pétalas
    _add_part(
        parts,
        create_cylinder(
            "_tmp_frill_ring",
            12,
            0.54,
            0.09,
            (0.0, -0.12, 1.26),
            rotation=(math.radians(16.0), 0.0, 0.0),
        ),
        mat_prefix,
        "ruff_white",
        pal,
    )

    # 4. CABEÇA AQUÁTICA FELINA + BARBATANA CENTRAL + ORELHAS-BARBATANAS AMARELAS LARGAS
    hx, hy, hz = 0.0, -0.18, 1.56
    _add_part(
        parts,
        create_icosphere("_tmp_head_main", 2, 0.40, (hx, hy, hz), scale=(1.04, 0.96, 0.92)),
        mat_prefix,
        "body_aqua",
        pal,
    )
    # Capacete em 'V' azul-marinho no topo da cabeça
    _add_part(
        parts,
        create_icosphere("_tmp_head_cap", 2, 0.38, (hx, hy + 0.04, hz + 0.16), scale=(1.02, 0.94, 0.62)),
        mat_prefix,
        "crest_navy",
        pal,
    )
    # Pico em 'V' frontal da crista na testa
    _add_part(
        parts,
        create_cone(
            "_tmp_brow_v",
            4,
            0.14,
            0.02,
            0.22,
            (hx, hy - 0.34, hz + 0.18),
            rotation=(math.radians(160.0), 0.0, 0.0),
            scale=(1.0, 0.45, 1.0),
        ),
        mat_prefix,
        "crest_navy",
        pal,
    )
    # Barbatana estreita central subindo alta no topo da cabeça
    _add_part(
        parts,
        create_cone(
            "_tmp_head_top_fin",
            5,
            0.14,
            0.015,
            0.78,
            (hx, hy - 0.04, hz + 0.66),
            rotation=(math.radians(-6.0), 0.0, 0.0),
            scale=(0.36, 1.10, 1.0),
        ),
        mat_prefix,
        "crest_navy",
        pal,
    )

    # 2 ORELHAS-BARBATANAS AMARELAS LARGAS COM BORDAS AZUL-MARINHO (ASSINATURA DO VAPOREON!)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Membrana amarela em leque largo
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_fin_web_{tag}",
                5,
                0.34,
                0.025,
                0.98,
                (hx + side * 0.78, hy + 0.02, hz + 0.26),
                rotation=(math.radians(-6.0), math.radians(side * 66.0), 0.0),
                scale=(1.0, 0.24, 1.0),
            ),
            mat_prefix,
            "fin_yellow",
            pal,
        )
        # Espinha superior azul-marinho da orelha-barbatana
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_fin_top_{tag}",
                5,
                0.075,
                0.015,
                1.04,
                (hx + side * 0.78, hy + 0.01, hz + 0.36),
                rotation=(math.radians(-6.0), math.radians(side * 60.0), 0.0),
                scale=(0.70, 0.48, 1.0),
            ),
            mat_prefix,
            "crest_navy",
            pal,
        )

    # 5. ROSTO ADORÁVEL FELINO-AQUÁTICO (OLHOS ESCUROS/VIOLETA + SORRISO ABERTO FELIZ)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_dark_{tag}",
                2,
                0.11,
                (hx + side * 0.20, hy - 0.35, hz + 0.02),
                rotation=(0.0, 0.0, math.radians(side * -16.0)),
                scale=(0.94, 0.48, 1.12),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.068,
                (hx + side * 0.20, hy - 0.39, hz - 0.02),
                scale=(0.90, 0.45, 0.76),
            ),
            mat_prefix,
            "eye_purple",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.042,
                (hx + side * 0.18, hy - 0.40, hz + 0.06),
                scale=(0.82, 0.50, 1.05),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # Narizinho e boca aberta sorridente felina
    _add_part(
        parts,
        create_icosphere("_tmp_nose", 1, 0.032, (hx, hy - 0.42, hz - 0.05), scale=(1.15, 0.65, 0.68)),
        mat_prefix,
        "eye_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_open", 2, 0.11, (hx, hy - 0.39, hz - 0.16), scale=(0.88, 0.46, 1.04)),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_tongue", 1, 0.075, (hx, hy - 0.42, hz - 0.20), scale=(0.84, 0.42, 0.66)),
        mat_prefix,
        "tongue_pink",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 134. Aquavulp lado a lado."""
    specs = [
        ("Aquavulp_Shiny", (-10.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Aquavulp_Normal", (-6.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Aquavulp_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Aquavulp_Gigante", (5.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Aquavulp_Dourada_SuperRara", (14.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_aquavulp(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
