"""
075_Cragroller_Graveler_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "075. Cragroller — Golem de Pedra (Ref: Graveler)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Cragroller_Shiny (1.0x - Paleta Shiny Rocha Terracota-Ocre Avermelhada)
  2. Cragroller_Normal (1.0x - Rocha Cinza-Pedra + Coroa Dentada na Testa + 4 Braços + Pernas Curtas)
  3. Cragroller_Grande (1.35x - Normal)
  4. Cragroller_Gigante (1.85x - Normal)
  5. Cragroller_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Crista Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada rochosa (icospheres subdiv=2/1 + blocos de rocha, 4 braços articulados)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas rochosas alinhadas em `Z = 0.0` e rosto/braços frontais apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "rock_main": (0.64, 0.63, 0.58, 1.0),
        "rock_light": (0.74, 0.73, 0.68, 1.0),
        "rock_slate": (0.45, 0.49, 0.52, 1.0),
        "rock_dark": (0.34, 0.36, 0.39, 1.0),
        "mouth_pink": (0.86, 0.54, 0.62, 1.0),
        "mouth_dark": (0.48, 0.24, 0.30, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "pupil_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "shiny_palette": {
        "rock_main": (0.78, 0.44, 0.22, 1.0),
        "rock_light": (0.88, 0.56, 0.30, 1.0),
        "rock_slate": (0.56, 0.30, 0.16, 1.0),
        "rock_dark": (0.40, 0.20, 0.10, 1.0),
        "mouth_pink": (0.88, 0.54, 0.62, 1.0),
        "mouth_dark": (0.50, 0.24, 0.30, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "pupil_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "rock_main": (0.98, 0.78, 0.14, 1.0),
        "rock_light": (1.00, 0.90, 0.38, 1.0),
        "rock_slate": (0.82, 0.60, 0.08, 1.0),
        "rock_dark": (0.64, 0.44, 0.06, 1.0),
        "mouth_pink": (0.98, 0.84, 0.34, 1.0),
        "mouth_dark": (0.56, 0.38, 0.05, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.34, 0.48, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_segment(parts: list, name: str, p0: tuple, p1: tuple, r0: float, r1: float, mat_prefix: str, mat_key: str, pal: dict, verts: int = 7):
    dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    if length < 1e-5:
        return None
    mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
    phi = math.atan2(dx, -dy)
    theta = math.acos(max(-1.0, min(1.0, dz / length)))
    obj = create_cone(name, verts, r0, r1, length + 0.05, mid, rotation=(theta, 0.0, phi))
    return _add_part(parts, obj, mat_prefix, mat_key, pal)


def build_cragroller(
    name: str = "Cragroller_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 075. Cragroller (Ref: Graveler):
      - Grande corpo pedregoso esférico e irregular com metade inferior cinza-ardósia e calombos rochosos
      - Coroa rochosa dentada icônica em arco na testa (5 ameias/blocos salientes)
      - Olhos ferozes inclinados e boca larga sorridente/rosnando com interior rosa
      - 4 braços musculosos de pedra: 2 grandes braços externos abertos + 2 braços menores cruzados no peito
      - 2 pernas curtas atarracadas com 3 dedos de rocha apoiados em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Crag_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Crag_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Crag_Norm"

    parts = []

    # 1. CORPO PEDREGOSO MASSIVO COM METADE INFERIOR ESCURA E CALOMBOS ROCHOSOS
    _add_part(
        parts,
        create_icosphere("_tmp_body_main", 2, 0.92, (0.0, 0.06, 1.12), scale=(1.08, 0.96, 0.96)),
        mat_prefix,
        "rock_main",
        pal,
    )
    # Metade inferior / barriga cinza-ardósia (sombra mineral característica do Graveler)
    _add_part(
        parts,
        create_icosphere("_tmp_body_lower", 2, 0.84, (0.0, 0.04, 0.78), scale=(1.10, 0.98, 0.74)),
        mat_prefix,
        "rock_slate",
        pal,
    )
    # Nódulos e cristas de pedra espalhados no topo e costas
    rock_nodules = [
        (0.32, (-0.54, 0.16, 1.72), (1.05, 0.92, 0.85), "rock_light"),
        (0.34, (0.52, 0.18, 1.74), (1.08, 0.90, 0.82), "rock_light"),
        (0.38, (0.00, 0.34, 1.88), (1.20, 0.95, 0.76), "rock_light"),
        (0.28, (-0.78, 0.10, 1.24), (0.86, 0.94, 0.92), "rock_slate"),
        (0.28, (0.78, 0.10, 1.26), (0.86, 0.94, 0.92), "rock_slate"),
        (0.36, (0.00, 0.64, 1.22), (1.16, 0.78, 1.05), "rock_slate"),
        (0.18, (-0.36, -0.58, 1.74), (1.0, 0.8, 0.8), "rock_light"),
        (0.16, (0.64, -0.34, 1.48), (0.9, 0.8, 0.9), "rock_light"),
    ]
    for n_idx, (rad, loc, sc, m_key) in enumerate(rock_nodules):
        _add_part(
            parts,
            create_icosphere(f"_tmp_nodule_{n_idx}", 1, rad, loc, rotation=(0.2 * n_idx, 0.3 * n_idx, 0.0), scale=sc),
            mat_prefix,
            m_key,
            pal,
        )

    # 2. COROA DE PEDRA DENTADA EM ARCO NA TESTA (ASSINATURA DO GRAVELER)
    crown_teeth = [
        # (x, y, z, rx, ry, rz, size)
        (-0.56, -0.66, 1.46, 10.0, -56.0, -18.0, (0.20, 0.24, 0.28)),
        (-0.34, -0.74, 1.66, 14.0, -28.0, -10.0, (0.22, 0.24, 0.30)),
        (0.00, -0.76, 1.74, 16.0, 0.0, 0.0, (0.24, 0.24, 0.32)),
        (0.34, -0.74, 1.66, 14.0, 28.0, 10.0, (0.22, 0.24, 0.30)),
        (0.56, -0.66, 1.46, 10.0, 56.0, 18.0, (0.20, 0.24, 0.28)),
    ]
    for c_idx, (cx, cy, cz, rx, ry, rz, sz) in enumerate(crown_teeth):
        _add_part(
            parts,
            create_cube(
                f"_tmp_crown_tooth_{c_idx}",
                sz,
                (cx, cy, cz),
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
            ),
            mat_prefix,
            "rock_light",
            pal,
        )

    # 3. ROSTO CARRANCUDO (OLHOS BRANCOS EM V + BOCA LARGA ABERTA ROSA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Sobrancelha rochosa inclinada
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.34, 0.16, 0.10),
                (side * 0.25, -0.86, 1.32),
                rotation=(math.radians(8.0), math.radians(side * -22.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "rock_light",
            pal,
        )
        # Esclera branca
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_{tag}",
                (0.28, 0.10, 0.13),
                (side * 0.25, -0.84, 1.21),
                rotation=(0.0, math.radians(side * -14.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pupila escura
        _add_part(
            parts,
            create_cube(
                f"_tmp_pupil_{tag}",
                (0.06, 0.08, 0.10),
                (side * 0.20, -0.88, 1.21),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # Boca larga aberta com interior rosa e borda escura
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_cav",
            2,
            0.26,
            (0.0, -0.78, 0.98),
            scale=(1.46, 0.36, 0.36),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_tongue",
            2,
            0.21,
            (0.0, -0.82, 0.96),
            scale=(1.34, 0.28, 0.25),
        ),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # 4. DOIS BRAÇOS SUPERIORES GRANDES E MUSCULOSOS ESTENDIDOS PARA FORA E FRENTE
    upper_arms = [
        ("L", -1.0, (-0.86, -0.02, 1.36), (-1.42, -0.18, 1.16), (-1.68, -0.46, 0.78)),
        ("R", 1.0, (0.86, -0.02, 1.36), (1.42, -0.18, 1.24), (1.72, -0.50, 0.92)),
    ]
    for tag, side, sh, el, ha in upper_arms:
        _add_part(parts, create_icosphere(f"_tmp_ushoulder_{tag}", 1, 0.24, sh), mat_prefix, "rock_main", pal)
        _add_segment(parts, f"_tmp_ubicep_{tag}", sh, el, 0.20, 0.18, mat_prefix, "rock_main", pal, verts=7)
        _add_part(parts, create_icosphere(f"_tmp_uelbow_{tag}", 1, 0.21, el), mat_prefix, "rock_light", pal)
        _add_segment(parts, f"_tmp_uforearm_{tag}", el, ha, 0.19, 0.24, mat_prefix, "rock_main", pal, verts=7)
        _add_part(parts, create_icosphere(f"_tmp_upalm_{tag}", 2, 0.25, ha, scale=(1.06, 0.96, 0.86)), mat_prefix, "rock_main", pal)
        # 3 dedos grossos espalhados de pedra
        finger_offsets = [
            (side * 0.22, -0.18, 0.12, side * 38.0),
            (side * 0.26, -0.22, -0.06, side * 52.0),
            (side * 0.04, -0.26, -0.16, side * 12.0),
        ]
        for f_i, (dx, dy, dz, ry_d) in enumerate(finger_offsets):
            _add_part(
                parts,
                create_cube(
                    f"_tmp_ufinger_{tag}_{f_i}",
                    (0.16, 0.30, 0.15),
                    (ha[0] + dx, ha[1] + dy, ha[2] + dz),
                    rotation=(math.radians(14.0), math.radians(ry_d), math.radians(side * -24.0)),
                ),
                mat_prefix,
                "rock_light",
                pal,
            )

    # 5. DOIS BRAÇOS INFERIORES MENORES CRUZADOS NA FRENTE DO PEITO (CARACTERÍSTICO DO GRAVELER!)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        sh = (side * 0.72, -0.34, 0.78)
        el = (side * 0.66, -0.68, 0.66)
        ha = (side * 0.26, -0.88, 0.64)
        _add_segment(parts, f"_tmp_lbicep_{tag}", sh, el, 0.15, 0.15, mat_prefix, "rock_slate", pal, verts=6)
        _add_part(parts, create_icosphere(f"_tmp_lelbow_{tag}", 1, 0.16, el), mat_prefix, "rock_slate", pal)
        _add_segment(parts, f"_tmp_lforearm_{tag}", el, ha, 0.15, 0.17, mat_prefix, "rock_slate", pal, verts=6)
        _add_part(parts, create_icosphere(f"_tmp_lhand_{tag}", 1, 0.18, ha, scale=(1.05, 0.85, 0.96)), mat_prefix, "rock_slate", pal)
        # 2 dedos dobrados para dentro no peito
        for f_i, dz in enumerate([0.07, -0.07]):
            _add_part(
                parts,
                create_cube(
                    f"_tmp_lfinger_{tag}_{f_i}",
                    (0.18, 0.10, 0.09),
                    (ha[0] - side * 0.12, ha[1] - 0.05, ha[2] + dz),
                ),
                mat_prefix,
                "rock_dark",
                pal,
            )

    # 6. PERNAS CURTAS ATARRACADAS COM PÉS DE 3 DEDOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_{tag}",
                7,
                0.24,
                0.28,
                0.42,
                (side * 0.44, 0.00, 0.24),
                scale=(1.05, 1.12, 1.0),
            ),
            mat_prefix,
            "rock_slate",
            pal,
        )
        # 3 dedos curtos de rocha apontando para frente
        for t_i, tx in enumerate([-0.14, 0.0, 0.14]):
            _add_part(
                parts,
                create_cube(
                    f"_tmp_toe_{tag}_{t_i}",
                    (0.12, 0.22, 0.14),
                    (side * 0.44 + tx, -0.22, 0.08),
                ),
                mat_prefix,
                "rock_dark",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 075. Cragroller lado a lado."""
    specs = [
        ("Cragroller_Shiny", (-12.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Cragroller_Normal", (-7.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Cragroller_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Cragroller_Gigante", (7.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Cragroller_Dourada_SuperRara", (17.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_cragroller(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
