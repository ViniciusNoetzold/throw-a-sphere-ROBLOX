"""
070_Pitcherpod_Weepinbell_5Variacoes_Blender.py
===============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "070. Pitcherpod — Planta Jarro (Ref: Weepinbell)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Pitcherpod_Shiny (1.0x - Paleta Shiny Corpo Verde-Limão + Folhas Douradas + Lábios Lavanda)
  2. Pitcherpod_Normal (1.0x - Sino Amarelo com Pintas Oliva + Grande Boca Rosa + 2 Folhas + Gancho Marrom)
  3. Pitcherpod_Grande (1.35x - Normal)
  4. Pitcherpod_Gigante (1.85x - Normal)
  5. Pitcherpod_Dourada_SuperRara (2.25x - Ouro Reluzente + Folhas, Lábios, Pintas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2, cones/cilindros 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base alinhada exatamente em `Z = 0.0` e boca/rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_yellow": (0.95, 0.92, 0.36, 1.0),
        "spot_olive": (0.54, 0.64, 0.24, 1.0),
        "leaf_green": (0.44, 0.80, 0.48, 1.0),
        "leaf_shade": (0.30, 0.64, 0.36, 1.0),
        "lip_pink": (0.92, 0.68, 0.72, 1.0),
        "throat_mauve": (0.58, 0.34, 0.46, 1.0),
        "mouth_dark": (0.10, 0.10, 0.12, 1.0),
        "hook_brown": (0.58, 0.50, 0.42, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
    },
    "shiny_palette": {
        "body_yellow": (0.84, 0.92, 0.28, 1.0),
        "spot_olive": (0.42, 0.64, 0.22, 1.0),
        "leaf_green": (0.92, 0.84, 0.24, 1.0),
        "leaf_shade": (0.72, 0.64, 0.16, 1.0),
        "lip_pink": (0.82, 0.60, 0.88, 1.0),
        "throat_mauve": (0.52, 0.32, 0.64, 1.0),
        "mouth_dark": (0.10, 0.10, 0.14, 1.0),
        "hook_brown": (0.56, 0.48, 0.36, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "body_yellow": (0.98, 0.78, 0.14, 1.0),
        "spot_olive": (0.10, 0.92, 1.00, 1.0),
        "leaf_green": (0.10, 0.92, 1.00, 1.0),
        "leaf_shade": (0.06, 0.62, 0.76, 1.0),
        "lip_pink": (0.10, 0.92, 1.00, 1.0),
        "throat_mauve": (0.08, 0.56, 0.70, 1.0),
        "mouth_dark": (0.05, 0.28, 0.40, 1.0),
        "hook_brown": (0.84, 0.62, 0.10, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_segment(
    name: str,
    p1: tuple,
    p2: tuple,
    r1: float,
    r2: float,
    vertices: int = 8,
    extend: float = 1.08,
):
    """Cria um cone/segmento conectando exatamente p1 -> p2 sem folgas."""
    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    dz = p2[2] - p1[2]
    dist = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dist < 1e-6:
        dist = 1e-6
    mid = ((p1[0] + p2[0]) * 0.5, (p1[1] + p2[1]) * 0.5, (p1[2] + p2[2]) * 0.5)
    theta = math.acos(max(-1.0, min(1.0, dz / dist)))
    phi = math.atan2(dy, dx)
    return create_cone(
        name=name,
        vertices=vertices,
        radius1=r1,
        radius2=r2,
        depth=dist * extend,
        location=mid,
        rotation=(0.0, theta, phi),
    )


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_pitcherpod(
    name: str = "Pitcherpod_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 070. Pitcherpod (Ref: Weepinbell):
      - Corpo em forma de sino/jarro amarelo largo inclinado para frente (-Y)
      - Boca oval enorme aberta na frente com anel labial rosa suave contínuo e garganta escura/malva
      - Olhos redondos grandes brancos com pupilas pretas bem acima do lábio
      - 3 pintas verde-oliva na testa + anel superior e gancho marrom curvado visível no topo
      - 2 folhas largas verdes curvadas para os lados e para cima como asas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Pitcher_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Pitcher_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Pitcher_Norm"

    parts = []

    # 1. CORPO EM SINO / JARRO AMARELO INCLINADO PARA FRENTE
    _add_part(
        parts,
        create_icosphere(
            "_tmp_body_upper",
            2,
            0.54,
            (0.0, 0.14, 1.38),
            rotation=(math.radians(22.0), 0.0, 0.0),
            scale=(1.04, 1.02, 1.18),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_body_lower",
            2,
            0.62,
            (0.0, -0.10, 0.84),
            rotation=(math.radians(24.0), 0.0, 0.0),
            scale=(1.06, 1.14, 1.08),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Anelzinho amarelo no topo + gancho marrom arqueado para a direita (+X) bem visível de frente!
    _add_part(
        parts,
        create_icosphere("_tmp_top_collar", 2, 0.28, (0.04, 0.36, 1.90), scale=(1.0, 0.92, 0.72)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    hook_pts = [
        (0.06, 0.36, 2.00, 0.12),
        (0.24, 0.36, 2.26, 0.10),
        (0.54, 0.34, 2.30, 0.08),
        (0.70, 0.32, 2.06, 0.024),
    ]
    for i in range(len(hook_pts) - 1):
        _add_part(
            parts,
            create_segment(
                f"_tmp_hook_{i}",
                hook_pts[i][:3],
                hook_pts[i + 1][:3],
                hook_pts[i][3],
                hook_pts[i + 1][3],
                vertices=7,
                extend=1.10,
            ),
            mat_prefix,
            "hook_brown",
            pal,
        )

    # 3 pintas verde-oliva na testa (como na referência do Weepinbell)
    for sp_idx, (sx, sy, sz, sr) in enumerate([
        (-0.22, -0.28, 1.62, 0.075),
        (0.00, -0.20, 1.78, 0.085),
        (0.22, -0.28, 1.62, 0.075),
    ]):
        _add_part(
            parts,
            create_icosphere(f"_tmp_spot_{sp_idx}", 1, sr, (sx, sy, sz), scale=(1.1, 0.45, 0.88)),
            mat_prefix,
            "spot_olive",
            pal,
        )

    # 2. ENORME BOCA ABERTA COM ANEL LABIAL ROSA TUBULAR SUAVE E GARGANTA PROFUNDA
    mouth_c = (0.0, -0.74, 0.66)
    tilt = math.radians(16.0)
    n_lip = 14
    lip_pts = []
    for i in range(n_lip):
        ang = 2.0 * math.pi * i / n_lip
        lx = mouth_c[0] + math.cos(ang) * 0.46
        ly = mouth_c[1] - math.sin(ang) * 0.50 * math.sin(tilt)
        lz = mouth_c[2] + math.sin(ang) * 0.50 * math.cos(tilt)
        lip_pts.append((lx, ly, lz))
    for i in range(n_lip):
        p1 = lip_pts[i]
        p2 = lip_pts[(i + 1) % n_lip]
        _add_part(parts, create_segment(f"_tmp_lip_seg_{i}", p1, p2, 0.135, 0.135, vertices=8, extend=1.24), mat_prefix, "lip_pink", pal)

    # Interior preto fundo da boca + fundo malva-rosa visível lá dentro
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_dark",
            2,
            0.46,
            (0.0, -0.64, 0.66),
            rotation=(tilt, 0.0, 0.0),
            scale=(0.98, 0.42, 1.04),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_throat_mauve",
            2,
            0.28,
            (0.08, -0.68, 0.68),
            rotation=(tilt, 0.0, 0.0),
            scale=(0.86, 0.36, 0.92),
        ),
        mat_prefix,
        "throat_mauve",
        pal,
    )

    # 3. OLHOS GRANDES REDONDOS BRANCOS COM PUPILAS PRETAS BEM ACIMA DA BOCA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.20,
                (side * 0.30, -0.50, 1.32),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(1.02, 0.60, 1.12),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                2,
                0.105,
                (side * 0.29, -0.59, 1.31),
                scale=(0.94, 0.50, 1.04),
            ),
            mat_prefix,
            "mouth_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.036,
                (side * 0.26, -0.64, 1.36),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # 4. DUAS GRANDES FOLHAS LATERAIS PONTUDAS CURVADAS PARA CIMA COMO ASAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_leaf_base_{tag}",
                2,
                0.44,
                (side * 0.76, -0.02, 1.18),
                rotation=(math.radians(16.0), math.radians(side * 24.0), math.radians(side * -14.0)),
                scale=(1.22, 0.24, 0.96),
            ),
            mat_prefix,
            "leaf_green",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_leaf_tip_{tag}",
                8,
                0.42,
                0.02,
                0.76,
                (side * 1.24, 0.04, 1.48),
                rotation=(math.radians(14.0), math.radians(side * 60.0), math.radians(side * -10.0)),
                scale=(0.94, 0.24, 1.0),
            ),
            mat_prefix,
            "leaf_green",
            pal,
        )
        _add_part(
            parts,
            create_segment(
                f"_tmp_leaf_vein_{tag}",
                (side * 0.52, -0.10, 1.04),
                (side * 1.30, -0.02, 1.54),
                0.036,
                0.014,
                vertices=5,
            ),
            mat_prefix,
            "leaf_shade",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 070. Pitcherpod lado a lado."""
    specs = [
        ("Pitcherpod_Shiny", (-12.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Pitcherpod_Normal", (-7.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Pitcherpod_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Pitcherpod_Gigante", (6.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Pitcherpod_Dourada_SuperRara", (15.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_pitcherpod(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
