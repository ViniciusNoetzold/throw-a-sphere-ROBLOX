"""
095_Cragwyrm_Onix_5Variacoes_Blender.py
=======================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "095. Cragwyrm — Serpente de Pedra (Ref: Onix)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Cragwyrm_Shiny (1.0x - Paleta Shiny Rocha Verde-Oliva Dourada + Sombras Musgo)
  2. Cragwyrm_Normal (1.0x - Serpente Articulada de Rochas Cinza-Pedra + Cabeça Angular + Chifre Alto)
  3. Cragwyrm_Grande (1.35x - Normal)
  4. Cragwyrm_Gigante (1.85x - Normal)
  5. Cragwyrm_Dourada_SuperRara (2.25x - Rochas Ouro Reluzente + Chifre e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada rochosa (icospheres subdiv=1 cinzeladas para cada pedregulho articulado + chifre lâmina)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Espiral da cauda apoiada em `Z = 0.0` e cabeça erguida apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "rock_main": (0.64, 0.65, 0.70, 1.0),
        "rock_light": (0.74, 0.75, 0.80, 1.0),
        "rock_dark": (0.44, 0.45, 0.50, 1.0),
        "mouth_dark": (0.14, 0.14, 0.18, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.08, 0.08, 0.12, 1.0),
    },
    "shiny_palette": {
        "rock_main": (0.62, 0.66, 0.28, 1.0),
        "rock_light": (0.74, 0.78, 0.36, 1.0),
        "rock_dark": (0.42, 0.46, 0.18, 1.0),
        "mouth_dark": (0.14, 0.16, 0.08, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.08, 0.08, 0.10, 1.0),
    },
    "golden_super_rare_palette": {
        "rock_main": (0.98, 0.78, 0.14, 1.0),
        "rock_light": (0.10, 0.92, 1.00, 1.0),
        "rock_dark": (0.76, 0.54, 0.08, 1.0),
        "mouth_dark": (0.32, 0.20, 0.04, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.26, 0.42, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_cragwyrm(
    name: str = "Cragwyrm_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 095. Cragwyrm (Ref: Onix):
      - 13 pedregulhos facetados interligados em arco serpentino majestoso (cauda fina no chão -> corpo colossal -> pescoço arqueado)
      - Alternância de facetas cinza-pedra e sombras de basalto para profundidade escultural de rocha
      - Cabeça angular esculpida avançando para -Y com mandíbula semiaberta, olhos brancos ferozes e crista nasal
      - Alto chifre lâmina vertical de pedra erguido no centro da testa
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Cra_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Cra_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Cra_Norm"

    parts = []

    # 1. CORPO ARTICULADO EM 13 PEDREGULHOS FACETADOS (DA PONTA DA CAUDA AO PESCOÇO)
    # Posicionados em arco serpentino fiel à arte oficial (base apoiada em Z = 0.0)
    boulders = [
        # (rad, (x, y, z), (sx, sy, sz), (rx, ry, rz), mat_key)
        # Ponta da cauda enrolada no chão
        (0.11, (0.64, -0.02, 0.11), (1.10, 0.95, 0.85), (12, 24, 18), "rock_dark"),
        (0.15, (0.44, 0.08, 0.14), (1.12, 0.98, 0.90), (20, -15, 34), "rock_main"),
        (0.20, (0.18, 0.18, 0.20), (1.08, 1.04, 0.92), (-18, 32, 12), "rock_dark"),
        (0.26, (-0.10, 0.28, 0.36), (1.04, 1.06, 0.96), (25, 16, -22), "rock_main"),
        # Subida curva da coluna rochosa pela direita
        (0.32, (0.14, 0.36, 0.64), (1.06, 1.02, 1.00), (-14, -28, 18), "rock_dark"),
        (0.38, (0.44, 0.40, 0.94), (1.04, 1.08, 0.96), (32, 12, -16), "rock_main"),
        (0.44, (0.68, 0.40, 1.32), (1.06, 1.04, 1.02), (-22, 26, 14), "rock_dark"),
        (0.49, (0.76, 0.34, 1.78), (1.04, 1.06, 1.04), (18, -22, 28), "rock_main"),
        # Grandes pedregulhos colossais do arco superior (pescoço/ombro)
        (0.52, (0.56, 0.22, 2.26), (1.06, 1.08, 1.00), (-16, 18, -24), "rock_main"),
        (0.48, (0.18, 0.10, 2.52), (1.08, 1.04, 0.96), (24, -14, 16), "rock_dark"),
        (0.46, (-0.22, -0.06, 2.46), (1.06, 1.08, 0.98), (-20, 28, -12), "rock_main"),
        (0.44, (-0.42, -0.26, 2.22), (1.04, 1.06, 1.02), (14, -18, 22), "rock_main"),
    ]
    for b_idx, (rad, loc, sc, rot_deg, mkey) in enumerate(boulders):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_boulder_{b_idx}",
                1,
                rad,
                loc,
                rotation=tuple(math.radians(a) for a in rot_deg),
                scale=sc,
            ),
            mat_prefix,
            mkey,
            pal,
        )
        # Detalhe de sombra de basalto encaixado na parte inferior dos pedregulhos grandes
        if b_idx >= 5:
            bx, by, bz = loc
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_boulder_crag_{b_idx}",
                    1,
                    rad * 0.62,
                    (bx + 0.06, by + 0.12, bz - rad * 0.36),
                    rotation=(math.radians(b_idx * 23.0), math.radians(b_idx * 17.0), 0.0),
                    scale=(1.08, 0.92, 0.86),
                ),
                mat_prefix,
                "rock_dark",
                pal,
            )

    # 2. CABEÇA ANGULAR ESCULPIDA EM ROCHA AVANÇANDO PARA -Y
    hx, hy, hz = (-0.42, -0.62, 1.98)
    # Crânio principal facetado
    _add_part(
        parts,
        create_icosphere(
            "_tmp_head_cranium",
            1,
            0.46,
            (hx, hy, hz + 0.06),
            rotation=(math.radians(8.0), 0.0, math.radians(10.0)),
            scale=(0.96, 1.24, 0.92),
        ),
        mat_prefix,
        "rock_main",
        pal,
    )
    # Focinho rochoso alongado para baixo e frente + crista nasal central
    _add_part(
        parts,
        create_cone(
            "_tmp_snout_bridge",
            6,
            0.34,
            0.22,
            0.52,
            (hx, hy - 0.28, hz - 0.04),
            rotation=(math.radians(106.0), 0.0, 0.0),
            scale=(0.94, 0.88, 1.0),
        ),
        mat_prefix,
        "rock_main",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_nasal_ridge",
            (0.11, 0.44, 0.24),
            (hx, hy - 0.34, hz - 0.02),
            rotation=(math.radians(24.0), 0.0, 0.0),
        ),
        mat_prefix,
        "rock_main",
        pal,
    )

    # Placas angulares de bochecha/têmpora
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_cheek_plate_{tag}",
                (0.22, 0.42, 0.30),
                (hx + side * 0.34, hy - 0.06, hz - 0.02),
                rotation=(math.radians(12.0), math.radians(side * 16.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "rock_dark",
            pal,
        )

    # Interior escuro da boca + mandíbula inferior articulada de pedra
    _add_part(
        parts,
        create_cube(
            "_tmp_mouth_gap",
            (0.46, 0.36, 0.16),
            (hx, hy - 0.28, hz - 0.26),
            rotation=(math.radians(8.0), 0.0, 0.0),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_lower_jaw",
            (0.50, 0.46, 0.18),
            (hx, hy - 0.26, hz - 0.38),
            rotation=(math.radians(16.0), 0.0, 0.0),
        ),
        mat_prefix,
        "rock_dark",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_chin_tip",
            (0.32, 0.26, 0.15),
            (hx, hy - 0.46, hz - 0.38),
            rotation=(math.radians(12.0), 0.0, 0.0),
        ),
        mat_prefix,
        "rock_main",
        pal,
    )

    # 3. OLHOS FEROZES BRANCOS SOB SOBRANCELHAS DE PEDRA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                1,
                0.125,
                (hx + side * 0.20, hy - 0.44, hz + 0.08),
                rotation=(0.0, math.radians(side * -18.0), math.radians(side * -22.0)),
                scale=(1.22, 0.44, 0.62),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Sobrancelha pesada de pedra cortando o topo do olho
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.28, 0.22, 0.12),
                (hx + side * 0.21, hy - 0.42, hz + 0.18),
                rotation=(math.radians(8.0), math.radians(side * -18.0), math.radians(side * -16.0)),
            ),
            mat_prefix,
            "rock_main",
            pal,
        )
        # Pupila vertical fina
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.036,
                (hx + side * 0.19, hy - 0.50, hz + 0.08),
                scale=(0.55, 0.48, 1.38),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 4. CHIFRE LÂMINA VERTICAL ALTO DE ROCHA NA TESTA (ASSINATURA DO ONIX!)
    _add_part(
        parts,
        create_cone(
            "_tmp_horn_base",
            6,
            0.18,
            0.12,
            0.40,
            (hx, hy - 0.10, hz + 0.54),
            rotation=(math.radians(-6.0), 0.0, 0.0),
            scale=(0.56, 1.24, 1.0),
        ),
        mat_prefix,
        "rock_light",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_horn_blade",
            6,
            0.12,
            0.032,
            0.78,
            (hx, hy - 0.14, hz + 1.04),
            rotation=(math.radians(-6.0), 0.0, 0.0),
            scale=(0.52, 1.12, 1.0),
        ),
        mat_prefix,
        "rock_light",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 095. Cragwyrm lado a lado."""
    specs = [
        ("Cragwyrm_Shiny", (-10.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Cragwyrm_Normal", (-6.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Cragwyrm_Grande", (-2.0, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Cragwyrm_Gigante", (3.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Cragwyrm_Dourada_SuperRara", (11.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_cragwyrm(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
