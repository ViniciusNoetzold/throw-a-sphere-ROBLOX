"""
109_Smogorb_Koffing_5Variacoes_Blender.py
=========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "109. Smogorb — Mina de Gás (Ref: Koffing)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Smogorb_Shiny (1.0x - Paleta Shiny Azul-Turquesa + Gás Lavanda-Roxo + Caveira Creme)
  2. Smogorb_Normal (1.0x - Roxo-Lavanda + Crateras Tubulares + Gás Amarelo-Oliva + Caveira Creme)
  3. Smogorb_Grande (1.35x - Normal)
  4. Smogorb_Gigante (1.85x - Normal)
  5. Smogorb_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Gás Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para corpo e nuvens de gás conectadas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base alinhada exatamente em `Z = 0.0` (sem partes soltas flutuando) e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_purple": (0.58, 0.54, 0.74, 1.0),
        "vent_dark": (0.36, 0.32, 0.50, 1.0),
        "emblem_cream": (0.92, 0.90, 0.80, 1.0),
        "gas_yellow": (0.82, 0.82, 0.48, 1.0),
        "gas_shade": (0.70, 0.70, 0.38, 1.0),
        "mouth_pink": (0.76, 0.48, 0.56, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "eye_dark": (0.10, 0.10, 0.14, 1.0),
    },
    "shiny_palette": {
        "body_purple": (0.24, 0.72, 0.76, 1.0),
        "vent_dark": (0.14, 0.48, 0.54, 1.0),
        "emblem_cream": (0.94, 0.92, 0.82, 1.0),
        "gas_yellow": (0.78, 0.50, 0.86, 1.0),
        "gas_shade": (0.62, 0.36, 0.72, 1.0),
        "mouth_pink": (0.82, 0.46, 0.58, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "eye_dark": (0.10, 0.10, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "body_purple": (0.98, 0.78, 0.14, 1.0),
        "vent_dark": (0.72, 0.50, 0.08, 1.0),
        "emblem_cream": (1.00, 0.96, 0.72, 1.0),
        "gas_yellow": (0.10, 0.92, 1.00, 1.0),
        "gas_shade": (0.08, 0.70, 0.84, 1.0),
        "mouth_pink": (0.86, 0.56, 0.12, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_vent(parts: list, idx: int, loc: tuple, rot_deg: tuple, r_base: float, r_top: float, depth: float, mat_prefix: str, pal: dict):
    rot = tuple(math.radians(a) for a in rot_deg)
    _add_part(
        parts,
        create_cone(f"_tmp_vent_rim_{idx}", 7, r_base, r_top, depth, loc, rotation=rot),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(f"_tmp_vent_hole_{idx}", 7, r_top * 0.68, depth * 0.92, loc, rotation=rot),
        mat_prefix,
        "vent_dark",
        pal,
    )


def _add_smoke_cloud(parts: list, tag: str, center: tuple, rad: float, mat_prefix: str, pal: dict):
    cx, cy, cz = center
    puffs = [
        (rad * 1.00, (cx, cy, cz), "gas_yellow"),
        (rad * 0.78, (cx - rad * 0.62, cy + 0.04, cz + rad * 0.24), "gas_yellow"),
        (rad * 0.74, (cx + rad * 0.56, cy - 0.03, cz + rad * 0.34), "gas_yellow"),
        (rad * 0.70, (cx + rad * 0.16, cy + 0.08, cz - rad * 0.44), "gas_shade"),
    ]
    for p_idx, (pr, ploc, mkey) in enumerate(puffs):
        _add_part(
            parts,
            create_icosphere(f"_tmp_smoke_{tag}_{p_idx}", 2, pr, ploc),
            mat_prefix,
            mkey,
            pal,
        )


def build_smogorb(
    name: str = "Smogorb_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 109. Smogorb (Ref: Koffing):
      - Esfera orgânica irregular de mina de gás roxa coberta de crateras tubulares
      - Nuvens de gás tóxico amarelo conectadas diretamente às crateras (zero peças soltas)
      - Rosto alegre e travesso: olhos brancos em meia-lua com pupilas + sorrisão com 2 presinhas
      - Emblema creme em alto-relevo de caveira oval e ossos cruzados no peito
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Smog_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Smog_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Smog_Norm"

    parts = []

    # 1. ESFERA DE MINA DE GÁS ORGÂNICA E LEVE IRREGULARIDADE
    _add_part(
        parts,
        create_icosphere("_tmp_body_core", 2, 0.86, (0.0, 0.0, 1.14), scale=(1.02, 0.96, 0.98)),
        mat_prefix,
        "body_purple",
        pal,
    )
    # Calombos sutis para dar aspecto de rocha-gás irregular
    for b_idx, (rad, loc) in enumerate([
        (0.28, (-0.54, -0.44, 0.96)),
        (0.26, (0.56, -0.42, 0.98)),
        (0.30, (0.0, 0.56, 1.38)),
    ]):
        _add_part(
            parts,
            create_icosphere(f"_tmp_bump_{b_idx}", 1, rad, loc),
            mat_prefix,
            "body_purple",
            pal,
        )

    # 2. CRATERAS TUBULARES DE SAÍDA DE GÁS DISTRIBUÍDAS NA ESFERA
    vent_specs = [
        ((0.0, 0.02, 1.98), (0.0, 0.0, 0.0), 0.22, 0.16, 0.26),
        ((-0.68, -0.04, 1.66), (0.0, -48.0, 0.0), 0.22, 0.16, 0.28),
        ((0.68, -0.04, 1.66), (0.0, 48.0, 0.0), 0.22, 0.16, 0.28),
        ((-0.86, 0.02, 1.06), (0.0, -90.0, 0.0), 0.24, 0.17, 0.28),
        ((0.86, 0.02, 1.06), (0.0, 90.0, 0.0), 0.24, 0.17, 0.28),
        ((-0.64, -0.02, 0.54), (0.0, -132.0, 0.0), 0.22, 0.15, 0.28),
        ((0.64, -0.02, 0.54), (0.0, 132.0, 0.0), 0.22, 0.15, 0.28),
        ((0.0, 0.0, 0.30), (180.0, 0.0, 0.0), 0.20, 0.14, 0.24),
        ((-0.44, 0.68, 1.44), (-52.0, -28.0, 0.0), 0.22, 0.15, 0.26),
        ((0.44, 0.68, 1.44), (-52.0, 28.0, 0.0), 0.22, 0.15, 0.26),
    ]
    for v_idx, (vloc, vrot, r1, r2, dp) in enumerate(vent_specs):
        _add_vent(parts, v_idx, vloc, vrot, r1, r2, dp, mat_prefix, pal)

    # 3. PLUMAS DE GÁS TÓXICO CONECTADAS ÀS CRATERAS (INCLUINDO BASE DE FUMAÇA EM Z = 0.0)
    # Jato superior esquerdo -> nuvem de fumaça esquerda
    _add_part(
        parts,
        create_cone(
            "_tmp_plume_UL",
            6,
            0.09,
            0.22,
            0.62,
            (-0.96, 0.02, 1.90),
            rotation=(0.0, math.radians(-48.0), 0.0),
        ),
        mat_prefix,
        "gas_shade",
        pal,
    )
    _add_smoke_cloud(parts, "UL", (-1.28, 0.06, 2.12), 0.30, mat_prefix, pal)

    # Jato superior direito -> nuvem de fumaça direita
    _add_part(
        parts,
        create_cone(
            "_tmp_plume_UR",
            6,
            0.09,
            0.22,
            0.62,
            (0.96, 0.02, 1.88),
            rotation=(0.0, math.radians(50.0), 0.0),
        ),
        mat_prefix,
        "gas_shade",
        pal,
    )
    _add_smoke_cloud(parts, "UR", (1.28, 0.06, 2.04), 0.29, mat_prefix, pal)

    # Jatos inferiores -> base de fumaça tóxica apoiada no chão (faz o Smogorb levitar visualmente!)
    for side, tag in [(-1.0, "BL"), (1.0, "BR")]:
        _add_part(
            parts,
            create_cone(
                f"_tmp_plume_{tag}",
                6,
                0.09,
                0.20,
                0.50,
                (side * 0.84, 0.04, 0.36),
                rotation=(0.0, math.radians(side * 136.0), 0.0),
            ),
            mat_prefix,
            "gas_shade",
            pal,
        )
        _add_smoke_cloud(parts, tag, (side * 1.02, 0.08, 0.24), 0.22, mat_prefix, pal)

    # 4. ROSTO ALEGRE E TRAVESSO: OLHOS MEIA-LUA + SORRISÃO COM 2 PRESINHAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Globo ocular meia-lua branco
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.18,
                (side * 0.32, -0.74, 1.44),
                rotation=(0.0, math.radians(side * -12.0), math.radians(side * -10.0)),
                scale=(1.12, 0.42, 0.72),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pálpebra inferior reta de contorno escuro
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_lid_{tag}",
                (0.36, 0.06, 0.055),
                (side * 0.32, -0.80, 1.35),
                rotation=(0.0, math.radians(side * -10.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Pupila escura vertical olhando ligeiramente para cima
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.036,
                (side * 0.32, -0.815, 1.48),
                scale=(0.68, 0.50, 1.35),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Boca aberta sorridente + linha superior + 2 presinhas brancas nos cantos
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_open",
            2,
            0.32,
            (0.0, -0.78, 1.14),
            scale=(1.32, 0.36, 0.54),
        ),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_mouth_top_rim",
            (0.84, 0.07, 0.055),
            (0.0, -0.86, 1.24),
        ),
        mat_prefix,
        "eye_dark",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.055,
                0.012,
                0.13,
                (side * 0.33, -0.88, 1.18),
                rotation=(math.radians(176.0), math.radians(side * -8.0), 0.0),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # 5. EMBLEMA CREME DE CAVEIRA E OSSOS CRUZADOS EM ALTO-RELEVO NO PEITO
    # Anel oval da caveira
    _add_part(
        parts,
        create_icosphere(
            "_tmp_skull_outer",
            2,
            0.22,
            (0.0, -0.80, 0.80),
            scale=(1.22, 0.34, 0.84),
        ),
        mat_prefix,
        "emblem_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_skull_hollow",
            1,
            0.12,
            (0.0, -0.845, 0.81),
            scale=(1.22, 0.34, 0.72),
        ),
        mat_prefix,
        "body_purple",
        pal,
    )
    # Dois ossos cruzados logo abaixo com pontas arredondadas
    for side, b_idx in [(-1.0, 0), (1.0, 1)]:
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_bone_{b_idx}",
                6,
                0.062,
                0.66,
                (0.0, -0.81, 0.56),
                rotation=(0.0, math.radians(side * 60.0), 0.0),
                scale=(1.0, 0.48, 1.0),
            ),
            mat_prefix,
            "emblem_cream",
            pal,
        )
        for end_s in (-1.0, 1.0):
            ex = end_s * side * 0.28
            ez = 0.56 + end_s * 0.16
            _add_part(
                parts,
                create_icosphere(f"_tmp_bone_knob_{b_idx}_{int(end_s + 1)}", 1, 0.074, (ex, -0.80, ez), scale=(1.0, 0.50, 1.0)),
                mat_prefix,
                "emblem_cream",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 109. Smogorb lado a lado."""
    specs = [
        ("Smogorb_Shiny", (-11.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Smogorb_Normal", (-6.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Smogorb_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Smogorb_Gigante", (6.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Smogorb_Dourada_SuperRara", (15.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_smogorb(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
