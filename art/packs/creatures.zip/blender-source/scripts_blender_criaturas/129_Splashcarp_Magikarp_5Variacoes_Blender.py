"""
129_Splashcarp_Magikarp_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "129. Splashcarp — Carpa Saltitante (Ref: Magikarp)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Splashcarp_Shiny (1.0x - Paleta Shiny Clássica Carpa Dourada + Coroa Creme + Nadadeiras Brancas)
  2. Splashcarp_Normal (1.0x - Corpo Laranja-Coral + Coroa e Bigodes Dourados + Olhos Atônitos)
  3. Splashcarp_Grande (1.35x - Normal)
  4. Splashcarp_Gigante (1.85x - Normal)
  5. Splashcarp_Dourada_SuperRara (2.25x - Ouro Reluzente + Coroa, Bigodes e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para corpo rechonchudo de carpa, cones 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Nadadeira ventral alinhada exatamente em `Z = 0.0` e boca aberta/olhos apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_orange": (0.93, 0.41, 0.29, 1.0),
        "body_shade": (0.76, 0.30, 0.20, 1.0),
        "crown_gold": (0.98, 0.80, 0.34, 1.0),
        "fin_white": (0.96, 0.96, 0.98, 1.0),
        "lip_pink": (0.96, 0.70, 0.74, 1.0),
        "mouth_dark": (0.34, 0.16, 0.20, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "pupil_dark": (0.08, 0.08, 0.10, 1.0),
    },
    "shiny_palette": {
        "body_orange": (0.98, 0.79, 0.18, 1.0),
        "body_shade": (0.84, 0.62, 0.10, 1.0),
        "crown_gold": (1.00, 0.94, 0.64, 1.0),
        "fin_white": (0.98, 0.98, 1.00, 1.0),
        "lip_pink": (0.98, 0.76, 0.72, 1.0),
        "mouth_dark": (0.42, 0.22, 0.14, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "pupil_dark": (0.08, 0.08, 0.10, 1.0),
    },
    "golden_super_rare_palette": {
        "body_orange": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.82, 0.58, 0.08, 1.0),
        "crown_gold": (0.10, 0.92, 1.00, 1.0),
        "fin_white": (1.00, 0.95, 0.68, 1.0),
        "lip_pink": (1.00, 0.88, 0.42, 1.0),
        "mouth_dark": (0.36, 0.24, 0.04, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.36, 0.52, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _orient_z_to_vec(dx: float, dy: float, dz: float):
    horiz = math.sqrt(dx * dx + dy * dy)
    pitch = math.atan2(horiz, dz)
    yaw = math.atan2(dx, -dy)
    return (pitch, 0.0, yaw)


def build_splashcarp(
    name: str = "Splashcarp_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 129. Splashcarp (Ref: Magikarp):
      - Corpo ovoidal rechonchudo laranja-coral com faixas sutis de escamas/guelras
      - Boca aberta em 'O' com lábios grossos rosados apontando para -Y
      - Olhos enormes redondos brancos com pupila minúscula de expressão atônita
      - 2 bigodes dourados longos curvando para fora e para baixo ao lado da boca
      - Coroa dorsal dourada de 3 pontas no topo e nadadeira ventral dourada de 3 pontas em Z = 0.0
      - Nadadeiras peitorais brancas abertas e grande nadadeira caudal branca bifurcada com borda coral
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Carp_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Carp_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Carp_Norm"

    parts = []

    # 1. CORPO OVOIDAL RECHONCHUDO DA CARPA + RELEVO DAS GUELRAS
    _add_part(
        parts,
        create_icosphere("_tmp_body_main", 2, 0.72, (0.0, 0.02, 1.02), scale=(0.74, 1.24, 0.94)),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Borda das guelras em anel sutil atrás da cabeça
    _add_part(
        parts,
        create_cylinder(
            "_tmp_gill_ridge",
            10,
            0.56,
            0.09,
            (0.0, -0.18, 1.04),
            rotation=(math.radians(90.0), 0.0, 0.0),
            scale=(0.98, 1.22, 1.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )
    # Pedúnculo caudal curvando sutilmente para +X para exibir bem a cauda na câmera 3/4
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_peduncle",
            8,
            0.34,
            0.18,
            0.54,
            (0.14, 0.92, 0.98),
            rotation=(math.radians(90.0), 0.0, math.radians(-22.0)),
            scale=(0.76, 1.15, 1.0),
        ),
        mat_prefix,
        "body_orange",
        pal,
    )

    # 2. LÁBIOS ROSADOS EM 'O' + BOCA ABERTA + OLHOS GRANDES ATÔNITOS
    # Anel labial rosado (4 segmentos suaves formando boca oval aberta)
    lip_segments = [
        (0.00, -0.84, 1.12, (0.95, 0.56, 0.36)),
        (0.00, -0.84, 0.84, (0.95, 0.56, 0.36)),
        (-0.18, -0.82, 0.98, (0.36, 0.56, 0.92)),
        (0.18, -0.82, 0.98, (0.36, 0.56, 0.92)),
    ]
    for l_idx, (lx, ly, lz, lsc) in enumerate(lip_segments):
        _add_part(
            parts,
            create_icosphere(f"_tmp_lip_{l_idx}", 2, 0.16, (lx, ly, lz), scale=lsc),
            mat_prefix,
            "lip_pink",
            pal,
        )
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_hole", 1, 0.17, (0.0, -0.80, 0.98), scale=(0.82, 0.45, 0.92)),
        mat_prefix,
        "mouth_dark",
        pal,
    )

    # Olhos gigantes redondos brancos com pupila minúscula nas laterais frontais
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.24,
                (side * 0.42, -0.44, 1.18),
                rotation=(0.0, 0.0, math.radians(side * -22.0)),
                scale=(0.48, 0.98, 1.02),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.042,
                (side * 0.53, -0.49, 1.18),
                scale=(0.55, 0.95, 0.95),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 3. BIGODES LONGOS DOURADOS CURVANDO PARA OS LADOS E PARA BAIXO
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        w_pts = [
            (side * 0.24, -0.74, 0.88),
            (side * 0.54, -0.78, 0.72),
            (side * 0.78, -0.72, 0.48),
            (side * 0.92, -0.60, 0.24),
            (side * 1.04, -0.46, 0.12),
        ]
        for s_idx in range(len(w_pts) - 1):
            p0, p1 = w_pts[s_idx], w_pts[s_idx + 1]
            mx, my, mz = (p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5
            dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
            seg_len = math.sqrt(dx * dx + dy * dy + dz * dz) + 0.04
            r_seg = 0.052 - s_idx * 0.008
            _add_part(
                parts,
                create_cone(
                    f"_tmp_whisker_{tag}_{s_idx}",
                    6,
                    r_seg,
                    max(0.015, r_seg - 0.008),
                    seg_len,
                    (mx, my, mz),
                    rotation=_orient_z_to_vec(dx, dy, dz),
                ),
                mat_prefix,
                "crown_gold",
                pal,
            )

    # 4. COROA DOURADA DE 3 PONTAS NAS COSTAS + NADADEIRA VENTRAL DOURADA (BASE Z = 0.0)
    dorsal_points = [
        (-0.18, 1.88, 0.19, 0.52, -22.0),
        (0.06, 2.02, 0.24, 0.74, 4.0),
        (0.32, 1.84, 0.18, 0.50, 28.0),
    ]
    for d_idx, (dy, dz, rad, dep, rx_deg) in enumerate(dorsal_points):
        _add_part(
            parts,
            create_cone(
                f"_tmp_dorsal_crown_{d_idx}",
                5,
                rad,
                0.018,
                dep,
                (0.0, dy, dz),
                rotation=(math.radians(rx_deg), 0.0, 0.0),
                scale=(0.34, 1.0, 1.0),
            ),
            mat_prefix,
            "crown_gold",
            pal,
        )
    # Nadadeira ventral dourada de 3 pontas tocando o chão (suporte limpo em Z = 0.0)
    ventral_points = [
        (-0.10, 0.24, 0.15, 0.36, 158.0),
        (0.10, 0.18, 0.19, 0.46, 180.0),
        (0.30, 0.24, 0.15, 0.36, 204.0),
    ]
    for v_idx, (vy, vz, rad, dep, rx_deg) in enumerate(ventral_points):
        _add_part(
            parts,
            create_cone(
                f"_tmp_ventral_crown_{v_idx}",
                5,
                rad,
                0.025,
                dep,
                (0.0, vy, vz),
                rotation=(math.radians(rx_deg), 0.0, 0.0),
                scale=(0.40, 1.0, 1.0),
            ),
            mat_prefix,
            "crown_gold",
            pal,
        )

    # 5. NADADEIRAS PEITORAIS BRANCAS COM BORDA SUPERIOR LARANJA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_pec_fin_{tag}",
                5,
                0.24,
                0.025,
                0.68,
                (side * 0.72, -0.02, 0.90),
                rotation=(math.radians(24.0), math.radians(side * 76.0), math.radians(side * 16.0)),
                scale=(0.32, 1.05, 1.0),
            ),
            mat_prefix,
            "fin_white",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_pec_trim_{tag}",
                5,
                0.06,
                0.015,
                0.70,
                (side * 0.74, -0.06, 1.02),
                rotation=(math.radians(20.0), math.radians(side * 82.0), math.radians(side * 14.0)),
                scale=(0.60, 0.70, 1.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )

    # 6. GRANDE NADADEIRA CAUDAL BRANCA BIFURCADA COM BORDAS LARANJA-CORAL
    # Lóbulo superior e inferior formando o leque em V inclinado para +X (muito visível na prévia!)
    caudal_lobes = [
        ("top", (0.48, 1.38, 1.24), (48.0, 26.0, -28.0)),
        ("bot", (0.44, 1.36, 0.68), (130.0, 24.0, -26.0)),
    ]
    for ctag, cloc, (rx, ry, rz) in caudal_lobes:
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_fin_{ctag}",
                5,
                0.34,
                0.03,
                0.88,
                cloc,
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
                scale=(0.24, 1.08, 1.0),
            ),
            mat_prefix,
            "fin_white",
            pal,
        )
        # Borda laranja da cauda
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_rim_{ctag}",
                5,
                0.07,
                0.018,
                0.92,
                (cloc[0] + 0.02, cloc[1] - 0.02, cloc[2] + (0.14 if ctag == "top" else -0.14)),
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
                scale=(0.55, 0.65, 1.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 129. Splashcarp lado a lado."""
    specs = [
        ("Splashcarp_Shiny", (-8.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Splashcarp_Normal", (-4.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Splashcarp_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Splashcarp_Gigante", (4.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Splashcarp_Dourada_SuperRara", (11.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_splashcarp(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
