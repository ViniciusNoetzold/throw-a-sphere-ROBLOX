"""
078_Solarsteed_Rapidash_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "078. Solarsteed — Unicórnio Flamejante (Ref: Rapidash)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Solarsteed_Shiny (1.0x - Paleta Shiny Icônica Chamas Cinza-Prata / Lavanda Fumê!)
  2. Solarsteed_Normal (1.0x - Garanhão Unicórnio Creme + Chifre Afiado + Crina/Cauda/Patas em Chamas)
  3. Solarsteed_Grande (1.35x - Normal)
  4. Solarsteed_Gigante (1.85x - Normal)
  5. Solarsteed_Dourada_SuperRara (2.25x - Ouro Reluzente + Chamas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (pose nobre empinando a pata dianteira direita + chifre cônico)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Cascos apoiados alinhados exatamente em `Z = 0.0` e cabeça/chifre apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "coat_cream": (0.96, 0.93, 0.78, 1.0),
        "coat_shade": (0.85, 0.80, 0.66, 1.0),
        "horn_ivory": (0.98, 0.97, 0.90, 1.0),
        "ear_inner": (0.72, 0.44, 0.46, 1.0),
        "hoof_slate": (0.28, 0.36, 0.52, 1.0),
        "flame_yellow": (1.00, 0.86, 0.16, 1.0),
        "flame_orange": (0.98, 0.38, 0.12, 1.0),
        "flame_red": (0.88, 0.20, 0.14, 1.0),
        "eye_red": (0.86, 0.24, 0.28, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "mouth_pink": (0.82, 0.46, 0.52, 1.0),
    },
    "shiny_palette": {
        "coat_cream": (0.94, 0.93, 0.89, 1.0),
        "coat_shade": (0.80, 0.79, 0.78, 1.0),
        "horn_ivory": (0.96, 0.96, 0.98, 1.0),
        "ear_inner": (0.58, 0.48, 0.62, 1.0),
        "hoof_slate": (0.24, 0.28, 0.42, 1.0),
        "flame_yellow": (0.84, 0.86, 0.96, 1.0),
        "flame_orange": (0.58, 0.54, 0.72, 1.0),
        "flame_red": (0.38, 0.34, 0.54, 1.0),
        "eye_red": (0.74, 0.28, 0.42, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "mouth_pink": (0.74, 0.44, 0.56, 1.0),
    },
    "golden_super_rare_palette": {
        "coat_cream": (0.98, 0.78, 0.14, 1.0),
        "coat_shade": (0.86, 0.64, 0.10, 1.0),
        "horn_ivory": (0.10, 0.92, 1.00, 1.0),
        "ear_inner": (0.64, 0.44, 0.08, 1.0),
        "hoof_slate": (0.56, 0.38, 0.06, 1.0),
        "flame_yellow": (0.78, 0.99, 1.00, 1.0),
        "flame_orange": (0.10, 0.92, 1.00, 1.0),
        "flame_red": (0.04, 0.64, 0.88, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (0.80, 0.99, 1.00, 1.0),
        "mouth_pink": (0.96, 0.82, 0.30, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha os cascos apoiados em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_segment(parts: list, name: str, p0: tuple, p1: tuple, r0: float, r1: float, mat_prefix: str, mat_key: str, pal: dict, verts: int = 7):
    dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    if length < 1e-5:
        return None
    mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
    phi = math.atan2(dx, -dy)
    theta = math.acos(max(-1.0, min(1.0, dz / length)))
    obj = create_cone(name, verts, r0, r1, length + 0.04, mid, rotation=(theta, 0.0, phi))
    return _add_part(parts, obj, mat_prefix, mat_key, pal)


def build_solarsteed(
    name: str = "Solarsteed_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 078. Solarsteed (Ref: Rapidash):
      - Garanhão alto, atlético e nobre creme-marfim com pescoço longo e ereto
      - Chifre cônico afiado de unicórnio na testa, orelhas erguidas e olhos rubi determinados
      - Pose dinâmica elegante: 3 patas firmes no solo (Z=0.0) e pata dianteira direita levantada em passo nobre
      - Crina gigantesca em chamas esvoaçantes, fogo ardente nos 4 tornozelos e cauda flamejante monumental
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Rapid_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Rapid_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Rapid_Norm"

    parts = []

    # 1. TRONCO ATLÉTICO ALTO E PESCOÇO LONGO ORGULHOSO
    _add_part(
        parts,
        create_icosphere("_tmp_chest", 2, 0.42, (0.0, -0.44, 1.38), scale=(0.90, 1.12, 1.06)),
        mat_prefix,
        "coat_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_barrel", 2, 0.39, (0.0, 0.04, 1.40), scale=(0.86, 1.56, 0.96)),
        mat_prefix,
        "coat_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_rump", 2, 0.42, (0.0, 0.56, 1.42), scale=(0.92, 1.10, 1.02)),
        mat_prefix,
        "coat_cream",
        pal,
    )
    # Pescoço alto e musculoso subindo majestosamente
    _add_segment(parts, "_tmp_neck", (0.0, -0.52, 1.52), (0.0, -0.78, 2.38), 0.28, 0.18, mat_prefix, "coat_cream", pal, verts=8)

    # 2. CABEÇA NOBRE DE UNICÓRNIO + CHIFRE AFIADO + ORELHAS + OLHOS RUBI
    _add_part(
        parts,
        create_icosphere("_tmp_head_cranium", 2, 0.25, (0.0, -0.82, 2.50), scale=(0.84, 1.18, 0.96)),
        mat_prefix,
        "coat_cream",
        pal,
    )
    # Focinho longo e elegante apontando para -Y
    _add_part(
        parts,
        create_cone(
            "_tmp_muzzle",
            7,
            0.20,
            0.11,
            0.48,
            (0.0, -1.14, 2.36),
            rotation=(math.radians(110.0), 0.0, 0.0),
            scale=(0.82, 0.84, 1.0),
        ),
        mat_prefix,
        "coat_cream",
        pal,
    )
    # Boca levemente entreaberta em relincho nobre
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_open", 1, 0.08, (0.0, -1.26, 2.24), scale=(0.90, 0.95, 0.52)),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # CHIFRE DE UNICÓRNIO AFIADO NA TESTA (ASSINATURA DO RAPIDASH)
    _add_part(
        parts,
        create_cone(
            "_tmp_unicorn_horn",
            7,
            0.078,
            0.010,
            0.66,
            (0.0, -1.04, 2.86),
            rotation=(math.radians(26.0), 0.0, 0.0),
        ),
        mat_prefix,
        "horn_ivory",
        pal,
    )

    # Olhos estreitos determinados rubi + orelhas altas pontudas
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_white_{tag}",
                (0.05, 0.16, 0.08),
                (side * 0.17, -0.98, 2.50),
                rotation=(math.radians(12.0), 0.0, math.radians(side * 16.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_iris_{tag}",
                (0.055, 0.09, 0.075),
                (side * 0.18, -1.00, 2.50),
                rotation=(math.radians(12.0), 0.0, math.radians(side * 16.0)),
            ),
            mat_prefix,
            "eye_red",
            pal,
        )
        # Orelha alta ereta
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{tag}",
                5,
                0.10,
                0.014,
                0.44,
                (side * 0.18, -0.68, 2.80),
                rotation=(math.radians(-14.0), math.radians(side * 16.0), 0.0),
                scale=(0.70, 1.05, 1.0),
            ),
            mat_prefix,
            "coat_cream",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_in_{tag}",
                4,
                0.052,
                0.010,
                0.30,
                (side * 0.18, -0.71, 2.78),
                rotation=(math.radians(-14.0), math.radians(side * 16.0), 0.0),
            ),
            mat_prefix,
            "ear_inner",
            pal,
        )

    # 3. QUATRO PATAS LONGAS (3 APOIADAS EM Z=0.0 + DIANTEIRA DIREITA ERGUIDA EM TROTE NOBRE)
    planted_legs = [
        ("FL", (-0.25, -0.46, 1.24), (-0.26, -0.52, 0.68), (-0.26, -0.56, 0.18), (-0.26, -0.58, 0.09)),
        ("BL", (-0.26, 0.56, 1.26), (-0.28, 0.72, 0.68), (-0.27, 0.62, 0.18), (-0.27, 0.60, 0.09)),
        ("BR", (0.26, 0.56, 1.26), (0.28, 0.72, 0.68), (0.27, 0.62, 0.18), (0.27, 0.60, 0.09)),
    ]
    for tag, hip, knee, ankle, hoof in planted_legs:
        _add_segment(parts, f"_tmp_thigh_{tag}", hip, knee, 0.16, 0.10, mat_prefix, "coat_cream", pal, verts=7)
        _add_part(parts, create_icosphere(f"_tmp_knee_{tag}", 1, 0.105, knee), mat_prefix, "coat_cream", pal)
        _add_segment(parts, f"_tmp_shin_{tag}", knee, ankle, 0.095, 0.075, mat_prefix, "coat_cream", pal, verts=7)
        _add_part(
            parts,
            create_cone(f"_tmp_hoof_{tag}", 6, 0.115, 0.078, 0.18, hoof, scale=(0.95, 1.26, 1.0)),
            mat_prefix,
            "hoof_slate",
            pal,
        )

    # Pata dianteira direita elegantemente erguida e dobrada no joelho (como na referência!)
    fr_hip = (0.25, -0.46, 1.24)
    fr_knee = (0.34, -0.96, 1.12)
    fr_ankle = (0.32, -0.78, 0.62)
    fr_hoof = (0.32, -0.72, 0.54)
    _add_segment(parts, "_tmp_thigh_FR", fr_hip, fr_knee, 0.16, 0.10, mat_prefix, "coat_cream", pal, verts=7)
    _add_part(parts, create_icosphere("_tmp_knee_FR", 1, 0.105, fr_knee), mat_prefix, "coat_cream", pal)
    _add_segment(parts, "_tmp_shin_FR", fr_knee, fr_ankle, 0.095, 0.075, mat_prefix, "coat_cream", pal, verts=7)
    _add_part(
        parts,
        create_cone("_tmp_hoof_FR", 6, 0.11, 0.075, 0.18, fr_hoof, rotation=(math.radians(-42.0), 0.0, 0.0), scale=(0.95, 1.22, 1.0)),
        mat_prefix,
        "hoof_slate",
        pal,
    )

    # 4. CRINA FLAMEJANTE GIGANTESCA ESVOAÇANDO DA CABEÇA PARA TRÁS E PARA A DIREITA
    mane_blobs = [
        ((0.02, -0.58, 2.78), 0.28, (0.86, 1.26, 1.18), "flame_yellow"),
        ((0.08, -0.26, 2.94), 0.34, (0.94, 1.38, 1.16), "flame_orange"),
        ((0.18, 0.14, 2.86), 0.32, (0.86, 1.32, 1.08), "flame_orange"),
        ((0.04, -0.44, 2.38), 0.28, (0.88, 1.20, 1.10), "flame_yellow"),
        ((0.14, -0.14, 2.22), 0.30, (0.88, 1.26, 1.04), "flame_orange"),
        ((0.10, -0.22, 1.88), 0.24, (0.84, 1.16, 0.98), "flame_yellow"),
        ((0.08, 0.10, 1.78), 0.22, (0.80, 1.20, 0.90), "flame_orange"),
    ]
    for m_i, (loc, rad, sc, m_key) in enumerate(mane_blobs):
        _add_part(parts, create_icosphere(f"_tmp_mblob_{m_i}", 2, rad, loc, scale=sc), mat_prefix, m_key, pal)

    mane_tips = [
        ((0.28, 0.56, 3.06), 0.22, 0.78, -62.0, 22.0, "flame_red"),
        ((0.06, -0.02, 3.24), 0.16, 0.56, -24.0, 10.0, "flame_yellow"),
        ((0.36, 0.42, 2.48), 0.18, 0.68, -72.0, 32.0, "flame_red"),
        ((-0.14, 0.24, 2.66), 0.16, 0.56, -54.0, -18.0, "flame_red"),
    ]
    for t_i, (loc, r1, dep, rx_d, ry_d, m_key) in enumerate(mane_tips):
        _add_part(
            parts,
            create_cone(f"_tmp_mtip_{t_i}", 6, r1, 0.015, dep, loc, rotation=(math.radians(rx_d), math.radians(ry_d), 0.0)),
            mat_prefix,
            m_key,
            pal,
        )

    # 5. CHAMAS NOS QUATRO TORNOZELOS / PATAS (ASSINATURA DO RAPIDASH)
    fetlock_flames = [
        ("FL", (-0.28, -0.34, 0.36), -62.0, -16.0),
        ("FR", (0.36, -0.58, 0.76), -68.0, 22.0),
        ("BL", (-0.32, 0.84, 0.36), -64.0, -24.0),
        ("BR", (0.32, 0.84, 0.36), -64.0, 24.0),
    ]
    for tag, loc, rx_d, ry_d in fetlock_flames:
        _add_part(
            parts,
            create_cone(f"_tmp_fet_o_{tag}", 6, 0.14, 0.015, 0.58, loc, rotation=(math.radians(rx_d), math.radians(ry_d), 0.0)),
            mat_prefix,
            "flame_orange",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fet_y_{tag}",
                5,
                0.095,
                0.012,
                0.38,
                (loc[0], loc[1] - 0.06, loc[2] + 0.06),
                rotation=(math.radians(rx_d + 12.0), math.radians(ry_d), 0.0),
            ),
            mat_prefix,
            "flame_yellow",
            pal,
        )

    # 6. CAUDA MONUMENTAL DE FOGO VARRENDO PARA TRÁS, CIMA E DIREITA (+X)
    tail_blobs = [
        ((0.08, 0.96, 1.56), 0.28, (0.86, 1.18, 1.06), "flame_orange"),
        ((0.28, 1.24, 1.84), 0.34, (0.90, 1.24, 1.12), "flame_yellow"),
        ((0.52, 1.48, 2.12), 0.32, (0.88, 1.24, 1.10), "flame_orange"),
        ((0.40, 1.32, 1.66), 0.26, (0.84, 1.18, 0.96), "flame_orange"),
    ]
    for t_i, (loc, rad, sc, m_key) in enumerate(tail_blobs):
        _add_part(parts, create_icosphere(f"_tmp_tblob_{t_i}", 2, rad, loc, scale=sc), mat_prefix, m_key, pal)
    tail_tips = [
        ((0.76, 1.72, 2.44), 0.20, 0.78, -42.0, 36.0, "flame_red"),
        ((0.42, 1.42, 2.46), 0.16, 0.56, -18.0, 18.0, "flame_yellow"),
        ((0.74, 1.60, 1.78), 0.18, 0.64, -68.0, 44.0, "flame_red"),
    ]
    for t_i, (loc, r1, dep, rx_d, ry_d, m_key) in enumerate(tail_tips):
        _add_part(
            parts,
            create_cone(f"_tmp_ttip_{t_i}", 6, r1, 0.015, dep, loc, rotation=(math.radians(rx_d), math.radians(ry_d), 0.0)),
            mat_prefix,
            m_key,
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 078. Solarsteed lado a lado."""
    specs = [
        ("Solarsteed_Shiny", (-8.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Solarsteed_Normal", (-5.1, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Solarsteed_Grande", (-0.9, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Solarsteed_Gigante", (4.5, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Solarsteed_Dourada_SuperRara", (11.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_solarsteed(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
