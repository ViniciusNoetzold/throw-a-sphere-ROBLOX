"""
131_Glacierness_Lapras_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "131. Glacierness — Plesiossauro Gentil (Ref: Lapras)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Glacierness_Shiny (1.0x - Paleta Shiny Lavanda-Violeta Real + Carapaça Cinza-Pedra)
  2. Glacierness_Normal (1.0x - Corpo Azul-Celeste + Pescoço Longo + Orelhas Espiral + Carapaça com Calombos)
  3. Glacierness_Grande (1.35x - Normal)
  4. Glacierness_Gigante (1.85x - Normal)
  5. Glacierness_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Chifre e Calombos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para silhueta suave aquática, cones 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Nadadeiras/barriga alinhadas exatamente em `Z = 0.0` e cabeça/sorriso gentil apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.34, 0.72, 0.90, 1.0),
        "spot_blue": (0.20, 0.52, 0.74, 1.0),
        "belly_cream": (0.95, 0.90, 0.74, 1.0),
        "shell_grey": (0.68, 0.69, 0.73, 1.0),
        "shell_rim": (0.80, 0.81, 0.85, 1.0),
        "eye_brown": (0.34, 0.22, 0.16, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "pupil_dark": (0.09, 0.08, 0.08, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.64, 0.36, 0.78, 1.0),
        "spot_blue": (0.46, 0.22, 0.60, 1.0),
        "belly_cream": (0.96, 0.91, 0.78, 1.0),
        "shell_grey": (0.66, 0.67, 0.74, 1.0),
        "shell_rim": (0.78, 0.79, 0.86, 1.0),
        "eye_brown": (0.36, 0.20, 0.26, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "pupil_dark": (0.09, 0.08, 0.10, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.98, 0.78, 0.14, 1.0),
        "spot_blue": (0.80, 0.56, 0.08, 1.0),
        "belly_cream": (1.00, 0.93, 0.54, 1.0),
        "shell_grey": (0.86, 0.66, 0.14, 1.0),
        "shell_rim": (0.10, 0.92, 1.00, 1.0),
        "eye_brown": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "pupil_dark": (0.04, 0.38, 0.54, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_glacierness(
    name: str = "Glacierness_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 131. Glacierness (Ref: Lapras):
      - Corpo aquático azul-celeste amplo com barriga creme apoiada limpo em Z = 0.0
      - 4 nadadeiras suaves em remo (2 frontais longas + 2 traseiras menores) com face inferior creme
      - Grande carapaça cinza-pedra abobadada nas costas com borda elevada e 8 calombos suaves
      - Pescoço longo curvado em cisne com faixa frontal creme contínua até o queixo
      - Cabeça gentil com chifre curto na testa, orelhas enroladas em caracol e olhos castanhos doces
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Lapras_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Lapras_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Lapras_Norm"

    parts = []

    # 1. CORPO AQUÁTICO AMPLO + BARRIGA CREME + CAUDA CURTA
    _add_part(
        parts,
        create_icosphere("_tmp_body_base", 2, 0.88, (0.0, 0.22, 0.56), scale=(1.04, 1.32, 0.62)),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_belly_base", 2, 0.82, (0.0, 0.14, 0.36), scale=(0.94, 1.24, 0.44)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # Cauda curta pontuda saindo atrás
    _add_part(
        parts,
        create_cone(
            "_tmp_tail",
            6,
            0.28,
            0.03,
            0.74,
            (0.0, 1.48, 0.34),
            rotation=(math.radians(82.0), 0.0, 0.0),
            scale=(1.10, 0.68, 1.0),
        ),
        mat_prefix,
        "body_blue",
        pal,
    )

    # 2. GRANDE CARAPAÇA CINZA-PEDRA COM BORDA E CALOMBOS SUAVES
    _add_part(
        parts,
        create_icosphere("_tmp_shell_dome", 2, 0.90, (0.0, 0.36, 0.90), scale=(0.98, 1.18, 0.72)),
        mat_prefix,
        "shell_grey",
        pal,
    )
    # Borda rolada clara na base da carapaça
    _add_part(
        parts,
        create_cylinder(
            "_tmp_shell_rim",
            14,
            0.94,
            0.14,
            (0.0, 0.36, 0.66),
            rotation=(math.radians(-6.0), 0.0, 0.0),
            scale=(0.98, 1.18, 1.0),
        ),
        mat_prefix,
        "shell_rim",
        pal,
    )
    # Calombos de pedra arredondados na carapaça (detalhe icônico do Lapras)
    shell_knobs = [
        (0.00, 0.36, 1.58, 0.17, 0.28, 0.0, 0.0),
        (-0.46, 0.06, 1.34, 0.14, 0.24, -26.0, -34.0),
        (0.46, 0.06, 1.34, 0.14, 0.24, -26.0, 34.0),
        (-0.62, 0.56, 1.18, 0.14, 0.22, 14.0, -48.0),
        (0.62, 0.56, 1.18, 0.14, 0.22, 14.0, 48.0),
        (0.00, 0.96, 1.32, 0.14, 0.24, 38.0, 0.0),
        (-0.34, 1.02, 1.02, 0.12, 0.20, 46.0, -28.0),
        (0.34, 1.02, 1.02, 0.12, 0.20, 46.0, 28.0),
    ]
    for k_idx, (kx, ky, kz, krad, kdep, krx, kry) in enumerate(shell_knobs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_shell_knob_{k_idx}",
                7,
                krad,
                krad * 0.55,
                kdep,
                (kx, ky, kz),
                rotation=(math.radians(krx), math.radians(kry), 0.0),
            ),
            mat_prefix,
            "shell_rim",
            pal,
        )

    # 3. QUATRO NADADEIRAS SUAVES EM REMO (2 FRONTAIS LONGAS + 2 TRASEIRAS)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Nadadeira frontal longa azul com face inferior creme
        _add_part(
            parts,
            create_cone(
                f"_tmp_flipper_F_{tag}",
                7,
                0.38,
                0.04,
                1.22,
                (side * 1.12, -0.34, 0.28),
                rotation=(math.radians(14.0), math.radians(side * 96.0), math.radians(side * -24.0)),
                scale=(0.36, 1.15, 1.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_flipper_F_bot_{tag}",
                7,
                0.34,
                0.035,
                1.14,
                (side * 1.10, -0.34, 0.21),
                rotation=(math.radians(14.0), math.radians(side * 96.0), math.radians(side * -24.0)),
                scale=(0.24, 1.06, 1.0),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )
        # Nadadeira traseira menor
        _add_part(
            parts,
            create_cone(
                f"_tmp_flipper_B_{tag}",
                6,
                0.28,
                0.035,
                0.86,
                (side * 0.94, 0.92, 0.26),
                rotation=(math.radians(-16.0), math.radians(side * 94.0), math.radians(side * 34.0)),
                scale=(0.34, 1.05, 1.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Manchas azul-escuro nas laterais do corpo
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_body_spot_{tag}",
                1,
                0.12,
                (side * 0.78, -0.34, 0.56),
                scale=(0.48, 1.10, 0.85),
            ),
            mat_prefix,
            "spot_blue",
            pal,
        )

    # 4. PESCOÇO LONGO CURVADO EM CISNE COM FAIXA FRONTAL CREME
    neck_nodes = [
        (0.0, -0.58, 0.84, 0.36, 0.28),
        (0.0, -0.68, 1.16, 0.31, 0.24),
        (0.0, -0.72, 1.48, 0.27, 0.21),
        (0.0, -0.70, 1.78, 0.24, 0.19),
        (0.0, -0.66, 2.04, 0.23, 0.18),
    ]
    for n_idx, (nx, ny, nz, nrad, crad) in enumerate(neck_nodes):
        _add_part(
            parts,
            create_icosphere(f"_tmp_neck_{n_idx}", 2, nrad, (nx, ny, nz), scale=(0.94, 0.98, 1.14)),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_neck_cream_{n_idx}", 2, crad, (nx, ny - nrad * 0.52, nz), scale=(0.82, 0.60, 1.16)),
            mat_prefix,
            "belly_cream",
            pal,
        )
    # Sardas azuis no pescoço
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(f"_tmp_neck_spot_{tag}", 1, 0.065, (side * 0.22, -0.70, 1.66), scale=(0.45, 0.85, 1.10)),
            mat_prefix,
            "spot_blue",
            pal,
        )

    # 5. CABEÇA GENTIL + CHIFRE NA TESTA + ORELHAS EM ESPIRAL + OLHOS DOCES
    hx, hy, hz = 0.0, -0.76, 2.26
    _add_part(
        parts,
        create_icosphere("_tmp_head_main", 2, 0.36, (hx, hy, hz), scale=(0.98, 1.18, 0.92)),
        mat_prefix,
        "body_blue",
        pal,
    )
    # Focinho suave e queixo creme sorridente
    _add_part(
        parts,
        create_icosphere("_tmp_snout", 2, 0.25, (hx, hy - 0.34, hz - 0.04), scale=(0.90, 1.18, 0.72)),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_jaw_cream", 2, 0.23, (hx, hy - 0.30, hz - 0.16), scale=(0.94, 1.12, 0.44)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # Chifre curto arredondado na testa
    _add_part(
        parts,
        create_cone(
            "_tmp_forehead_horn",
            7,
            0.10,
            0.04,
            0.28,
            (hx, hy - 0.26, hz + 0.34),
            rotation=(math.radians(-26.0), 0.0, 0.0),
        ),
        mat_prefix,
        "shell_rim" if variant == "DouradaSuperRara" else "body_blue",
        pal,
    )
    # Orelhas icônicas enroladas em espiral no topo traseiro da cabeça
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ear_curl_{tag}",
                2,
                0.22,
                (side * 0.34, hy + 0.12, hz + 0.26),
                rotation=(0.0, math.radians(side * 16.0), math.radians(side * -14.0)),
                scale=(0.68, 1.04, 1.04),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Centro da espiral da orelha em azul-escuro sutil
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ear_swirl_{tag}",
                8,
                0.08,
                0.06,
                (side * 0.44, hy + 0.10, hz + 0.24),
                rotation=(0.0, math.radians(90.0), 0.0),
            ),
            mat_prefix,
            "spot_blue",
            pal,
        )

    # Olhos expressivos gentis castanhos com brilho branco
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.11,
                (side * 0.26, hy - 0.26, hz + 0.04),
                rotation=(0.0, 0.0, math.radians(side * -26.0)),
                scale=(0.56, 1.12, 0.84),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.072,
                (side * 0.30, hy - 0.28, hz + 0.04),
                scale=(0.52, 0.90, 0.95),
            ),
            mat_prefix,
            "eye_brown",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.032,
                (side * 0.33, hy - 0.30, hz + 0.07),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 131. Glacierness lado a lado."""
    specs = [
        ("Glacierness_Shiny", (-10.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Glacierness_Normal", (-6.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Glacierness_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Glacierness_Gigante", (5.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Glacierness_Dourada_SuperRara", (14.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_glacierness(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
