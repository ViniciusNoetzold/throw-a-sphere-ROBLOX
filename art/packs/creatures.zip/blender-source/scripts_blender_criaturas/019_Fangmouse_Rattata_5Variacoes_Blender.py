"""
019_Fangmouse_Rattata_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "019. Fangmouse — Ratinho Dentuço (Ref: Rattata)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Fangmouse_Shiny (1.0x - Paleta Shiny / Shyne Oliva-Dourado + Barriga Creme)
  2. Fangmouse_Normal (1.0x - Corpo Roxo-Lavanda + Barriga Creme + Incisivos Brancos + Olhos Rubi)
  3. Fangmouse_Grande (1.35x - Normal)
  4. Fangmouse_Gigante (1.85x - Normal)
  5. Fangmouse_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e frente/focinho apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Fangmouse_Shiny`, `Fangmouse_Normal`, `Fangmouse_Grande`,
     `Fangmouse_Gigante`, `Fangmouse_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_purple": (0.60, 0.40, 0.78, 1.0),
        "belly_cream": (0.95, 0.90, 0.72, 1.0),
        "teeth_white": (0.98, 0.98, 0.98, 1.0),
        "eye_ruby": (0.86, 0.20, 0.28, 1.0),
        "mouth_pink": (0.84, 0.54, 0.62, 1.0),
        "pupil_black": (0.12, 0.10, 0.15, 1.0),
    },
    "shiny_palette": {
        "body_purple": (0.66, 0.76, 0.34, 1.0),
        "belly_cream": (0.97, 0.94, 0.74, 1.0),
        "teeth_white": (0.99, 0.99, 0.96, 1.0),
        "eye_ruby": (0.92, 0.24, 0.28, 1.0),
        "mouth_pink": (0.88, 0.56, 0.62, 1.0),
        "pupil_black": (0.14, 0.14, 0.10, 1.0),
    },
    "golden_super_rare_palette": {
        "body_purple": (0.98, 0.78, 0.14, 1.0),
        "belly_cream": (1.00, 0.94, 0.56, 1.0),
        "teeth_white": (1.00, 0.99, 0.90, 1.0),
        "eye_ruby": (0.10, 0.92, 1.00, 1.0),
        "mouth_pink": (0.90, 0.64, 0.16, 1.0),
        "pupil_black": (0.14, 0.12, 0.08, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base das patas em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_fangmouse(
    name: str = "Fangmouse_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 019. Fangmouse (Ref: Rattata):
      - Frente/focinho apontando para -Y e patinhas tocando Z = 0.0
      - Corpo quadrúpede ágil roxo-lavanda com barriga e peito creme
      - Cabeça com focinho pontudo, grandes incisivos frontais brancos,
        bigodes longos creme, olhos rubi expressivos e orelhas arredondadas bicolores
      - Longa cauda roxa erguida com espiral enrolada no topo
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Fang_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Fang_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Fang_Norm"

    parts = []

    # 1. TORSO QUADRÚPEDE (DORSO ROXO + BARRIGA CREME + QUADRIL ARREDONDADO)
    _add_part(
        parts,
        create_cube("_tmp_torso_back", (0.76, 1.16, 0.54), (0.0, 0.10, 0.56), rotation=(math.radians(-6.0), 0.0, 0.0)),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_rump", 1, 0.42, (0.0, 0.54, 0.58), scale=(0.94, 1.05, 0.88)),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_belly_cream", (0.64, 1.02, 0.28), (0.0, 0.12, 0.36), rotation=(math.radians(-4.0), 0.0, 0.0)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_chest_cream", (0.58, 0.34, 0.36), (0.0, -0.34, 0.42)),
        mat_prefix,
        "belly_cream",
        pal,
    )

    # 2. CABEÇA, FOCINHO, INCISIVOS FRONTAIS, OLHOS RUBI, BIGODES E ORELHAS
    _add_part(
        parts,
        create_cube("_tmp_head_main", (0.78, 0.72, 0.56), (0.0, -0.58, 0.78), rotation=(math.radians(6.0), 0.0, 0.0)),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout_top", (0.48, 0.46, 0.28), (0.0, -0.98, 0.75), rotation=(math.radians(10.0), 0.0, 0.0)),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_snout_tip",
            4,
            0.22,
            0.10,
            0.22,
            (0.0, -1.24, 0.72),
            rotation=(math.radians(96.0), 0.0, math.radians(45.0)),
            scale=(1.05, 0.85, 1.0),
        ),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_nose_dark", (0.12, 0.08, 0.08), (0.0, -1.34, 0.72)),
        mat_prefix,
        "pupil_black",
        pal,
    )

    # Bochechas e mandíbula creme + boca aberta com língua rosa
    _add_part(
        parts,
        create_cube("_tmp_cheek_cream", (0.72, 0.56, 0.24), (0.0, -0.74, 0.54)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_jaw_lower", (0.40, 0.36, 0.14), (0.0, -0.90, 0.36), rotation=(math.radians(22.0), 0.0, 0.0)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth_inner", (0.30, 0.24, 0.16), (0.0, -0.86, 0.46), rotation=(math.radians(16.0), 0.0, 0.0)),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # 2 grandes dentes incisivos frontais brancos (assinatura visual do Fangmouse)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_incisor_{tag}",
                (0.14, 0.09, 0.28),
                (side * 0.085, -1.14, 0.52),
                rotation=(math.radians(-6.0), 0.0, 0.0),
            ),
            mat_prefix,
            "teeth_white",
            pal,
        )

    # Olhos rubi facetados + sobrancelha + bigodes creme + orelhas grandes arredondadas
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_eye_white_{tag}", (0.14, 0.24, 0.20), (side * 0.34, -0.82, 0.84)),
            mat_prefix,
            "teeth_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_ruby_{tag}", (0.14, 0.15, 0.16), (side * 0.36, -0.86, 0.83)),
            mat_prefix,
            "eye_ruby",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_pupil_{tag}", (0.12, 0.08, 0.10), (side * 0.38, -0.89, 0.83)),
            mat_prefix,
            "pupil_black",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.16, 0.28, 0.09),
                (side * 0.33, -0.84, 0.96),
                rotation=(math.radians(14.0), math.radians(side * -10.0), 0.0),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )

        # Bigode longo creme saindo lateralmente da bochecha
        _add_part(
            parts,
            create_cone(
                f"_tmp_whisker_{tag}",
                4,
                0.048,
                0.008,
                0.68,
                (side * 0.64, -0.82, 0.62),
                rotation=(math.radians(8.0), math.radians(side * 90.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )

        # Orelha externa roxa + interior creme
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ear_outer_{tag}",
                6,
                0.28,
                0.14,
                (side * 0.42, -0.44, 1.16),
                rotation=(math.radians(76.0), math.radians(side * -16.0), math.radians(side * 22.0)),
                scale=(1.0, 1.16, 1.0),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ear_inner_{tag}",
                6,
                0.20,
                0.10,
                (side * 0.42, -0.49, 1.15),
                rotation=(math.radians(76.0), math.radians(side * -16.0), math.radians(side * 22.0)),
                scale=(1.0, 1.08, 1.0),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )

    # 3. QUATRO PATAS (PERNAS ROXAS + PATINHAS CREME COM DEDINHOS EM Z = 0.0)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"

        # Patas dianteiras
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_front_leg_{tag}",
                6,
                0.13,
                0.42,
                (side * 0.34, -0.26, 0.28),
                rotation=(math.radians(14.0), 0.0, math.radians(side * 6.0)),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_front_paw_{tag}", (0.22, 0.26, 0.10), (side * 0.36, -0.34, 0.05)),
            mat_prefix,
            "belly_cream",
            pal,
        )
        for t_idx, dx in enumerate((-0.075, 0.0, 0.075)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_front_toe_{tag}_{t_idx}",
                    4,
                    0.036,
                    0.008,
                    0.12,
                    (side * 0.36 + dx, -0.50, 0.045),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "belly_cream",
                pal,
            )

        # Patas traseiras (coxa forte + perna + patinha creme)
        _add_part(
            parts,
            create_cube(
                f"_tmp_back_thigh_{tag}",
                (0.24, 0.36, 0.34),
                (side * 0.36, 0.46, 0.34),
                rotation=(math.radians(-12.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_back_leg_{tag}",
                6,
                0.11,
                0.30,
                (side * 0.37, 0.54, 0.18),
                rotation=(math.radians(-16.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_back_paw_{tag}", (0.24, 0.30, 0.10), (side * 0.37, 0.44, 0.05)),
            mat_prefix,
            "belly_cream",
            pal,
        )
        for t_idx, dx in enumerate((-0.08, 0.0, 0.08)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_back_toe_{tag}_{t_idx}",
                    4,
                    0.038,
                    0.008,
                    0.12,
                    (side * 0.37 + dx, 0.26, 0.045),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "belly_cream",
                pal,
            )

    # 4. LONGA CAUDA ROXA ERGUIDA COM ESPIRAL ENROLADA NA PONTA
    tail_segments = [
        # (r1, r2, depth, (x, y, z), rot_x_deg)
        (0.11, 0.095, 0.34, (0.0, 0.90, 0.68), -32.0),
        (0.095, 0.088, 0.38, (0.0, 1.06, 0.96), -14.0),
        (0.088, 0.095, 0.38, (0.0, 1.08, 1.28), 16.0),
        (0.095, 0.115, 0.36, (0.0, 0.92, 1.56), 54.0),
        (0.115, 0.130, 0.32, (0.0, 0.64, 1.66), 98.0),
        (0.130, 0.110, 0.28, (0.0, 0.42, 1.54), 152.0),
        (0.110, 0.070, 0.24, (0.0, 0.46, 1.34), -136.0),
    ]
    for idx, (r1, r2, depth, loc, rx) in enumerate(tail_segments):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_seg_{idx}",
                6,
                r1,
                r2,
                depth,
                loc,
                rotation=(math.radians(rx), 0.0, 0.0),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )

    _add_part(
        parts,
        create_icosphere("_tmp_tail_curl_core", 1, 0.13, (0.0, 0.56, 1.44), scale=(0.95, 1.05, 1.05)),
        mat_prefix,
        "body_purple",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 019. Fangmouse lado a lado."""
    specs = [
        ("Fangmouse_Shiny", (-5.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Fangmouse_Normal", (-3.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Fangmouse_Grande", (-0.7, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Fangmouse_Gigante", (2.5, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Fangmouse_Dourada_SuperRara", (6.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_fangmouse(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
