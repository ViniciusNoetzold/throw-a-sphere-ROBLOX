"""
093_Shadeclaw_Haunter_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "093. Shadeclaw — Mãos Sombrias (Ref: Haunter)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Shadeclaw_Shiny (1.0x - Paleta Shiny Roxo-Índigo + Boca e Língua Azul-Elétrico Clássico)
  2. Shadeclaw_Normal (1.0x - Corpo Espectral Roxo-Sombrio + Espinhos + Boca Serrilhada + Garras)
  3. Shadeclaw_Grande (1.35x - Normal)
  4. Shadeclaw_Gigante (1.85x - Normal)
  5. Shadeclaw_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Boca Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para cabeça e palmas; cones para espinhos e garras)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Ponta inferior da cauda alinhada em `Z = 0.0` e rosto/garras apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_purple": (0.44, 0.35, 0.58, 1.0),
        "body_dark": (0.28, 0.22, 0.40, 1.0),
        "mouth_pink": (0.76, 0.38, 0.56, 1.0),
        "tongue_pink": (0.90, 0.52, 0.68, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.08, 0.08, 0.12, 1.0),
    },
    "shiny_palette": {
        "body_purple": (0.38, 0.36, 0.68, 1.0),
        "body_dark": (0.22, 0.22, 0.46, 1.0),
        "mouth_pink": (0.14, 0.52, 0.94, 1.0),
        "tongue_pink": (0.34, 0.76, 1.00, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.06, 0.08, 0.16, 1.0),
    },
    "golden_super_rare_palette": {
        "body_purple": (0.98, 0.78, 0.14, 1.0),
        "body_dark": (0.78, 0.54, 0.08, 1.0),
        "mouth_pink": (0.08, 0.74, 0.88, 1.0),
        "tongue_pink": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.28, 0.42, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_shadeclaw(
    name: str = "Shadeclaw_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 093. Shadeclaw (Ref: Haunter):
      - Cabeça/corpo espectral triangular-arredondado afunilando em cauda rasgada até Z=0
      - 1 espinho dorsal alto no topo + 3 pares de longos espinhos laterais/traseiros em leque
      - Olhos triangulares brancos furiosos e boca enorme serrilhada com presas roxas e língua rosa (azul na Shiny)
      - 2 grandes mãos espectrais com 3 garras curvas projetadas à frente, ligadas por névoa sombria sutil
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Sha_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Sha_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Sha_Norm"

    parts = []

    # 1. CORPO / CABEÇA ESPECTRAL PRINCIPAL + CAUDA AFUNILADA RASGADA
    _add_part(
        parts,
        create_icosphere("_tmp_head_body", 2, 0.72, (0.0, 0.04, 1.38), scale=(1.04, 0.96, 0.98)),
        mat_prefix,
        "body_purple",
        pal,
    )
    # Volume frontal da mandíbula/bochecha
    _add_part(
        parts,
        create_icosphere("_tmp_jaw_base", 2, 0.56, (0.0, -0.14, 1.12), scale=(1.10, 0.90, 0.86)),
        mat_prefix,
        "body_purple",
        pal,
    )
    # Cauda espectral cônica descendo para trás e tocando Z = 0.0
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_upper",
            7,
            0.22,
            0.54,
            0.78,
            (0.0, 0.22, 0.74),
            rotation=(math.radians(-18.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_tip",
            6,
            0.03,
            0.22,
            0.62,
            (0.0, 0.38, 0.26),
            rotation=(math.radians(-26.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_dark",
        pal,
    )
    # Pequenas pontas rasgadas na lateral inferior da cauda
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_fray_{tag}",
                5,
                0.12,
                0.02,
                0.42,
                (side * 0.22, 0.34, 0.44),
                rotation=(math.radians(150.0), math.radians(side * 22.0), 0.0),
            ),
            mat_prefix,
            "body_dark",
            pal,
        )

    # 2. ESPINHOS ICÔNICOS DA CABEÇA (1 CRISTA TOPO + 3 PARES LATERAIS/TRASEIROS + BOCHECHAS)
    # Espinho alto central no topo da cabeça
    _add_part(
        parts,
        create_cone(
            "_tmp_top_crest",
            6,
            0.34,
            0.024,
            0.96,
            (0.0, -0.02, 2.24),
            rotation=(math.radians(-10.0), 0.0, 0.0),
            scale=(0.86, 1.04, 1.0),
        ),
        mat_prefix,
        "body_purple",
        pal,
    )

    # 3 pares de grandes espinhos sweeping para os lados e trás (fiel à silhueta do Haunter!)
    side_spike_specs = [
        # (name, x, y, z, r1, depth, rx_deg, ry_deg, rz_deg)
        ("top", 0.94, 0.28, 1.92, 0.28, 1.18, -16.0, 56.0, -14.0),
        ("mid", 0.96, 0.34, 1.44, 0.24, 1.06, -12.0, 76.0, -12.0),
        ("low", 0.84, 0.36, 0.98, 0.20, 0.88, -10.0, 96.0, -10.0),
        ("cheek", 0.62, -0.18, 1.54, 0.16, 0.48, 8.0, 48.0, 12.0),
    ]
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        for sname, sx, sy, sz, r1, dp, rx, ry, rz in side_spike_specs:
            _add_part(
                parts,
                create_cone(
                    f"_tmp_spike_{sname}_{tag}",
                    6,
                    r1,
                    0.02,
                    dp,
                    (side * sx, sy, sz),
                    rotation=(math.radians(rx), math.radians(side * ry), math.radians(side * rz)),
                    scale=(0.88, 0.72, 1.0),
                ),
                mat_prefix,
                "body_purple",
                pal,
            )

    # 3. OLHOS TRIANGULARES FEROZES + PUPILAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.20,
                (side * 0.28, -0.60, 1.48),
                rotation=(math.radians(6.0), math.radians(side * -24.0), math.radians(side * -20.0)),
                scale=(1.22, 0.42, 0.72),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Sobrancelha furiosa afiada
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.42, 0.18, 0.12),
                (side * 0.27, -0.62, 1.60),
                rotation=(math.radians(6.0), math.radians(side * -26.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.042,
                (side * 0.22, -0.69, 1.47),
                scale=(0.58, 0.50, 1.32),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 4. BOCA ENORME ABERTA SERRILHADA (PRESAS ROXAS EM ZIGUEZAGUE + LÍNGUA ROSA/AZUL)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_cavity",
            2,
            0.38,
            (0.0, -0.56, 1.08),
            rotation=(math.radians(14.0), 0.0, 0.0),
            scale=(1.28, 0.48, 0.86),
        ),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tongue",
            2,
            0.28,
            (0.0, -0.62, 0.94),
            rotation=(math.radians(16.0), 0.0, 0.0),
            scale=(1.14, 0.44, 0.62),
        ),
        mat_prefix,
        "tongue_pink",
        pal,
    )
    # Dentes serrilhados superiores (da mesma cor do corpo, assinatura do Haunter!)
    for idx, (tx, tz) in enumerate([(-0.34, 1.24), (-0.12, 1.22), (0.12, 1.22), (0.34, 1.24)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_jaw_top_tooth_{idx}",
                4,
                0.085,
                0.015,
                0.20,
                (tx, -0.68, tz),
                rotation=(math.radians(170.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )
    # Dentes serrilhados inferiores apontando para cima
    for idx, (tx, tz) in enumerate([(-0.32, 0.92), (-0.16, 0.84), (0.0, 0.82), (0.16, 0.84), (0.32, 0.92)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_jaw_bot_tooth_{idx}",
                4,
                0.075,
                0.015,
                0.18,
                (tx, -0.68, tz),
                rotation=(math.radians(10.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )

    # 5. DUAS MÃOS ESPECTRAIS COM 3 GARRAS CURVAS + CONEXÃO DE NÉVOA SOMBRIA
    hand_specs = [
        # (tag, side, palm_loc, palm_rot_deg)
        ("L", -1.0, (-1.04, -0.58, 1.16), (12.0, -16.0, 18.0)),
        ("R", 1.0, (1.04, -0.58, 1.02), (16.0, 14.0, -18.0)),
    ]
    for tag, side, p_loc, p_rot in hand_specs:
        px, py, pz = p_loc
        # Fio sombrio conectando o pulso da mão ao corpo (sem peças soltas!)
        _add_part(
            parts,
            create_cone(
                f"_tmp_shadow_tether_{tag}",
                6,
                0.14,
                0.06,
                0.68,
                (side * 0.72, -0.26, pz - 0.04),
                rotation=(math.radians(52.0), math.radians(side * 54.0), 0.0),
            ),
            mat_prefix,
            "body_dark",
            pal,
        )
        # Palma robusta da mão espectral
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_palm_{tag}",
                2,
                0.28,
                p_loc,
                rotation=tuple(math.radians(a) for a in p_rot),
                scale=(1.08, 1.12, 0.64),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )
        # 3 dedos com garras articuladas curvadas para baixo e frente
        finger_offsets = [
            (-0.18, -0.22, -0.02, -24.0),
            (0.00, -0.28, 0.02, 0.0),
            (0.18, -0.22, -0.02, 24.0),
        ]
        for f_idx, (fx, fy, fz, f_yaw) in enumerate(finger_offsets):
            # Falange proximal estendendo para frente
            _add_part(
                parts,
                create_cone(
                    f"_tmp_finger_base_{tag}_{f_idx}",
                    6,
                    0.095,
                    0.068,
                    0.30,
                    (px + fx, py + fy, pz + fz - 0.04),
                    rotation=(math.radians(118.0), math.radians(f_yaw * 0.6), math.radians(f_yaw * 0.4)),
                ),
                mat_prefix,
                "body_purple",
                pal,
            )
            # Ponta da garra curvando abruptamente para baixo
            _add_part(
                parts,
                create_cone(
                    f"_tmp_finger_claw_{tag}_{f_idx}",
                    5,
                    0.068,
                    0.014,
                    0.34,
                    (px + fx * 1.25, py + fy - 0.14, pz + fz - 0.24),
                    rotation=(math.radians(164.0), math.radians(f_yaw * 0.4), 0.0),
                ),
                mat_prefix,
                "body_dark",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 093. Shadeclaw lado a lado."""
    specs = [
        ("Shadeclaw_Shiny", (-12.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Shadeclaw_Normal", (-7.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Shadeclaw_Grande", (-2.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Shadeclaw_Gigante", (4.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Shadeclaw_Dourada_SuperRara", (12.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_shadeclaw(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
