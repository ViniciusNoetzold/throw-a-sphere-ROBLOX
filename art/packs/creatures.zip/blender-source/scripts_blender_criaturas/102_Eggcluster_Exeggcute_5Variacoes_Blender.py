"""
102_Eggcluster_Exeggcute_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "102. Eggcluster — Ninho Psíquico (Ref: Exeggcute)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Eggcluster_Shiny (1.0x - Cascas Amarelo-Ouro + Gema Laranja-Âmbar)
  2. Eggcluster_Normal (1.0x - Grupo de 6 Ovos Rosa-Suave com Faces Distintas e Ovo Rachado com Gema)
  3. Eggcluster_Grande (1.35x - Normal)
  4. Eggcluster_Gigante (1.85x - Normal)
  5. Eggcluster_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Gema Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 em formato oval de ovo, rachaduras e gema 3D)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base do ninho alinhada exatamente em `Z = 0.0` e faces apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "shell_pink": (0.96, 0.80, 0.84, 1.0),
        "shell_shade": (0.85, 0.68, 0.72, 1.0),
        "yolk_yellow": (0.98, 0.84, 0.24, 1.0),
        "crack_dark": (0.20, 0.16, 0.18, 1.0),
        "mouth_pink": (0.76, 0.44, 0.52, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "shiny_palette": {
        "shell_pink": (0.96, 0.84, 0.28, 1.0),
        "shell_shade": (0.84, 0.70, 0.18, 1.0),
        "yolk_yellow": (0.96, 0.50, 0.14, 1.0),
        "crack_dark": (0.24, 0.18, 0.10, 1.0),
        "mouth_pink": (0.78, 0.44, 0.22, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "shell_pink": (0.98, 0.78, 0.14, 1.0),
        "shell_shade": (0.86, 0.62, 0.08, 1.0),
        "yolk_yellow": (0.10, 0.92, 1.00, 1.0),
        "crack_dark": (0.44, 0.30, 0.05, 1.0),
        "mouth_pink": (0.78, 0.52, 0.10, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.04, 0.40, 0.56, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_egg_face(
    parts: list,
    tag: str,
    cx: float,
    cy: float,
    cz: float,
    rad: float,
    mood: str,
    yaw_deg: float,
    mat_prefix: str,
    pal: dict,
):
    """Adiciona olhos expressivos, sobrancelhas e boca à superfície frontal de um ovo."""
    yaw = math.radians(yaw_deg)
    ca, sa = math.cos(yaw), math.sin(yaw)

    def place(lx, ly, lz):
        wx = cx + lx * ca - ly * sa
        wy = cy + lx * sa + ly * ca
        wz = cz + lz
        return (wx, wy, wz)

    eye_z = 0.08 * rad
    eye_y = -0.90 * rad

    for side in (-1.0, 1.0):
        st = "L" if side < 0 else "R"
        ex = side * 0.34 * rad
        if mood == "sleepy":
            brow_tilt = side * 4.0
            eye_h = 0.14 * rad
        elif mood == "smug":
            brow_tilt = -side * 16.0
            eye_h = 0.20 * rad
        else:  # angry / stern
            brow_tilt = -side * 24.0
            eye_h = 0.22 * rad

        # Contorno escuro do olho
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_bg_{tag}_{st}",
                (0.32 * rad, 0.06, eye_h + 0.045),
                place(ex, eye_y, eye_z),
                rotation=(0.0, math.radians(brow_tilt), yaw + math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Esclera branca
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_w_{tag}_{st}",
                (0.27 * rad, 0.065, eye_h),
                place(ex, eye_y - 0.018, eye_z),
                rotation=(0.0, math.radians(brow_tilt), yaw + math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pupila vertical escura
        _add_part(
            parts,
            create_cube(
                f"_tmp_pupil_{tag}_{st}",
                (0.055 * rad, 0.06, eye_h * 0.72),
                place(ex - side * 0.02 * rad, eye_y - 0.04, eye_z - 0.01 * rad),
                rotation=(0.0, 0.0, yaw + math.radians(side * -10.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Boca distinta conforme a personalidade de cada ovo
    if mood == "smug":
        _add_part(
            parts,
            create_cube(
                f"_tmp_mouth_{tag}",
                (0.46 * rad, 0.055, 0.055 * rad),
                place(0.02 * rad, -0.94 * rad, -0.18 * rad),
                rotation=(0.0, math.radians(-10.0), yaw),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
    elif mood == "sleepy":
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_mouth_{tag}",
                1,
                0.15 * rad,
                place(0.0, -0.92 * rad, -0.22 * rad),
                rotation=(0.0, 0.0, yaw),
                scale=(1.25, 0.45, 0.65),
            ),
            mat_prefix,
            "mouth_pink",
            pal,
        )
    elif mood == "open_frown":
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_mouth_bg_{tag}",
                1,
                0.15 * rad,
                place(0.0, -0.92 * rad, -0.24 * rad),
                rotation=(0.0, 0.0, yaw),
                scale=(1.30, 0.42, 0.56),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_mouth_in_{tag}",
                1,
                0.11 * rad,
                place(0.0, -0.95 * rad, -0.25 * rad),
                rotation=(0.0, 0.0, yaw),
                scale=(1.15, 0.40, 0.46),
            ),
            mat_prefix,
            "mouth_pink",
            pal,
        )
    else:  # angry frown
        _add_part(
            parts,
            create_cube(
                f"_tmp_mouth_{tag}",
                (0.38 * rad, 0.05, 0.05 * rad),
                place(0.0, -0.93 * rad, -0.24 * rad),
                rotation=(0.0, math.radians(8.0), yaw),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )


def _add_egg_crack(parts: list, tag: str, pts: list, mat_prefix: str, pal: dict):
    """Adiciona uma rachadura ziguezague escura na superfície de um ovo."""
    for idx, (loc, length, rx_d, ry_d, rz_d) in enumerate(pts):
        _add_part(
            parts,
            create_cube(
                f"_tmp_crack_{tag}_{idx}",
                (0.032, 0.038, length),
                loc,
                rotation=(math.radians(rx_d), math.radians(ry_d), math.radians(rz_d)),
            ),
            mat_prefix,
            "crack_dark",
            pal,
        )


def build_eggcluster(
    name: str = "Eggcluster_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel do 102. Eggcluster (Ref: Exeggcute):
      - Grupo compacto e unido de 6 ovos rosa-claro (dourados na Shiny) sem peças soltas
      - 5 ovos com expressões faciais únicas (confiante, bravo, sonolento, zangado, sério) e rachaduras
      - 6º ovo no fundo esquerdo com casca superior quebrada revelando a gema amarela brilhante!
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Eggcluster_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Eggcluster_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Eggcluster_Norm"

    parts = []

    # 1. OVO CENTRAL LÍDER (MEIO, SORRISO CONFIANTE)
    _add_part(
        parts,
        create_icosphere("_tmp_egg_center", 2, 0.44, (0.0, 0.02, 0.64), scale=(0.98, 0.94, 1.22)),
        mat_prefix,
        "shell_pink",
        pal,
    )
    _add_egg_face(parts, "center", 0.0, 0.02, 0.68, 0.44, "smug", 0.0, mat_prefix, pal)

    # 2. OVO FRONTAL ESQUERDO (BRAVO + RACHADURA NA TESTA)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_egg_FL",
            2,
            0.40,
            (-0.64, -0.24, 0.48),
            rotation=(math.radians(-6.0), math.radians(-12.0), math.radians(16.0)),
            scale=(0.98, 0.94, 1.20),
        ),
        mat_prefix,
        "shell_pink",
        pal,
    )
    _add_egg_face(parts, "FL", -0.64, -0.24, 0.48, 0.40, "angry", 18.0, mat_prefix, pal)
    _add_egg_crack(
        parts,
        "FL",
        [
            ((-0.62, -0.55, 0.72), 0.20, -18.0, -16.0, 16.0),
            ((-0.58, -0.57, 0.56), 0.16, -10.0, 22.0, 16.0),
        ],
        mat_prefix,
        pal,
    )

    # 3. OVO FRONTAL INFERIOR DIREITO (CARRANCA ABERTA + RACHADURA EM Y)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_egg_FR",
            2,
            0.41,
            (0.28, -0.44, 0.45),
            rotation=(math.radians(-8.0), math.radians(10.0), math.radians(-12.0)),
            scale=(0.98, 0.94, 1.20),
        ),
        mat_prefix,
        "shell_pink",
        pal,
    )
    _add_egg_face(parts, "FR", 0.28, -0.44, 0.45, 0.41, "open_frown", -12.0, mat_prefix, pal)
    _add_egg_crack(
        parts,
        "FR",
        [
            ((0.40, -0.74, 0.72), 0.22, -20.0, 18.0, -10.0),
            ((0.46, -0.76, 0.55), 0.20, -8.0, -16.0, -10.0),
        ],
        mat_prefix,
        pal,
    )

    # 4. OVO LATERAL DIREITO (OLHAR SÉRIO + RACHADURA LATERAL)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_egg_R",
            2,
            0.39,
            (0.76, -0.02, 0.56),
            rotation=(0.0, math.radians(16.0), math.radians(-26.0)),
            scale=(0.98, 0.94, 1.20),
        ),
        mat_prefix,
        "shell_pink",
        pal,
    )
    _add_egg_face(parts, "R", 0.76, -0.02, 0.56, 0.39, "angry", -28.0, mat_prefix, pal)
    _add_egg_crack(
        parts,
        "R",
        [
            ((0.68, -0.34, 0.42), 0.22, 12.0, 14.0, -24.0),
        ],
        mat_prefix,
        pal,
    )

    # 5. OVO TRASEIRO DIREITO (MAIS ALTO, EXPRESSÃO SONOLENTA)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_egg_BR",
            2,
            0.40,
            (0.50, 0.36, 0.86),
            rotation=(math.radians(6.0), math.radians(8.0), math.radians(-14.0)),
            scale=(0.98, 0.94, 1.22),
        ),
        mat_prefix,
        "shell_shade",
        pal,
    )
    _add_egg_face(parts, "BR", 0.50, 0.36, 0.88, 0.40, "sleepy", -14.0, mat_prefix, pal)
    _add_egg_crack(
        parts,
        "BR",
        [
            ((0.68, 0.04, 0.92), 0.26, 0.0, -8.0, -14.0),
        ],
        mat_prefix,
        pal,
    )

    # 6. OVO TRASEIRO ESQUERDO RACHADO COM GEMA AMARELA EXPOSTA (ICÔNICO!)
    # Metade inferior do ovo quebrado
    _add_part(
        parts,
        create_icosphere(
            "_tmp_egg_BL_base",
            2,
            0.37,
            (-0.52, 0.28, 0.82),
            rotation=(math.radians(10.0), math.radians(-16.0), 0.0),
            scale=(1.00, 0.96, 1.08),
        ),
        mat_prefix,
        "shell_pink",
        pal,
    )
    # Interior escuro da casca quebrada no topo
    _add_part(
        parts,
        create_icosphere(
            "_tmp_egg_BL_cavity",
            2,
            0.30,
            (-0.56, 0.28, 1.06),
            rotation=(math.radians(-14.0), math.radians(-16.0), 0.0),
            scale=(1.04, 0.92, 0.56),
        ),
        mat_prefix,
        "crack_dark",
        pal,
    )
    # Gema amarela redonda brilhante (ou ciano na Dourada) aparecendo nitidamente na casca quebrada!
    _add_part(
        parts,
        create_icosphere(
            "_tmp_egg_BL_yolk",
            2,
            0.27,
            (-0.54, 0.12, 1.08),
            scale=(1.06, 0.98, 0.88),
        ),
        mat_prefix,
        "yolk_yellow",
        pal,
    )
    # Pontinhas irregulares de casca quebrada ao redor da gema
    shard_specs = [
        (-0.80, 0.22, 1.04, -26.0),
        (-0.68, 0.42, 1.18, -10.0),
        (-0.42, 0.40, 1.16, 14.0),
        (-0.32, 0.18, 1.02, 26.0),
    ]
    for s_idx, (sx, sy, sz, ry_d) in enumerate(shard_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_egg_shard_{s_idx}",
                4,
                0.12,
                0.025,
                0.24,
                (sx, sy, sz),
                rotation=(math.radians(-12.0), math.radians(ry_d), 0.0),
            ),
            mat_prefix,
            "shell_pink",
            pal,
        )

    # Base discreta de conexão interna (totalmente oculta no centro do ninho para garantir coesão 100% sólida)
    _add_part(
        parts,
        create_icosphere("_tmp_nest_core", 1, 0.46, (0.04, 0.02, 0.36), scale=(1.45, 0.95, 0.56)),
        mat_prefix,
        "shell_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 102. Eggcluster lado a lado."""
    specs = [
        ("Eggcluster_Shiny", (-9.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Eggcluster_Normal", (-5.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Eggcluster_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Eggcluster_Gigante", (5.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Eggcluster_Dourada_SuperRara", (12.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_eggcluster(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
