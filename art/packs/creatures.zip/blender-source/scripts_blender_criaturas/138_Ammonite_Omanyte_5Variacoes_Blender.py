"""
138_Ammonite_Omanyte_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "138. Ammonite — Molusco Espiral (Ref: Omanyte)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Ammonite_Shiny (1.0x - Paleta Shiny Tentáculos Roxo-Lavanda + Concha Bege-Claro)
  2. Ammonite_Normal (1.0x - Concha Espiral Bege-Fóssil + Corpo e 10 Tentáculos Azul-Celeste)
  3. Ammonite_Grande (1.35x - Normal)
  4. Ammonite_Gigante (1.85x - Normal)
  5. Ammonite_Dourada_SuperRara (2.25x - Concha Ouro Reluzente + Tentáculos e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para a concha espiralada e olhos + cones curvados para os 10 tentáculos)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Tentáculos inferiores alinhados exatamente em `Z = 0.0` e olhos/rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "shell_beige": (0.91, 0.86, 0.70, 1.0),
        "shell_shade": (0.76, 0.70, 0.54, 1.0),
        "shell_rib": (0.48, 0.42, 0.32, 1.0),
        "hood_dark": (0.10, 0.10, 0.12, 1.0),
        "body_blue": (0.38, 0.78, 0.90, 1.0),
        "body_blue_shade": (0.24, 0.62, 0.76, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.09, 0.09, 0.12, 1.0),
    },
    "shiny_palette": {
        "shell_beige": (0.94, 0.90, 0.76, 1.0),
        "shell_shade": (0.78, 0.74, 0.58, 1.0),
        "shell_rib": (0.50, 0.44, 0.34, 1.0),
        "hood_dark": (0.12, 0.08, 0.16, 1.0),
        "body_blue": (0.58, 0.44, 0.88, 1.0),
        "body_blue_shade": (0.42, 0.30, 0.70, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.09, 0.09, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "shell_beige": (0.98, 0.78, 0.14, 1.0),
        "shell_shade": (0.82, 0.60, 0.08, 1.0),
        "shell_rib": (0.58, 0.40, 0.04, 1.0),
        "hood_dark": (0.26, 0.18, 0.04, 1.0),
        "body_blue": (0.10, 0.92, 1.00, 1.0),
        "body_blue_shade": (0.06, 0.64, 0.80, 1.0),
        "eye_white": (1.00, 0.99, 0.94, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une primitivas, normaliza a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_ammonite(
    name: str = "Ammonite_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 138. Ammonite (Ref: Omanyte):
      - Grande concha espiralada bege-fóssil com gomos segmentados e caracol nas laterais
      - Abertura frontal sombreada revelando o rosto azul-celeste com 2 olhos redondos enormes
      - 2 tentáculos frontais externos erguidos em curva crescente nas laterais do rosto
      - Feixe fofo de 8 tentáculos azuis curvados na base apoiados em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Amm_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Amm_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Amm_Norm"

    parts = []

    # 1. CONCHA ESPIRALADA DE NÁUTILO (GOMOS EM ARCO + CARACOL LATERAL)
    shell_arc = [
        # (rad, (x, y, z), scale, mat_key)
        (0.56, (0.0, -0.26, 0.80), (1.06, 0.82, 0.84), "shell_beige"),
        (0.54, (0.0, -0.20, 1.12), (1.02, 0.88, 0.88), "shell_beige"),
        (0.52, (0.0, -0.02, 1.38), (0.98, 0.94, 0.90), "shell_beige"),
        (0.50, (0.0, 0.24, 1.48), (0.94, 0.96, 0.92), "shell_beige"),
        (0.46, (0.0, 0.50, 1.36), (0.90, 0.96, 0.92), "shell_beige"),
        (0.42, (0.0, 0.64, 1.12), (0.86, 0.94, 0.92), "shell_shade"),
        (0.38, (0.0, 0.62, 0.84), (0.84, 0.92, 0.90), "shell_shade"),
        (0.34, (0.0, 0.44, 0.62), (0.82, 0.90, 0.88), "shell_shade"),
    ]
    for idx, (rad, loc, sc, mkey) in enumerate(shell_arc):
        _add_part(
            parts,
            create_icosphere(f"_tmp_shell_seg_{idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            mkey,
            pal,
        )

    # Frisos/anéis sutis marcando a segmentação transversal da concha
    rib_specs = [
        ((0.0, -0.24, 0.96), (78.0, 0.0, 0.0), 0.55, 0.04),
        ((0.0, -0.14, 1.26), (52.0, 0.0, 0.0), 0.53, 0.04),
        ((0.0, 0.12, 1.46), (18.0, 0.0, 0.0), 0.50, 0.04),
        ((0.0, 0.40, 1.44), (-22.0, 0.0, 0.0), 0.47, 0.04),
        ((0.0, 0.58, 1.24), (-56.0, 0.0, 0.0), 0.43, 0.04),
    ]
    for idx, (loc, (rx, ry, rz), rad, dep) in enumerate(rib_specs):
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_shell_rib_{idx}",
                10,
                rad,
                dep,
                loc,
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
                scale=(1.02, 0.86, 1.0),
            ),
            mat_prefix,
            "shell_rib",
            pal,
        )

    # Discos laterais em espiral da concha (assinatura visual do náutilo)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_spiral_outer_{tag}",
                10,
                0.38,
                0.12,
                (side * 0.42, 0.26, 1.04),
                rotation=(0.0, math.radians(90.0), 0.0),
            ),
            mat_prefix,
            "shell_shade",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_spiral_ring_{tag}",
                10,
                0.24,
                0.14,
                (side * 0.44, 0.28, 1.02),
                rotation=(0.0, math.radians(90.0), 0.0),
            ),
            mat_prefix,
            "shell_rib",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_spiral_core_{tag}",
                8,
                0.15,
                0.16,
                (side * 0.45, 0.26, 1.00),
                rotation=(0.0, math.radians(90.0), 0.0),
            ),
            mat_prefix,
            "shell_beige",
            pal,
        )

    # 2. ABERTURA ESCURA DA CONCHA, ROSTO AZUL E OLHOS ENORMES EXPRESSIVOS
    _add_part(
        parts,
        create_icosphere("_tmp_hood_cavity", 2, 0.44, (0.0, -0.44, 0.56), scale=(1.12, 0.72, 0.84)),
        mat_prefix,
        "hood_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_head_blue", 2, 0.46, (0.0, -0.34, 0.38), scale=(1.14, 0.96, 0.82)),
        mat_prefix,
        "body_blue",
        pal,
    )
    # Dois olhos redondos enormes com pupilas grandes pretas e brilho branco
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.19,
                (side * 0.24, -0.70, 0.56),
                scale=(1.02, 0.68, 1.06),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                2,
                0.125,
                (side * 0.24, -0.79, 0.55),
                scale=(0.98, 0.52, 1.04),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.044,
                (side * 0.20, -0.84, 0.61),
                scale=(0.88, 0.50, 0.92),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # 3. DOIS TENTÁCULOS EXTERNOS CURVADOS PARA CIMA (EMOLDURANDO O ROSTO)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_arm_base_{tag}",
                2,
                0.19,
                (side * 0.52, -0.50, 0.36),
                scale=(1.15, 0.92, 0.86),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_mid_{tag}",
                8,
                0.17,
                0.11,
                0.40,
                (side * 0.72, -0.54, 0.50),
                rotation=(math.radians(-12.0), math.radians(side * 42.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_tip_{tag}",
                8,
                0.11,
                0.018,
                0.34,
                (side * 0.78, -0.56, 0.76),
                rotation=(math.radians(-8.0), math.radians(side * -14.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    # 4. FEIXE DE 8 TENTÁCULOS INFERIORES EM LEQUE APOIADOS EM Z = 0.0
    lower_tentacles = [
        # (x, y, z, rx, ry, rz, r1, depth, mat_key)
        (-0.14, -0.74, 0.14, -104.0, -14.0, 0.0, 0.12, 0.44, "body_blue"),
        (0.14, -0.74, 0.14, -104.0, 14.0, 0.0, 0.12, 0.44, "body_blue"),
        (-0.36, -0.66, 0.15, -102.0, -34.0, 0.0, 0.12, 0.46, "body_blue"),
        (0.36, -0.66, 0.15, -102.0, 34.0, 0.0, 0.12, 0.46, "body_blue"),
        (-0.56, -0.48, 0.15, -96.0, -56.0, 0.0, 0.11, 0.44, "body_blue_shade"),
        (0.56, -0.48, 0.15, -96.0, 56.0, 0.0, 0.11, 0.44, "body_blue_shade"),
        (-0.48, -0.18, 0.14, 96.0, -78.0, 0.0, 0.11, 0.42, "body_blue_shade"),
        (0.48, -0.18, 0.14, 96.0, 78.0, 0.0, 0.11, 0.42, "body_blue_shade"),
    ]
    for idx, (tx, ty, tz, rx, ry, rz, r1, dep, mkey) in enumerate(lower_tentacles):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tent_{idx}",
                8,
                r1,
                0.022,
                dep,
                (tx, ty, tz),
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
                scale=(1.0, 0.82, 1.0),
            ),
            mat_prefix,
            mkey,
            pal,
        )

    # Almofada inferior central garantindo apoio firme e sem frestas
    _add_part(
        parts,
        create_icosphere("_tmp_base_pad", 2, 0.36, (0.0, -0.26, 0.14), scale=(1.18, 1.12, 0.44)),
        mat_prefix,
        "body_blue_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 138. Ammonite lado a lado."""
    specs = [
        ("Ammonite_Shiny", (-9.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Ammonite_Normal", (-5.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Ammonite_Grande", (-0.7, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Ammonite_Gigante", (4.9, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Ammonite_Dourada_SuperRara", (12.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_ammonite(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
