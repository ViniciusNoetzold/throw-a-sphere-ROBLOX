"""
125_Voltbeast_Electabuzz_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "125. Voltbeast — Fera do Raio (Ref: Electabuzz)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Voltbeast_Shiny (1.0x - Paleta Shiny Laranja-Tangerina Elétrico + Listras Pretas em Raio)
  2. Voltbeast_Normal (1.0x - Amarelo-Raio + Listras Pretas em Relâmpago + 2 Antenas de Bola + Punhos Cerrados)
  3. Voltbeast_Grande (1.35x - Normal)
  4. Voltbeast_Gigante (1.85x - Normal)
  5. Voltbeast_Dourada_SuperRara (2.25x - Ouro Reluzente + Raios, Antenas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para tronco musculoso, cabeça felina, punhos cerrados e bolas das antenas; cones/cilindros para garras, presas, tufos e cauda listrada)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas com 3 garras alinhadas exatamente em `Z = 0.0` e rosto/rugido apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_yellow": (0.96, 0.82, 0.34, 1.0),
        "body_shade": (0.84, 0.68, 0.24, 1.0),
        "stripe_black": (0.10, 0.13, 0.17, 1.0),
        "mouth_pink": (0.84, 0.56, 0.62, 1.0),
        "mouth_deep": (0.48, 0.22, 0.28, 1.0),
        "white_sharp": (0.98, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.12, 0.16, 1.0),
    },
    "shiny_palette": {
        "body_yellow": (0.96, 0.54, 0.16, 1.0),
        "body_shade": (0.82, 0.42, 0.10, 1.0),
        "stripe_black": (0.10, 0.12, 0.16, 1.0),
        "mouth_pink": (0.88, 0.52, 0.56, 1.0),
        "mouth_deep": (0.50, 0.20, 0.26, 1.0),
        "white_sharp": (0.98, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.12, 0.16, 1.0),
    },
    "golden_super_rare_palette": {
        "body_yellow": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.60, 0.08, 1.0),
        "stripe_black": (0.10, 0.92, 1.00, 1.0),
        "mouth_pink": (1.00, 0.88, 0.40, 1.0),
        "mouth_deep": (0.56, 0.36, 0.04, 1.0),
        "white_sharp": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.04, 0.46, 0.64, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_voltbeast(
    name: str = "Voltbeast_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de 125. Voltbeast (Ref: Electabuzz):
      - Tronco musculoso amarelo-raio em pera com grande raio preto em zigue-zague no peito e listras laterais
      - Cabeça larga felina/oni com bochechas saltadas, marca preta em "V" na testa, 2 tufos centrais e 2 antenas de bola
      - Olhos ferozes estreitos brancos + boca aberta rugindo com presas brancas afiadas
      - Braços musculosos listrados de preto em pose de ataque (esquerdo erguido no alto, direito socando para frente)
      - Pernas robustas listradas, pés com 3 garras brancas em Z=0.0 e longa cauda felina listrada
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Vlb_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Vlb_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Vlb_Norm"

    parts = []

    # 1. TRONCO MUSCULOSO AMARELO + GRANDE RAIO PRETO NO PEITO E LISTRAS DE TIGRE
    _add_part(
        parts,
        create_icosphere("_tmp_torso_lower", 2, 0.68, (0.0, 0.02, 0.94), scale=(1.04, 0.94, 0.96)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_torso_upper", 2, 0.56, (0.0, -0.02, 1.44), scale=(1.02, 0.90, 0.92)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Emblema de raio preto em zigue-zague no peito/barriga frontal (-Y)
    bolt_segments = [
        ((-0.08, -0.51, 1.38), (0.34, 0.14, 0.34), (8.0, -28.0, 0.0)),
        ((0.06, -0.57, 1.14), (0.44, 0.14, 0.22), (4.0, 12.0, 0.0)),
        ((-0.10, -0.56, 0.88), (0.30, 0.14, 0.38), (-10.0, -34.0, 0.0)),
    ]
    for b_idx, (loc, sz, rot_d) in enumerate(bolt_segments):
        _add_part(
            parts,
            create_cube(
                f"_tmp_chest_bolt_{b_idx}",
                sz,
                loc,
                rotation=(math.radians(rot_d[0]), math.radians(rot_d[1]), math.radians(rot_d[2])),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )
    # Listras pretas laterais na cintura
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_side_stripe_{tag}",
                (0.24, 0.56, 0.12),
                (side * 0.58, -0.06, 0.96),
                rotation=(math.radians(16.0), math.radians(side * 16.0), 0.0),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )

    # 2. CABEÇA FELINA/ONI LARGA + MARCA EM "V" + 2 TUFOS + 2 ANTENAS DE BOLA
    _add_part(
        parts,
        create_icosphere("_tmp_head_main", 2, 0.44, (0.0, -0.08, 1.98), scale=(1.12, 0.96, 0.86)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Tufos laterais largos nas bochechas (silhueta clássica do Electabuzz!)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_cheek_tuft_{tag}",
                2,
                0.24,
                (side * 0.46, -0.08, 1.94),
                scale=(1.22, 0.82, 0.72),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # Marca preta em "V" na testa
        _add_part(
            parts,
            create_cube(
                f"_tmp_forehead_v_{tag}",
                (0.11, 0.12, 0.36),
                (side * 0.11, -0.45, 2.16),
                rotation=(math.radians(-14.0), math.radians(side * 34.0), 0.0),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )
        # Antena com haste + esfera na ponta
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ant_stem_{tag}",
                6,
                0.036,
                0.38,
                (side * 0.36, -0.04, 2.38),
                rotation=(0.0, math.radians(side * 46.0), 0.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_ant_ball_{tag}", 2, 0.115, (side * 0.50, -0.04, 2.52)),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # Dois tufos finos pontiagudos de pelo no topo da cabeça
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_tuft_{tag}",
                5,
                0.068,
                0.012,
                0.56,
                (side * 0.09, -0.06, 2.54),
                rotation=(math.radians(-6.0), math.radians(side * 16.0), 0.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )

    # 3. OLHOS FEROZES + BOCA RUGINDO COM PRESAS BRANCAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_white_{tag}",
                (0.16, 0.09, 0.10),
                (side * 0.19, -0.46, 2.02),
                rotation=(math.radians(6.0), math.radians(side * -18.0), math.radians(side * -16.0)),
            ),
            mat_prefix,
            "white_sharp",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_pupil_{tag}",
                (0.055, 0.06, 0.075),
                (side * 0.19, -0.50, 2.02),
                rotation=(math.radians(6.0), math.radians(side * -18.0), math.radians(side * -16.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
    # Boca aberta rugindo + língua + 2 presas brancas
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_open",
            2,
            0.22,
            (0.0, -0.45, 1.76),
            scale=(1.14, 0.56, 0.86),
        ),
        mat_prefix,
        "mouth_deep",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tongue",
            1,
            0.15,
            (0.0, -0.50, 1.69),
            scale=(1.04, 0.44, 0.58),
        ),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.048,
                0.008,
                0.13,
                (side * 0.16, -0.54, 1.85),
                rotation=(math.radians(180.0), 0.0, 0.0),
            ),
            mat_prefix,
            "white_sharp",
            pal,
        )

    # 4. BRAÇOS MUSCULOSOS LISTRADOS + PUNHOS CERRADOS GIGANTES (POSE DINÂMICA DA ARTE!)
    # Braço esquerdo (-X) erguido no alto com punho cerrado poderoso
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_upper_L",
            8,
            0.15,
            0.54,
            (-0.74, -0.02, 1.78),
            rotation=(0.0, math.radians(-38.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_stripe_L1",
            8,
            0.16,
            0.14,
            (-0.72, -0.02, 1.76),
            rotation=(0.0, math.radians(-38.0), 0.0),
        ),
        mat_prefix,
        "stripe_black",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_elbow_L", 2, 0.17, (-0.94, -0.04, 2.02)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Tufo de pelo no cotovelo esquerdo
    _add_part(
        parts,
        create_cone(
            "_tmp_elbow_tuft_L",
            4,
            0.10,
            0.015,
            0.24,
            (-1.08, -0.02, 1.94),
            rotation=(0.0, math.radians(-128.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_lower_L",
            8,
            0.17,
            0.56,
            (-0.76, -0.10, 2.34),
            rotation=(math.radians(12.0), math.radians(32.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_stripe_L2",
            8,
            0.18,
            0.13,
            (-0.78, -0.09, 2.32),
            rotation=(math.radians(12.0), math.radians(32.0), 0.0),
        ),
        mat_prefix,
        "stripe_black",
        pal,
    )
    # Punho esquerdo cerrado no alto
    _add_part(
        parts,
        create_icosphere("_tmp_fist_L", 2, 0.28, (-0.54, -0.18, 2.66), scale=(1.12, 0.96, 0.96)),
        mat_prefix,
        "body_yellow",
        pal,
    )

    # Braço direito (+X) estendido para o lado/frente desferindo soco elétrico!
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_upper_R",
            8,
            0.15,
            0.52,
            (0.76, -0.04, 1.62),
            rotation=(0.0, math.radians(82.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_stripe_R1",
            8,
            0.16,
            0.13,
            (0.74, -0.04, 1.62),
            rotation=(0.0, math.radians(82.0), 0.0),
        ),
        mat_prefix,
        "stripe_black",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_elbow_R", 2, 0.17, (1.02, -0.06, 1.64)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_elbow_tuft_R",
            4,
            0.10,
            0.015,
            0.24,
            (1.02, -0.04, 1.82),
            rotation=(0.0, math.radians(12.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_lower_R",
            8,
            0.17,
            0.54,
            (1.24, -0.18, 1.54),
            rotation=(math.radians(24.0), math.radians(104.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_stripe_R2",
            8,
            0.18,
            0.13,
            (1.22, -0.17, 1.55),
            rotation=(math.radians(24.0), math.radians(104.0), 0.0),
        ),
        mat_prefix,
        "stripe_black",
        pal,
    )
    # Punho direito cerrado gigante
    _add_part(
        parts,
        create_icosphere("_tmp_fist_R", 2, 0.30, (1.54, -0.32, 1.44), scale=(1.14, 1.02, 0.96)),
        mat_prefix,
        "body_yellow",
        pal,
    )

    # 5. PERNAS ROBUSTAS LISTRADAS + PÉS COM 3 GARRAS BRANCAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_leg_{tag}",
                8,
                0.155,
                0.62,
                (side * 0.56, -0.04, 0.42),
                rotation=(math.radians(8.0), math.radians(side * -28.0), 0.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # 2 faixas pretas em cada perna
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_leg_stripe_top_{tag}",
                8,
                0.165,
                0.12,
                (side * 0.50, -0.02, 0.54),
                rotation=(math.radians(8.0), math.radians(side * -28.0), 0.0),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_leg_stripe_bot_{tag}",
                8,
                0.165,
                0.11,
                (side * 0.62, -0.06, 0.30),
                rotation=(math.radians(8.0), math.radians(side * -28.0), 0.0),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )
        # Pé largo amarelo
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.24,
                (side * 0.72, -0.18, 0.14),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(1.12, 1.38, 0.62),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # 3 garras brancas frontais
        for c_idx, (cx, cy, rz) in enumerate([(-0.14, -0.32, -16.0), (0.0, -0.38, 0.0), (0.14, -0.32, 16.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_claw_{tag}_{c_idx}",
                    4,
                    0.058,
                    0.01,
                    0.22,
                    (side * 0.72 + cx, -0.18 + cy, 0.08),
                    rotation=(math.radians(84.0), 0.0, math.radians(rz + side * -12.0)),
                ),
                mat_prefix,
                "white_sharp",
                pal,
            )

    # 6. CAUDA LONGA FELINA LISTRADA DE PRETO E AMARELO CONTÍNUA CURVANDO PARA CIMA/DIREITA
    tail_nodes = [
        ((0.06, 0.56, 0.62), 0.14, "body_yellow"),
        ((0.20, 0.70, 0.58), 0.138, "stripe_black"),
        ((0.36, 0.80, 0.56), 0.135, "body_yellow"),
        ((0.52, 0.86, 0.58), 0.132, "stripe_black"),
        ((0.68, 0.88, 0.64), 0.128, "body_yellow"),
        ((0.82, 0.87, 0.72), 0.124, "stripe_black"),
        ((0.94, 0.84, 0.82), 0.120, "body_yellow"),
        ((1.04, 0.79, 0.94), 0.116, "stripe_black"),
        ((1.12, 0.74, 1.07), 0.112, "body_yellow"),
        ((1.18, 0.69, 1.20), 0.108, "stripe_black"),
        ((1.22, 0.65, 1.32), 0.104, "body_yellow"),
    ]
    for t_idx, (loc, rad, mkey) in enumerate(tail_nodes):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tail_seg_{t_idx}", 2, rad, loc, scale=(1.18, 1.12, 1.12)),
            mat_prefix,
            mkey,
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 125. Voltbeast lado a lado."""
    specs = [
        ("Voltbeast_Shiny", (-13.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Voltbeast_Normal", (-8.1, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Voltbeast_Grande", (-2.2, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Voltbeast_Gigante", (5.1, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Voltbeast_Dourada_SuperRara", (14.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_voltbeast(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
