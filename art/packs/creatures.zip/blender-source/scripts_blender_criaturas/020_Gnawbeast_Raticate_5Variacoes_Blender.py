"""
020_Gnawbeast_Raticate_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "020. Gnawbeast — Ratazana Feroz (Ref: Raticate)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Gnawbeast_Shiny (1.0x - Paleta Shiny / Shyne Canela-Tijolo + Barriga Creme)
  2. Gnawbeast_Normal (1.0x - Corpo Marrom-Ocre + Barriga Creme + Incisivos Gigantes + Cauda Rosada)
  3. Gnawbeast_Grande (1.35x - Normal)
  4. Gnawbeast_Gigante (1.85x - Normal)
  5. Gnawbeast_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.017`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas traseiras alinhadas exatamente em `Z = 0.0` e frente/focinho apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Gnawbeast_Shiny`, `Gnawbeast_Normal`, `Gnawbeast_Grande`,
     `Gnawbeast_Gigante`, `Gnawbeast_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.017,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_ochre": (0.76, 0.56, 0.30, 1.0),
        "belly_cream": (0.96, 0.88, 0.64, 1.0),
        "tail_pink": (0.90, 0.72, 0.66, 1.0),
        "teeth_white": (0.98, 0.98, 0.98, 1.0),
        "mouth_pink": (0.84, 0.50, 0.58, 1.0),
        "eye_dark": (0.12, 0.10, 0.12, 1.0),
    },
    "shiny_palette": {
        "body_ochre": (0.80, 0.36, 0.24, 1.0),
        "belly_cream": (0.98, 0.90, 0.68, 1.0),
        "tail_pink": (0.92, 0.68, 0.64, 1.0),
        "teeth_white": (0.99, 0.99, 0.97, 1.0),
        "mouth_pink": (0.88, 0.52, 0.58, 1.0),
        "eye_dark": (0.14, 0.10, 0.10, 1.0),
    },
    "golden_super_rare_palette": {
        "body_ochre": (0.98, 0.78, 0.14, 1.0),
        "belly_cream": (1.00, 0.94, 0.56, 1.0),
        "tail_pink": (0.96, 0.82, 0.34, 1.0),
        "teeth_white": (1.00, 0.99, 0.92, 1.0),
        "mouth_pink": (0.90, 0.64, 0.16, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base das patas em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_gnawbeast(
    name: str = "Gnawbeast_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 020. Gnawbeast (Ref: Raticate):
      - Frente/focinho apontando para -Y e pés traseiros tocando Z = 0.0
      - Corpo corpulento marrom-ocre erguido sobre as patas traseiras, com barriga creme volumosa
      - Cabeça robusta com tufos arrepiados, focinho quadrado, grandes incisivos superiores e inferiores,
        3 pares de bigodes creme em leque e orelhas chanfradas
      - Longa cauda lisa rosada erguida em arco atrás do dorso
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Gnaw_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Gnaw_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Gnaw_Norm"

    parts = []

    # 1. TORSO CORPULENTO ERGUIDO (MARROM-OCRE + BARRIGA CREME + TUFOS NO DORSO)
    _add_part(
        parts,
        create_icosphere("_tmp_torso_main", 1, 0.72, (0.0, 0.14, 0.78), scale=(0.94, 0.96, 1.02)),
        mat_prefix,
        "body_ochre",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_torso_upper", (1.06, 0.94, 0.78), (0.0, 0.04, 1.06), rotation=(math.radians(-10.0), 0.0, 0.0)),
        mat_prefix,
        "body_ochre",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_belly_cream", 1, 0.62, (0.0, -0.18, 0.68), scale=(0.90, 0.78, 0.96)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_chest_cream", (0.86, 0.44, 0.62), (0.0, -0.34, 0.98)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    for t_idx, tz in enumerate((1.18, 0.96, 0.74)):
        _add_part(
            parts,
            create_cone(
                f"_tmp_back_tuft_{t_idx}",
                4,
                0.15,
                0.02,
                0.30,
                (0.0, 0.64 + t_idx * 0.05, tz),
                rotation=(math.radians(-58.0), 0.0, math.radians(45.0)),
            ),
            mat_prefix,
            "body_ochre",
            pal,
        )

    # 2. CABEÇA ROBUSTA, FOCINHO QUADRADO, INCISIVOS GIGANTES E BIGODES EM LEQUE
    _add_part(
        parts,
        create_cube("_tmp_head_main", (1.06, 0.94, 0.74), (0.0, -0.22, 1.48), rotation=(math.radians(8.0), 0.0, 0.0)),
        mat_prefix,
        "body_ochre",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout_upper", (0.76, 0.56, 0.36), (0.0, -0.74, 1.44), rotation=(math.radians(8.0), 0.0, 0.0)),
        mat_prefix,
        "body_ochre",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_cheek_cream", (0.94, 0.62, 0.34), (0.0, -0.58, 1.24)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_nose_tip", (0.24, 0.12, 0.14), (0.0, -1.03, 1.44)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_nose_dark", (0.14, 0.06, 0.07), (0.0, -1.08, 1.44)),
        mat_prefix,
        "eye_dark",
        pal,
    )

    # Boca aberta com língua rosa e mandíbula creme
    _add_part(
        parts,
        create_cube("_tmp_mouth_inner", (0.46, 0.32, 0.42), (0.0, -0.76, 1.12)),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_jaw_lower", (0.58, 0.44, 0.18), (0.0, -0.78, 0.88), rotation=(math.radians(12.0), 0.0, 0.0)),
        mat_prefix,
        "belly_cream",
        pal,
    )

    # Tufos eriçados no topo da cabeça
    for h_idx, (hx, hy, hz) in enumerate([(-0.22, -0.18, 1.92), (0.0, -0.10, 1.96), (0.22, -0.18, 1.92)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_tuft_{h_idx}",
                4,
                0.14,
                0.02,
                0.28,
                (hx, hy, hz),
                rotation=(math.radians(-18.0), 0.0, math.radians(45.0)),
            ),
            mat_prefix,
            "body_ochre",
            pal,
        )

    # 4 Grandes dentes incisivos brancos (par superior + par inferior)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_tooth_up_{tag}",
                (0.18, 0.11, 0.28),
                (side * 0.10, -0.96, 1.24),
                rotation=(math.radians(-4.0), 0.0, 0.0),
            ),
            mat_prefix,
            "teeth_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_tooth_low_{tag}",
                (0.16, 0.10, 0.22),
                (side * 0.095, -0.94, 0.99),
                rotation=(math.radians(6.0), 0.0, 0.0),
            ),
            mat_prefix,
            "teeth_white",
            pal,
        )

    # Olhos ferozes, 3 bigodes em V de cada lado e orelhas chanfradas
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_eye_white_{tag}", (0.14, 0.28, 0.18), (side * 0.46, -0.58, 1.56)),
            mat_prefix,
            "teeth_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_pupil_{tag}", (0.14, 0.13, 0.15), (side * 0.49, -0.64, 1.55)),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.18, 0.34, 0.10),
                (side * 0.45, -0.58, 1.67),
                rotation=(math.radians(16.0), math.radians(side * -12.0), 0.0),
            ),
            mat_prefix,
            "body_ochre",
            pal,
        )

        # 3 bigodes longos creme em leque (assinatura visual do Raticate)
        for w_idx, (dz, rx_deg, rz_deg, length) in enumerate([
            (0.08, 14.0, -10.0, 0.86),
            (0.00, 0.0, -18.0, 0.78),
            (-0.08, -18.0, -24.0, 0.72),
        ]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_whisker_{tag}_{w_idx}",
                    4,
                    0.044,
                    0.008,
                    length,
                    (side * 0.78, -0.66, 1.30 + dz),
                    rotation=(math.radians(rx_deg), math.radians(side * 90.0), math.radians(side * rz_deg)),
                ),
                mat_prefix,
                "belly_cream",
                pal,
            )

        # Orelha externa ocre + ponta serrilhada + interior creme
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ear_outer_{tag}",
                6,
                0.32,
                0.15,
                (side * 0.56, -0.04, 1.78),
                rotation=(math.radians(74.0), math.radians(side * -22.0), math.radians(side * 24.0)),
                scale=(1.05, 1.18, 1.0),
            ),
            mat_prefix,
            "body_ochre",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ear_inner_{tag}",
                6,
                0.22,
                0.10,
                (side * 0.56, -0.10, 1.77),
                rotation=(math.radians(74.0), math.radians(side * -22.0), math.radians(side * 24.0)),
                scale=(1.0, 1.08, 1.0),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )

    # 3. BRAÇOS DIANTEIROS CURTOS + PATAS TRASEIRAS GRANDES TOCANDO Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"

        # Patinhas dianteiras erguidas na frente do peito
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_arm_{tag}",
                6,
                0.14,
                0.38,
                (side * 0.46, -0.46, 0.74),
                rotation=(math.radians(72.0), 0.0, math.radians(side * -14.0)),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_hand_{tag}", (0.22, 0.22, 0.14), (side * 0.48, -0.66, 0.68)),
            mat_prefix,
            "belly_cream",
            pal,
        )
        for c_idx, dx in enumerate((-0.07, 0.0, 0.07)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{tag}_{c_idx}",
                    4,
                    0.036,
                    0.008,
                    0.12,
                    (side * 0.48 + dx, -0.80, 0.64),
                    rotation=(math.radians(108.0), 0.0, 0.0),
                ),
                mat_prefix,
                "belly_cream",
                pal,
            )

        # Coxas e pés traseiros robustos conectados ao tronco e apoiados em Z = 0.0
        _add_part(
            parts,
            create_cube(f"_tmp_hind_leg_{tag}", (0.32, 0.38, 0.34), (side * 0.44, 0.04, 0.24)),
            mat_prefix,
            "body_ochre",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_pad_{tag}", (0.34, 0.50, 0.14), (side * 0.44, -0.06, 0.07)),
            mat_prefix,
            "belly_cream",
            pal,
        )
        for t_idx, (dx, dy) in enumerate([(-0.11, -0.34), (0.0, -0.38), (0.11, -0.34)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_toe_{tag}_{t_idx}",
                    4,
                    0.055,
                    0.012,
                    0.22,
                    (side * 0.44 + dx, dy, 0.06),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "belly_cream",
                pal,
            )

    # 4. LONGA CAUDA LISA ROSADA EM ARCO ERGUIDO
    tail_segments = [
        (0.15, 0.125, 0.44, (0.0, 0.86, 0.34), -68.0),
        (0.125, 0.105, 0.44, (0.0, 1.20, 0.56), -42.0),
        (0.105, 0.088, 0.46, (0.0, 1.40, 0.92), -12.0),
        (0.088, 0.068, 0.46, (0.0, 1.42, 1.34), 16.0),
        (0.068, 0.044, 0.44, (0.0, 1.24, 1.72), 42.0),
        (0.044, 0.014, 0.40, (0.0, 0.96, 1.98), 62.0),
    ]
    for idx, (r1, r2, depth, loc, rx) in enumerate(tail_segments):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_seg_{idx}",
                6,
                r1,
                r2,
                depth,
                loc,
                rotation=(math.radians(rx), 0.0, 0.0),
            ),
            mat_prefix,
            "tail_pink",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 020. Gnawbeast lado a lado."""
    specs = [
        ("Gnawbeast_Shiny", (-6.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Gnawbeast_Normal", (-3.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Gnawbeast_Grande", (-0.7, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Gnawbeast_Gigante", (2.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Gnawbeast_Dourada_SuperRara", (7.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_gnawbeast(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
