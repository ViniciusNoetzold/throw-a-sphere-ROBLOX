"""
104_Bonecub_Cubone_5Variacoes_Blender.py
========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "104. Bonecub — Órfão do Crânio (Ref: Cubone)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Bonecub_Shiny (1.0x - Corpo Verde-Oliva + Barriga Creme + Crânio e Osso Marfim)
  2. Bonecub_Normal (1.0x - Corpo Marrom-Ocre + Crânio com 2 Chifres + Porrete de Osso)
  3. Bonecub_Grande (1.35x - Normal)
  4. Bonecub_Gigante (1.85x - Normal)
  5. Bonecub_Dourada_SuperRara (2.25x - Ouro Reluzente + Crânio Platina + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (corpo rechonchudo, crânio com focinho/narinas/chifres e porrete de osso)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e focinho do crânio apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_tan": (0.76, 0.58, 0.40, 1.0),
        "body_shade": (0.62, 0.46, 0.30, 1.0),
        "belly_cream": (0.95, 0.90, 0.74, 1.0),
        "bone_white": (0.94, 0.94, 0.96, 1.0),
        "bone_shade": (0.80, 0.81, 0.85, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.12, 0.12, 0.15, 1.0),
    },
    "shiny_palette": {
        "body_tan": (0.50, 0.72, 0.32, 1.0),
        "body_shade": (0.38, 0.58, 0.22, 1.0),
        "belly_cream": (0.94, 0.93, 0.72, 1.0),
        "bone_white": (0.95, 0.95, 0.97, 1.0),
        "bone_shade": (0.80, 0.82, 0.86, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.12, 0.12, 0.15, 1.0),
    },
    "golden_super_rare_palette": {
        "body_tan": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.82, 0.60, 0.08, 1.0),
        "belly_cream": (1.00, 0.94, 0.64, 1.0),
        "bone_white": (1.00, 0.98, 0.88, 1.0),
        "bone_shade": (0.92, 0.82, 0.48, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.04, 0.44, 0.60, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_bonecub(
    name: str = "Bonecub_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel do 104. Bonecub (Ref: Cubone):
      - Corpo rechonchudo bípede marrom-ocre (verde-oliva na Shiny) com grande barriga creme
      - Capacete de crânio ósseo grande com focinho longo, narinas escuras, 2 chifres e dentes laterais
      - Olhos determinados visíveis dentro das órbitas do crânio com pupila e brilho branco
      - Braço direito (-X) empunhando porrete de osso duplo branco + cauda curta atrás
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Bonecub_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Bonecub_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Bonecub_Norm"

    parts = []

    # 1. TRONCO RECHONCHUDO + BARRIGA CREME LARGA
    _add_part(
        parts,
        create_icosphere("_tmp_torso", 2, 0.54, (0.0, 0.06, 0.64), scale=(1.02, 0.94, 1.12)),
        mat_prefix,
        "body_tan",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_belly", 2, 0.44, (0.0, -0.14, 0.60), scale=(0.94, 0.72, 1.06)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # Pescoço robusto unindo corpo ao capacete de crânio
    _add_part(
        parts,
        create_cylinder("_tmp_neck", 8, 0.30, 0.32, (0.0, 0.02, 1.16)),
        mat_prefix,
        "body_shade",
        pal,
    )

    # 2. CAPACETE DE CRÂNIO ÓSSEO (GRANDE, PROPORCIONAL AO CUBONE DA ARTE!)
    # Crânio principal em domo arredondado
    _add_part(
        parts,
        create_icosphere("_tmp_skull_dome", 2, 0.56, (0.0, 0.04, 1.54), scale=(1.04, 1.04, 0.96)),
        mat_prefix,
        "bone_white",
        pal,
    )
    # Focinho longo e largo de dinossauro projetado para -Y
    _add_part(
        parts,
        create_icosphere(
            "_tmp_skull_snout",
            2,
            0.38,
            (0.0, -0.52, 1.38),
            rotation=(math.radians(14.0), 0.0, 0.0),
            scale=(0.94, 1.24, 0.84),
        ),
        mat_prefix,
        "bone_white",
        pal,
    )
    # Ponte nasal unindo testa ao focinho
    _add_part(
        parts,
        create_cone(
            "_tmp_skull_bridge",
            6,
            0.34,
            0.24,
            0.48,
            (0.0, -0.34, 1.54),
            rotation=(math.radians(-58.0), 0.0, 0.0),
            scale=(0.94, 0.76, 1.0),
        ),
        mat_prefix,
        "bone_white",
        pal,
    )
    # Narinas escuras marcantes nas laterais do focinho
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_nostril_{tag}",
                1,
                0.11,
                (side * 0.24, -0.74, 1.34),
                rotation=(0.0, 0.0, math.radians(side * -22.0)),
                scale=(0.56, 1.05, 0.86),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Dois chifres grossos no topo traseiro do crânio
        _add_part(
            parts,
            create_cone(
                f"_tmp_skull_horn_{tag}",
                6,
                0.15,
                0.055,
                0.44,
                (side * 0.44, 0.24, 1.98),
                rotation=(math.radians(24.0), math.radians(side * 42.0), 0.0),
            ),
            mat_prefix,
            "bone_white",
            pal,
        )
        # Placa lateral da bochecha/mandíbula traseira do crânio
        _add_part(
            parts,
            create_cone(
                f"_tmp_skull_cheek_{tag}",
                5,
                0.20,
                0.07,
                0.38,
                (side * 0.50, 0.26, 1.46),
                rotation=(math.radians(52.0), math.radians(side * 54.0), 0.0),
                scale=(0.82, 0.72, 1.0),
            ),
            mat_prefix,
            "bone_shade",
            pal,
        )
        # Dente/bico lateral pendendo da borda do crânio (característico da arte!)
        _add_part(
            parts,
            create_cone(
                f"_tmp_skull_fang_{tag}",
                5,
                0.11,
                0.028,
                0.22,
                (side * 0.34, -0.34, 1.14),
                rotation=(math.radians(176.0), math.radians(side * -12.0), 0.0),
            ),
            mat_prefix,
            "bone_white",
            pal,
        )

    # 3. ÓRBITAS E OLHOS DETERMINADOS (PELE MARROM + OLHO BRANCO + PUPILA ESCURA + BRILHO)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Contorno escuro da órbita do crânio
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_socket_rim_{tag}",
                2,
                0.22,
                (side * 0.36, -0.26, 1.46),
                rotation=(0.0, math.radians(side * -10.0), math.radians(side * -34.0)),
                scale=(0.94, 0.45, 1.06),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Pele marrom interna visível dentro da órbita
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_socket_skin_{tag}",
                2,
                0.185,
                (side * 0.38, -0.29, 1.46),
                rotation=(0.0, math.radians(side * -10.0), math.radians(side * -34.0)),
                scale=(0.90, 0.42, 0.98),
            ),
            mat_prefix,
            "body_tan",
            pal,
        )
        # Olho branco focado
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                1,
                0.125,
                (side * 0.40, -0.34, 1.44),
                rotation=(0.0, 0.0, math.radians(side * -36.0)),
                scale=(0.92, 0.40, 0.88),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pupila escura
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.078,
                (side * 0.41, -0.37, 1.43),
                rotation=(0.0, 0.0, math.radians(side * -36.0)),
                scale=(0.76, 0.38, 1.05),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Brilho branco no olho
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.032,
                (side * 0.43, -0.39, 1.47),
                scale=(0.75, 0.45, 0.95),
            ),
            mat_prefix,
            "bone_white",
            pal,
        )

    # 4. BRAÇOS + PORRETE DE OSSO BRANCO NA MÃO DIREITA (-X)
    # Braço direito (-X) estendido para frente-baixo segurando o osso
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R",
            7,
            0.16,
            0.12,
            0.52,
            (-0.62, -0.14, 0.86),
            rotation=(math.radians(-26.0), math.radians(-128.0), 0.0),
        ),
        mat_prefix,
        "body_tan",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hand_R", 1, 0.13, (-0.78, -0.26, 0.68)),
        mat_prefix,
        "body_tan",
        pal,
    )

    # PORRETE DE OSSO CLÁSSICO NA MÃO DIREITA (-X)
    bone_rot = (math.radians(-22.0), math.radians(28.0), math.radians(-12.0))
    _add_part(
        parts,
        create_cylinder("_tmp_bone_shaft", 8, 0.072, 0.94, (-0.96, -0.44, 0.46), rotation=bone_rot),
        mat_prefix,
        "bone_white",
        pal,
    )
    # Extremidade inferior do osso (duas cabeças de fêmur arredondadas)
    _add_part(
        parts,
        create_icosphere("_tmp_bone_bot_a", 2, 0.125, (-1.18, -0.58, 0.14)),
        mat_prefix,
        "bone_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_bone_bot_b", 2, 0.125, (-1.04, -0.66, 0.10)),
        mat_prefix,
        "bone_white",
        pal,
    )
    # Extremidade superior do osso (acima da mão)
    _add_part(
        parts,
        create_icosphere("_tmp_bone_top_a", 2, 0.10, (-0.76, -0.28, 0.82)),
        mat_prefix,
        "bone_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_bone_top_b", 2, 0.10, (-0.86, -0.32, 0.86)),
        mat_prefix,
        "bone_white",
        pal,
    )

    # Braço esquerdo (+X) abaixado ao lado com pequena garra branca
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_L",
            7,
            0.16,
            0.12,
            0.52,
            (0.62, -0.06, 0.84),
            rotation=(math.radians(-14.0), math.radians(130.0), 0.0),
        ),
        mat_prefix,
        "body_tan",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hand_L", 1, 0.13, (0.78, -0.14, 0.66)),
        mat_prefix,
        "body_tan",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_thumb_claw_L",
            4,
            0.042,
            0.012,
            0.11,
            (0.76, -0.22, 0.56),
            rotation=(math.radians(168.0), 0.0, 0.0),
        ),
        mat_prefix,
        "bone_white",
        pal,
    )

    # 5. PERNAS RECHONCHUDAS + PÉS COM UNHA BRANCA EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.30,
                (side * 0.38, -0.02, 0.34),
                scale=(0.88, 1.04, 1.12),
            ),
            mat_prefix,
            "body_tan",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.22,
                (side * 0.42, -0.14, 0.14),
                scale=(0.94, 1.24, 0.62),
            ),
            mat_prefix,
            "body_tan",
            pal,
        )
        # Unha branca única na ponta de cada pé (fiel à arte!)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_toenail_{tag}",
                1,
                0.13,
                (side * 0.44, -0.32, 0.08),
                scale=(0.96, 0.92, 0.48),
            ),
            mat_prefix,
            "bone_white",
            pal,
        )

    # 6. CAUDA CURTA AFUNILADA ATRÁS
    _add_part(
        parts,
        create_cone(
            "_tmp_tail",
            6,
            0.22,
            0.035,
            0.58,
            (-0.18, 0.62, 0.32),
            rotation=(math.radians(78.0), math.radians(-22.0), 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 104. Bonecub lado a lado."""
    specs = [
        ("Bonecub_Shiny", (-9.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Bonecub_Normal", (-5.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Bonecub_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Bonecub_Gigante", (4.9, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Bonecub_Dourada_SuperRara", (11.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_bonecub(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
