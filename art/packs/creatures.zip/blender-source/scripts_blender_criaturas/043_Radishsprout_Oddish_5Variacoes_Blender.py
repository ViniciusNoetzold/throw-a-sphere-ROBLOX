"""
043_Radishsprout_Oddish_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "043. Radishsprout — Nabo Noturno (Ref: Oddish)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Radishsprout_Shiny (1.0x - Paleta Shiny Corpo Verde-Limão + Folhas Verde-Esmeralda)
  2. Radishsprout_Normal (1.0x - Bulbo Azul-Ardósia + 5 Folhas Verdes Largas + Olhos Rubi)
  3. Radishsprout_Grande (1.35x - Normal)
  4. Radishsprout_Gigante (1.85x - Normal)
  5. Radishsprout_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Folhas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para o bulbo fofo e folhas largas facetadas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pezinhos ovais alinhados exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.32, 0.44, 0.60, 1.0),
        "body_shade": (0.22, 0.32, 0.46, 1.0),
        "leaf_green": (0.32, 0.72, 0.28, 1.0),
        "leaf_dark": (0.20, 0.50, 0.20, 1.0),
        "eye_red": (0.94, 0.24, 0.24, 1.0),
        "mouth_pink": (0.86, 0.48, 0.54, 1.0),
        "white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.56, 0.80, 0.24, 1.0),
        "body_shade": (0.40, 0.62, 0.16, 1.0),
        "leaf_green": (0.20, 0.68, 0.32, 1.0),
        "leaf_dark": (0.12, 0.48, 0.22, 1.0),
        "eye_red": (0.94, 0.22, 0.24, 1.0),
        "mouth_pink": (0.88, 0.48, 0.54, 1.0),
        "white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.60, 0.08, 1.0),
        "leaf_green": (0.10, 0.92, 1.00, 1.0),
        "leaf_dark": (0.06, 0.60, 0.76, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
        "mouth_pink": (0.82, 0.48, 0.08, 1.0),
        "white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_broad_leaf(parts: list, tag: str, base_pos: tuple, rot_deg: tuple, length: float, width: float, mat_prefix: str, mat_key: str, pal: dict):
    """Cria uma folha larga orgânica de Oddish (lâmina abaulada + ponta afiada + nervura)."""
    rx, ry, rz = [math.radians(a) for a in rot_deg]
    # Vetor de direção +Z rotacionado por Rz @ Ry @ Rx
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    # Rz @ Ry @ Rx @ (0, 0, 1)
    vx = sy * cz * cx + sz * sx
    vy = sy * sz * cx - cz * sx
    vz = cy * cx

    mid_base = (
        base_pos[0] + vx * (length * 0.30),
        base_pos[1] + vy * (length * 0.30),
        base_pos[2] + vz * (length * 0.30),
    )
    mid_tip = (
        base_pos[0] + vx * (length * 0.72),
        base_pos[1] + vy * (length * 0.72),
        base_pos[2] + vz * (length * 0.72),
    )
    _add_part(
        parts,
        create_cone(
            f"_tmp_leaf_b_{tag}",
            6,
            width * 0.38,
            width,
            length * 0.56,
            mid_base,
            rotation=(rx, ry, rz),
            scale=(1.0, 0.24, 1.0),
        ),
        mat_prefix,
        mat_key,
        pal,
    )
    _add_part(
        parts,
        create_cone(
            f"_tmp_leaf_t_{tag}",
            6,
            width,
            0.02,
            length * 0.54,
            mid_tip,
            rotation=(rx, ry, rz),
            scale=(1.0, 0.22, 1.0),
        ),
        mat_prefix,
        mat_key,
        pal,
    )
    # Retorna a ponta para eventual folha dobrada
    return (
        base_pos[0] + vx * (length * 0.96),
        base_pos[1] + vy * (length * 0.96),
        base_pos[2] + vz * (length * 0.96),
    )


def build_radishsprout(
    name: str = "Radishsprout_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de alta fidelidade do 043. Radishsprout (Ref: Oddish):
      - Corpo pequeno e bem redondo em formato de bulbo azul-ardósia (verde-limão na Shiny)
      - Olhos redondos vermelho-rubi brilhantes e boquinha alegre sorrindo aberta
      - 2 pezinhos ovais rechonchudos apoiados exatamente em Z = 0.0
      - Coroa exuberante de 5 grandes folhas verdes largas, incluindo a folha direita com ponta dobrada
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Radish_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Radish_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Radish_Norm"

    parts = []

    # 1. CORPO EM BULBO ARREDONDADO FOFO
    _add_part(
        parts,
        create_icosphere("_tmp_body", 2, 0.64, (0.0, 0.0, 0.84), scale=(1.04, 0.96, 0.94)),
        mat_prefix,
        "body_blue",
        pal,
    )

    # 2. ROSTO SIMPLES E ADORÁVEL (OLHOS RUBI + SORRISO ALEGRE ABERTO)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.082,
                (side * 0.24, -0.56, 0.94),
                scale=(0.88, 0.48, 1.04),
            ),
            mat_prefix,
            "eye_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.030,
                (side * 0.23, -0.60, 0.97),
                scale=(0.85, 0.45, 0.85),
            ),
            mat_prefix,
            "white",
            pal,
        )

    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth",
            2,
            0.135,
            (0.0, -0.58, 0.76),
            scale=(0.88, 0.42, 1.12),
        ),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # 3. DOIS PEZINHOS OVAIS RECHONCHUDOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.24,
                (side * 0.28, -0.06, 0.20),
                rotation=(math.radians(8.0), math.radians(side * -12.0), math.radians(side * -14.0)),
                scale=(0.76, 1.24, 0.84),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    # 4. COROA DE 5 GRANDES FOLHAS LARGAS NO TOPO (ASSINATURA DO ODDISH)
    crown = (0.0, 0.0, 1.32)
    # Folha 1: alta esquerda-vertical
    _add_broad_leaf(parts, "L1", (-0.06, -0.02, 1.32), (-6.0, -28.0, 8.0), 1.24, 0.34, mat_prefix, "leaf_green", pal)
    # Folha 2: alta central-traseira (tom verde um pouco mais escuro para profundidade)
    _add_broad_leaf(parts, "B2", (0.04, 0.08, 1.32), (14.0, 14.0, 0.0), 1.22, 0.32, mat_prefix, "leaf_dark", pal)
    # Folha 3: folha principal inclinada à direita com ponta dobrada característica
    tip_r = _add_broad_leaf(parts, "R3", (0.04, -0.04, 1.32), (-8.0, 48.0, -10.0), 1.32, 0.38, mat_prefix, "leaf_green", pal)
    # Ponta dobrada contínua sem folga na extremidade da folha 3
    _add_part(
        parts,
        create_icosphere(
            "_tmp_leaf_fold_joint",
            1,
            0.16,
            (tip_r[0] - 0.08, tip_r[1] + 0.02, tip_r[2] - 0.04),
            scale=(1.05, 0.32, 0.90),
        ),
        mat_prefix,
        "leaf_green",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_leaf_fold",
            5,
            0.15,
            0.02,
            0.44,
            (tip_r[0] - 0.02, tip_r[1] + 0.02, tip_r[2] - 0.22),
            rotation=(math.radians(172.0), math.radians(14.0), 0.0),
            scale=(1.0, 0.28, 1.0),
        ),
        mat_prefix,
        "leaf_dark",
        pal,
    )
    # Folha 4: traseira direita intermediária
    _add_broad_leaf(parts, "R4", (0.06, 0.08, 1.30), (14.0, 70.0, -12.0), 1.26, 0.34, mat_prefix, "leaf_dark", pal)
    # Folha 5: larga inferior direita abrindo para o lado
    _add_broad_leaf(parts, "R5", (0.08, -0.02, 1.26), (-4.0, 86.0, -6.0), 1.30, 0.36, mat_prefix, "leaf_green", pal)

    # Nó central verde unindo firmemente a base das 5 folhas ao topo do bulbo
    _add_part(
        parts,
        create_icosphere("_tmp_leaf_hub", 1, 0.20, crown, scale=(1.15, 1.05, 0.72)),
        mat_prefix,
        "leaf_dark",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 043. Radishsprout lado a lado."""
    specs = [
        ("Radishsprout_Shiny", (-9.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Radishsprout_Normal", (-5.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Radishsprout_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Radishsprout_Gigante", (4.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Radishsprout_Dourada_SuperRara", (11.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_radishsprout(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
