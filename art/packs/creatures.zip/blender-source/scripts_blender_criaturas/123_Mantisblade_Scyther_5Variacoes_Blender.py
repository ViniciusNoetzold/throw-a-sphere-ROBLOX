"""
123_Mantisblade_Scyther_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "123. Mantisblade — Louva-Deus Foice (Ref: Scyther)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Mantisblade_Shiny (1.0x - Paleta Shiny Verde-Esmeralda Vibrante + Articulações Vermelho-Carmim)
  2. Mantisblade_Normal (1.0x - Verde-Esmeralda + Peito/Juntas Creme + 4 Asas Gelo + 2 Enormes Lâminas Foice)
  3. Mantisblade_Grande (1.35x - Normal)
  4. Mantisblade_Gigante (1.85x - Normal)
  5. Mantisblade_Dourada_SuperRara (2.25x - Ouro Reluzente + Lâminas, Asas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para abdômen segmentado, tórax e ombros; cones 5-6 lados para cristas, lâminas foice, asas e garras)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés com 3 garras alinhados exatamente em `Z = 0.0` e rosto/foices apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_green": (0.46, 0.74, 0.42, 1.0),
        "body_dark": (0.30, 0.56, 0.28, 1.0),
        "joint_cream": (0.92, 0.88, 0.68, 1.0),
        "blade_white": (0.92, 0.95, 0.98, 1.0),
        "wing_pale": (0.94, 0.93, 0.84, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.12, 0.16, 0.28, 1.0),
    },
    "shiny_palette": {
        "body_green": (0.38, 0.78, 0.34, 1.0),
        "body_dark": (0.24, 0.58, 0.22, 1.0),
        "joint_cream": (0.88, 0.28, 0.34, 1.0),
        "blade_white": (0.95, 0.96, 0.99, 1.0),
        "wing_pale": (0.95, 0.92, 0.84, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.12, 0.16, 0.28, 1.0),
    },
    "golden_super_rare_palette": {
        "body_green": (0.98, 0.78, 0.14, 1.0),
        "body_dark": (0.84, 0.60, 0.08, 1.0),
        "joint_cream": (1.00, 0.92, 0.48, 1.0),
        "blade_white": (0.10, 0.92, 1.00, 1.0),
        "wing_pale": (0.46, 0.96, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.04, 0.44, 0.64, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_mantisblade(
    name: str = "Mantisblade_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de 123. Mantisblade (Ref: Scyther):
      - Abdômen segmentado de louva-deus + cintura esguia creme + tórax blindado verde-esmeralda
      - Cabeça reptiliana/insetoide triangular com 3 cristas pontiagudas no topo e olhos ferozes
      - 4 asas translúcidas alongadas em dois pares nas costas (borda verde na superior)
      - 2 enormes lâminas foice curvas brancas com dorso verde nos antebraços em postura de combate
      - Pernas insetoides musculosas com joelheiras pontiagudas, canelas creme e pés com 3 garras em Z=0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Mtb_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Mtb_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Mtb_Norm"

    parts = []

    # 1. ABDÔMEN SEGMENTADO + CINTURA CREME + TÓRAX BLINDADO
    abdomen_segs = [
        (0.36, (0.0, 0.14, 0.96), (0.94, 1.06, 0.88), "body_green"),
        (0.32, (0.0, 0.24, 0.72), (0.86, 1.04, 0.84), "body_green"),
        (0.24, (0.0, 0.30, 0.54), (0.76, 0.96, 0.82), "body_dark"),
    ]
    for idx, (rad, loc, sc, mkey) in enumerate(abdomen_segs):
        _add_part(
            parts,
            create_icosphere(f"_tmp_abdomen_{idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            mkey,
            pal,
        )
    # Cintura esguia creme conectando abdômen ao tórax
    _add_part(
        parts,
        create_cylinder(
            "_tmp_waist",
            8,
            0.16,
            0.34,
            (0.0, 0.04, 1.24),
            rotation=(math.radians(10.0), 0.0, 0.0),
        ),
        mat_prefix,
        "joint_cream",
        pal,
    )
    # Tórax blindado + peitoral creme
    _add_part(
        parts,
        create_icosphere("_tmp_thorax", 2, 0.36, (0.0, -0.02, 1.56), scale=(0.94, 0.88, 1.12)),
        mat_prefix,
        "body_green",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_chest_plate", 2, 0.24, (0.0, -0.22, 1.54), scale=(0.86, 0.54, 1.08)),
        mat_prefix,
        "joint_cream",
        pal,
    )
    # Pescoço fino
    _add_part(
        parts,
        create_cylinder(
            "_tmp_neck",
            8,
            0.11,
            0.28,
            (0.0, -0.06, 1.92),
            rotation=(math.radians(12.0), 0.0, 0.0),
        ),
        mat_prefix,
        "joint_cream",
        pal,
    )

    # 2. CABEÇA TRIANGULAR COM 3 CRISTAS PONTIAGUDAS + OLHOS FEROZES
    _add_part(
        parts,
        create_icosphere(
            "_tmp_head_main",
            2,
            0.34,
            (0.0, -0.14, 2.22),
            rotation=(math.radians(12.0), 0.0, 0.0),
            scale=(0.94, 1.18, 0.88),
        ),
        mat_prefix,
        "body_green",
        pal,
    )
    # Focinho pontudo reptiliano (-Y)
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            6,
            0.22,
            0.09,
            0.36,
            (0.0, -0.46, 2.12),
            rotation=(math.radians(104.0), 0.0, 0.0),
            scale=(0.96, 0.72, 1.0),
        ),
        mat_prefix,
        "body_green",
        pal,
    )
    # Crista tripla na cabeça (central + 2 laterais)
    _add_part(
        parts,
        create_cone(
            "_tmp_crest_center",
            5,
            0.13,
            0.015,
            0.46,
            (0.0, -0.08, 2.62),
            rotation=(math.radians(-18.0), 0.0, 0.0),
            scale=(0.68, 1.0, 1.0),
        ),
        mat_prefix,
        "body_green",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_crest_side_{tag}",
                5,
                0.13,
                0.015,
                0.44,
                (side * 0.28, -0.06, 2.50),
                rotation=(math.radians(-16.0), math.radians(side * 44.0), 0.0),
                scale=(0.72, 1.0, 1.0),
            ),
            mat_prefix,
            "body_green",
            pal,
        )
        # Olhos ferozes triangulares brancos com pupila escura
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_white_{tag}",
                (0.15, 0.08, 0.11),
                (side * 0.16, -0.44, 2.24),
                rotation=(math.radians(10.0), math.radians(side * -18.0), math.radians(side * -22.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_pupil_{tag}",
                (0.07, 0.06, 0.08),
                (side * 0.15, -0.47, 2.23),
                rotation=(math.radians(10.0), math.radians(side * -18.0), math.radians(side * -22.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # 3. QUATRO ASAS DE INSETO TRANSLÚCIDAS NAS COSTAS (2 PARES EM LEQUE)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Asa superior longa apontando para cima e fora
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_top_{tag}",
                5,
                0.22,
                0.025,
                1.38,
                (side * 0.78, 0.42, 2.18),
                rotation=(math.radians(-26.0), math.radians(side * 46.0), math.radians(side * -16.0)),
                scale=(1.0, 0.22, 1.0),
            ),
            mat_prefix,
            "wing_pale",
            pal,
        )
        # Borda superior verde da asa (detalhe fiel à arte!)
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_edge_{tag}",
                4,
                0.08,
                0.015,
                1.34,
                (side * 0.72, 0.40, 2.28),
                rotation=(math.radians(-26.0), math.radians(side * 44.0), math.radians(side * -16.0)),
                scale=(0.85, 0.30, 1.0),
            ),
            mat_prefix,
            "body_green",
            pal,
        )
        # Asa inferior menor logo abaixo
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_bot_{tag}",
                5,
                0.20,
                0.025,
                1.04,
                (side * 0.76, 0.44, 1.82),
                rotation=(math.radians(-22.0), math.radians(side * 66.0), math.radians(side * -14.0)),
                scale=(1.0, 0.20, 1.0),
            ),
            mat_prefix,
            "wing_pale",
            pal,
        )

    # 4. OMBROS MUSCULOSOS + DUAS ENORMES LÂMINAS FOICE CURVAS BRANCAS/VERDES
    # Braço esquerdo (-X) erguido em corte alto (como na arte!)
    _add_part(
        parts,
        create_icosphere("_tmp_shoulder_L", 2, 0.24, (-0.42, -0.02, 1.66)),
        mat_prefix,
        "body_green",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_L",
            8,
            0.10,
            0.52,
            (-0.62, -0.08, 1.92),
            rotation=(math.radians(10.0), math.radians(-38.0), 0.0),
        ),
        mat_prefix,
        "body_green",
        pal,
    )
    # Foice esquerda erguida: dorso verde + lâmina curva branca em 2 segmentos
    _add_part(
        parts,
        create_cone(
            "_tmp_blade_L_1",
            4,
            0.22,
            0.16,
            0.84,
            (-0.88, -0.18, 2.38),
            rotation=(math.radians(12.0), math.radians(-28.0), math.radians(12.0)),
            scale=(1.0, 0.26, 1.0),
        ),
        mat_prefix,
        "blade_white",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_blade_L_spine1",
            4,
            0.09,
            0.07,
            0.84,
            (-0.80, -0.16, 2.42),
            rotation=(math.radians(12.0), math.radians(-28.0), math.radians(12.0)),
            scale=(1.0, 0.42, 1.0),
        ),
        mat_prefix,
        "body_green",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_blade_L_2",
            4,
            0.17,
            0.02,
            0.78,
            (-1.28, -0.28, 2.74),
            rotation=(math.radians(14.0), math.radians(-62.0), math.radians(14.0)),
            scale=(1.0, 0.24, 1.0),
        ),
        mat_prefix,
        "blade_white",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_blade_L_spine2",
            4,
            0.07,
            0.015,
            0.76,
            (-1.24, -0.26, 2.81),
            rotation=(math.radians(14.0), math.radians(-62.0), math.radians(14.0)),
            scale=(1.0, 0.40, 1.0),
        ),
        mat_prefix,
        "body_green",
        pal,
    )

    # Braço direito (+X) estendido para frente/baixo com foice longa em postura de guarda!
    _add_part(
        parts,
        create_icosphere("_tmp_shoulder_R", 2, 0.24, (0.42, -0.06, 1.62)),
        mat_prefix,
        "body_green",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_R",
            8,
            0.105,
            0.46,
            (0.60, -0.22, 1.54),
            rotation=(math.radians(44.0), math.radians(58.0), 0.0),
        ),
        mat_prefix,
        "body_green",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_wrist_R", 2, 0.13, (0.74, -0.34, 1.44)),
        mat_prefix,
        "body_green",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_blade_R_1",
            4,
            0.22,
            0.17,
            0.84,
            (0.94, -0.42, 1.26),
            rotation=(math.radians(20.0), math.radians(122.0), math.radians(-14.0)),
            scale=(1.0, 0.26, 1.0),
        ),
        mat_prefix,
        "blade_white",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_blade_R_spine1",
            4,
            0.09,
            0.07,
            0.84,
            (0.98, -0.40, 1.34),
            rotation=(math.radians(20.0), math.radians(122.0), math.radians(-14.0)),
            scale=(1.0, 0.42, 1.0),
        ),
        mat_prefix,
        "body_green",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_blade_R_2",
            4,
            0.18,
            0.02,
            0.86,
            (1.18, -0.48, 0.76),
            rotation=(math.radians(14.0), math.radians(168.0), math.radians(-10.0)),
            scale=(1.0, 0.24, 1.0),
        ),
        mat_prefix,
        "blade_white",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_blade_R_spine2",
            4,
            0.07,
            0.015,
            0.84,
            (1.25, -0.46, 0.78),
            rotation=(math.radians(14.0), math.radians(168.0), math.radians(-10.0)),
            scale=(1.0, 0.40, 1.0),
        ),
        mat_prefix,
        "body_green",
        pal,
    )

    # 5. PERNAS INSETOIDES PODEROSAS + JOELHEIRAS PONTIAGUDAS + PÉS COM 3 GARRAS EM Z=0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa blindada verde
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.24,
                (side * 0.46, 0.02, 0.86),
                rotation=(0.0, math.radians(side * -26.0), 0.0),
                scale=(0.88, 0.94, 1.38),
            ),
            mat_prefix,
            "body_green",
            pal,
        )
        # Espinho pontiagudo no joelho
        _add_part(
            parts,
            create_cone(
                f"_tmp_knee_spike_{tag}",
                5,
                0.12,
                0.018,
                0.34,
                (side * 0.56, -0.10, 1.18),
                rotation=(math.radians(16.0), math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "body_green",
            pal,
        )
        # Canela fina creme
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_shin_{tag}",
                8,
                0.08,
                0.42,
                (side * 0.60, -0.02, 0.54),
                rotation=(math.radians(-6.0), math.radians(side * -24.0), 0.0),
            ),
            mat_prefix,
            "joint_cream",
            pal,
        )
        # Pé largo blindado verde tocando o solo
        _add_part(
            parts,
            create_cone(
                f"_tmp_foot_{tag}",
                8,
                0.25,
                0.15,
                0.46,
                (side * 0.72, -0.10, 0.23),
                rotation=(math.radians(14.0), math.radians(side * -14.0), 0.0),
                scale=(1.0, 1.24, 1.0),
            ),
            mat_prefix,
            "body_green",
            pal,
        )
        # 3 garras afiadas brancas na frente de cada pé
        for c_idx, (cx, cy, rz) in enumerate([(-0.15, -0.32, -16.0), (0.0, -0.38, 0.0), (0.15, -0.32, 16.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_claw_{tag}_{c_idx}",
                    4,
                    0.055,
                    0.01,
                    0.22,
                    (side * 0.72 + cx, -0.10 + cy, 0.08),
                    rotation=(math.radians(82.0), 0.0, math.radians(rz)),
                ),
                mat_prefix,
                "blade_white",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 123. Mantisblade lado a lado."""
    specs = [
        ("Mantisblade_Shiny", (-13.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Mantisblade_Normal", (-8.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Mantisblade_Grande", (-2.2, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Mantisblade_Gigante", (5.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Mantisblade_Dourada_SuperRara", (14.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_mantisblade(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
