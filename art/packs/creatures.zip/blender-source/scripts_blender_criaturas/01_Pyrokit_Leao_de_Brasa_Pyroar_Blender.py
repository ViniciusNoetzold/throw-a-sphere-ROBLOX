"""
01_Pyrokit_Leao_de_Brasa_Pyroar_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera o modelo 3D
da criatura "01. Pyrokit — Leão de Brasa (Estilo Pyroar)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere".

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no modelo final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Variações automáticas (`Normal`, `Dourada`, `Enorme / Huge`) geradas lado a lado
  - Base dos pés alinhada exatamente em `Z = 0.0` e frente apontando para `-Y` (pronto para FBX -> Roblox Studio)

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione um modelo (ex: `Pyrokit_Normal`) e exporte via `File > Export > FBX (.fbx)`
     com `Selected Objects` marcado e `Apply Transform` para importar como `MeshPart` no Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "huge_scale": 1.85,
    "palette": {
        "body_dark": (0.21, 0.18, 0.16, 1.0),       # Pelagem torso e coxas marrom-carvão (#362E29)
        "tan_fur": (0.82, 0.67, 0.49, 1.0),         # Face, patas inferiores e ponta da cauda bege-areia (#D1AB7D)
        "mane_red": (0.91, 0.22, 0.12, 1.0),        # Juba principal vermelho-fogo (#E8381F)
        "mane_gold": (0.98, 0.84, 0.18, 1.0),       # Crista em V, abas laterais e faixas douradas (#FAD62E)
        "eyes_cyan": (0.10, 0.78, 0.82, 1.0),       # Olhos azul-turquesa (#1AC7D1)
        "brow_nose_dark": (0.11, 0.09, 0.08, 1.0),  # Máscara dos olhos, pupilas e nariz escuro
    },
    "golden_palette": {
        "body_dark": (0.76, 0.56, 0.12, 1.0),
        "tan_fur": (1.00, 0.90, 0.42, 1.0),
        "mane_red": (1.00, 0.72, 0.08, 1.0),
        "mane_gold": (1.00, 0.96, 0.65, 1.0),
        "eyes_cyan": (0.12, 0.94, 1.00, 1.0),
        "brow_nose_dark": (0.24, 0.16, 0.04, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (ideal para acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, zera a origem na base dos pés (Z = 0.0),
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    # Garante escala e rotação uniformes na malha antes do Bevel
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    # Garante que a base exata das patas toque Z = 0.0 após o Bevel
    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_pyrokit_lion(
    name: str = "Pyrokit_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    is_golden: bool = False,
):
    """
    Constrói o modelo 3D completo do Leão de Brasa (Pyrokit / Pyroar):
      - Frente apontando para -Y
      - Base das 4 patas alinhada em Z = 0.0
      - Juba estrela/chama vermelha com crista em 'V', abas laterais e fitas peitorais douradas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    pal = CONFIG["golden_palette"] if is_golden else CONFIG["palette"]
    mat_prefix = "Mat_Pyrokit_Gold" if is_golden else "Mat_Pyrokit"
    parts = []

    # 1. TORSO E PESCOÇO (Pelagem Marrom-Carvão Escura)
    _add_part(
        parts,
        create_cube("_tmp_chest", (0.96, 0.92, 0.86), (0.0, -0.28, 1.24), (math.radians(8), 0.0, 0.0)),
        mat_prefix,
        "body_dark",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_hips", (0.88, 0.90, 0.80), (0.0, 0.42, 1.18), (math.radians(-5), 0.0, 0.0)),
        mat_prefix,
        "body_dark",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_waist", (0.82, 0.60, 0.72), (0.0, 0.08, 1.16)),
        mat_prefix,
        "body_dark",
        pal,
    )
    # Tufo pontudo na base da cauda sobre o quadril
    _add_part(
        parts,
        create_cone("_tmp_rump_tuft", 4, 0.16, 0.02, 0.34, (0.0, 0.85, 1.54), (math.radians(-22), 0.0, 0.0)),
        mat_prefix,
        "body_dark",
        pal,
    )
    # Pescoço inclinado para frente (-Y)
    _add_part(
        parts,
        create_cone("_tmp_neck", 6, 0.34, 0.28, 0.56, (0.0, -0.76, 1.56), (math.radians(24), 0.0, 0.0)),
        mat_prefix,
        "body_dark",
        pal,
    )

    # 2. CABEÇA, FOCINHO E OLHOS TURQUESA (Frente em -Y)
    _add_part(
        parts,
        create_cube("_tmp_head", (0.74, 0.68, 0.74), (0.0, -1.08, 1.88), (math.radians(6), 0.0, 0.0)),
        mat_prefix,
        "tan_fur",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_jaw", (0.56, 0.54, 0.32), (0.0, -1.14, 1.63)),
        mat_prefix,
        "tan_fur",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout", (0.42, 0.34, 0.28), (0.0, -1.42, 1.72)),
        mat_prefix,
        "tan_fur",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_nose", 4, 0.11, 0.03, 0.14, (0.0, -1.59, 1.80), (math.radians(115), 0.0, 0.0)),
        mat_prefix,
        "brow_nose_dark",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        # Olho azul-turquesa brilhante
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_{side_idx}",
                (0.15, 0.10, 0.15),
                (sx * 0.17, -1.41, 1.88),
                (0.0, math.radians(sx * 10), math.radians(sx * -10)),
            ),
            mat_prefix,
            "eyes_cyan",
            pal,
        )
        # Pupila escura
        _add_part(
            parts,
            create_cube(
                f"_tmp_pupil_{side_idx}",
                (0.06, 0.06, 0.09),
                (sx * 0.16, -1.45, 1.88),
            ),
            mat_prefix,
            "brow_nose_dark",
            pal,
        )
        # Faixa angular escura lateral dos olhos (marca característica do Pyroar)
        _add_part(
            parts,
            create_cube(
                f"_tmp_eyemask_{side_idx}",
                (0.18, 0.13, 0.16),
                (sx * 0.28, -1.36, 1.90),
                (0.0, math.radians(sx * 26), math.radians(sx * -14)),
            ),
            mat_prefix,
            "brow_nose_dark",
            pal,
        )

    # 3. JUBA REAL DE CHAMA (Coroa Vermelha + Crista em 'V', Abas e Fitas Douradas)
    # Volume base da juba ao redor do pescoço e peito
    _add_part(
        parts,
        create_icosphere("_tmp_mane_upper", 1, 0.64, (0.0, -0.84, 1.90), scale=(1.18, 0.68, 1.04)),
        mat_prefix,
        "mane_red",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_mane_chest", 1, 0.60, (0.0, -0.88, 1.32), scale=(1.12, 0.72, 0.98)),
        mat_prefix,
        "mane_red",
        pal,
    )
    # Ponta inferior vermelha da juba entre as patas dianteiras
    _add_part(
        parts,
        create_cone("_tmp_mane_bottom_tip", 4, 0.36, 0.03, 0.56, (0.0, -0.96, 0.84), (math.radians(180), 0.0, math.radians(45))),
        mat_prefix,
        "mane_red",
        pal,
    )

    # Ponta superior central vermelha atrás da crista dourada
    _add_part(
        parts,
        create_cone("_tmp_crown_center_red", 4, 0.32, 0.04, 0.74, (0.0, -0.82, 2.52), (math.radians(-12), 0.0, 0.0), scale=(1.0, 0.55, 1.0)),
        mat_prefix,
        "mane_red",
        pal,
    )

    # Abas laterais de orelha/juba, chifres da coroa, crista em 'V' e fitas peitorais simétricas
    for side_idx, sx in enumerate([-1.0, 1.0]):
        # Pontas superiores laterais vermelhas da coroa
        _add_part(
            parts,
            create_cone(
                f"_tmp_crown_horn_red_{side_idx}",
                4,
                0.28,
                0.04,
                0.80,
                (sx * 0.42, -0.88, 2.54),
                (math.radians(-8), math.radians(sx * 24), 0.0),
                scale=(1.0, 0.50, 1.0),
            ),
            mat_prefix,
            "mane_red",
            pal,
        )
        # Crista frontal em "V" Amarelo-Ouro no topo da testa
        _add_part(
            parts,
            create_cone(
                f"_tmp_crown_v_gold_{side_idx}",
                4,
                0.17,
                0.02,
                0.86,
                (sx * 0.21, -1.14, 2.46),
                (math.radians(-10), math.radians(sx * 26), 0.0),
                scale=(1.0, 0.48, 1.0),
            ),
            mat_prefix,
            "mane_gold",
            pal,
        )
        # Grande aba lateral vermelha (formato orelha/chama arqueada)
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_red_{side_idx}",
                4,
                0.48,
                0.05,
                0.96,
                (sx * 0.78, -0.94, 2.12),
                (0.0, math.radians(sx * 58), 0.0),
                scale=(1.0, 0.42, 1.0),
            ),
            mat_prefix,
            "mane_red",
            pal,
        )
        # Preenchimento interno Amarelo-Ouro da aba lateral
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_gold_{side_idx}",
                4,
                0.32,
                0.04,
                0.72,
                (sx * 0.64, -1.08, 2.04),
                (0.0, math.radians(sx * 62), 0.0),
                scale=(1.0, 0.36, 1.0),
            ),
            mat_prefix,
            "mane_gold",
            pal,
        )
        # Fita/faixa dourada descendo pelo peito (forma de '人')
        _add_part(
            parts,
            create_cone(
                f"_tmp_chest_ribbon_{side_idx}",
                4,
                0.20,
                0.09,
                0.74,
                (sx * 0.28, -1.16, 1.24),
                (math.radians(8), math.radians(sx * -32), 0.0),
                scale=(1.0, 0.44, 1.0),
            ),
            mat_prefix,
            "mane_gold",
            pal,
        )
        # Ponta curvada para fora na base da fita dourada
        _add_part(
            parts,
            create_cone(
                f"_tmp_chest_ribbon_tip_{side_idx}",
                4,
                0.15,
                0.02,
                0.42,
                (sx * 0.56, -1.14, 0.96),
                (0.0, math.radians(sx * 76), 0.0),
                scale=(1.0, 0.40, 1.0),
            ),
            mat_prefix,
            "mane_gold",
            pal,
        )

    # União central da crista em V na testa
    _add_part(
        parts,
        create_cube("_tmp_crown_v_base", (0.20, 0.16, 0.22), (0.0, -1.24, 2.10), (math.radians(-12), 0.0, 0.0)),
        mat_prefix,
        "mane_gold",
        pal,
    )

    # 4. QUATRO PATAS BICOLORES (Coxa Escura + Canela Bege com Recorte Pontudo + Dedos em Z=0)
    # 4A. Patas Dianteiras
    for side_idx, sx in enumerate([-1.0, 1.0]):
        lx = sx * 0.36
        # Coxa/braço superior escuro
        _add_part(
            parts,
            create_cone(f"_tmp_fleg_top_{side_idx}", 6, 0.17, 0.24, 0.68, (lx, -0.54, 0.96)),
            mat_prefix,
            "body_dark",
            pal,
        )
        # Canela inferior bege-areia
        _add_part(
            parts,
            create_cone(f"_tmp_fleg_bot_{side_idx}", 6, 0.14, 0.17, 0.56, (lx, -0.58, 0.40)),
            mat_prefix,
            "tan_fur",
            pal,
        )
        # Pontas de transição zig-zag bege na canela
        _add_part(
            parts,
            create_cone(f"_tmp_fleg_spike_f_{side_idx}", 4, 0.10, 0.02, 0.28, (lx, -0.68, 0.72)),
            mat_prefix,
            "tan_fur",
            pal,
        )
        _add_part(
            parts,
            create_cone(f"_tmp_fleg_spike_s_{side_idx}", 4, 0.09, 0.02, 0.24, (lx + sx * 0.08, -0.56, 0.70)),
            mat_prefix,
            "tan_fur",
            pal,
        )
        # Pata dianteira + 3 dedos tocando Z = 0
        _add_part(
            parts,
            create_cube(f"_tmp_fpaw_{side_idx}", (0.30, 0.34, 0.16), (lx, -0.60, 0.08)),
            mat_prefix,
            "tan_fur",
            pal,
        )
        for toe_i, tx_off in enumerate([-0.095, 0.0, 0.095]):
            _add_part(
                parts,
                create_cube(
                    f"_tmp_ftoe_{side_idx}_{toe_i}",
                    (0.085, 0.14, 0.12),
                    (lx + tx_off, -0.78, 0.06),
                ),
                mat_prefix,
                "tan_fur",
                pal,
            )

    # 4B. Patas Traseiras (com crista alta pontiaguda na coxa como na imagem)
    for side_idx, sx in enumerate([-1.0, 1.0]):
        lx = sx * 0.40
        # Coxa superior escura
        _add_part(
            parts,
            create_cone(f"_tmp_bleg_top_{side_idx}", 6, 0.19, 0.27, 0.76, (lx, 0.64, 0.96), (math.radians(10), 0.0, 0.0)),
            mat_prefix,
            "body_dark",
            pal,
        )
        # Canela inferior bege-areia
        _add_part(
            parts,
            create_cone(f"_tmp_bleg_bot_{side_idx}", 6, 0.14, 0.18, 0.56, (lx, 0.70, 0.40), (math.radians(-6), 0.0, 0.0)),
            mat_prefix,
            "tan_fur",
            pal,
        )
        # Crista alta pontiaguda bege na lateral da coxa traseira (detalhe fiel à imagem)
        _add_part(
            parts,
            create_cone(
                f"_tmp_bleg_crest_main_{side_idx}",
                4,
                0.13,
                0.02,
                0.68,
                (lx + sx * 0.09, 0.62, 0.88),
                (math.radians(10), 0.0, 0.0),
                scale=(0.75, 1.0, 1.0),
            ),
            mat_prefix,
            "tan_fur",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_bleg_crest_sec_{side_idx}",
                4,
                0.10,
                0.02,
                0.44,
                (lx + sx * 0.07, 0.77, 0.76),
                (math.radians(6), 0.0, 0.0),
                scale=(0.75, 1.0, 1.0),
            ),
            mat_prefix,
            "tan_fur",
            pal,
        )
        # Pata traseira + 3 dedos tocando Z = 0
        _add_part(
            parts,
            create_cube(f"_tmp_bpaw_{side_idx}", (0.30, 0.34, 0.16), (lx, 0.68, 0.08)),
            mat_prefix,
            "tan_fur",
            pal,
        )
        for toe_i, tx_off in enumerate([-0.095, 0.0, 0.095]):
            _add_part(
                parts,
                create_cube(
                    f"_tmp_btoe_{side_idx}_{toe_i}",
                    (0.085, 0.14, 0.12),
                    (lx + tx_off, 0.50, 0.06),
                ),
                mat_prefix,
                "tan_fur",
                pal,
            )

    # 5. CAUDA EM CHICOTE SINUOSO COM PONTA BIPARTIDA DE CHAMA
    _add_part(
        parts,
        create_cylinder("_tmp_tail_seg1", 6, 0.085, 0.56, (0.0, 0.98, 1.66), (math.radians(-18), 0.0, 0.0)),
        mat_prefix,
        "body_dark",
        pal,
    )
    _add_part(
        parts,
        create_cylinder("_tmp_tail_seg2", 6, 0.070, 0.54, (0.0, 1.24, 2.02), (math.radians(-52), 0.0, 0.0)),
        mat_prefix,
        "body_dark",
        pal,
    )
    _add_part(
        parts,
        create_cylinder("_tmp_tail_seg3", 6, 0.058, 0.46, (0.0, 1.60, 2.22), (math.radians(-84), 0.0, 0.0)),
        mat_prefix,
        "body_dark",
        pal,
    )
    # Ponta principal curvada da chama da cauda (bege-areia)
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_tip_main",
            4,
            0.18,
            0.02,
            0.66,
            (0.0, 2.02, 1.98),
            (math.radians(-145), 0.0, 0.0),
            scale=(0.65, 1.0, 1.0),
        ),
        mat_prefix,
        "tan_fur",
        pal,
    )
    # Segunda ponta superior menor da cauda bipartida (bege-areia)
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_tip_upper",
            4,
            0.13,
            0.02,
            0.46,
            (0.0, 1.98, 2.38),
            (math.radians(-46), 0.0, 0.0),
            scale=(0.65, 1.0, 1.0),
        ),
        mat_prefix,
        "tan_fur",
        pal,
    )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """Gera lado a lado as versões Normal, Dourada (Mutação 2x) e Enorme (Huge 1.85x)."""
    build_pyrokit_lion("Pyrokit_Normal", location=(0.0, 0.0, 0.0), scale=1.0, is_golden=False)
    build_pyrokit_lion("Pyrokit_Dourado", location=(3.8, 0.0, 0.0), scale=1.0, is_golden=True)
    build_pyrokit_lion("Pyrokit_Huge", location=(-5.0, 0.0, 0.0), scale=CONFIG["huge_scale"], is_golden=False)


if __name__ == "__main__":
    generate_variations()
    print("Pyrokit (Leão de Brasa - Estilo Pyroar) gerado com sucesso! Pronto para exportar em .FBX para o Roblox Studio.")
