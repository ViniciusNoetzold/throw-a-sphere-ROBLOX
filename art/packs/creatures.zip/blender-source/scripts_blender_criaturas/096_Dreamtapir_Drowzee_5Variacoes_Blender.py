"""
096_Dreamtapir_Drowzee_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "096. Dreamtapir — Anta Hipnótica (Ref: Drowzee)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Dreamtapir_Shiny (1.0x - Paleta Shiny Rosa-Chiclete em Cima + Roxo-Ameixa em Baixo)
  2. Dreamtapir_Normal (1.0x - Metade Superior Amarelo-Ouro + Metade Inferior Marrom em Recorte Ondulado)
  3. Dreamtapir_Grande (1.35x - Normal)
  4. Dreamtapir_Gigante (1.85x - Normal)
  5. Dreamtapir_Dourada_SuperRara (2.25x - Ouro Reluzente + Bronze Real + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para corpo bicolor, tromba e patas; cones para dedinhos)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas apoiadas exatamente em `Z = 0.0` e tromba/sorriso apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "upper_yellow": (0.96, 0.82, 0.28, 1.0),
        "upper_shade": (0.82, 0.66, 0.20, 1.0),
        "lower_brown": (0.40, 0.33, 0.29, 1.0),
        "ear_dark": (0.28, 0.22, 0.19, 1.0),
        "mouth_dark": (0.52, 0.30, 0.38, 1.0),
        "tongue_pink": (0.88, 0.56, 0.66, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.10, 0.10, 0.12, 1.0),
    },
    "shiny_palette": {
        "upper_yellow": (0.95, 0.52, 0.74, 1.0),
        "upper_shade": (0.80, 0.38, 0.60, 1.0),
        "lower_brown": (0.50, 0.22, 0.54, 1.0),
        "ear_dark": (0.34, 0.14, 0.38, 1.0),
        "mouth_dark": (0.52, 0.24, 0.40, 1.0),
        "tongue_pink": (0.94, 0.62, 0.76, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.10, 0.08, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "upper_yellow": (0.98, 0.78, 0.14, 1.0),
        "upper_shade": (0.84, 0.62, 0.10, 1.0),
        "lower_brown": (0.64, 0.42, 0.08, 1.0),
        "ear_dark": (0.44, 0.28, 0.06, 1.0),
        "mouth_dark": (0.52, 0.32, 0.06, 1.0),
        "tongue_pink": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.28, 0.42, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_dreamtapir(
    name: str = "Dreamtapir_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 096. Dreamtapir (Ref: Drowzee):
      - Corpo bípede rechonchudo bicolor: metade superior amarela + barriga/pernas marrons
      - Recorte ondulado em zigue-zague ao redor de toda a cintura (assinatura do Drowzee!)
      - Cabeça arredondada com tromba curta caída com vincos, orelhas pequenas marrons internas
      - Olhos sonolentos semicerrados + boca aberta alegre com língua rosa
      - Braços expressivos (esquerdo erguido bem alto, direito estendido) com 3 dedinhos + pés com almofadas amarelas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Dre_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Dre_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Dre_Norm"

    parts = []

    # 1. BARRIGA / METADE INFERIOR RECHONCHUDA MARROM (PERA ORGÂNICA SUAVE)
    _add_part(
        parts,
        create_icosphere("_tmp_belly_brown", 2, 0.80, (0.0, 0.02, 0.78), scale=(1.08, 0.96, 0.90)),
        mat_prefix,
        "lower_brown",
        pal,
    )

    # 2. TORSO SUPERIOR AMARELO + RECORTE ONDULADO BICOLOR RENTE AO CONTORNO DA BARRIGA
    _add_part(
        parts,
        create_icosphere("_tmp_chest_yellow", 2, 0.74, (0.0, 0.02, 1.34), scale=(1.04, 0.92, 0.88)),
        mat_prefix,
        "upper_yellow",
        pal,
    )
    # Lobos ondulados rentes à superfície do corpo (efeito zigue-zague clássico SEM cinto saltado!)
    n_waves = 8
    for i in range(n_waves):
        ang = (2.0 * math.pi * i) / n_waves
        wx = 0.62 * math.sin(ang)
        wy = 0.02 - 0.54 * math.cos(ang)
        # Lobo amarelo descendo suavemente sobre o marrom
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_waist_y_{i}",
                2,
                0.22,
                (wx, wy, 1.04),
                scale=(1.02, 0.92, 0.96),
            ),
            mat_prefix,
            "upper_yellow",
            pal,
        )
        # Lobo marrom subindo rente entre os lobos amarelos
        ang2 = ang + (math.pi / n_waves)
        bx = 0.64 * math.sin(ang2)
        by = 0.02 - 0.56 * math.cos(ang2)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_waist_b_{i}",
                2,
                0.22,
                (bx, by, 1.00),
                scale=(1.02, 0.92, 0.94),
            ),
            mat_prefix,
            "lower_brown",
            pal,
        )

    # 3. CABEÇA ARREDONDADA + TROMBA CAÍDA DE ANTA COM VINCOS + ORELHINHAS
    _add_part(
        parts,
        create_icosphere("_tmp_head_main", 2, 0.56, (0.0, -0.08, 1.94), scale=(1.02, 1.08, 0.94)),
        mat_prefix,
        "upper_yellow",
        pal,
    )
    # Tromba curta caída curvando para frente e para baixo
    trunk_segs = [
        (0.32, (0.0, -0.52, 1.92), (0.94, 1.04, 0.88), 18.0),
        (0.28, (0.0, -0.76, 1.82), (0.90, 0.96, 0.84), 40.0),
        (0.23, (0.0, -0.88, 1.66), (0.88, 0.84, 0.84), 68.0),
    ]
    for t_idx, (rad, loc, sc, rx_deg) in enumerate(trunk_segs):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_trunk_{t_idx}",
                2,
                rad,
                loc,
                rotation=(math.radians(rx_deg), 0.0, 0.0),
                scale=sc,
            ),
            mat_prefix,
            "upper_yellow",
            pal,
        )
    # 2 vincos transversais escuros no dorso da tromba
    for r_idx, (ry_pos, rz_pos, rw) in enumerate([(-0.62, 2.04, 0.42), (-0.78, 1.92, 0.36)]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_trunk_crease_{r_idx}",
                (rw, 0.05, 0.045),
                (0.0, ry_pos, rz_pos),
                rotation=(math.radians(28.0 + r_idx * 18.0), 0.0, 0.0),
            ),
            mat_prefix,
            "upper_shade",
            pal,
        )

    # Orelhas pequenas arredondadas nas laterais da cabeça com interior marrom
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ear_outer_{tag}",
                1,
                0.20,
                (side * 0.54, 0.04, 2.18),
                rotation=(0.0, math.radians(side * 34.0), math.radians(side * -14.0)),
                scale=(0.82, 0.56, 1.18),
            ),
            mat_prefix,
            "upper_yellow",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ear_inner_{tag}",
                1,
                0.13,
                (side * 0.54, -0.02, 2.16),
                rotation=(0.0, math.radians(side * 34.0), math.radians(side * -14.0)),
                scale=(0.76, 0.44, 1.06),
            ),
            mat_prefix,
            "ear_dark",
            pal,
        )

    # 4. OLHOS SONOLENTOS SEMICERRADOS + BOCA ABERTA COM LÍNGUA ROSA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.14,
                (side * 0.32, -0.52, 2.02),
                rotation=(0.0, math.radians(side * 16.0), math.radians(side * -24.0)),
                scale=(1.18, 0.44, 0.54),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pálpebra superior caída sonolenta
        _add_part(
            parts,
            create_cube(
                f"_tmp_eyelid_{tag}",
                (0.32, 0.14, 0.08),
                (side * 0.32, -0.53, 2.09),
                rotation=(0.0, math.radians(side * 14.0), math.radians(side * -18.0)),
            ),
            mat_prefix,
            "upper_yellow",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.036,
                (side * 0.33, -0.58, 2.02),
                scale=(0.82, 0.50, 0.90),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # Boca aberta sorridente sob a tromba + língua rosa
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_open",
            2,
            0.22,
            (0.0, -0.54, 1.66),
            rotation=(math.radians(16.0), 0.0, 0.0),
            scale=(1.18, 0.56, 0.86),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tongue",
            1,
            0.16,
            (0.0, -0.59, 1.58),
            scale=(1.08, 0.50, 0.60),
        ),
        mat_prefix,
        "tongue_pink",
        pal,
    )

    # 5. BRAÇOS EXPRESSIVOS (ESQUERDO ERGUIDO BEM ALTO + DIREITO ESTENDIDO) COM 3 DEDINHOS
    # Braço esquerdo levantado alto (pose clássica da referência!)
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_L",
            8,
            0.26,
            0.19,
            0.88,
            (-0.78, -0.06, 1.92),
            rotation=(math.radians(-6.0), math.radians(-16.0), 0.0),
        ),
        mat_prefix,
        "upper_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hand_L", 2, 0.20, (-0.88, -0.08, 2.34), scale=(1.02, 0.78, 0.96)),
        mat_prefix,
        "upper_yellow",
        pal,
    )
    for f_idx, (dx, dz, rot_y) in enumerate([(-0.14, 0.16, -34.0), (0.0, 0.22, -6.0), (0.14, 0.14, 24.0)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_finger_L_{f_idx}",
                5,
                0.064,
                0.016,
                0.24,
                (-0.88 + dx, -0.08, 2.34 + dz),
                rotation=(0.0, math.radians(rot_y), 0.0),
            ),
            mat_prefix,
            "upper_yellow",
            pal,
        )

    # Braço direito estendido para frente-lado (mexendo os dedos hipnóticos)
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R",
            8,
            0.25,
            0.18,
            0.78,
            (0.86, -0.14, 1.54),
            rotation=(math.radians(-14.0), math.radians(66.0), 0.0),
        ),
        mat_prefix,
        "upper_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hand_R", 2, 0.19, (1.18, -0.22, 1.66), scale=(1.04, 0.78, 0.94)),
        mat_prefix,
        "upper_yellow",
        pal,
    )
    for f_idx, (dx, dz, rot_y) in enumerate([(0.16, 0.14, 42.0), (0.20, 0.0, 82.0), (0.14, -0.14, 118.0)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_finger_R_{f_idx}",
                5,
                0.062,
                0.016,
                0.24,
                (1.18 + dx, -0.22, 1.66 + dz),
                rotation=(0.0, math.radians(rot_y), 0.0),
            ),
            mat_prefix,
            "upper_yellow",
            pal,
        )

    # 6. PERNAS GROSSAS MARRONS COM ALMOFADAS DE DEDOS AMARELAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_{tag}",
                8,
                0.24,
                0.38,
                0.68,
                (side * 0.56, -0.02, 0.36),
                rotation=(math.radians(6.0), math.radians(side * -14.0), 0.0),
                scale=(1.04, 1.10, 1.0),
            ),
            mat_prefix,
            "lower_brown",
            pal,
        )
        # Almofada frontal amarela dos pés (detalhe clássico do Drowzee!)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_pad_{tag}",
                2,
                0.22,
                (side * 0.62, -0.16, 0.11),
                scale=(1.08, 1.12, 0.56),
            ),
            mat_prefix,
            "upper_yellow",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 096. Dreamtapir lado a lado."""
    specs = [
        ("Dreamtapir_Shiny", (-10.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Dreamtapir_Normal", (-6.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Dreamtapir_Grande", (-1.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Dreamtapir_Gigante", (4.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Dreamtapir_Dourada_SuperRara", (11.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_dreamtapir(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
