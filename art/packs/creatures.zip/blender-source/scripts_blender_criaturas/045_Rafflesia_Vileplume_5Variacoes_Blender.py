"""
045_Rafflesia_Vileplume_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "045. Rafflesia — Flor Gigante (Ref: Vileplume)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Rafflesia_Shiny (1.0x - Corpo Verde-Folha + Flor Laranja-Coral com Manchas Amarelo-Creme)
  2. Rafflesia_Normal (1.0x - Corpo Azul-Índigo + Flor Gigante Vermelho-Rosa com Manchas Brancas e Miolo Ocre)
  3. Rafflesia_Grande (1.35x - Normal)
  4. Rafflesia_Gigante (1.85x - Normal)
  5. Rafflesia_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Manchas e Miolo Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para pétalas volumosas e corpo rechonchudo)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.31, 0.39, 0.56, 1.0),
        "body_shade": (0.23, 0.30, 0.45, 1.0),
        "petal_red": (0.85, 0.34, 0.44, 1.0),
        "petal_deep": (0.72, 0.24, 0.34, 1.0),
        "spot_white": (0.97, 0.93, 0.95, 1.0),
        "bud_ochre": (0.86, 0.58, 0.33, 1.0),
        "bud_hollow": (0.18, 0.15, 0.14, 1.0),
        "bud_inner": (0.68, 0.45, 0.28, 1.0),
        "eye_red": (0.94, 0.38, 0.36, 1.0),
        "dark_line": (0.12, 0.14, 0.19, 1.0),
        "shine_white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.42, 0.67, 0.36, 1.0),
        "body_shade": (0.31, 0.52, 0.26, 1.0),
        "petal_red": (0.92, 0.55, 0.24, 1.0),
        "petal_deep": (0.78, 0.42, 0.16, 1.0),
        "spot_white": (0.98, 0.94, 0.70, 1.0),
        "bud_ochre": (0.68, 0.80, 0.26, 1.0),
        "bud_hollow": (0.20, 0.22, 0.12, 1.0),
        "bud_inner": (0.52, 0.64, 0.20, 1.0),
        "eye_red": (0.96, 0.34, 0.22, 1.0),
        "dark_line": (0.12, 0.18, 0.12, 1.0),
        "shine_white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.92, 0.70, 0.12, 1.0),
        "body_shade": (0.78, 0.56, 0.08, 1.0),
        "petal_red": (0.98, 0.78, 0.14, 1.0),
        "petal_deep": (0.86, 0.64, 0.10, 1.0),
        "spot_white": (0.10, 0.92, 1.00, 1.0),
        "bud_ochre": (1.00, 0.88, 0.36, 1.0),
        "bud_hollow": (0.06, 0.48, 0.64, 1.0),
        "bud_inner": (0.10, 0.92, 1.00, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
        "dark_line": (0.52, 0.36, 0.06, 1.0),
        "shine_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _rot_point_xyz(p: tuple, rx: float, ry: float, rz: float):
    """Rotaciona ponto 3D usando Euler XYZ (igual ao Blender)."""
    x, y, z = p
    cx, sx = math.cos(rx), math.sin(rx)
    y, z = y * cx - z * sx, y * sx + z * cx
    cy, sy = math.cos(ry), math.sin(ry)
    x, z = x * cy + z * sy, -x * sy + z * cy
    cz, sz = math.cos(rz), math.sin(rz)
    x, y = x * cz - y * sz, x * sz + y * cz
    return (x, y, z)


def build_rafflesia(
    name: str = "Rafflesia_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 045. Rafflesia (Ref: Vileplume):
      - Corpo arredondado em formato de gota/pêra azul-índigo apoiado em 2 pés ovais achatados
      - Bracinhos curtos arredondados abertos nas laterais
      - Rosto doce sob a borda da flor: olhinhos rubi redondos e sorriso curvo
      - Flor gigante de 5 pétalas grossas e rechonchudas inclinada levemente para frente/esquerda
        para exibir todas as manchas brancas e o miolo ocre elevado com cavidade escura
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Raff_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Raff_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Raff_Norm"

    parts = []

    # 1. CORPO ARREDONDADO AZUL-ÍNDIGO (PERFIL DE PÊRA FOFO DA REFERÊNCIA)
    _add_part(
        parts,
        create_icosphere("_tmp_body_low", 2, 0.64, (0.0, 0.0, 0.68), scale=(1.04, 0.96, 0.88)),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_body_head", 2, 0.56, (0.0, -0.02, 1.06), scale=(0.94, 0.90, 0.84)),
        mat_prefix,
        "body_blue",
        pal,
    )

    # 2. PATINHAS OVAIS ABERTAS PARA OS LADOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ankle_{tag}",
                6,
                0.13,
                0.17,
                0.24,
                (side * 0.30, 0.0, 0.19),
                rotation=(0.0, math.radians(side * -16.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.22,
                (side * 0.44, -0.08, 0.08),
                rotation=(0.0, 0.0, math.radians(side * -30.0)),
                scale=(1.36, 0.72, 0.42),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    # 3. BRACINHOS CURTOS RECHONCHUDOS ABERTOS PARA AS LATERAIS
    arm_specs = [
        ("L", -1.0, (-0.76, -0.04, 0.74), (-0.94, -0.08, 0.70), -102.0),
        ("R", 1.0, (0.76, -0.04, 0.78), (0.94, -0.08, 0.78), 92.0),
    ]
    for tag, side, a_loc, h_loc, rot_y in arm_specs:
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_{tag}",
                8,
                0.16,
                0.11,
                0.42,
                a_loc,
                rotation=(math.radians(-6.0), math.radians(rot_y), 0.0),
                scale=(1.0, 0.82, 1.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hand_{tag}",
                2,
                0.12,
                h_loc,
                scale=(1.15, 0.82, 0.86),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    # 4. ROSTO SIMPÁTICO SOB A BORDA DA FLOR (OLHINHOS RUBI + SORRISO CURVO)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_ring_{tag}",
                1,
                0.068,
                (side * 0.22, -0.52, 0.98),
                scale=(0.95, 0.45, 0.95),
            ),
            mat_prefix,
            "dark_line",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                1,
                0.054,
                (side * 0.22, -0.545, 0.98),
                scale=(0.92, 0.48, 0.92),
            ),
            mat_prefix,
            "eye_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.020,
                (side * 0.21, -0.57, 1.00),
                scale=(0.8, 0.5, 0.8),
            ),
            mat_prefix,
            "shine_white",
            pal,
        )

    # Sorriso curvo fofo feito com 3 pequenos segmentos escuros
    smile_pts = [
        (-0.10, -0.57, 0.87, 24.0),
        (0.0, -0.59, 0.84, 0.0),
        (0.10, -0.57, 0.87, -24.0),
    ]
    for s_idx, (sx, sy, sz, ry_deg) in enumerate(smile_pts):
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_smile_{s_idx}",
                6,
                0.022,
                0.11,
                (sx, sy, sz),
                rotation=(0.0, math.radians(90.0 + ry_deg), 0.0),
            ),
            mat_prefix,
            "dark_line",
            pal,
        )

    # 5. FLOR GIGANTE DE 5 PÉTALAS VOLUMOSAS + MANCHAS BRANCAS + MIOLO OCRE
    # Inclinada para frente (-Y) com rx POSITIVO (+28°) e altura ajustada para mostrar
    # tanto os 2 olhinhos rubi + sorriso quanto todas as pétalas, manchas e o miolo ocre!
    flower_center = (0.0, 0.16, 1.78)
    f_rx = math.radians(28.0)
    f_ry = math.radians(-8.0)

    def flower_world(local_pt):
        rp = _rot_point_xyz(local_pt, f_rx, f_ry, 0.0)
        return (
            flower_center[0] + rp[0],
            flower_center[1] + rp[1],
            flower_center[2] + rp[2],
        )

    # Base de encaixe da flor no topo da cabeça (evita qualquer vão)
    _add_part(
        parts,
        create_cone(
            "_tmp_flower_neck",
            8,
            0.46,
            0.34,
            0.44,
            (0.0, 0.06, 1.48),
            rotation=(math.radians(16.0), f_ry, 0.0),
        ),
        mat_prefix,
        "petal_deep",
        pal,
    )

    # 5 pétalas enormes distribuídas radialmente a cada 72 graus
    petal_angles_deg = [-122.0, -50.0, 22.0, 94.0, 166.0]
    for p_idx, ang_deg in enumerate(petal_angles_deg):
        ang = math.radians(ang_deg)
        dist = 0.78
        lx = math.cos(ang) * dist
        ly = math.sin(ang) * dist
        lz = -0.02

        p_pos = flower_world((lx, ly, lz))
        petal_obj = create_icosphere(
            f"_tmp_petal_{p_idx}",
            2,
            0.66,
            (0.0, 0.0, 0.0),
            rotation=(0.0, 0.0, ang),
            scale=(1.12, 0.88, 0.34),
        )
        bpy.context.view_layer.objects.active = petal_obj
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
        petal_obj.rotation_euler = (f_rx, f_ry, 0.0)
        petal_obj.location = p_pos
        _add_part(parts, petal_obj, mat_prefix, "petal_red", pal)

        # 5 manchas brancas ovais bem nítidas sobre a face superior de cada pétala
        spot_specs = [
            (0.56, 0.02, 0.21, 0.16, 0.12),
            (0.92, 0.24, 0.19, 0.15, 0.11),
            (0.98, -0.22, 0.19, 0.14, 0.10),
            (1.18, 0.06, 0.15, 0.12, 0.09),
            (0.66, -0.32, 0.17, 0.11, 0.08),
        ]
        for s_i, (r_d, t_off, z_up, sx_s, sy_s) in enumerate(spot_specs):
            slx = math.cos(ang) * r_d - math.sin(ang) * t_off
            sly = math.sin(ang) * r_d + math.cos(ang) * t_off
            slz = lz + z_up
            spot_obj = create_icosphere(
                f"_tmp_spot_{p_idx}_{s_i}",
                1,
                1.0,
                (0.0, 0.0, 0.0),
                rotation=(0.0, 0.0, ang),
                scale=(sx_s, sy_s, 0.065),
            )
            bpy.context.view_layer.objects.active = spot_obj
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
            spot_obj.rotation_euler = (f_rx, f_ry, 0.0)
            spot_obj.location = flower_world((slx, sly, slz))
            _add_part(parts, spot_obj, mat_prefix, "spot_white", pal)

    # 6. MIOLO CENTRAL OCRE ELEVADO COM ABERTURA PROFUNDA
    bud_loc = flower_world((0.0, 0.0, 0.22))
    _add_part(
        parts,
        create_cone(
            "_tmp_bud_outer",
            10,
            0.40,
            0.35,
            0.34,
            bud_loc,
            rotation=(f_rx, f_ry, 0.0),
            scale=(1.04, 0.96, 1.0),
        ),
        mat_prefix,
        "bud_ochre",
        pal,
    )
    # Aro arredondado no topo do miolo
    bud_rim_loc = flower_world((0.0, 0.0, 0.34))
    _add_part(
        parts,
        create_icosphere(
            "_tmp_bud_rim",
            2,
            0.36,
            bud_rim_loc,
            rotation=(f_rx, f_ry, 0.0),
            scale=(1.04, 0.96, 0.36),
        ),
        mat_prefix,
        "bud_ochre",
        pal,
    )
    # Borda escura da cavidade do miolo
    bud_dark_loc = flower_world((0.0, 0.0, 0.42))
    _add_part(
        parts,
        create_cylinder(
            "_tmp_bud_dark",
            10,
            0.25,
            0.09,
            bud_dark_loc,
            rotation=(f_rx, f_ry, 0.0),
            scale=(1.04, 0.94, 1.0),
        ),
        mat_prefix,
        "bud_hollow",
        pal,
    )
    # Fundo ocre mais claro dentro da cavidade
    bud_in_loc = flower_world((0.0, 0.0, 0.445))
    _add_part(
        parts,
        create_cylinder(
            "_tmp_bud_inner",
            8,
            0.16,
            0.06,
            bud_in_loc,
            rotation=(f_rx, f_ry, 0.0),
            scale=(1.04, 0.92, 1.0),
        ),
        mat_prefix,
        "bud_inner",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 045. Rafflesia lado a lado sem sobreposição."""
    specs = [
        ("Rafflesia_Shiny", (-11.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Rafflesia_Normal", (-7.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Rafflesia_Grande", (-2.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Rafflesia_Gigante", (3.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Rafflesia_Dourada_SuperRara", (10.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_rafflesia(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
