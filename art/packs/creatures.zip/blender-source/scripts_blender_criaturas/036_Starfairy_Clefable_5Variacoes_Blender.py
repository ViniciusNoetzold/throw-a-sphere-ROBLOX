"""
036_Starfairy_Clefable_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "036. Starfairy — Guardiã Estelar (Ref: Clefable)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Starfairy_Shiny (1.0x - Paleta Shiny Rosa-Pêssego + Pontas das Orelhas Verde-Menta)
  2. Starfairy_Normal (1.0x - Rosa-Claro + Pontas das Orelhas Marrom + Asas 3 Pontas)
  3. Starfairy_Grande (1.35x - Normal)
  4. Starfairy_Gigante (1.85x - Normal)
  5. Starfairy_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Pontas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para silhueta suave e cones 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_pink": (0.98, 0.80, 0.84, 1.0),
        "body_shade": (0.86, 0.66, 0.72, 1.0),
        "wing_pink": (0.86, 0.56, 0.68, 1.0),
        "ear_tip": (0.36, 0.25, 0.22, 1.0),
        "ear_dark": (0.18, 0.14, 0.14, 1.0),
        "mouth_pink": (0.88, 0.50, 0.64, 1.0),
        "eye_dark": (0.12, 0.12, 0.18, 1.0),
        "eye_iris": (0.46, 0.36, 0.56, 1.0),
        "claw_white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_pink": (0.99, 0.84, 0.86, 1.0),
        "body_shade": (0.88, 0.70, 0.74, 1.0),
        "wing_pink": (0.90, 0.68, 0.78, 1.0),
        "ear_tip": (0.30, 0.86, 0.50, 1.0),
        "ear_dark": (0.16, 0.56, 0.32, 1.0),
        "mouth_pink": (0.90, 0.52, 0.66, 1.0),
        "eye_dark": (0.12, 0.12, 0.18, 1.0),
        "eye_iris": (0.36, 0.58, 0.48, 1.0),
        "claw_white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_pink": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.86, 0.62, 0.10, 1.0),
        "wing_pink": (1.00, 0.88, 0.36, 1.0),
        "ear_tip": (0.10, 0.92, 1.00, 1.0),
        "ear_dark": (0.06, 0.56, 0.72, 1.0),
        "mouth_pink": (0.82, 0.48, 0.08, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "eye_iris": (0.58, 0.98, 1.00, 1.0),
        "claw_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_starfairy(
    name: str = "Starfairy_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de alta fidelidade do 036. Starfairy (Ref: Clefable):
      - Corpo fada mais alto e esguio-rechonchudo em formato pera suave
      - Orelhas bem longas e pontiagudas com pontas marrom-escuras (verde-menta na Shiny)
      - Topete em espiral limpa no centro superior da cabeça
      - Asas de fada icônicas de 3 pontas serrilhadas em cada lado das costas
      - Braços erguidos alegres com mãozinhas de 3 dedos em estrela
      - Rosto gentil com olhinhos ovais verticais, risquinhos sorridentes e boca feliz
      - Cauda grande enrolada aparecendo na lateral direita e pezinhos com 2 unhas brancas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Starfairy_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Starfairy_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Starfairy_Norm"

    parts = []

    # 1. CORPO UNIFICADO EM FORMATO ESTRELA-PERA (MAIS ALTO QUE CLEFAIRY)
    _add_part(
        parts,
        create_icosphere("_tmp_body_upper", 2, 0.86, (0.0, 0.02, 1.24), scale=(0.98, 0.84, 1.12)),
        mat_prefix,
        "body_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_body_lower", 2, 0.84, (0.0, -0.02, 0.84), scale=(1.06, 0.88, 0.88)),
        mat_prefix,
        "body_pink",
        pal,
    )

    # 2. TOPETE ESPIRALADO NO TOPO DA TESTA
    curl_spheres = [
        (0.32, (0.02, -0.22, 2.08), (1.06, 0.86, 1.00)),
        (0.27, (-0.18, -0.32, 2.00), (0.98, 0.84, 1.00)),
        (0.23, (-0.10, -0.44, 1.84), (1.02, 0.82, 0.92)),
        (0.21, (0.10, -0.46, 1.82), (1.02, 0.82, 0.92)),
        (0.17, (0.14, -0.48, 1.96), (0.94, 0.78, 0.94)),
        (0.12, (0.02, -0.52, 1.98), (0.92, 0.76, 0.90)),
    ]
    for idx, (rad, loc, sc) in enumerate(curl_spheres):
        _add_part(
            parts,
            create_icosphere(f"_tmp_curl_{idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "body_pink",
            pal,
        )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_curl_shade",
            8,
            0.08,
            0.06,
            (0.02, -0.60, 1.94),
            rotation=(math.radians(90.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    # 3. ORELHAS LONGAS E PONTIAGUDAS COM PONTAS MARRONS (VERDE-MENTA NA SHINY)
    ear_specs = [
        ("L", -1.0, -6.0, -44.0, (-0.74, 0.0, 1.96), (-1.14, 0.0, 2.38)),
        ("R", 1.0, 8.0, 62.0, (0.80, 0.0, 1.90), (1.30, 0.0, 2.16)),
    ]
    for tag, side, rz_deg, ry_deg, b_loc, t_loc in ear_specs:
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_base_{tag}",
                6,
                0.38,
                0.19,
                0.80,
                b_loc,
                rotation=(math.radians(-6.0), math.radians(ry_deg), math.radians(rz_deg)),
                scale=(1.0, 0.54, 1.0),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_tip_{tag}",
                6,
                0.195,
                0.022,
                0.46,
                t_loc,
                rotation=(math.radians(-6.0), math.radians(ry_deg), math.radians(rz_deg)),
                scale=(1.0, 0.52, 1.0),
            ),
            mat_prefix,
            "ear_tip",
            pal,
        )

    # 4. ASAS DE FADA DE 3 PONTAS SERRILHADAS NAS COSTAS (ASSINATURA DA CLEFABLE)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        wing_blades = [
            # (z_pos, x_pos, depth, r1, ry_deg)
            (1.66, side * 1.12, 1.08, 0.24, side * 52.0),
            (1.38, side * 1.24, 1.14, 0.24, side * 72.0),
            (1.10, side * 1.10, 0.96, 0.21, side * 90.0),
        ]
        for w_idx, (wz, wx, wd, wr, wry) in enumerate(wing_blades):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_wing_{tag}_{w_idx}",
                    6,
                    wr,
                    0.022,
                    wd,
                    (wx, 0.34, wz),
                    rotation=(math.radians(8.0), math.radians(wry), math.radians(side * -10.0)),
                    scale=(1.0, 0.30, 1.0),
                ),
                mat_prefix,
                "wing_pink",
                pal,
            )
        # Base conectora das asas nas costas
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_wing_root_{tag}",
                1,
                0.34,
                (side * 0.64, 0.36, 1.38),
                scale=(0.86, 0.42, 1.35),
            ),
            mat_prefix,
            "wing_pink",
            pal,
        )

    # 5. ROSTO GENTIL (OLHOS OVAIS VERTICAIS + MARQUINHAS SORRIDENTES + BOCA FELIZ)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.092,
                (side * 0.20, -0.71, 1.56),
                scale=(0.56, 0.42, 1.25),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.052,
                (side * 0.20, -0.74, 1.51),
                scale=(0.55, 0.36, 0.82),
            ),
            mat_prefix,
            "eye_iris",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.036,
                (side * 0.19, -0.75, 1.61),
                scale=(0.72, 0.48, 1.05),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )
        # Risquinho curvo delicado ao lado de cada olho como na arte oficial
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_cheek_mark_{tag}",
                1,
                0.045,
                (side * 0.34, -0.68, 1.54),
                scale=(0.35, 0.30, 1.55),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )

    # Sorriso rosa suave
    _add_part(
        parts,
        create_icosphere(
            "_tmp_smile",
            1,
            0.13,
            (0.0, -0.75, 1.36),
            scale=(1.26, 0.36, 0.48),
        ),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # 6. BRAÇOS ERGUIDOS COM MÃOZINHAS DE 3 DEDOS EM ESTRELA
    # Braço esquerdo erguido alegremente
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_L",
            8,
            0.27,
            0.19,
            0.78,
            (-0.90, -0.14, 1.44),
            rotation=(math.radians(-14.0), math.radians(-46.0), 0.0),
        ),
        mat_prefix,
        "body_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hand_L", 2, 0.20, (-1.16, -0.22, 1.70)),
        mat_prefix,
        "body_pink",
        pal,
    )
    for f_idx, (dx, dz, ry) in enumerate([(-0.15, 0.10, -68.0), (-0.04, 0.18, -22.0), (0.10, 0.12, 24.0)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_finger_L_{f_idx}",
                5,
                0.068,
                0.018,
                0.18,
                (-1.16 + dx, -0.24, 1.70 + dz),
                rotation=(0.0, math.radians(ry), 0.0),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )

    # Braço direito aberto para o lado
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R",
            8,
            0.27,
            0.19,
            0.74,
            (0.94, -0.12, 1.24),
            rotation=(math.radians(-10.0), math.radians(70.0), 0.0),
        ),
        mat_prefix,
        "body_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hand_R", 2, 0.20, (1.26, -0.18, 1.34)),
        mat_prefix,
        "body_pink",
        pal,
    )
    for f_idx, (dx, dz, ry) in enumerate([(0.06, 0.15, 36.0), (0.16, 0.06, 76.0), (0.12, -0.09, 118.0)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_finger_R_{f_idx}",
                5,
                0.068,
                0.018,
                0.18,
                (1.26 + dx, -0.20, 1.34 + dz),
                rotation=(0.0, math.radians(ry), 0.0),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )

    # 7. PERNINHAS CURTAS E GROSSAS COM 2 UNHAS BRANCAS EM CADA PÉ (Z = 0.0)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_{tag}",
                8,
                0.22,
                0.34,
                0.48,
                (side * 0.44, -0.04, 0.24),
                rotation=(math.radians(6.0), math.radians(side * -12.0), 0.0),
                scale=(1.0, 1.12, 1.0),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        for n_idx, nx_off in enumerate((-0.075, 0.075)):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_nail_{tag}_{n_idx}",
                    1,
                    0.095,
                    (side * 0.44 + nx_off, -0.24, 0.08),
                    scale=(0.95, 0.92, 0.56),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 8. CAUDA GRANDE ENROLADA EM ESPIRAL NA TRASEIRA DIREITA
    tail_nodes = [
        (0.36, (0.42, 0.54, 0.54), (0.98, 1.00, 1.02)),
        (0.35, (0.82, 0.42, 0.58), (0.94, 0.96, 1.06)),
        (0.32, (1.02, 0.28, 0.80), (0.90, 0.92, 1.02)),
        (0.26, (0.88, 0.28, 1.00), (0.88, 0.88, 0.94)),
        (0.20, (0.72, 0.30, 0.92), (0.84, 0.84, 0.88)),
    ]
    for t_idx, (rad, loc, sc) in enumerate(tail_nodes):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tail_{t_idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "body_pink",
            pal,
        )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_tail_spiral",
            8,
            0.13,
            0.08,
            (0.96, 0.24, 0.78),
            rotation=(math.radians(90.0), 0.0, math.radians(32.0)),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 036. Starfairy lado a lado."""
    specs = [
        ("Starfairy_Shiny", (-9.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Starfairy_Normal", (-5.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Starfairy_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Starfairy_Gigante", (5.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Starfairy_Dourada_SuperRara", (12.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_starfairy(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
