"""
049_Dustwing_Venomoth_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "049. Dustwing — Mariposa Pólen (Ref: Venomoth)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Dustwing_Shiny (1.0x - Corpo Azul-Safira + Asas Azul-Gelo com Nervuras Azul-Real)
  2. Dustwing_Normal (1.0x - Corpo Lavanda + Crista Tripla + Abdômen com Zigue-Zague + 4 Asas Largas Lilás)
  3. Dustwing_Grande (1.35x - Normal)
  4. Dustwing_Gigante (1.85x - Normal)
  5. Dustwing_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Nervuras e Crista Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (asas amplas em camadas, nervuras, crista tripla e faixas no abdômen)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base alinhada em `Z = 0.0`, rosto apontando para `-Y` e espaçamento amplo para envergadura total
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "head_lav": (0.58, 0.54, 0.76, 1.0),
        "abdomen_gray": (0.74, 0.70, 0.78, 1.0),
        "wing_pale": (0.86, 0.80, 0.93, 1.0),
        "wing_mid": (0.72, 0.64, 0.84, 1.0),
        "vein_dark": (0.44, 0.36, 0.56, 1.0),
        "rib_cream": (0.94, 0.92, 0.88, 1.0),
        "eye_ice": (0.84, 0.92, 0.99, 1.0),
        "pupil_dark": (0.10, 0.11, 0.15, 1.0),
        "white_pure": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "head_lav": (0.30, 0.56, 0.88, 1.0),
        "abdomen_gray": (0.64, 0.78, 0.90, 1.0),
        "wing_pale": (0.72, 0.88, 0.99, 1.0),
        "wing_mid": (0.46, 0.72, 0.94, 1.0),
        "vein_dark": (0.22, 0.44, 0.76, 1.0),
        "rib_cream": (0.94, 0.96, 0.98, 1.0),
        "eye_ice": (0.88, 0.95, 1.00, 1.0),
        "pupil_dark": (0.08, 0.12, 0.20, 1.0),
        "white_pure": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "head_lav": (0.98, 0.78, 0.14, 1.0),
        "abdomen_gray": (0.88, 0.66, 0.10, 1.0),
        "wing_pale": (1.00, 0.86, 0.28, 1.0),
        "wing_mid": (0.92, 0.70, 0.12, 1.0),
        "vein_dark": (0.10, 0.92, 1.00, 1.0),
        "rib_cream": (1.00, 0.96, 0.74, 1.0),
        "eye_ice": (1.00, 0.99, 0.92, 1.0),
        "pupil_dark": (0.10, 0.92, 1.00, 1.0),
        "white_pure": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_dustwing(
    name: str = "Dustwing_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 049. Dustwing (Ref: Venomoth):
      - Cabeça lavanda esbelta com crista tripla pontiaguda no topo (chifre central mais alto + 2 laterais)
      - Olhos grandes azul-gelo com pupilas escuras e brilho branco + 2 presinhas brancas
      - Peitoral com 3 pares de patinhas/costelas creme recolhidas junto ao tronco
      - Abdômen oval lavanda-cinza com faixas escuras horizontais em zigue-zague
      - 4 asas amplas de mariposa (2 grandes superiores em V elevado com nervuras + 2 inferiores com lóbulo)
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Dust_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Dust_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Dust_Norm"

    parts = []

    # 1. ABDÔMEN OVAL SEGMENTADO + FAIXAS ESCURAS
    _add_part(
        parts,
        create_icosphere(
            "_tmp_abdomen",
            2,
            0.46,
            (0.0, 0.22, 0.62),
            rotation=(math.radians(26.0), 0.0, 0.0),
            scale=(0.86, 0.92, 1.30),
        ),
        mat_prefix,
        "abdomen_gray",
        pal,
    )
    # 3 faixas escuras envolvendo o abdômen (remetendo ao zigue-zague da arte!)
    for b_i, (bz, by, br) in enumerate([
        (0.84, 0.14, 0.37),
        (0.60, 0.23, 0.40),
        (0.36, 0.32, 0.34),
    ]):
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_band_{b_i}",
                10,
                br,
                0.045,
                (0.0, by, bz),
                rotation=(math.radians(26.0), 0.0, 0.0),
                scale=(0.98, 1.05, 1.0),
            ),
            mat_prefix,
            "vein_dark",
            pal,
        )

    # 2. TÓRAX E CABEÇA LAVANDA + CRISTA TRIPLA ICÔNICA
    _add_part(
        parts,
        create_icosphere("_tmp_thorax", 2, 0.38, (0.0, -0.08, 1.18), scale=(0.96, 1.02, 0.96)),
        mat_prefix,
        "head_lav",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_head_face", 2, 0.32, (0.0, -0.28, 1.24), scale=(0.92, 0.88, 0.96)),
        mat_prefix,
        "head_lav",
        pal,
    )

    # Crista tripla no topo da cabeça: espiga central bem alta + 2 laterais inclinadas
    _add_part(
        parts,
        create_cone(
            "_tmp_crest_mid",
            5,
            0.14,
            0.015,
            0.96,
            (0.0, -0.22, 1.88),
            rotation=(math.radians(-12.0), 0.0, 0.0),
            scale=(0.92, 0.56, 1.0),
        ),
        mat_prefix,
        "head_lav",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_crest_{tag}",
                5,
                0.11,
                0.015,
                0.66,
                (side * 0.24, -0.24, 1.68),
                rotation=(math.radians(-14.0), math.radians(side * 34.0), 0.0),
                scale=(0.88, 0.54, 1.0),
            ),
            mat_prefix,
            "head_lav",
            pal,
        )

    # 3. OLHOS GRANDES AZUL-GELO + PUPILAS ESCURAS + PRESINHAS + PATINHAS CREME NO PEITO
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.16,
                (side * 0.22, -0.46, 1.28),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(0.96, 0.72, 1.04),
            ),
            mat_prefix,
            "eye_ice",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                2,
                0.095,
                (side * 0.24, -0.54, 1.29),
                scale=(0.92, 0.55, 0.96),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.036,
                (side * 0.21, -0.58, 1.34),
            ),
            mat_prefix,
            "white_pure",
            pal,
        )
        # Presinha branca
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                5,
                0.042,
                0.010,
                0.15,
                (side * 0.11, -0.54, 1.06),
                rotation=(math.radians(174.0), math.radians(side * 8.0), 0.0),
            ),
            mat_prefix,
            "white_pure",
            pal,
        )
        # 3 pequenos segmentos de patinhas creme recolhidas sob o tórax
        for r_i, rz in enumerate([1.02, 0.94, 0.86]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_rib_{tag}_{r_i}",
                    5,
                    0.042,
                    0.025,
                    0.22,
                    (side * 0.24, -0.26 + r_i * 0.07, rz),
                    rotation=(math.radians(42.0), math.radians(side * -46.0), 0.0),
                ),
                mat_prefix,
                "rib_cream",
                pal,
            )

    # 4. QUATRO ASAS LARGAS DE MARIPOSA (2 SUPERIORES ENORMES + 2 INFERIORES COM LÓBULO)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"

        # ASA SUPERIOR: base interna + lâmina principal ampla + ponta alongada superior
        # Elevada em ~30 graus e levemente angulada para trás (+Y)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_uwing_in_{tag}",
                2,
                0.68,
                (side * 0.82, 0.16, 1.56),
                rotation=(math.radians(-10.0), math.radians(side * -30.0), math.radians(side * -14.0)),
                scale=(1.26, 0.12, 0.72),
            ),
            mat_prefix,
            "wing_mid",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_uwing_main_{tag}",
                2,
                0.82,
                (side * 1.24, 0.24, 1.84),
                rotation=(math.radians(-10.0), math.radians(side * -32.0), math.radians(side * -14.0)),
                scale=(1.36, 0.11, 0.74),
            ),
            mat_prefix,
            "wing_pale",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_uwing_tip_{tag}",
                2,
                0.56,
                (side * 1.66, 0.34, 2.18),
                rotation=(math.radians(-10.0), math.radians(side * -36.0), math.radians(side * -16.0)),
                scale=(1.28, 0.10, 0.56),
            ),
            mat_prefix,
            "wing_pale",
            pal,
        )

        # 3 nervuras elegantes percorrendo a face frontal da asa superior (bem nítidas na câmera!)
        vein_specs = [
            (1.18, 0.08, 1.98, 1.72, -38.0),
            (1.22, 0.09, 1.78, 1.62, -28.0),
            (1.06, 0.08, 1.52, 1.30, -16.0),
        ]
        for v_i, (vx, vy, vz, vlen, v_ry) in enumerate(vein_specs):
            _add_part(
                parts,
                create_cylinder(
                    f"_tmp_vein_{tag}_{v_i}",
                    5,
                    0.028,
                    vlen,
                    (side * vx, vy, vz),
                    rotation=(math.radians(-10.0), math.radians(side * (90.0 + v_ry)), math.radians(side * -14.0)),
                ),
                mat_prefix,
                "vein_dark",
                pal,
            )

        # 3 anéis/manchas suaves na asa superior (referência do Venomoth)
        for sp_i, (spx, spy, spz, spr) in enumerate([
            (1.02, 0.11, 1.84, 0.16),
            (1.42, 0.18, 2.02, 0.14),
            (1.26, 0.15, 1.60, 0.13),
        ]):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_wspot_{tag}_{sp_i}",
                    1,
                    spr,
                    (side * spx, spy, spz),
                    rotation=(math.radians(-10.0), math.radians(side * -32.0), math.radians(side * -14.0)),
                    scale=(1.18, 0.36, 0.85),
                ),
                mat_prefix,
                "wing_mid",
                pal,
            )

        # ASA INFERIOR com lóbulo característico bem integrado na ponta externa
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_lwing_{tag}",
                2,
                0.56,
                (side * 0.78, 0.26, 0.92),
                rotation=(math.radians(-8.0), math.radians(side * 24.0), math.radians(side * -12.0)),
                scale=(1.18, 0.10, 0.54),
            ),
            mat_prefix,
            "wing_mid",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_lwing_lobe_{tag}",
                1,
                0.19,
                (side * 1.14, 0.32, 0.70),
                rotation=(0.0, math.radians(side * 36.0), 0.0),
                scale=(1.14, 0.36, 0.78),
            ),
            mat_prefix,
            "wing_pale",
            pal,
        )
        # Nervura da asa inferior bem visível pela frente
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_lvein_{tag}",
                5,
                0.024,
                0.96,
                (side * 0.76, 0.17, 0.92),
                rotation=(math.radians(-8.0), math.radians(side * 114.0), math.radians(side * -12.0)),
            ),
            mat_prefix,
            "vein_dark",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 049. Dustwing com amplo espaço para as asas."""
    specs = [
        ("Dustwing_Shiny", (-16.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Dustwing_Normal", (-10.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Dustwing_Grande", (-4.0, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Dustwing_Gigante", (4.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Dustwing_Dourada_SuperRara", (14.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_dustwing(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
