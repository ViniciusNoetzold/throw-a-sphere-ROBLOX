"""
107_Ironboxer_Hitmonchan_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "107. Ironboxer — Boxeador Relâmpago (Ref: Hitmonchan)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Ironboxer_Shiny (1.0x - Luvas Azul-Royal + Túnica Menta-Prata + Pele Bronze)
  2. Ironboxer_Normal (1.0x - Túnica Lilás Pregueada + Coroa de 5 Pontas + Luvas de Boxe Vermelhas)
  3. Ironboxer_Grande (1.35x - Normal)
  4. Ironboxer_Gigante (1.85x - Normal)
  5. Ironboxer_Dourada_SuperRara (2.25x - Ouro Reluzente + Luvas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (cabeça coroada de 5 pontas, ombreiras, saiote pregueado e luvas de boxe)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Sapatos de boxe alinhados exatamente em `Z = 0.0` e rosto/soco apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "skin_brown": (0.74, 0.63, 0.52, 1.0),
        "shoulder_brown": (0.62, 0.52, 0.42, 1.0),
        "tunic_lilac": (0.82, 0.80, 0.90, 1.0),
        "tunic_shade": (0.68, 0.66, 0.78, 1.0),
        "belt_dark": (0.16, 0.16, 0.20, 1.0),
        "glove_red": (0.90, 0.30, 0.30, 1.0),
        "glove_shade": (0.74, 0.22, 0.24, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_iris": (0.16, 0.36, 0.52, 1.0),
        "eye_dark": (0.10, 0.11, 0.15, 1.0),
    },
    "shiny_palette": {
        "skin_brown": (0.74, 0.62, 0.48, 1.0),
        "shoulder_brown": (0.60, 0.50, 0.38, 1.0),
        "tunic_lilac": (0.78, 0.88, 0.88, 1.0),
        "tunic_shade": (0.62, 0.74, 0.76, 1.0),
        "belt_dark": (0.16, 0.16, 0.20, 1.0),
        "glove_red": (0.20, 0.44, 0.92, 1.0),
        "glove_shade": (0.14, 0.32, 0.74, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_iris": (0.16, 0.36, 0.52, 1.0),
        "eye_dark": (0.10, 0.11, 0.15, 1.0),
    },
    "golden_super_rare_palette": {
        "skin_brown": (0.98, 0.78, 0.14, 1.0),
        "shoulder_brown": (0.82, 0.60, 0.08, 1.0),
        "tunic_lilac": (1.00, 0.94, 0.66, 1.0),
        "tunic_shade": (0.88, 0.76, 0.36, 1.0),
        "belt_dark": (0.48, 0.34, 0.06, 1.0),
        "glove_red": (0.10, 0.92, 1.00, 1.0),
        "glove_shade": (0.06, 0.66, 0.80, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "eye_iris": (0.06, 0.62, 0.80, 1.0),
        "eye_dark": (0.04, 0.36, 0.54, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_boxing_glove(
    parts: list,
    tag: str,
    center: tuple,
    thumb_offset: tuple,
    cuff_offset: tuple,
    rot: tuple,
    mat_prefix: str,
    pal: dict,
):
    """Constrói uma luva de boxe grande e rechonchuda (punho + polegar lateral + punho/cuff)."""
    cx, cy, cz = center
    # Punho principal volumoso
    _add_part(
        parts,
        create_icosphere(
            f"_tmp_glove_main_{tag}",
            2,
            0.30,
            (cx, cy, cz),
            rotation=rot,
            scale=(1.12, 1.04, 0.94),
        ),
        mat_prefix,
        "glove_red",
        pal,
    )
    # Polegar lateral arredondado da luva
    tx, ty, tz = thumb_offset
    _add_part(
        parts,
        create_icosphere(
            f"_tmp_glove_thumb_{tag}",
            2,
            0.15,
            (cx + tx, cy + ty, cz + tz),
            scale=(0.96, 1.05, 0.88),
        ),
        mat_prefix,
        "glove_shade",
        pal,
    )
    # Borda do punho da luva
    kx, ky, kz = cuff_offset
    _add_part(
        parts,
        create_cylinder(
            f"_tmp_glove_cuff_{tag}",
            8,
            0.16,
            0.14,
            (cx + kx, cy + ky, cz + kz),
            rotation=rot,
        ),
        mat_prefix,
        "glove_shade",
        pal,
    )


def build_ironboxer(
    name: str = "Ironboxer_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel do 107. Ironboxer (Ref: Hitmonchan):
      - Cabeça marrom coroada por 5 pontas largas planas em leque + olhos azuis determinados
      - Ombreiras protetoras largas marrons caindo sobre os ombros
      - Túnica lilás-lavanda ajustada + cinturão preto + saiote pregueado dinâmico de 9 pregas
      - Braço direito (-X) estendido desferindo um jab direto + braço esquerdo (+X) em guarda fechada
      - 2 GRANDES LUVAS DE BOXE vermelhas (azul-royal na Shiny!) e botas lilás em base firme Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Ironboxer_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Ironboxer_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Ironboxer_Norm"

    parts = []

    # 1. TÚNICA LILÁS + CINTURÃO PRETO + SAIOTE PREGUEADO
    _add_part(
        parts,
        create_icosphere("_tmp_chest", 2, 0.36, (0.0, 0.02, 1.38), scale=(0.96, 0.78, 1.12)),
        mat_prefix,
        "tunic_lilac",
        pal,
    )
    # Cinturão preto estreito na cintura
    _add_part(
        parts,
        create_cylinder("_tmp_belt", 10, 0.27, 0.14, (0.0, 0.02, 1.04), scale=(1.04, 0.84, 1.0)),
        mat_prefix,
        "belt_dark",
        pal,
    )
    # Base cônica interna do saiote
    _add_part(
        parts,
        create_cone("_tmp_skirt_core", 10, 0.56, 0.26, 0.52, (0.0, 0.02, 0.78), scale=(1.06, 0.88, 1.0)),
        mat_prefix,
        "tunic_shade",
        pal,
    )
    # 10 pregas facetadas simétricas abrindo em saia plissada uniforme
    for p_idx in range(10):
        ang = math.radians(p_idx * 36.0)
        px = math.cos(ang) * 0.34
        py = math.sin(ang) * 0.28 + 0.02
        _add_part(
            parts,
            create_cone(
                f"_tmp_skirt_pleat_{p_idx}",
                4,
                0.24,
                0.08,
                0.56,
                (px, py, 0.76),
                rotation=(0.0, math.radians(-22.0), ang),
                scale=(0.55, 1.0, 1.0),
            ),
            mat_prefix,
            "tunic_lilac" if p_idx % 2 == 0 else "tunic_shade",
            pal,
        )

    # 2. OMBREIRAS LARGAS MARRONS (ARMADURA CLÁSSICA DO HITMONCHAN)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_shoulder_pad_{tag}",
                5,
                0.30,
                0.16,
                0.62,
                (side * 0.48, 0.02, 1.62),
                rotation=(math.radians(6.0), math.radians(side * 66.0), 0.0),
                scale=(0.58, 1.24, 1.0),
            ),
            mat_prefix,
            "shoulder_brown",
            pal,
        )

    # 3. PESCOÇO + CABEÇA COM COROA DE 5 PONTAS PLANAS + ROSTO DETERMINADO
    _add_part(
        parts,
        create_cylinder("_tmp_neck", 8, 0.16, 0.24, (0.0, -0.02, 1.72)),
        mat_prefix,
        "skin_brown",
        pal,
    )
    # Rosto oval afinado no queixo
    _add_part(
        parts,
        create_icosphere("_tmp_head_base", 2, 0.34, (0.0, -0.04, 1.98), scale=(0.94, 0.88, 1.04)),
        mat_prefix,
        "skin_brown",
        pal,
    )
    # Coroa de 5 pontas retangulares/chanfradas características no topo da cabeça!
    crown_spires = [
        # (x, y, z, width, height, ry_deg)
        (-0.34, 0.00, 2.26, 0.13, 0.42, -38.0),
        (-0.18, -0.01, 2.40, 0.14, 0.48, -18.0),
        (0.00, -0.01, 2.46, 0.15, 0.52, 0.0),
        (0.18, -0.01, 2.40, 0.14, 0.48, 18.0),
        (0.34, 0.00, 2.26, 0.13, 0.42, 38.0),
    ]
    for c_idx, (cx, cy, cz, cw, ch, ry_d) in enumerate(crown_spires):
        _add_part(
            parts,
            create_cube(
                f"_tmp_head_spire_{c_idx}",
                (cw, 0.22, ch),
                (cx, cy, cz),
                rotation=(math.radians(6.0), math.radians(ry_d), 0.0),
            ),
            mat_prefix,
            "skin_brown",
            pal,
        )

    # Olhos determinados com íris azul-escura + boca séria
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_bg_{tag}",
                (0.17, 0.05, 0.12),
                (side * 0.14, -0.32, 1.98),
                rotation=(0.0, math.radians(-side * 16.0), math.radians(-side * 14.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_w_{tag}",
                (0.14, 0.05, 0.095),
                (side * 0.14, -0.34, 1.98),
                rotation=(0.0, math.radians(-side * 16.0), math.radians(-side * 14.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.048,
                (side * 0.12, -0.36, 1.97),
                scale=(0.76, 0.42, 1.15),
            ),
            mat_prefix,
            "eye_iris",
            pal,
        )
    # Boca séria arqueada para baixo
    _add_part(
        parts,
        create_cube("_tmp_mouth", (0.14, 0.04, 0.028), (0.0, -0.33, 1.80)),
        mat_prefix,
        "eye_dark",
        pal,
    )

    # 4. BRAÇO DIREITO (-X) DESFERINDO SOCO DIRETO (JAB) + GRANDE LUVA DE BOXE
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R",
            7,
            0.12,
            0.10,
            0.78,
            (-0.74, -0.14, 1.66),
            rotation=(math.radians(-18.0), math.radians(-70.0), math.radians(-16.0)),
        ),
        mat_prefix,
        "skin_brown",
        pal,
    )
    _add_boxing_glove(
        parts,
        "R_jab",
        (-1.20, -0.34, 1.82),
        (0.18, -0.10, -0.14),
        (0.24, 0.10, -0.06),
        (math.radians(-16.0), math.radians(-70.0), 0.0),
        mat_prefix,
        pal,
    )

    # 5. BRAÇO ESQUERDO (+X) DOBRADO EM GUARDA FECHADA + GRANDE LUVA DE BOXE
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_L_up",
            7,
            0.12,
            0.10,
            0.44,
            (0.48, 0.00, 1.38),
            rotation=(0.0, math.radians(24.0), 0.0),
        ),
        mat_prefix,
        "skin_brown",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_L_fore",
            7,
            0.11,
            0.10,
            0.44,
            (0.46, -0.18, 1.44),
            rotation=(math.radians(-48.0), math.radians(-14.0), 0.0),
        ),
        mat_prefix,
        "skin_brown",
        pal,
    )
    _add_boxing_glove(
        parts,
        "L_guard",
        (0.44, -0.44, 1.66),
        (-0.20, -0.04, -0.08),
        (0.04, 0.22, -0.14),
        (math.radians(-40.0), 0.0, 0.0),
        mat_prefix,
        pal,
    )

    # 6. PERNAS ATLÉTICAS DE BOXEADOR + BOTAS LILÁS FIRMES EM Z = 0.0
    # Perna direita (-X) adiantada na base de boxe
    _add_part(
        parts,
        create_cone(
            "_tmp_leg_R_up",
            7,
            0.13,
            0.11,
            0.44,
            (-0.20, -0.08, 0.56),
            rotation=(math.radians(-18.0), math.radians(-8.0), 0.0),
        ),
        mat_prefix,
        "skin_brown",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_leg_R_lo",
            7,
            0.11,
            0.095,
            0.42,
            (-0.22, -0.16, 0.24),
            rotation=(math.radians(8.0), 0.0, 0.0),
        ),
        mat_prefix,
        "skin_brown",
        pal,
    )
    # Bota lilás direita
    _add_part(
        parts,
        create_icosphere("_tmp_shoe_R", 2, 0.19, (-0.24, -0.24, 0.10), scale=(0.94, 1.38, 0.62)),
        mat_prefix,
        "tunic_lilac",
        pal,
    )

    # Perna esquerda (+X) recuada dando impulso ao golpe
    _add_part(
        parts,
        create_cone(
            "_tmp_leg_L_up",
            7,
            0.13,
            0.11,
            0.44,
            (0.22, 0.12, 0.56),
            rotation=(math.radians(18.0), math.radians(10.0), 0.0),
        ),
        mat_prefix,
        "skin_brown",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_leg_L_lo",
            7,
            0.11,
            0.095,
            0.42,
            (0.26, 0.22, 0.24),
            rotation=(math.radians(-6.0), 0.0, 0.0),
        ),
        mat_prefix,
        "skin_brown",
        pal,
    )
    # Bota lilás esquerda
    _add_part(
        parts,
        create_icosphere("_tmp_shoe_L", 2, 0.19, (0.28, 0.16, 0.10), scale=(0.94, 1.36, 0.62)),
        mat_prefix,
        "tunic_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 107. Ironboxer lado a lado."""
    specs = [
        ("Ironboxer_Shiny", (-10.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Ironboxer_Normal", (-5.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Ironboxer_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Ironboxer_Gigante", (5.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Ironboxer_Dourada_SuperRara", (13.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_ironboxer(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
