"""
06_Leviathorn_Dragao_Abissal_Leviathan_Blender.py
=================================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera o modelo 3D
da criatura "06. Leviathorn (Leviathan) — Dragão Abissal (Evolução Final Água - Estágio 3)"
no estilo Low-Poly / Voxel Blocky para o jogo Roblox "Jogue uma Orbe / Throw a Sphere".

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no modelo final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Variações automáticas (`Normal`, `Dourado`, `Huge`) geradas lado a lado
  - Ponta das nadadeiras dianteiras alinhada exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione um modelo (ex: `Leviathorn_Normal`) e exporte via `File > Export > FBX (.fbx)`
     com `Selected Objects` marcado e `Apply Transform` para importar como `MeshPart` no Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "huge_scale": 1.85,
    "palette": {
        "body_teal_gray": (0.58, 0.72, 0.72, 1.0),  # Corpo de plesiossauro, pescoço e nadadeiras cinza-água (#94B8B8)
        "glow_cyan": (0.06, 0.88, 0.92, 1.0),       # Focinho, garganta/barriga, borda das asas e cauda ciano (#0FE0EB)
        "armor_slate": (0.34, 0.38, 0.36, 1.0),     # 11 placas dorsais segmentadas de carapaça (#57615C)
        "armor_dark": (0.18, 0.21, 0.20, 1.0),      # Detalhes escuros da carapaça e pupilas (#2E3633)
        "eye_white": (0.94, 0.98, 1.00, 1.0),       # Olhos brancos brilhantes (#F0FAFF)
    },
    "golden_palette": {
        "body_teal_gray": (0.96, 0.78, 0.20, 1.0),
        "glow_cyan": (0.18, 0.96, 1.00, 1.0),
        "armor_slate": (0.76, 0.56, 0.12, 1.0),
        "armor_dark": (0.28, 0.18, 0.04, 1.0),
        "eye_white": (1.00, 0.98, 0.82, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (ideal para acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, zera a origem na base das nadadeiras (Z = 0.0),
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_leviathorn(
    name: str = "Leviathorn_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    is_golden: bool = False,
):
    """
    Constrói o modelo 3D completo do Dragão Abissal (06. Leviathorn / Estilo Leviathan):
      - Frente apontando para -Y e pontas das nadadeiras dianteiras tocando Z = 0.0
      - Corpo de plesiossauro em S, garganta/barriga/focinho ciano brilhante
      - 11 placas dorsais segmentadas de carapaça + cristas com membrana ciano
      - 4 nadadeiras em formato de asa marítima + grande cauda bifurcada em leque ciano
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    pal = CONFIG["golden_palette"] if is_golden else CONFIG["palette"]
    mat_prefix = "Mat_Levia_Gold" if is_golden else "Mat_Levia"
    parts = []

    # 1. TORSO HIDRODINÂMICO E FAIXA VENTRAL BIOLUMINESCENTE (Cinza-Água + Ciano)
    _add_part(
        parts,
        create_cube("_tmp_chest", (0.86, 0.88, 0.78), (0.0, -0.42, 1.62), (math.radians(-18), 0.0, 0.0)),
        mat_prefix,
        "body_teal_gray",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mid_torso", (0.94, 0.96, 0.82), (0.0, 0.12, 1.48)),
        mat_prefix,
        "body_teal_gray",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_rear_torso", (0.78, 0.90, 0.68), (0.0, 0.72, 1.60), (math.radians(16), 0.0, 0.0)),
        mat_prefix,
        "body_teal_gray",
        pal,
    )
    # Faixa ventral luminosa ciano ao longo do peito e barriga
    _add_part(
        parts,
        create_cube("_tmp_belly_chest", (0.58, 0.74, 0.24), (0.0, -0.46, 1.24), (math.radians(-18), 0.0, 0.0)),
        mat_prefix,
        "glow_cyan",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_belly_mid", (0.64, 0.92, 0.22), (0.0, 0.14, 1.12)),
        mat_prefix,
        "glow_cyan",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_belly_rear", (0.52, 0.82, 0.20), (0.0, 0.74, 1.28), (math.radians(18), 0.0, 0.0)),
        mat_prefix,
        "glow_cyan",
        pal,
    )

    # 2. PESCOÇO LONGO EM ARCO DE PLESIOSSAURO + GARGANTA CIANO
    neck_specs = [
        ((0.0, -0.78, 2.02), 0.36, 0.31, 0.56, 16.0, -0.22),
        ((0.0, -0.90, 2.48), 0.31, 0.27, 0.54, 10.0, -0.19),
        ((0.0, -0.95, 2.90), 0.27, 0.24, 0.46, -4.0, -0.17),
    ]
    for idx, (loc, r1, r2, depth, rx_deg, cy_off) in enumerate(neck_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_neck_{idx}",
                6,
                r1,
                r2,
                depth,
                loc,
                (math.radians(rx_deg), 0.0, 0.0),
            ),
            mat_prefix,
            "body_teal_gray",
            pal,
        )
        # Faixa frontal ciano descendo pela garganta
        _add_part(
            parts,
            create_cube(
                f"_tmp_throat_{idx}",
                (r1 * 0.95, 0.16, depth * 0.96),
                (loc[0], loc[1] + cy_off, loc[2]),
                (math.radians(rx_deg), 0.0, 0.0),
            ),
            mat_prefix,
            "glow_cyan",
            pal,
        )

    # 3. CABEÇA DRACÔNICA, FOCINHO CIANO E CRISTAS COM MEMBRANA
    _add_part(
        parts,
        create_cube("_tmp_head_skull", (0.54, 0.58, 0.44), (0.0, -1.16, 3.24), (math.radians(-16), 0.0, 0.0)),
        mat_prefix,
        "body_teal_gray",
        pal,
    )
    # Focinho afilado e máscara facial ciano (como na imagem e nos retratos)
    _add_part(
        parts,
        create_cone(
            "_tmp_snout_cyan",
            4,
            0.30,
            0.12,
            0.54,
            (0.0, -1.46, 3.04),
            (math.radians(112), 0.0, 0.0),
            scale=(0.82, 0.72, 1.0),
        ),
        mat_prefix,
        "glow_cyan",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_cheek_cyan", (0.56, 0.38, 0.24), (0.0, -1.24, 3.08), (math.radians(-16), 0.0, 0.0)),
        mat_prefix,
        "glow_cyan",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        # Olho branco expressivo + pupila escura
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_{side_idx}",
                (0.09, 0.18, 0.12),
                (sx * 0.24, -1.32, 3.22),
                (math.radians(-18), 0.0, math.radians(sx * -12)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_pupil_{side_idx}",
                (0.05, 0.09, 0.09),
                (sx * 0.26, -1.33, 3.22),
            ),
            mat_prefix,
            "armor_dark",
            pal,
        )

        # 2 Grandes chifres-crista principais curvados para trás
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_horn_{side_idx}",
                4,
                0.15,
                0.02,
                0.68,
                (sx * 0.16, -0.98, 3.54),
                (math.radians(-42), math.radians(sx * 16), 0.0),
                scale=(0.75, 1.0, 1.0),
            ),
            mat_prefix,
            "body_teal_gray",
            pal,
        )
        # Barbatanas laterais cefálicas (nervuras cinza-água + membrana ciano)
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_fin_web_{side_idx}",
                4,
                0.22,
                0.04,
                0.56,
                (sx * 0.26, -0.88, 3.28),
                (math.radians(-68), math.radians(sx * 32), 0.0),
                scale=(0.35, 1.0, 1.0),
            ),
            mat_prefix,
            "glow_cyan",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_fin_rib1_{side_idx}",
                4,
                0.07,
                0.015,
                0.62,
                (sx * 0.29, -0.85, 3.36),
                (math.radians(-58), math.radians(sx * 34), 0.0),
            ),
            mat_prefix,
            "body_teal_gray",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_fin_rib2_{side_idx}",
                4,
                0.06,
                0.015,
                0.52,
                (sx * 0.30, -0.86, 3.20),
                (math.radians(-82), math.radians(sx * 36), 0.0),
            ),
            mat_prefix,
            "body_teal_gray",
            pal,
        )

    # 4. FILEIRA DE 11 PLACAS DORSAIS SEGMENTADAS DE CARAPAÇA (Nuca -> Dorso -> Cauda)
    dorsal_plates = [
        (-0.78, 2.94, -82.0, 0.32, 0.26, 0.14),
        (-0.74, 2.66, -76.0, 0.38, 0.30, 0.16),
        (-0.66, 2.38, -68.0, 0.44, 0.32, 0.18),
        (-0.56, 2.10, -54.0, 0.52, 0.34, 0.20),
        (-0.38, 1.92, -26.0, 0.62, 0.36, 0.22),
        (-0.12, 1.84, -8.0, 0.68, 0.38, 0.24),
        (0.16, 1.82, 6.0, 0.68, 0.38, 0.24),
        (0.44, 1.86, 16.0, 0.62, 0.36, 0.22),
        (0.70, 1.94, 24.0, 0.54, 0.32, 0.20),
        (0.94, 2.04, 30.0, 0.44, 0.28, 0.18),
        (1.16, 2.16, 34.0, 0.34, 0.24, 0.16),
    ]
    for idx, (py, pz, rx_deg, pw, pd, ph) in enumerate(dorsal_plates):
        _add_part(
            parts,
            create_cube(
                f"_tmp_shell_plate_{idx}",
                (pw, pd, ph),
                (0.0, py, pz),
                (math.radians(rx_deg), 0.0, 0.0),
            ),
            mat_prefix,
            "armor_slate",
            pal,
        )

    # 5. QUATRO NADADEIRAS EM FORMA DE ASAS MARÍTIMAS (Dianteiras tocam Z = 0)
    # 5A. Grandes Nadadeiras Dianteiras em Foice (Cinza-Água + Borda Ciano)
    for side_idx, sx in enumerate([-1.0, 1.0]):
        # Lâmina superior da nadadeira
        _add_part(
            parts,
            create_cone(
                f"_tmp_fflip_upper_{side_idx}",
                4,
                0.38,
                0.24,
                0.95,
                (sx * 0.56, -0.46, 1.08),
                (math.radians(170), math.radians(sx * -14), 0.0),
                scale=(0.28, 1.0, 1.0),
            ),
            mat_prefix,
            "body_teal_gray",
            pal,
        )
        # Ponta inferior em foice tocando Z = 0
        _add_part(
            parts,
            create_cone(
                f"_tmp_fflip_tip_{side_idx}",
                4,
                0.26,
                0.025,
                0.88,
                (sx * 0.60, -0.56, 0.42),
                (math.radians(164), math.radians(sx * -6), 0.0),
                scale=(0.24, 1.0, 1.0),
            ),
            mat_prefix,
            "body_teal_gray",
            pal,
        )
        # Borda traseira bioluminescente ciano da nadadeira dianteira
        _add_part(
            parts,
            create_cone(
                f"_tmp_fflip_cyan_edge_{side_idx}",
                4,
                0.22,
                0.03,
                1.28,
                (sx * 0.57, -0.26, 0.78),
                (math.radians(168), math.radians(sx * -10), 0.0),
                scale=(0.20, 0.85, 1.0),
            ),
            mat_prefix,
            "glow_cyan",
            pal,
        )
        # Pequeno esporão na base da nadadeira dianteira
        _add_part(
            parts,
            create_cone(
                f"_tmp_fflip_spur_{side_idx}",
                4,
                0.07,
                0.015,
                0.24,
                (sx * 0.46, -0.34, 1.56),
                (math.radians(-38), math.radians(sx * 24), 0.0),
            ),
            mat_prefix,
            "armor_slate",
            pal,
        )

    # 5B. Nadadeiras Pélvicas Traseiras Menores
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_bflip_{side_idx}",
                4,
                0.22,
                0.02,
                0.86,
                (sx * 0.52, 0.78, 1.24),
                (math.radians(-118), math.radians(sx * -26), 0.0),
                scale=(0.28, 1.0, 1.0),
            ),
            mat_prefix,
            "body_teal_gray",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_bflip_spur_{side_idx}",
                4,
                0.06,
                0.015,
                0.22,
                (sx * 0.44, 0.62, 1.52),
                (math.radians(-32), math.radians(sx * 22), 0.0),
            ),
            mat_prefix,
            "armor_slate",
            pal,
        )

    # 6. CAUDA ARQUEADA + 3 ESPINHOS + GRANDE NADADEIRA CAUDAL BIFURCADA (CIANO)
    tail_segs = [
        ((0.0, 1.18, 1.82), 0.34, 0.24, 0.54, -56.0),
        ((0.0, 1.56, 2.12), 0.24, 0.16, 0.52, -46.0),
        ((0.0, 1.88, 2.46), 0.16, 0.11, 0.46, -42.0),
    ]
    for idx, (loc, r1, r2, depth, rx_deg) in enumerate(tail_segs):
        _add_part(
            parts,
            create_cone(f"_tmp_tail_seg_{idx}", 6, r1, r2, depth, loc, (math.radians(rx_deg), 0.0, 0.0)),
            mat_prefix,
            "body_teal_gray",
            pal,
        )

    # 3 Pequenos espinhos dorsais na ponta da cauda
    for idx, (sy, sz) in enumerate([(1.54, 2.34), (1.68, 2.48), (1.82, 2.60)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_spike_{idx}",
                4,
                0.055,
                0.012,
                0.22,
                (0.0, sy, sz),
                (math.radians(-32), 0.0, 0.0),
            ),
            mat_prefix,
            "body_teal_gray",
            pal,
        )

    # Grande nadadeira caudal bifurcada em leque ciano
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_fin_upper",
            4,
            0.44,
            0.03,
            1.02,
            (0.0, 2.36, 2.78),
            (math.radians(-58), 0.0, 0.0),
            scale=(0.14, 1.0, 1.0),
        ),
        mat_prefix,
        "glow_cyan",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_fin_lower",
            4,
            0.44,
            0.03,
            1.02,
            (0.0, 2.40, 2.36),
            (math.radians(-116), 0.0, 0.0),
            scale=(0.14, 1.0, 1.0),
        ),
        mat_prefix,
        "glow_cyan",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_fin_spine",
            4,
            0.10,
            0.02,
            0.58,
            (0.0, 2.22, 2.58),
            (math.radians(-82), 0.0, 0.0),
        ),
        mat_prefix,
        "body_teal_gray",
        pal,
    )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """Gera lado a lado as versões Normal, Dourada (Mutação 2x) e Enorme (Huge 1.85x)."""
    build_leviathorn("Leviathorn_Normal", location=(0.0, 0.0, 0.0), scale=1.0, is_golden=False)
    build_leviathorn("Leviathorn_Dourado", location=(4.2, 0.0, 0.0), scale=1.0, is_golden=True)
    build_leviathorn("Leviathorn_Huge", location=(-5.6, 0.0, 0.0), scale=CONFIG["huge_scale"], is_golden=False)


if __name__ == "__main__":
    generate_variations()
    print("Leviathorn (Dragão Abissal - Estilo Leviathan) gerado com sucesso! Pronto para exportar em .FBX para o Roblox Studio.")
