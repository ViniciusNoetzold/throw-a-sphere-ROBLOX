"""
004_Embernewt_Charmander_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "004. Embernewt — Lagarto de Brasa (Ref: Charmander)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Embernewt_Shiny (1.0x - Paleta Shiny / Shyne Amarelo-Dourado Luminoso)
  2. Embernewt_Normal (1.0x - Pele Laranja-Brasa + Barriga Creme + Chama Bicolor)
  3. Embernewt_Grande (1.35x - Normal)
  4. Embernewt_Gigante (1.85x - Normal)
  5. Embernewt_Dourada_SuperRara (2.25x - Ouro Reluzente + Chama Solar Platina + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cilindros 8 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base dos pés e garras alinhada exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Embernewt_Shiny`, `Embernewt_Normal`, `Embernewt_Grande`,
     `Embernewt_Gigante`, `Embernewt_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_orange": (0.96, 0.46, 0.14, 1.0),
        "belly_cream": (0.98, 0.88, 0.58, 1.0),
        "flame_outer": (0.98, 0.28, 0.08, 1.0),
        "flame_core": (1.00, 0.86, 0.14, 1.0),
        "eyes_teal": (0.12, 0.52, 0.60, 1.0),
        "eye_dark": (0.06, 0.22, 0.28, 1.0),
        "mouth_rose": (0.84, 0.36, 0.40, 1.0),
        "claws_white": (0.97, 0.97, 0.98, 1.0),
    },
    "shiny_palette": {
        "body_orange": (0.98, 0.78, 0.20, 1.0),
        "belly_cream": (1.00, 0.95, 0.72, 1.0),
        "flame_outer": (1.00, 0.52, 0.10, 1.0),
        "flame_core": (1.00, 0.94, 0.36, 1.0),
        "eyes_teal": (0.14, 0.68, 0.52, 1.0),
        "eye_dark": (0.06, 0.30, 0.24, 1.0),
        "mouth_rose": (0.86, 0.42, 0.44, 1.0),
        "claws_white": (0.98, 0.98, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "body_orange": (0.98, 0.76, 0.12, 1.0),
        "belly_cream": (1.00, 0.92, 0.48, 1.0),
        "flame_outer": (1.00, 0.86, 0.22, 1.0),
        "flame_core": (1.00, 0.98, 0.82, 1.0),
        "eyes_teal": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.05, 0.48, 0.62, 1.0),
        "mouth_rose": (0.88, 0.62, 0.14, 1.0),
        "claws_white": (1.00, 0.96, 0.82, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_embernewt(
    name: str = "Embernewt_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 004. Embernewt (Ref: Charmander):
      - Frente apontando para -Y e base dos pés/garras em Z = 0.0
      - Torso bípede esguio com placa frontal creme e braços abertos
      - Cabeça arredondada facetada com olhos grandes, sorriso e presinhas
      - Cauda curvada para cima com chama bicolor na ponta
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Ember_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Ember_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Ember"

    parts = []

    # 1. TORSO BÍPEDE ESGUIO + BARRIGA CREME + PESCOÇO
    _add_part(
        parts,
        create_cube("_tmp_torso", (0.92, 0.82, 1.12), (0.0, 0.0, 1.02)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_pelvis", (0.98, 0.88, 0.64), (0.0, 0.06, 0.68)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_belly", (0.70, 0.14, 0.98), (0.0, -0.40, 0.96)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_neck", (0.62, 0.58, 0.34), (0.0, -0.04, 1.62)),
        mat_prefix,
        "body_orange",
        pal,
    )

    # 2. PERNAS BÍPEDES, PÉS COM 3 GARRAS (Z = 0) E BRAÇOS COM DEDINHOS
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_thigh_{side_idx}",
                (0.44, 0.52, 0.56),
                (sx * 0.44, 0.02, 0.56),
                (math.radians(8), 0.0, math.radians(sx * -6)),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{side_idx}", (0.40, 0.56, 0.32), (sx * 0.46, -0.08, 0.18)),
            mat_prefix,
            "body_orange",
            pal,
        )
        for claw_i, cx_off in enumerate([-0.11, 0.0, 0.11]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_claw_{side_idx}_{claw_i}",
                    4,
                    0.055,
                    0.010,
                    0.20,
                    (sx * 0.46 + cx_off, -0.40, 0.08),
                    (math.radians(86), 0.0, 0.0),
                ),
                mat_prefix,
                "claws_white",
                pal,
            )

        # Braço aberto com 3 pequenos dedos
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_{side_idx}",
                6,
                0.18,
                0.13,
                0.64,
                (sx * 0.68, -0.10, 1.32),
                (math.radians(14), math.radians(sx * 68), 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        for fin_i, fy_off in enumerate([-0.06, 0.0, 0.06]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{side_idx}_{fin_i}",
                    4,
                    0.032,
                    0.008,
                    0.12,
                    (sx * 0.99, -0.18 + fy_off, 1.44),
                    (math.radians(14), math.radians(sx * 72), 0.0),
                ),
                mat_prefix,
                "claws_white",
                pal,
            )

    # 3. CABEÇA ARREDONDADA FACETADA (-Y), SORRISO COM PRESAS E OLHOS GRANDES
    _add_part(
        parts,
        create_icosphere("_tmp_cranium", 1, 0.58, (0.0, -0.10, 2.08), scale=(0.96, 0.98, 1.05)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_head_block", (0.94, 0.92, 0.78), (0.0, -0.12, 1.98)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout", (0.80, 0.42, 0.38), (0.0, -0.52, 1.82)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth_inner", (0.64, 0.12, 0.14), (0.0, -0.70, 1.76)),
        mat_prefix,
        "mouth_rose",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_lower_jaw", (0.68, 0.22, 0.08), (0.0, -0.62, 1.67)),
        mat_prefix,
        "body_orange",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_dark_{side_idx}",
                (0.24, 0.10, 0.32),
                (sx * 0.30, -0.55, 2.05),
                (0.0, 0.0, math.radians(sx * -16)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_iris_{side_idx}",
                (0.20, 0.08, 0.25),
                (sx * 0.30, -0.57, 2.03),
                (0.0, 0.0, math.radians(sx * -16)),
            ),
            mat_prefix,
            "eyes_teal",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_shine_{side_idx}",
                (0.09, 0.06, 0.10),
                (sx * 0.28, -0.59, 2.13),
                (0.0, 0.0, math.radians(sx * -16)),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )
        # Presinhas superiores e inferiores
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_up_{side_idx}",
                4,
                0.042,
                0.008,
                0.10,
                (sx * 0.24, -0.73, 1.80),
                (math.radians(180), 0.0, 0.0),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_low_{side_idx}",
                4,
                0.036,
                0.008,
                0.09,
                (sx * 0.19, -0.74, 1.72),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )

    # 4. CAUDA CURVADA PARA CIMA (+Y) + CHAMA BICOLOR NA PONTA
    _add_part(
        parts,
        create_cone("_tmp_tail_base", 6, 0.28, 0.20, 0.68, (0.0, 0.64, 0.58), (math.radians(-68), 0.0, 0.0)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_tail_cream", (0.28, 0.52, 0.14), (0.0, 0.68, 0.45), (math.radians(-22), 0.0, 0.0)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_tail_mid", 6, 0.20, 0.13, 0.62, (0.0, 1.12, 0.78), (math.radians(-38), 0.0, 0.0)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_tail_tip", 6, 0.13, 0.07, 0.52, (0.0, 1.40, 1.16), (math.radians(-14), 0.0, 0.0)),
        mat_prefix,
        "body_orange",
        pal,
    )

    # Chama bicolor na ponta da cauda
    _add_part(
        parts,
        create_icosphere("_tmp_flame_orb", 1, 0.24, (0.0, 1.48, 1.52)),
        mat_prefix,
        "flame_outer",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_flame_main", 5, 0.24, 0.02, 0.62, (0.0, 1.48, 1.76)),
        mat_prefix,
        "flame_outer",
        pal,
    )
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_flame_side_{side_idx}",
                4,
                0.12,
                0.01,
                0.38,
                (sx * 0.14, 1.50, 1.66),
                (math.radians(10), math.radians(sx * 24), 0.0),
            ),
            mat_prefix,
            "flame_outer",
            pal,
        )
    _add_part(
        parts,
        create_cone("_tmp_flame_core", 4, 0.16, 0.02, 0.44, (0.0, 1.44, 1.68)),
        mat_prefix,
        "flame_core",
        pal,
    )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """
    Gera lado a lado os 5 modelos do 004. Embernewt (Charmander):
      1. Shiny (1.0x) | 2. Normal (1.0x) | 3. Grande (1.35x) | 4. Gigante (1.85x) | 5. Dourada Super Rara (2.25x)
    """
    build_embernewt("Embernewt_Shiny", location=(-6.6, 0.0, 0.0), scale=CONFIG["scales"]["Shiny"], variant="Shiny")
    build_embernewt("Embernewt_Normal", location=(-3.9, 0.0, 0.0), scale=CONFIG["scales"]["Normal"], variant="Normal")
    build_embernewt("Embernewt_Grande", location=(-0.9, 0.0, 0.0), scale=CONFIG["scales"]["Grande"], variant="Normal")
    build_embernewt("Embernewt_Gigante", location=(2.8, 0.0, 0.0), scale=CONFIG["scales"]["Gigante"], variant="Normal")
    build_embernewt(
        "Embernewt_Dourada_SuperRara",
        location=(7.8, 0.0, 0.0),
        scale=CONFIG["scales"]["DouradaSuperRara"],
        variant="DouradaSuperRara",
    )


if __name__ == "__main__":
    generate_variations()
    print("004. Embernewt (5 variações: Shiny, Normal, Grande, Gigante e Dourada Super Rara) gerado com sucesso!")
