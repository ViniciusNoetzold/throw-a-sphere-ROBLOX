"""
117_Spikehorse_Seadra_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "117. Spikehorse — Dragão-Marinho (Ref: Seadra)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Spikehorse_Shiny (1.0x - Paleta Shiny Roxo-Violeta + Barbatanas Rosa-Magenta)
  2. Spikehorse_Normal (1.0x - Azul-Oceano + Barriga Creme Escamada + Espinhos e Barbatanas Pontiagudas)
  3. Spikehorse_Grande (1.35x - Normal)
  4. Spikehorse_Gigante (1.85x - Normal)
  5. Spikehorse_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Espinhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para cabeça, tronco e espiral da cauda; cones 6-8 lados para focinho tubular, espinhos e barbatanas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base da cauda enrolada alinhada exatamente em `Z = 0.0` e focinho/rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.36, 0.72, 0.88, 1.0),
        "body_shade": (0.22, 0.54, 0.74, 1.0),
        "belly_cream": (0.88, 0.84, 0.70, 1.0),
        "fin_tip": (0.86, 0.82, 0.68, 1.0),
        "spike_back": (0.72, 0.66, 0.56, 1.0),
        "snout_hole": (0.10, 0.12, 0.16, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.12, 0.16, 1.0),
        "eye_iris": (0.82, 0.18, 0.22, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.50, 0.34, 0.78, 1.0),
        "body_shade": (0.34, 0.20, 0.58, 1.0),
        "belly_cream": (0.92, 0.86, 0.64, 1.0),
        "fin_tip": (0.92, 0.36, 0.56, 1.0),
        "spike_back": (0.86, 0.30, 0.50, 1.0),
        "snout_hole": (0.12, 0.08, 0.18, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.10, 0.16, 1.0),
        "eye_iris": (0.92, 0.24, 0.36, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.60, 0.08, 1.0),
        "belly_cream": (1.00, 0.92, 0.52, 1.0),
        "fin_tip": (0.10, 0.92, 1.00, 1.0),
        "spike_back": (0.08, 0.72, 0.88, 1.0),
        "snout_hole": (0.16, 0.12, 0.04, 1.0),
        "eye_white": (1.00, 0.99, 0.90, 1.0),
        "eye_dark": (0.04, 0.42, 0.58, 1.0),
        "eye_iris": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_spikehorse(
    name: str = "Spikehorse_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de 117. Spikehorse (Ref: Seadra):
      - Tronco curvo de dragão-marinho com 4 placas escamadas creme sobrepostas no ventre
      - Cauda grande enrolada em espiral na base (Z=0.0) com anéis bem legíveis de frente
      - Cabeça feroz com focinho tubular longo apontando para -Y e abertura escura na ponta
      - Olhos estreitos determinados com sobrancelha marcada, íris rubi e brilho branco
      - Coroa de espinhos pontiagudos atrás da cabeça + barbatana bochechal de 3 pontas em cada lado
      - Par de grandes barbatanas dorsais/peitorais em leque pontiagudo (azul na base, creme na ponta)
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Spk_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Spk_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Spk_Norm"

    parts = []

    # 1. CAUDA ENROLADA EM ESPIRAL NA BASE (Z=0.0) - FORTE ASSINATURA DE CAVALO-MARINHO
    coil_segments = [
        # (rad, loc, sc)
        (0.46, (0.0, 0.10, 0.56), (0.86, 1.05, 1.00)),
        (0.42, (0.0, 0.36, 0.44), (0.84, 1.00, 0.96)),
        (0.38, (0.0, 0.44, 0.24), (0.82, 0.96, 0.88)),
        (0.36, (0.0, 0.20, 0.14), (0.84, 1.00, 0.84)),
        (0.34, (0.0, -0.08, 0.24), (0.84, 0.96, 0.92)),
        (0.28, (0.0, -0.14, 0.42), (0.80, 0.90, 0.88)),
        (0.22, (0.0, 0.04, 0.48), (0.76, 0.86, 0.86)),
    ]
    for idx, (rad, loc, sc) in enumerate(coil_segments):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tail_coil_{idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "body_blue",
            pal,
        )
    # Acento lateral da espiral em ambos os lados para destacar o caracol da cauda
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_coil_ring_{tag}",
                8,
                0.24,
                0.08,
                (side * 0.35, 0.14, 0.36),
                rotation=(0.0, math.radians(90.0), 0.0),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_coil_center_{tag}",
                8,
                0.13,
                0.10,
                (side * 0.37, 0.12, 0.36),
                rotation=(0.0, math.radians(90.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    # 2. TRONCO ESBELTO E BARRIGA SERRILHADA COM 4 PLACAS CREME SOBREPOSTAS
    _add_part(
        parts,
        create_icosphere(
            "_tmp_torso_lower",
            2,
            0.46,
            (0.0, 0.02, 0.96),
            rotation=(math.radians(-10.0), 0.0, 0.0),
            scale=(0.88, 0.92, 1.18),
        ),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_torso_upper",
            2,
            0.40,
            (0.0, -0.06, 1.38),
            rotation=(math.radians(8.0), 0.0, 0.0),
            scale=(0.82, 0.88, 1.06),
        ),
        mat_prefix,
        "body_blue",
        pal,
    )

    # 4 Placas creme escalonadas na barriga frontal (apontando para -Y)
    belly_plates = [
        (1.36, -0.34, 0.28, 0.16),
        (1.18, -0.39, 0.33, 0.17),
        (0.99, -0.40, 0.35, 0.17),
        (0.80, -0.36, 0.31, 0.16),
    ]
    for p_idx, (bz, by, rad_x, h_z) in enumerate(belly_plates):
        _add_part(
            parts,
            create_cone(
                f"_tmp_belly_plate_{p_idx}",
                8,
                rad_x,
                rad_x * 0.86,
                h_z,
                (0.0, by, bz),
                rotation=(math.radians(12.0), 0.0, 0.0),
                scale=(1.0, 0.56, 1.0),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )

    # 3. CABEÇA FEROZ + FOCINHO TUBULAR ALONGADO (-Y)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_head_main",
            2,
            0.48,
            (0.0, -0.14, 1.88),
            scale=(0.92, 1.08, 0.94),
        ),
        mat_prefix,
        "body_blue",
        pal,
    )
    # Focinho tubular longo projetado para a frente (-Y) e levemente inclinado para cima
    _add_part(
        parts,
        create_cone(
            "_tmp_snout_tube",
            8,
            0.18,
            0.22,
            0.78,
            (0.0, -0.78, 1.94),
            rotation=(math.radians(80.0), 0.0, 0.0),
            scale=(0.88, 1.05, 1.0),
        ),
        mat_prefix,
        "body_blue",
        pal,
    )
    # Borda do focinho e cavidade escura na ponta frontal (-Y)
    _add_part(
        parts,
        create_cylinder(
            "_tmp_snout_hole",
            8,
            0.135,
            0.08,
            (0.0, -1.16, 2.00),
            rotation=(math.radians(80.0), 0.0, 0.0),
            scale=(0.82, 1.02, 1.0),
        ),
        mat_prefix,
        "snout_hole",
        pal,
    )

    # 4. OLHOS FEROZES COM SOBRANCELHA MARCADA + ÍRIS RUBI + BRILHO
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Globo ocular branco (levemente angulado para frente para leitura frontal excelente)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.15,
                (side * 0.30, -0.44, 1.94),
                rotation=(0.0, 0.0, math.radians(side * -24.0)),
                scale=(0.76, 0.62, 0.86),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Íris rubi
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.082,
                (side * 0.33, -0.52, 1.93),
                scale=(0.68, 0.50, 0.92),
            ),
            mat_prefix,
            "eye_iris",
            pal,
        )
        # Pupila escura
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.048,
                (side * 0.34, -0.55, 1.93),
                scale=(0.65, 0.45, 0.90),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Brilho branco no olho
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.026,
                (side * 0.32, -0.57, 1.97),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Sobrancelha feroz inclinada sobre o olho
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.24, 0.20, 0.08),
                (side * 0.30, -0.46, 2.04),
                rotation=(math.radians(10.0), math.radians(side * -18.0), math.radians(side * -22.0)),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    # 5. ESPINHOS DA COROA E DA NUCA + BARBATANAS PONTIAGUDAS NAS BOCHECHAS
    # Espinho central superior na testa/coroa
    _add_part(
        parts,
        create_cone(
            "_tmp_crown_center",
            6,
            0.22,
            0.02,
            0.68,
            (0.0, 0.08, 2.40),
            rotation=(math.radians(-38.0), 0.0, 0.0),
            scale=(0.56, 1.0, 1.0),
        ),
        mat_prefix,
        "body_blue",
        pal,
    )
    # 6 Espinhos laterais/traseiros da cabeça (3 por lado em leque feroz)
    head_spikes = [
        # (dx, dy, dz, rx, ry, rz, r1, depth, mat_key)
        (0.32, 0.16, 2.34, -36.0, 32.0, 0.0, 0.16, 0.64, "body_blue"),
        (0.42, 0.24, 2.10, -48.0, 48.0, 0.0, 0.14, 0.62, "body_blue"),
        (0.24, 0.34, 2.26, -52.0, 18.0, 0.0, 0.11, 0.56, "spike_back"),
    ]
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        for s_idx, (dx, dy, dz, rx, ry, rz, r1, depth, mkey) in enumerate(head_spikes):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_head_spike_{tag}_{s_idx}",
                    5,
                    r1,
                    0.018,
                    depth,
                    (side * dx, dy, dz),
                    rotation=(math.radians(rx), math.radians(side * ry), math.radians(side * rz)),
                    scale=(0.68, 1.0, 1.0),
                ),
                mat_prefix,
                mkey,
                pal,
            )

        # Barbatana facial em leque com 3 pontas atrás de cada bochecha
        cheek_fins = [
            (0.62, 0.04, 1.76, -16.0, 74.0, 0.15, 0.58),
            (0.58, 0.08, 1.58, -14.0, 102.0, 0.12, 0.46),
            (0.44, 0.02, 1.46, -10.0, 134.0, 0.10, 0.36),
        ]
        for c_idx, (dx, dy, dz, rx, ry, r1, depth) in enumerate(cheek_fins):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_cheek_fin_{tag}_{c_idx}",
                    5,
                    r1,
                    0.015,
                    depth,
                    (side * dx, dy, dz),
                    rotation=(math.radians(rx), math.radians(side * ry), 0.0),
                    scale=(1.0, 0.42, 1.0),
                ),
                mat_prefix,
                "body_blue",
                pal,
            )

    # 6. GRANDES BARBATANAS DORSAIS / PEITORAIS EM LEQUE PONTIAGUDO (3 PONTAS POR ASA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        wing_rays = [
            # (base_pos, tip_pos, rx, ry, rz, base_r, base_d, tip_r, tip_d)
            ((0.52, 0.36, 1.44), (0.94, 0.54, 1.72), -24.0, 56.0, -18.0, 0.18, 0.54, 0.13, 0.56),
            ((0.58, 0.40, 1.24), (1.08, 0.58, 1.32), -20.0, 82.0, -16.0, 0.20, 0.58, 0.14, 0.60),
            ((0.52, 0.38, 1.04), (0.92, 0.54, 0.94), -16.0, 108.0, -14.0, 0.17, 0.50, 0.12, 0.52),
        ]
        for w_idx, (b_loc, t_loc, rx, ry, rz, br, bd, tr, td) in enumerate(wing_rays):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_wing_base_{tag}_{w_idx}",
                    5,
                    br,
                    tr,
                    bd,
                    (side * b_loc[0], b_loc[1], b_loc[2]),
                    rotation=(math.radians(rx), math.radians(side * ry), math.radians(side * rz)),
                    scale=(1.0, 0.34, 1.0),
                ),
                mat_prefix,
                "body_blue",
                pal,
            )
            _add_part(
                parts,
                create_cone(
                    f"_tmp_wing_tip_{tag}_{w_idx}",
                    5,
                    tr,
                    0.015,
                    td,
                    (side * t_loc[0], t_loc[1], t_loc[2]),
                    rotation=(math.radians(rx), math.radians(side * ry), math.radians(side * rz)),
                    scale=(1.0, 0.32, 1.0),
                ),
                mat_prefix,
                "fin_tip",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 117. Spikehorse lado a lado."""
    specs = [
        ("Spikehorse_Shiny", (-10.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Spikehorse_Normal", (-6.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Spikehorse_Grande", (-1.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Spikehorse_Gigante", (3.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Spikehorse_Dourada_SuperRara", (10.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_spikehorse(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
