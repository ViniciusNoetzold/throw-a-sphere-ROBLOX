"""
130_Tempestwyrm_Gyarados_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "130. Tempestwyrm — Serpente Abissal (Ref: Gyarados)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Tempestwyrm_Shiny (1.0x - Paleta Lendária Gyarados Vermelho-Carmesim + Barriga Ouro-Creme)
  2. Tempestwyrm_Normal (1.0x - Serpente Marinha Azul-Oceano em S + Crista Tripla + Boca Feroz)
  3. Tempestwyrm_Grande (1.35x - Normal)
  4. Tempestwyrm_Gigante (1.85x - Normal)
  5. Tempestwyrm_Dourada_SuperRara (2.25x - Ouro Reluzente + Crista, Barbatanas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 formando corpo serpentino contínuo, cones 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base da curva inferior alinhada exatamente em `Z = 0.0` e boca rugindo apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.20, 0.61, 0.86, 1.0),
        "crest_teal": (0.20, 0.52, 0.66, 1.0),
        "belly_cream": (0.91, 0.85, 0.66, 1.0),
        "fin_white": (0.89, 0.91, 0.95, 1.0),
        "mouth_dark": (0.44, 0.16, 0.18, 1.0),
        "tongue_pink": (0.88, 0.56, 0.62, 1.0),
        "lip_cream": (0.95, 0.90, 0.72, 1.0),
        "fang_white": (0.99, 0.99, 1.00, 1.0),
        "eye_red": (0.88, 0.20, 0.18, 1.0),
        "pupil_dark": (0.08, 0.08, 0.10, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.86, 0.18, 0.18, 1.0),
        "crest_teal": (0.64, 0.12, 0.14, 1.0),
        "belly_cream": (0.96, 0.86, 0.56, 1.0),
        "fin_white": (0.95, 0.94, 0.92, 1.0),
        "mouth_dark": (0.38, 0.10, 0.14, 1.0),
        "tongue_pink": (0.92, 0.56, 0.62, 1.0),
        "lip_cream": (0.98, 0.90, 0.64, 1.0),
        "fang_white": (0.99, 0.99, 1.00, 1.0),
        "eye_red": (0.98, 0.78, 0.18, 1.0),
        "pupil_dark": (0.08, 0.08, 0.10, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.98, 0.78, 0.14, 1.0),
        "crest_teal": (0.10, 0.92, 1.00, 1.0),
        "belly_cream": (1.00, 0.93, 0.54, 1.0),
        "fin_white": (0.10, 0.92, 1.00, 1.0),
        "mouth_dark": (0.42, 0.24, 0.04, 1.0),
        "tongue_pink": (0.96, 0.74, 0.24, 1.0),
        "lip_cream": (1.00, 0.94, 0.66, 1.0),
        "fang_white": (1.00, 0.99, 0.92, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.36, 0.52, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _orient_z_to_vec(dx: float, dy: float, dz: float):
    horiz = math.sqrt(dx * dx + dy * dy)
    pitch = math.atan2(horiz, dz)
    yaw = math.atan2(dx, -dy)
    return (pitch, 0.0, yaw)


def build_tempestwyrm(
    name: str = "Tempestwyrm_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 130. Tempestwyrm (Ref: Gyarados):
      - Corpo longo serpentino azul-oceano segmentado em majestosa curva S com placas creme na barriga
      - Cabeça dracônica feroz no topo com boca escancarada, língua rosa, lábios creme e 4 presas brancas
      - Crista tripla em tridente azul-petróleo na testa, olhos vermelhos raivosos e barbelas longas azuis
      - Barbatanas brancas pontudas nas bochechas e 4 cristas dorsais brancas serrilhadas ao longo dos anéis
      - Cauda em leque azul e branco na extremidade traseira direita
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Wyrm_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Wyrm_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Wyrm_Norm"

    parts = []

    # 1. CORPO SERPENTINO SEGMENTADO EM CURVA 'S' (15 ANÉIS SOBREPOSTOS + BARRIGA CREME)
    # Começa no pescoço superior, desce pelo peito até o chão (Z=0.45), sobe num arco a +X e cai na cauda
    spine_segments = [
        # (x, y, z, radius, belly_dir_x, belly_dir_y, belly_dir_z)
        (-0.24, -0.02, 2.38, 0.36, 0.0, -0.18, -0.06),
        (-0.20, 0.14, 2.02, 0.40, 0.0, -0.22, -0.02),
        (-0.22, 0.16, 1.62, 0.42, 0.0, -0.24, 0.0),
        (-0.24, 0.10, 1.22, 0.43, 0.0, -0.24, 0.0),
        (-0.20, 0.02, 0.82, 0.44, 0.0, -0.24, -0.04),
        (-0.04, 0.08, 0.48, 0.42, -0.06, -0.20, -0.10),
        (0.24, 0.24, 0.40, 0.39, -0.06, -0.18, -0.14),
        (0.52, 0.40, 0.56, 0.36, -0.08, -0.16, -0.10),
        (0.76, 0.52, 0.86, 0.33, -0.08, -0.16, -0.08),
        (0.98, 0.58, 1.18, 0.30, -0.06, -0.16, -0.08),
        (1.22, 0.56, 1.32, 0.27, -0.04, -0.14, -0.10),
        (1.42, 0.48, 1.16, 0.24, -0.04, -0.14, -0.08),
        (1.50, 0.42, 0.90, 0.20, -0.06, -0.12, -0.04),
        (1.48, 0.38, 0.66, 0.16, -0.06, -0.10, -0.02),
    ]
    for s_idx, (sx, sy, sz, rad, bx, by, bz) in enumerate(spine_segments):
        _add_part(
            parts,
            create_icosphere(f"_tmp_coil_{s_idx}", 2, rad, (sx, sy, sz), scale=(1.04, 1.04, 0.96)),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Placa creme na barriga de cada segmento (detalhe marcante do Gyarados)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_belly_{s_idx}",
                2,
                rad * 0.78,
                (sx + bx, sy + by, sz + bz),
                scale=(0.88, 0.72, 0.90),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )
        # Manchas ovais laterais creme nos segmentos da curva traseira
        if s_idx in (6, 7, 8, 9, 10):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_spot_{s_idx}",
                    1,
                    rad * 0.34,
                    (sx - rad * 0.35, sy - rad * 0.78, sz + rad * 0.15),
                    scale=(0.90, 0.45, 0.65),
                ),
                mat_prefix,
                "belly_cream",
                pal,
            )

    # Capuz/placa dorsal azul larga atrás do pescoço (como na arte!)
    _add_part(
        parts,
        create_icosphere("_tmp_neck_hood", 2, 0.42, (-0.18, 0.28, 2.34), scale=(1.08, 1.12, 0.74)),
        mat_prefix,
        "body_blue",
        pal,
    )

    # 2. QUATRO CRISTAS DORSAIS BRANCAS PONTUDAS AO LONGO DOS ANÉIS
    dorsal_fins = [
        # (x, y, z, rx, ry, rz, size_scale)
        (-0.20, 0.24, 2.86, 12.0, -8.0, 0.0, 1.00),
        (-0.12, 0.56, 2.26, 48.0, 14.0, 0.0, 0.80),
        (1.26, 0.66, 1.72, 16.0, 22.0, 0.0, 0.88),
        (1.66, 0.52, 1.12, 18.0, 68.0, 0.0, 0.58),
    ]
    for f_idx, (fx, fy, fz, frx, fry, frz, fsc) in enumerate(dorsal_fins):
        # Espinho central alto + 2 espinhos laterais menores em leque
        for sub_idx, (off_x, off_z, ang_y, sub_h) in enumerate([(-0.10, -0.06, -24.0, 0.42), (0.0, 0.06, 0.0, 0.64), (0.10, -0.06, 24.0, 0.42)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_dorsal_fin_{f_idx}_{sub_idx}",
                    5,
                    0.11 * fsc,
                    0.015,
                    sub_h * fsc,
                    (fx + off_x * fsc, fy, fz + off_z * fsc),
                    rotation=(math.radians(frx), math.radians(fry + ang_y), math.radians(frz)),
                    scale=(0.55, 0.45, 1.0),
                ),
                mat_prefix,
                "fin_white",
                pal,
            )

    # 3. CAUDA EM LEQUE AZUL E BRANCO NA PONTA DIREITA
    tx, ty, tz = 1.44, 0.36, 0.42
    tail_rays = [
        (-0.20, -24.0, "body_blue"),
        (0.00, 0.0, "fin_white"),
        (0.20, 24.0, "body_blue"),
    ]
    for r_idx, (dx, ry_deg, mkey) in enumerate(tail_rays):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_fan_{r_idx}",
                5,
                0.18 if mkey == "fin_white" else 0.11,
                0.02,
                0.62,
                (tx + dx, ty, tz - 0.16),
                rotation=(math.radians(174.0), math.radians(ry_deg), 0.0),
                scale=(1.10, 0.36, 1.0),
            ),
            mat_prefix,
            mkey,
            pal,
        )

    # 4. CABEÇA DRACÔNICA FEROZ + BOCA ESCANCARADA + 4 PRESAS + CRISTA TRIPLA NA TESTA
    hx, hy, hz = -0.34, -0.44, 2.48
    # Crânio azul largo
    _add_part(
        parts,
        create_icosphere("_tmp_head_skull", 2, 0.44, (hx, hy, hz), scale=(1.04, 1.18, 0.88)),
        mat_prefix,
        "body_blue",
        pal,
    )
    # Focinho superior azul
    _add_part(
        parts,
        create_icosphere("_tmp_snout_top", 2, 0.32, (hx, hy - 0.36, hz - 0.02), scale=(1.06, 0.92, 0.56)),
        mat_prefix,
        "body_blue",
        pal,
    )
    # Lábio superior creme
    _add_part(
        parts,
        create_icosphere("_tmp_lip_upper", 2, 0.31, (hx, hy - 0.42, hz - 0.12), scale=(1.08, 0.86, 0.24)),
        mat_prefix,
        "lip_cream",
        pal,
    )
    # Cavidade enorme da boca escancarada
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_cav",
            2,
            0.34,
            (hx, hy - 0.32, hz - 0.34),
            rotation=(math.radians(14.0), 0.0, 0.0),
            scale=(0.86, 0.86, 1.12),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )
    # Língua rosa dentro da boca aberta
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tongue",
            2,
            0.22,
            (hx, hy - 0.38, hz - 0.46),
            rotation=(math.radians(24.0), 0.0, 0.0),
            scale=(0.82, 0.90, 0.65),
        ),
        mat_prefix,
        "tongue_pink",
        pal,
    )
    # Mandíbula inferior escancarada (externo azul + lábio creme)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_jaw_lower",
            2,
            0.28,
            (hx, hy - 0.38, hz - 0.66),
            rotation=(math.radians(-18.0), 0.0, 0.0),
            scale=(0.94, 1.04, 0.34),
        ),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_lip_lower",
            2,
            0.26,
            (hx, hy - 0.44, hz - 0.62),
            rotation=(math.radians(-14.0), 0.0, 0.0),
            scale=(0.96, 0.94, 0.22),
        ),
        mat_prefix,
        "lip_cream",
        pal,
    )
    # 4 presas brancas afiadas (2 superiores descendo, 2 inferiores subindo)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_top_{tag}",
                4,
                0.048,
                0.008,
                0.17,
                (hx + side * 0.16, hy - 0.56, hz - 0.22),
                rotation=(math.radians(180.0), 0.0, 0.0),
            ),
            mat_prefix,
            "fang_white",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_bot_{tag}",
                4,
                0.044,
                0.008,
                0.15,
                (hx + side * 0.14, hy - 0.56, hz - 0.54),
            ),
            mat_prefix,
            "fang_white",
            pal,
        )

    # Olhos vermelhos ferozes sob sobrancelha fechada
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                1,
                0.11,
                (hx + side * 0.22, hy - 0.38, hz + 0.10),
                rotation=(0.0, math.radians(side * 16.0), math.radians(side * -22.0)),
                scale=(1.10, 0.52, 0.72),
            ),
            mat_prefix,
            "fang_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.058,
                (hx + side * 0.20, hy - 0.44, hz + 0.09),
                scale=(0.82, 0.55, 1.05),
            ),
            mat_prefix,
            "eye_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.026,
                (hx + side * 0.20, hy - 0.47, hz + 0.09),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # Crista tripla em tridente na testa (azul-petróleo, assinatura do Gyarados!)
    crest_prongs = [
        (0.00, 0.38, 0.0, 0.14, 0.78),
        (-0.34, 0.24, -44.0, 0.12, 0.64),
        (0.34, 0.24, 44.0, 0.12, 0.64),
    ]
    for c_idx, (dx, dz, ry_deg, rad, dep) in enumerate(crest_prongs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_crest_{c_idx}",
                6,
                rad,
                0.016,
                dep,
                (hx + dx, hy - 0.22, hz + 0.22 + dz),
                rotation=(math.radians(24.0), math.radians(ry_deg), 0.0),
                scale=(0.82, 0.65, 1.0),
            ),
            mat_prefix,
            "crest_teal",
            pal,
        )

    # Barbatanas brancas em leque nas bochechas + bigodes longos azuis curvados
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_cheek_fin_{tag}",
                5,
                0.24,
                0.02,
                0.56,
                (hx + side * 0.56, hy - 0.02, hz - 0.06),
                rotation=(math.radians(16.0), math.radians(side * 86.0), math.radians(side * 18.0)),
                scale=(0.35, 1.15, 1.0),
            ),
            mat_prefix,
            "fin_white",
            pal,
        )
        # Bigode longo azul descendo em espiral graciosa
        w_pts = [
            (hx + side * 0.30, hy - 0.30, hz - 0.22),
            (hx + side * 0.46, hy - 0.38, hz - 0.44),
            (hx + side * 0.48, hy - 0.42, hz - 0.78),
            (hx + side * 0.38, hy - 0.44, hz - 1.02),
            (hx + side * 0.50, hy - 0.46, hz - 1.06),
        ]
        for s_idx in range(len(w_pts) - 1):
            p0, p1 = w_pts[s_idx], w_pts[s_idx + 1]
            mx, my, mz = (p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5
            dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
            seg_len = math.sqrt(dx * dx + dy * dy + dz * dz) + 0.04
            _add_part(
                parts,
                create_cylinder(
                    f"_tmp_barbel_{tag}_{s_idx}",
                    6,
                    0.032,
                    seg_len,
                    (mx, my, mz),
                    rotation=_orient_z_to_vec(dx, dy, dz),
                ),
                mat_prefix,
                "body_blue",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 130. Tempestwyrm lado a lado."""
    specs = [
        ("Tempestwyrm_Shiny", (-10.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Tempestwyrm_Normal", (-6.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Tempestwyrm_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Tempestwyrm_Gigante", (5.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Tempestwyrm_Dourada_SuperRara", (14.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_tempestwyrm(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
