"""
073_Krakenorb_Tentacruel_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "073. Krakenorb — Kraken das Gemas (Ref: Tentacruel)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Krakenorb_Shiny (1.0x - Paleta Shiny Roxo-Índigo + Gemas Verde-Esmeralda)
  2. Krakenorb_Normal (1.0x - Domo Azul-Oceano + 2 Gemas Rubi Gigantes + Bicos Azuis + 10 Tentáculos)
  3. Krakenorb_Grande (1.35x - Normal)
  4. Krakenorb_Gigante (1.85x - Normal)
  5. Krakenorb_Dourada_SuperRara (2.25x - Ouro Reluzente + Gemas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para domo/gemas, cones/cilindros 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pontas inferiores dos tentáculos alinhadas em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "dome_blue": (0.34, 0.72, 0.90, 1.0),
        "dome_shade": (0.22, 0.54, 0.76, 1.0),
        "gem_ruby": (0.84, 0.20, 0.34, 1.0),
        "gem_shine": (0.98, 0.58, 0.68, 1.0),
        "face_black": (0.12, 0.13, 0.16, 1.0),
        "tentacle_main": (0.62, 0.58, 0.52, 1.0),
        "tentacle_back": (0.46, 0.45, 0.50, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "pupil_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "shiny_palette": {
        "dome_blue": (0.50, 0.44, 0.84, 1.0),
        "dome_shade": (0.36, 0.30, 0.68, 1.0),
        "gem_ruby": (0.18, 0.86, 0.46, 1.0),
        "gem_shine": (0.62, 0.99, 0.74, 1.0),
        "face_black": (0.12, 0.11, 0.18, 1.0),
        "tentacle_main": (0.64, 0.64, 0.70, 1.0),
        "tentacle_back": (0.46, 0.48, 0.56, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "pupil_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "dome_blue": (0.98, 0.78, 0.14, 1.0),
        "dome_shade": (0.86, 0.62, 0.10, 1.0),
        "gem_ruby": (0.10, 0.92, 1.00, 1.0),
        "gem_shine": (0.76, 0.99, 1.00, 1.0),
        "face_black": (0.34, 0.24, 0.05, 1.0),
        "tentacle_main": (0.94, 0.74, 0.22, 1.0),
        "tentacle_back": (0.78, 0.56, 0.12, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.38, 0.52, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_segment(parts: list, name: str, p0: tuple, p1: tuple, r0: float, r1: float, mat_prefix: str, mat_key: str, pal: dict, verts: int = 6):
    dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    if length < 1e-5:
        return None
    mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
    phi = math.atan2(dx, -dy)
    theta = math.acos(max(-1.0, min(1.0, dz / length)))
    obj = create_cone(name, verts, r0, r1, length + 0.04, mid, rotation=(theta, 0.0, phi))
    return _add_part(parts, obj, mat_prefix, mat_key, pal)


def build_krakenorb(
    name: str = "Krakenorb_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 073. Krakenorb (Ref: Tentacruel):
      - Elmo/domo largo azul com crista central e abas laterais aerodinâmicas
      - 2 gemas rubi gigantes lado a lado + 1 gema rubi central na testa com brilhos
      - Núcleo facial escuro com olhos brancos ferozes sob a aba do elmo
      - 2 mandíbulas/pinças azuis grandes curvadas pendendo na frente
      - Feixe imponente de 10 tentáculos fluidos acinzentados em leque
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Kraken_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Kraken_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Kraken_Norm"

    parts = []

    # 1. ELMO / DOMO LARGO COM CRISTA CENTRAL E ABAS LATERAIS
    _add_part(
        parts,
        create_icosphere("_tmp_helmet_core", 2, 0.84, (0.0, 0.04, 1.82), scale=(1.18, 0.96, 0.88)),
        mat_prefix,
        "dome_blue",
        pal,
    )
    # Crista vertical central separando as duas gemas gigantes
    _add_part(
        parts,
        create_icosphere("_tmp_crest_ridge", 2, 0.44, (0.0, -0.06, 2.02), scale=(0.48, 1.48, 1.24)),
        mat_prefix,
        "dome_blue",
        pal,
    )
    # Aba frontal em V apontando para baixo sobre os olhos
    _add_part(
        parts,
        create_cone(
            "_tmp_front_visor",
            6,
            0.96,
            0.56,
            0.44,
            (0.0, -0.08, 1.56),
            scale=(1.22, 0.94, 0.85),
        ),
        mat_prefix,
        "dome_blue",
        pal,
    )
    # Abas laterais pontudas em formato de chapéu-elmo (esquerda e direita)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_brim_wing_{tag}",
                6,
                0.38,
                0.08,
                0.76,
                (side * 1.14, 0.04, 1.56),
                rotation=(math.radians(8.0), math.radians(side * 78.0), math.radians(side * -10.0)),
                scale=(0.82, 1.18, 1.0),
            ),
            mat_prefix,
            "dome_blue",
            pal,
        )

    # 2. GEMAS RUBI GIGANTES (2 GRANDES NO TOPO + 1 NA TESTA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_giant_gem_{tag}",
                2,
                0.56,
                (side * 0.56, -0.10, 2.02),
                rotation=(math.radians(16.0), math.radians(side * 24.0), math.radians(side * -14.0)),
                scale=(0.88, 0.96, 1.02),
            ),
            mat_prefix,
            "gem_ruby",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_giant_gem_shine_{tag}",
                1,
                0.18,
                (side * 0.58, -0.44, 2.28),
                scale=(0.82, 0.58, 0.86),
            ),
            mat_prefix,
            "gem_shine",
            pal,
        )
    # Gema central frontal
    _add_part(
        parts,
        create_icosphere(
            "_tmp_center_gem",
            2,
            0.24,
            (0.0, -0.82, 1.72),
            scale=(0.94, 0.68, 1.06),
        ),
        mat_prefix,
        "gem_ruby",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_center_gem_shine",
            1,
            0.08,
            (-0.04, -0.95, 1.79),
            scale=(0.85, 0.50, 0.90),
        ),
        mat_prefix,
        "gem_shine",
        pal,
    )

    # 3. ROSTO ESCURO SOB O ELMO + OLHOS BRANCOS FEROZES
    _add_part(
        parts,
        create_icosphere("_tmp_face_core", 2, 0.66, (0.0, 0.02, 1.24), scale=(1.08, 0.94, 0.78)),
        mat_prefix,
        "face_black",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.19,
                (side * 0.28, -0.64, 1.24),
                rotation=(0.0, math.radians(side * 14.0), math.radians(side * -18.0)),
                scale=(1.24, 0.48, 0.62),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_pupil_{tag}",
                (0.052, 0.08, 0.15),
                (side * 0.24, -0.72, 1.24),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 4. DUAS GRANDES MANDÍBULAS/PINÇAS AZUIS CURVADAS NA FRENTE
    # Pinça frontal esquerda (grande bico curvo descendo pela frente)
    mandible_L = [
        (-0.18, -0.52, 1.18),
        (-0.34, -0.68, 0.80),
        (-0.30, -0.64, 0.44),
        (-0.02, -0.54, 0.16),
    ]
    m_radii_L = [0.20, 0.18, 0.14, 0.03]
    for i in range(len(mandible_L) - 1):
        _add_segment(parts, f"_tmp_mand_L_{i}", mandible_L[i], mandible_L[i + 1], m_radii_L[i], m_radii_L[i + 1], mat_prefix, "dome_blue", pal, verts=6)

    # Pinça direita curva espelhada
    mandible_R = [
        (0.28, -0.34, 1.14),
        (0.48, -0.36, 0.78),
        (0.46, -0.30, 0.44),
        (0.24, -0.24, 0.18),
    ]
    m_radii_R = [0.18, 0.15, 0.11, 0.028]
    for i in range(len(mandible_R) - 1):
        _add_segment(parts, f"_tmp_mand_R_{i}", mandible_R[i], mandible_R[i + 1], m_radii_R[i], m_radii_R[i + 1], mat_prefix, "dome_shade", pal, verts=6)

    # 5. FEIXE DE 10 TENTÁCULOS FLUIDOS EM LEQUE (2 LONGOS EXTERNOS + 8 INTERNOS)
    tentacle_paths = [
        # (mat_key, points, radii)
        # Tentáculo externo esquerdo (longo chicote com ponta em remo)
        ("tentacle_main", [(-0.44, -0.18, 1.14), (-0.96, -0.26, 0.94), (-1.42, -0.28, 0.80), (-1.62, -0.22, 0.46)], [0.09, 0.082, 0.09, 0.11]),
        # Tentáculo externo direito (longo chicote varrendo para fora)
        ("tentacle_main", [(0.44, -0.18, 1.14), (0.98, -0.28, 0.92), (1.46, -0.26, 0.84), (1.68, -0.18, 0.56)], [0.09, 0.082, 0.09, 0.11]),
        # Tentáculos intermediários frontais/laterais
        ("tentacle_main", [(-0.40, -0.10, 1.10), (-0.82, -0.16, 0.68), (-1.04, -0.18, 0.26)], [0.08, 0.074, 0.068]),
        ("tentacle_main", [(-0.26, -0.06, 1.06), (-0.62, -0.10, 0.56), (-0.72, -0.10, 0.14)], [0.078, 0.072, 0.064]),
        ("tentacle_main", [(0.36, -0.10, 1.10), (0.78, -0.16, 0.68), (1.06, -0.16, 0.24)], [0.08, 0.074, 0.068]),
        ("tentacle_main", [(0.24, -0.06, 1.06), (0.58, -0.10, 0.56), (0.76, -0.08, 0.08)], [0.078, 0.072, 0.064]),
        # Tentáculos traseiros para volume cheio e profundidade
        ("tentacle_back", [(-0.36, 0.18, 1.10), (-0.90, 0.24, 0.68), (-1.28, 0.26, 0.30)], [0.08, 0.072, 0.062]),
        ("tentacle_back", [(-0.14, 0.24, 1.06), (-0.36, 0.30, 0.56), (-0.42, 0.32, 0.16)], [0.078, 0.070, 0.060]),
        ("tentacle_back", [(0.16, 0.24, 1.06), (0.40, 0.30, 0.56), (0.48, 0.30, 0.16)], [0.078, 0.070, 0.060]),
        ("tentacle_back", [(0.38, 0.18, 1.10), (0.94, 0.24, 0.68), (1.30, 0.24, 0.30)], [0.08, 0.072, 0.062]),
    ]

    for t_idx, (m_key, pts, rads) in enumerate(tentacle_paths):
        for s_idx in range(len(pts) - 1):
            _add_segment(parts, f"_tmp_tent_{t_idx}_{s_idx}", pts[s_idx], pts[s_idx + 1], rads[s_idx], rads[s_idx + 1], mat_prefix, m_key, pal, verts=6)
            _add_part(
                parts,
                create_icosphere(f"_tmp_tent_tip_{t_idx}_{s_idx}", 1, rads[s_idx + 1] * 1.02, pts[s_idx + 1]),
                mat_prefix,
                m_key,
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 073. Krakenorb lado a lado."""
    specs = [
        ("Krakenorb_Shiny", (-11.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Krakenorb_Normal", (-6.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Krakenorb_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Krakenorb_Gigante", (6.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Krakenorb_Dourada_SuperRara", (15.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_krakenorb(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
