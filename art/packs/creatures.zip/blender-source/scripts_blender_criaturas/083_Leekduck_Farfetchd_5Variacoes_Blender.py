"""
083_Leekduck_Farfetchd_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "083. Leekduck — Pato Esgrimista (Ref: Farfetchd)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Leekduck_Shiny (1.0x - Paleta Shiny Plumagem Rosa-Avelã + Alho-Poró Verde-Lima Vivo)
  2. Leekduck_Normal (1.0x - Pato Marrom-Avelã + Peito Creme + Máscara Preta em V + Alho-Poró)
  3. Leekduck_Grande (1.35x - Normal)
  4. Leekduck_Gigante (1.85x - Normal)
  5. Leekduck_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Máscara e Folhas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2, cones e cilindros facetados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés palmípedes apoiados exatamente em `Z = 0.0` e frente/bico apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_brown": (0.64, 0.56, 0.52, 1.0),
        "body_shade": (0.50, 0.43, 0.40, 1.0),
        "belly_cream": (0.93, 0.91, 0.84, 1.0),
        "beak_yellow": (0.96, 0.76, 0.20, 1.0),
        "beak_dark": (0.78, 0.58, 0.14, 1.0),
        "mask_black": (0.12, 0.12, 0.14, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "leek_white": (0.96, 0.97, 0.90, 1.0),
        "leek_light": (0.48, 0.78, 0.24, 1.0),
        "leek_green": (0.24, 0.54, 0.20, 1.0),
    },
    "shiny_palette": {
        "body_brown": (0.76, 0.54, 0.56, 1.0),
        "body_shade": (0.60, 0.40, 0.44, 1.0),
        "belly_cream": (0.96, 0.92, 0.88, 1.0),
        "beak_yellow": (0.98, 0.72, 0.18, 1.0),
        "beak_dark": (0.80, 0.54, 0.12, 1.0),
        "mask_black": (0.14, 0.12, 0.16, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "leek_white": (0.97, 0.98, 0.90, 1.0),
        "leek_light": (0.56, 0.86, 0.26, 1.0),
        "leek_green": (0.30, 0.64, 0.22, 1.0),
    },
    "golden_super_rare_palette": {
        "body_brown": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.62, 0.10, 1.0),
        "belly_cream": (1.00, 0.94, 0.56, 1.0),
        "beak_yellow": (1.00, 0.88, 0.30, 1.0),
        "beak_dark": (0.82, 0.62, 0.12, 1.0),
        "mask_black": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "leek_white": (1.00, 0.96, 0.72, 1.0),
        "leek_light": (0.28, 0.96, 1.00, 1.0),
        "leek_green": (0.06, 0.72, 0.90, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel angular e Flat Shading."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_leekduck(
    name: str = "Leekduck_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 083. Leekduck (Ref: Farfetch'd):
      - Corpo compacto de pato marrom-avelã com peito/barriga creme-claro e cauda pontuda
      - Cabeça redonda com 3 penas de topete no topo, máscara preta icônica em V na testa
      - Olhos expressivos brancos com pupilas focadas e bico largo dourado de pato
      - Asa direita erguida em leque (penas creme/marrom) + asa esquerda cruzando o peito segurando o alho-poró
      - Grande talo de alho-poró (base branca + folhas duplas verde-lima e verde-escuro)
      - Pés palmípedes amarelos firmes em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Leek_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Leek_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Leek_Norm"

    parts = []

    # 1. CORPO COMPACTO DE PATO + PEITO CREME + CAUDA
    _add_part(
        parts,
        create_icosphere(
            "_tmp_torso",
            2,
            0.70,
            (0.06, 0.12, 0.90),
            rotation=(math.radians(-16.0), 0.0, 0.0),
            scale=(0.90, 1.12, 0.92),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_belly",
            2,
            0.60,
            (0.04, 0.00, 0.72),
            rotation=(math.radians(-10.0), 0.0, 0.0),
            scale=(0.94, 1.02, 0.82),
        ),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # Penas do pescoço unindo cabeça e corpo
    _add_part(
        parts,
        create_cylinder(
            "_tmp_neck",
            8,
            0.38,
            0.46,
            (0.02, -0.06, 1.32),
            rotation=(math.radians(10.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Cauda pontuda traseira
    _add_part(
        parts,
        create_cone(
            "_tmp_tail",
            6,
            0.24,
            0.02,
            0.54,
            (0.14, 0.90, 1.06),
            rotation=(math.radians(-58.0), math.radians(10.0), 0.0),
            scale=(0.82, 1.0, 1.0),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )

    # 2. CABEÇA + TOPETE DE 3 PENAS + MÁSCARA PRETA EM V + OLHOS + BICO LARGO
    _add_part(
        parts,
        create_icosphere(
            "_tmp_head",
            2,
            0.52,
            (0.0, -0.14, 1.66),
            scale=(0.96, 1.04, 1.06),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Topete com 3 penas (central mais alta)
    crest_specs = [
        ("L", (-0.18, -0.12, 2.24), (math.radians(-6.0), math.radians(-24.0), 0.0), 0.13, 0.42),
        ("C", (0.00, -0.10, 2.34), (math.radians(-8.0), math.radians(2.0), 0.0), 0.14, 0.56),
        ("R", (0.18, -0.12, 2.22), (math.radians(-6.0), math.radians(28.0), 0.0), 0.12, 0.38),
    ]
    for tag, loc, rot, r1, dep in crest_specs:
        _add_part(
            parts,
            create_cone(
                f"_tmp_crest_{tag}",
                6,
                r1,
                0.04,
                dep,
                loc,
                rotation=rot,
                scale=(1.0, 0.48, 1.0),
            ),
            mat_prefix,
            "body_brown",
            pal,
        )

    # Máscara preta em V na testa (assinatura visual do Farfetch'd!)
    _add_part(
        parts,
        create_cube(
            "_tmp_v_mask_L",
            (0.28, 0.08, 0.09),
            (-0.11, -0.63, 1.84),
            rotation=(math.radians(-10.0), math.radians(-38.0), math.radians(-14.0)),
        ),
        mat_prefix,
        "mask_black",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_v_mask_R",
            (0.28, 0.08, 0.09),
            (0.11, -0.63, 1.84),
            rotation=(math.radians(-10.0), math.radians(38.0), math.radians(14.0)),
        ),
        mat_prefix,
        "mask_black",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_v_mask_tip",
            4,
            0.09,
            0.02,
            0.14,
            (0.0, -0.66, 1.74),
            rotation=(math.radians(176.0), 0.0, 0.0),
            scale=(1.0, 0.55, 1.0),
        ),
        mat_prefix,
        "mask_black",
        pal,
    )

    # Olhos expressivos determinados
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_w_{tag}",
                2,
                0.155,
                (side * 0.22, -0.56, 1.70),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(0.76, 0.44, 1.18),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_p_{tag}",
                1,
                0.085,
                (side * 0.22, -0.63, 1.70),
                scale=(0.66, 0.48, 1.16),
            ),
            mat_prefix,
            "mask_black",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_sh_{tag}",
                1,
                0.032,
                (side * 0.20, -0.67, 1.75),
                scale=(0.8, 0.5, 1.0),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # Bico largo e achatado de pato (dourado)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_beak_upper",
            2,
            0.28,
            (-0.02, -0.78, 1.48),
            rotation=(math.radians(10.0), 0.0, math.radians(-6.0)),
            scale=(1.22, 1.38, 0.42),
        ),
        mat_prefix,
        "beak_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_beak_bridge",
            2,
            0.20,
            (-0.01, -0.64, 1.54),
            scale=(1.02, 0.90, 0.62),
        ),
        mat_prefix,
        "beak_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_beak_lower",
            2,
            0.23,
            (-0.02, -0.75, 1.40),
            rotation=(math.radians(6.0), 0.0, math.radians(-6.0)),
            scale=(1.10, 1.24, 0.30),
        ),
        mat_prefix,
        "beak_dark",
        pal,
    )

    # 3. ASA DIREITA (ESQUERDA DA TELA, -X) ERGUIDA EM LEQUE COM PENAS CREME/MARROM
    wing_r_feathers = [
        ((-0.56, -0.02, 1.56), (math.radians(-8.0), math.radians(-24.0), math.radians(-8.0)), 0.16, 0.78, "belly_cream"),
        ((-0.68, -0.06, 1.40), (math.radians(-6.0), math.radians(-42.0), math.radians(-8.0)), 0.15, 0.72, "belly_cream"),
        ((-0.74, -0.08, 1.22), (math.radians(-4.0), math.radians(-58.0), math.radians(-8.0)), 0.14, 0.62, "belly_cream"),
        ((-0.54, 0.08, 1.48), (math.radians(-8.0), math.radians(-28.0), math.radians(-6.0)), 0.17, 0.70, "body_brown"),
    ]
    for f_idx, (loc, rot, r1, dep, mkey) in enumerate(wing_r_feathers):
        _add_part(
            parts,
            create_cone(
                f"_tmp_wingR_f_{f_idx}",
                6,
                r1,
                0.05,
                dep,
                loc,
                rotation=rot,
                scale=(0.82, 0.34, 1.0),
            ),
            mat_prefix,
            mkey,
            pal,
        )
    _add_part(
        parts,
        create_icosphere("_tmp_wingR_sh", 2, 0.28, (-0.48, -0.04, 1.12), scale=(0.9, 1.0, 1.1)),
        mat_prefix,
        "body_brown",
        pal,
    )

    # 4. ASA ESQUERDA (+X) CRUZANDO À FRENTE PARA SEGURAR O ALHO-PORÓ (POSE ICÔNICA)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_wingL_sh",
            2,
            0.34,
            (0.56, -0.08, 0.98),
            scale=(0.88, 1.10, 1.04),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Braço da asa atravessando abaixo do bico (não obstrui o rosto!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_wingL_mid",
            2,
            0.36,
            (0.06, -0.58, 0.96),
            rotation=(0.0, 0.0, math.radians(-12.0)),
            scale=(1.68, 0.62, 0.82),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    # 3 dedos-penas envolvendo o talo do alho-poró
    for f_idx, dz in enumerate((0.15, 0.0, -0.15)):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_wingL_finger_{f_idx}",
                2,
                0.15,
                (-0.56, -0.68, 0.96 + dz),
                rotation=(0.0, math.radians(-14.0), math.radians(-18.0)),
                scale=(1.55, 0.85, 0.56),
            ),
            mat_prefix,
            "body_brown" if f_idx != 2 else "body_shade",
            pal,
        )

    # 5. GRANDE TALO DE ALHO-PORÓ (BRANCO NA BASE + FOLHAS DUPLAS VERDES NO TOPO)
    leek_rot = (math.radians(-6.0), math.radians(-22.0), 0.0)
    # Base branca inferior saindo por baixo da asa
    _add_part(
        parts,
        create_cylinder(
            "_tmp_leek_bulb",
            8,
            0.105,
            0.88,
            (-0.52, -0.66, 0.66),
            rotation=leek_rot,
        ),
        mat_prefix,
        "leek_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_leek_root", 1, 0.115, (-0.36, -0.64, 0.25)),
        mat_prefix,
        "leek_white",
        pal,
    )
    # Transição verde-claro logo acima da asa
    _add_part(
        parts,
        create_cone(
            "_tmp_leek_mid",
            8,
            0.105,
            0.145,
            0.56,
            (-0.78, -0.71, 1.32),
            rotation=leek_rot,
        ),
        mat_prefix,
        "leek_light",
        pal,
    )
    # Duas folhas largas verde-escuras abrindo em V no topo
    _add_part(
        parts,
        create_cone(
            "_tmp_leek_leaf_L",
            6,
            0.13,
            0.17,
            0.76,
            (-1.10, -0.77, 1.88),
            rotation=(math.radians(-6.0), math.radians(-28.0), 0.0),
            scale=(1.0, 0.42, 1.0),
        ),
        mat_prefix,
        "leek_green",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_leek_leaf_R",
            6,
            0.13,
            0.16,
            0.72,
            (-0.88, -0.75, 1.86),
            rotation=(math.radians(-6.0), math.radians(-12.0), 0.0),
            scale=(1.0, 0.42, 1.0),
        ),
        mat_prefix,
        "leek_green",
        pal,
    )
    # Pontas arredondadas das duas folhas do alho-poró
    _add_part(
        parts,
        create_icosphere("_tmp_leek_tip_L", 1, 0.145, (-1.26, -0.80, 2.22), scale=(0.95, 0.45, 0.80)),
        mat_prefix,
        "leek_green",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_leek_tip_R", 1, 0.14, (-0.95, -0.78, 2.20), scale=(0.95, 0.45, 0.80)),
        mat_prefix,
        "leek_green",
        pal,
    )

    # 6. PERNAS E PÉS PALMÍPEDES AMARELOS APOIADOS EM Z = 0.0
    for side, fx, fy in ((-1.0, -0.22, -0.02), (1.0, 0.30, -0.08)):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_leg_{tag}",
                8,
                0.095,
                0.38,
                (fx, fy, 0.24),
                rotation=(math.radians(4.0), math.radians(side * -6.0), 0.0),
            ),
            mat_prefix,
            "beak_yellow",
            pal,
        )
        # Membrana palmípede + 3 dedos abertos no chão
        _add_part(
            parts,
            create_cone(
                f"_tmp_foot_web_{tag}",
                5,
                0.30,
                0.10,
                0.10,
                (fx, fy - 0.14, 0.05),
                rotation=(0.0, 0.0, math.radians(side * -10.0)),
                scale=(1.05, 1.25, 1.0),
            ),
            mat_prefix,
            "beak_yellow",
            pal,
        )
        for t_idx, ang in enumerate((-26.0, 0.0, 26.0)):
            rad = math.radians(ang + side * -8.0)
            tx = fx + math.sin(rad) * 0.20
            ty = fy - 0.12 - math.cos(rad) * 0.20
            _add_part(
                parts,
                create_cone(
                    f"_tmp_toe_{tag}_{t_idx}",
                    5,
                    0.068,
                    0.018,
                    0.26,
                    (tx, ty, 0.045),
                    rotation=(math.radians(-86.0), 0.0, -rad),
                    scale=(1.0, 0.65, 1.0),
                ),
                mat_prefix,
                "beak_yellow",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 083. Leekduck lado a lado."""
    specs = [
        ("Leekduck_Shiny", (-9.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Leekduck_Normal", (-5.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Leekduck_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Leekduck_Gigante", (5.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Leekduck_Dourada_SuperRara", (12.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_leekduck(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
