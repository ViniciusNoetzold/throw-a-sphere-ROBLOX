"""
041_Sonarbat_Zubat_5Variacoes_Blender.py
========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "041. Sonarbat — Morcego Cego (Ref: Zubat)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Sonarbat_Shiny (1.0x - Paleta Shiny Verde-Limão + Membranas das Asas Verde-Esmeralda)
  2. Sonarbat_Normal (1.0x - Azul-Cerúleo + Asas Roxas + Sem Olhos + 4 Presas + 2 Caudas)
  3. Sonarbat_Grande (1.35x - Normal)
  4. Sonarbat_Gigante (1.85x - Normal)
  5. Sonarbat_Dourada_SuperRara (2.25x - Ouro Reluzente + Membranas e Orelhas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para corpo e cones 6-8 lados para asas/caudas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pontas das duas caudas longas alinhadas exatamente em `Z = 0.0` e boca apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.30, 0.56, 0.78, 1.0),
        "body_shade": (0.20, 0.42, 0.62, 1.0),
        "wing_purple": (0.68, 0.40, 0.68, 1.0),
        "ear_deep": (0.44, 0.26, 0.48, 1.0),
        "mouth_dark": (0.09, 0.09, 0.12, 1.0),
        "mouth_palate": (0.26, 0.24, 0.30, 1.0),
        "fang_white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.44, 0.82, 0.24, 1.0),
        "body_shade": (0.30, 0.64, 0.16, 1.0),
        "wing_purple": (0.26, 0.62, 0.34, 1.0),
        "ear_deep": (0.18, 0.42, 0.24, 1.0),
        "mouth_dark": (0.09, 0.10, 0.10, 1.0),
        "mouth_palate": (0.26, 0.28, 0.26, 1.0),
        "fang_white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.60, 0.08, 1.0),
        "wing_purple": (0.10, 0.92, 1.00, 1.0),
        "ear_deep": (0.06, 0.58, 0.74, 1.0),
        "mouth_dark": (0.18, 0.12, 0.06, 1.0),
        "mouth_palate": (0.54, 0.38, 0.10, 1.0),
        "fang_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def _segment_between(name: str, p0: tuple, p1: tuple, r0: float, r1: float, verts: int = 6):
    """Cria um segmento cônico exato conectando p0 a p1 sem folgas ou flutuação."""
    dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
    # Alinha eixo +Z ao vetor (dx, dy, dz) usando rotação Euler XYZ (Rz @ Ry @ Rx)
    horiz = math.sqrt(dx * dx + dy * dy)
    ry = math.atan2(horiz, dz)
    rz = math.atan2(dy, dx)
    return create_cone(name, verts, r0, r1, length, mid, rotation=(0.0, ry, rz))


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_sonarbat(
    name: str = "Sonarbat_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de alta fidelidade do 041. Sonarbat (Ref: Zubat):
      - Corpo compacto azul-cerúleo sem olhos, em voo dinâmico sustentado pelas 2 longas caudas-fita
      - Boca grande aberta com 4 presas brancas afiadas (2 superiores + 2 inferiores)
      - Grandes orelhas pontiagudas com interior roxo-magenta e concha auditiva escura
      - Asas largas de morcego com estrutura óssea azul e membranas roxas recortadas em arco
      - Duas caudas finas longas em V tocando exatamente Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Sonarbat_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Sonarbat_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Sonarbat_Norm"

    parts = []

    # 1. CORPO COMPACTO OVAL SEM OLHOS (SUSPENSO SOBRE AS 2 CAUDAS LONGAS)
    _add_part(
        parts,
        create_icosphere("_tmp_body", 2, 0.44, (0.0, 0.02, 1.50), scale=(0.90, 0.80, 1.24)),
        mat_prefix,
        "body_blue",
        pal,
    )

    # 2. BOCA LARGA ABERTA SEM OLHOS + 4 PRESAS BRANCAS AFIADAS
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_cavity", 2, 0.30, (0.0, -0.26, 1.66), scale=(0.96, 0.50, 0.86)),
        mat_prefix,
        "mouth_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_inner", 1, 0.21, (0.0, -0.29, 1.56), scale=(0.92, 0.38, 0.56)),
        mat_prefix,
        "mouth_palate",
        pal,
    )
    # 2 presas superiores apontadas para baixo + 2 inferiores apontadas para cima
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_up_{tag}",
                4,
                0.048,
                0.010,
                0.14,
                (side * 0.13, -0.37, 1.82),
                rotation=(math.radians(180.0), math.radians(side * 8.0), 0.0),
            ),
            mat_prefix,
            "fang_white",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_lo_{tag}",
                4,
                0.048,
                0.010,
                0.13,
                (side * 0.15, -0.38, 1.50),
                rotation=(0.0, math.radians(side * -10.0), 0.0),
            ),
            mat_prefix,
            "fang_white",
            pal,
        )

    # 3. ORELHAS GRANDES DE MORCEGO COM INTERIOR ROXO-MAGENTA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_out_{tag}",
                6,
                0.28,
                0.03,
                0.68,
                (side * 0.42, -0.02, 2.08),
                rotation=(math.radians(-6.0), math.radians(side * 46.0), math.radians(side * -12.0)),
                scale=(1.0, 0.46, 1.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_in_{tag}",
                5,
                0.20,
                0.022,
                0.52,
                (side * 0.41, -0.10, 2.07),
                rotation=(math.radians(-6.0), math.radians(side * 46.0), math.radians(side * -12.0)),
                scale=(0.94, 0.28, 1.0),
            ),
            mat_prefix,
            "wing_purple",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ear_lobe_{tag}",
                1,
                0.12,
                (side * 0.28, -0.12, 1.94),
                scale=(0.95, 0.42, 0.95),
            ),
            mat_prefix,
            "ear_deep",
            pal,
        )

    # 4. ASAS LARGAS MEMBRANOSAS DE MORCEGO (ESTRUTURA ÓSSEA AZUL + MEMBRANA ROXA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Pontos-chave da asa do Zubat (completamente conectados e arqueados para cima!)
        p_shoulder = (side * 0.30, 0.06, 1.56)
        p_elbow = (side * 0.90, 0.08, 2.34)
        p_tip_outer = (side * 1.90, -0.04, 1.88)
        p_tip_mid = (side * 1.44, 0.04, 1.24)
        p_tip_inner = (side * 0.90, 0.08, 1.28)

        # Ossos azuis da borda e dedos da asa (sem haste sobrando abaixo da membrana)
        bones = [
            (p_shoulder, p_elbow, 0.068, 0.058),
            (p_elbow, p_tip_outer, 0.056, 0.026),
            (p_elbow, p_tip_mid, 0.048, 0.024),
            (p_elbow, p_tip_inner, 0.046, 0.024),
        ]
        for b_idx, (a, b, r0, r1) in enumerate(bones):
            _add_part(
                parts,
                _segment_between(f"_tmp_wbone_{tag}_{b_idx}", a, b, r0, r1, verts=6),
                mat_prefix,
                "body_blue",
                pal,
            )

        # Painéis finos de membrana roxa preenchendo perfeitamente os 3 arcos da asa
        mem_panels = [
            ((side * 0.64, 0.09, 1.62), (0.44, 0.052, 0.48), (0.0, math.radians(side * 14.0), 0.0)),
            ((side * 1.12, 0.07, 1.72), (0.42, 0.050, 0.52), (0.0, math.radians(side * -14.0), 0.0)),
            ((side * 1.48, 0.03, 1.90), (0.44, 0.048, 0.36), (0.0, math.radians(side * -32.0), 0.0)),
        ]
        for m_idx, (mloc, msc, mrot) in enumerate(mem_panels):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_wmem_{tag}_{m_idx}",
                    1,
                    1.0,
                    mloc,
                    rotation=mrot,
                    scale=msc,
                ),
                mat_prefix,
                "wing_purple",
                pal,
            )

    # 5. DUAS CAUDAS LONGAS EM FITA ESTENDENDO-SE ATÉ Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        p_top = (side * 0.16, 0.04, 1.10)
        p_bot = (side * 0.38, -0.04, 0.00)
        _add_part(
            parts,
            _segment_between(f"_tmp_tail_{tag}", p_top, p_bot, 0.075, 0.022, verts=6),
            mat_prefix,
            "body_blue",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 041. Sonarbat lado a lado."""
    specs = [
        ("Sonarbat_Shiny", (-13.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Sonarbat_Normal", (-7.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Sonarbat_Grande", (-0.9, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Sonarbat_Gigante", (7.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Sonarbat_Dourada_SuperRara", (16.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_sonarbat(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
