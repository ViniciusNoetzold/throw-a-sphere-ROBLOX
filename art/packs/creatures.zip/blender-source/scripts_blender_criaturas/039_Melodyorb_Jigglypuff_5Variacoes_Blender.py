"""
039_Melodyorb_Jigglypuff_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "039. Melodyorb — Balão Melódico (Ref: Jigglypuff)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Melodyorb_Shiny (1.0x - Paleta Shiny Rosa-Chiclete + Olhos Grandes Verde-Esmeralda)
  2. Melodyorb_Normal (1.0x - Esfera Rosa-Chiclete + Enormes Olhos Azul-Turquesa + Topete)
  3. Melodyorb_Grande (1.35x - Normal)
  4. Melodyorb_Gigante (1.85x - Normal)
  5. Melodyorb_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para silhueta perfeitamente redonda)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_pink": (0.98, 0.78, 0.86, 1.0),
        "body_shade": (0.86, 0.62, 0.74, 1.0),
        "ear_dark": (0.14, 0.14, 0.18, 1.0),
        "eye_iris": (0.08, 0.62, 0.72, 1.0),
        "eye_glow": (0.28, 0.82, 0.90, 1.0),
        "mouth_dark": (0.36, 0.20, 0.28, 1.0),
        "white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_pink": (0.99, 0.76, 0.88, 1.0),
        "body_shade": (0.88, 0.60, 0.76, 1.0),
        "ear_dark": (0.14, 0.16, 0.16, 1.0),
        "eye_iris": (0.16, 0.74, 0.36, 1.0),
        "eye_glow": (0.42, 0.92, 0.56, 1.0),
        "mouth_dark": (0.38, 0.20, 0.28, 1.0),
        "white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_pink": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.86, 0.62, 0.08, 1.0),
        "ear_dark": (0.08, 0.58, 0.72, 1.0),
        "eye_iris": (0.10, 0.92, 1.00, 1.0),
        "eye_glow": (0.64, 0.98, 1.00, 1.0),
        "mouth_dark": (0.58, 0.34, 0.06, 1.0),
        "white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_melodyorb(
    name: str = "Melodyorb_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de alta fidelidade do 039. Melodyorb (Ref: Jigglypuff):
      - Corpo esférico fofo em balão rosa-chiclete
      - Grandes orelhas triangulares felinas com interior preto/grafite bem marcante
      - Topete macio enrolado caindo sobre a testa entre os olhos
      - Enormes olhos circulares azul-turquesa (verde-esmeralda na Shiny) com esclera branca e brilho duplo
      - Sorriso pequeno delicado, bracinhos curtos e pezinhos ovais alinhados em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Melodyorb_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Melodyorb_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Melodyorb_Norm"

    parts = []

    # 1. CORPO ESFÉRICO BALÃO FOFO
    _add_part(
        parts,
        create_icosphere("_tmp_body", 2, 0.92, (0.0, 0.0, 1.04), scale=(1.04, 0.96, 0.98)),
        mat_prefix,
        "body_pink",
        pal,
    )

    # 2. TOPETE ENROLADO CAINDO NA TESTA ENTRE OS OLHOS
    tuft_nodes = [
        (0.36, (0.04, -0.22, 1.88), (1.06, 0.90, 0.96)),
        (0.32, (-0.12, -0.44, 1.74), (0.98, 0.88, 1.00)),
        (0.27, (-0.12, -0.62, 1.54), (1.04, 0.78, 0.92)),
        (0.24, (0.08, -0.66, 1.50), (1.04, 0.74, 0.88)),
        (0.18, (0.14, -0.66, 1.62), (0.94, 0.70, 0.86)),
    ]
    for idx, (rad, loc, sc) in enumerate(tuft_nodes):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tuft_{idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "body_pink",
            pal,
        )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_tuft_shade",
            8,
            0.09,
            0.06,
            (0.06, -0.78, 1.56),
            rotation=(math.radians(90.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    # 3. ORELHAS TRIANGULARES FELINAS COM INTERIOR ESCURO PROEMINENTE
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{tag}",
                5,
                0.42,
                0.04,
                0.76,
                (side * 0.74, -0.02, 1.78),
                rotation=(math.radians(-6.0), math.radians(side * 42.0), math.radians(side * -10.0)),
                scale=(1.0, 0.46, 1.0),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_in_{tag}",
                4,
                0.28,
                0.025,
                0.56,
                (side * 0.73, -0.14, 1.76),
                rotation=(math.radians(-6.0), math.radians(side * 42.0), math.radians(side * -10.0)),
                scale=(1.0, 0.28, 1.0),
            ),
            mat_prefix,
            "ear_dark",
            pal,
        )

    # 4. ENORMES OLHOS CIRCULARES AZUL-TURQUESA (VERDE-ESMERALDA NA SHINY)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        ex = side * 0.36
        # Esclera branca grande
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_sclera_{tag}",
                2,
                0.30,
                (ex, -0.74, 1.06),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(1.00, 0.42, 1.04),
            ),
            mat_prefix,
            "white",
            pal,
        )
        # Íris grande turquesa
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_iris_{tag}",
                2,
                0.225,
                (ex * 0.96, -0.82, 1.06),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(0.98, 0.36, 1.02),
            ),
            mat_prefix,
            "eye_iris",
            pal,
        )
        # Reflexo inferior luminoso ciano
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_iris_glow_{tag}",
                1,
                0.11,
                (ex * 0.96, -0.87, 0.94),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(1.10, 0.28, 0.56),
            ),
            mat_prefix,
            "eye_glow",
            pal,
        )
        # Grande brilho especular branco no canto superior
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.078,
                (ex * 0.88, -0.88, 1.16),
                scale=(0.95, 0.40, 0.95),
            ),
            mat_prefix,
            "white",
            pal,
        )

    # Sorriso pequeno e meigo
    _add_part(
        parts,
        create_icosphere(
            "_tmp_smile",
            1,
            0.095,
            (0.0, -0.88, 0.82),
            scale=(1.32, 0.28, 0.32),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )

    # 5. BRACINHOS CURTOS E ARREDONDADOS EM POSE FOFA
    # Braço esquerdo acenando para o lado
    _add_part(
        parts,
        create_icosphere(
            "_tmp_arm_L",
            2,
            0.22,
            (-0.96, -0.18, 0.88),
            rotation=(0.0, math.radians(28.0), math.radians(-18.0)),
            scale=(1.42, 0.72, 0.68),
        ),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Braço direito apontado fofo para baixo/frente
    _add_part(
        parts,
        create_icosphere(
            "_tmp_arm_R",
            2,
            0.22,
            (0.84, -0.34, 0.68),
            rotation=(math.radians(22.0), math.radians(-48.0), math.radians(20.0)),
            scale=(1.36, 0.72, 0.68),
        ),
        mat_prefix,
        "body_pink",
        pal,
    )

    # 6. PEZINHOS OVAIS LONGOS ALINHADOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.24,
                (side * 0.48, -0.20, 0.16),
                rotation=(0.0, 0.0, math.radians(side * -24.0)),
                scale=(0.86, 1.46, 0.64),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 039. Melodyorb lado a lado."""
    specs = [
        ("Melodyorb_Shiny", (-8.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Melodyorb_Normal", (-4.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Melodyorb_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Melodyorb_Gigante", (4.3, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Melodyorb_Dourada_SuperRara", (10.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_melodyorb(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
