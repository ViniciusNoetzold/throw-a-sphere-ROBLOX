"""
076_Megaboulder_Golem_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "076. Megaboulder — Titã Esférico (Ref: Golem)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Megaboulder_Shiny (1.0x - Paleta Shiny Casco Terracota-Bronze + Pele Ocre-Dourada)
  2. Megaboulder_Normal (1.0x - Casco de Placas Hexagonais Cinza-Oliva + Cabeça/Membros Reptilianos)
  3. Megaboulder_Grande (1.35x - Normal)
  4. Megaboulder_Gigante (1.85x - Normal)
  5. Megaboulder_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Garras Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (casco composto por placas poligonais salientes sobre núcleo escuro)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas pesadas com garras alinhadas em `Z = 0.0` e rosto rugindo apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "shell_plate": (0.50, 0.51, 0.46, 1.0),
        "shell_light": (0.60, 0.62, 0.56, 1.0),
        "shell_seam": (0.24, 0.23, 0.21, 1.0),
        "skin_taupe": (0.66, 0.60, 0.57, 1.0),
        "skin_shade": (0.52, 0.47, 0.45, 1.0),
        "mouth_pink": (0.86, 0.52, 0.60, 1.0),
        "mouth_dark": (0.44, 0.20, 0.26, 1.0),
        "eye_red": (0.86, 0.24, 0.22, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "pupil_dark": (0.10, 0.10, 0.12, 1.0),
        "claw_white": (0.96, 0.97, 0.99, 1.0),
    },
    "shiny_palette": {
        "shell_plate": (0.76, 0.44, 0.20, 1.0),
        "shell_light": (0.88, 0.56, 0.28, 1.0),
        "shell_seam": (0.36, 0.18, 0.08, 1.0),
        "skin_taupe": (0.82, 0.66, 0.34, 1.0),
        "skin_shade": (0.66, 0.50, 0.24, 1.0),
        "mouth_pink": (0.88, 0.52, 0.60, 1.0),
        "mouth_dark": (0.46, 0.20, 0.26, 1.0),
        "eye_red": (0.88, 0.26, 0.20, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "pupil_dark": (0.10, 0.10, 0.12, 1.0),
        "claw_white": (0.96, 0.97, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "shell_plate": (0.92, 0.70, 0.12, 1.0),
        "shell_light": (1.00, 0.86, 0.26, 1.0),
        "shell_seam": (0.46, 0.32, 0.05, 1.0),
        "skin_taupe": (0.98, 0.80, 0.18, 1.0),
        "skin_shade": (0.84, 0.62, 0.10, 1.0),
        "mouth_pink": (0.98, 0.84, 0.34, 1.0),
        "mouth_dark": (0.52, 0.34, 0.04, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (0.76, 0.99, 1.00, 1.0),
        "pupil_dark": (0.04, 0.34, 0.48, 1.0),
        "claw_white": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_oriented_plate(parts: list, name: str, center: tuple, direction: tuple, radius: float, thickness: float, mat_prefix: str, mat_key: str, pal: dict):
    """Posiciona uma placa hexagonal de rocha na superfície da esfera apontando na direção dada."""
    dx, dy, dz = direction
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    if length < 1e-5:
        return None
    nx, ny, nz = dx / length, dy / length, dz / length
    dist = 1.02
    loc = (center[0] + nx * dist, center[1] + ny * dist, center[2] + nz * dist)
    phi = math.atan2(nx, -ny)
    theta = math.acos(max(-1.0, min(1.0, nz)))
    obj = create_cone(name, 6, radius, radius * 0.80, thickness, loc, rotation=(theta, 0.0, phi))
    return _add_part(parts, obj, mat_prefix, mat_key, pal)


def build_megaboulder(
    name: str = "Megaboulder_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 076. Megaboulder (Ref: Golem):
      - Casco esférico titânico composto por núcleo escuro + 18 placas hexagonais de rocha salientes
      - Cabeça reptiliana de tartaruga projetada à frente com olhos rubi ferozes, boca aberta e 2 presas
      - Dois braços musculosos reptilianos saindo do casco com 3 garras cônicas brancas em cada mão
      - Duas pernas pesadas de pilar com pés largos e 4 garras brancas firmes em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Golem_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Golem_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Golem_Norm"

    parts = []
    shell_center = (0.0, 0.16, 1.38)

    # 1. NÚCLEO ESCURO DO CASCO + 18 PLACAS HEXAGONAIS DE ROCHA SALIENTES
    _add_part(
        parts,
        create_icosphere("_tmp_shell_core", 2, 1.05, shell_center, scale=(1.02, 1.00, 1.02)),
        mat_prefix,
        "shell_seam",
        pal,
    )

    plate_dirs = [
        # Topo e coroa superior (mais claras sob o sol)
        ((0.0, 0.0, 1.0), 0.54, 0.24, "shell_light"),
        ((-0.55, -0.52, 0.65), 0.48, 0.22, "shell_light"),
        ((0.55, -0.52, 0.65), 0.48, 0.22, "shell_light"),
        ((0.0, -0.76, 0.64), 0.46, 0.22, "shell_light"),
        ((-0.62, 0.48, 0.62), 0.50, 0.22, "shell_light"),
        ((0.62, 0.48, 0.62), 0.50, 0.22, "shell_light"),
        ((0.0, 0.78, 0.62), 0.50, 0.22, "shell_light"),
        # Faixa equatorial
        ((-0.88, -0.44, 0.12), 0.46, 0.20, "shell_plate"),
        ((0.88, -0.44, 0.12), 0.46, 0.20, "shell_plate"),
        ((-0.94, 0.30, 0.08), 0.48, 0.20, "shell_plate"),
        ((0.94, 0.30, 0.08), 0.48, 0.20, "shell_plate"),
        ((-0.50, 0.85, 0.10), 0.50, 0.20, "shell_plate"),
        ((0.50, 0.85, 0.10), 0.50, 0.20, "shell_plate"),
        # Faixa inferior / barriga
        ((0.0, -0.84, -0.42), 0.46, 0.20, "shell_plate"),
        ((-0.68, -0.42, -0.56), 0.44, 0.18, "shell_plate"),
        ((0.68, -0.42, -0.56), 0.44, 0.18, "shell_plate"),
        ((-0.58, 0.56, -0.58), 0.48, 0.18, "shell_plate"),
        ((0.58, 0.56, -0.58), 0.48, 0.18, "shell_plate"),
    ]
    for p_idx, (dvec, prad, pthk, m_key) in enumerate(plate_dirs):
        _add_oriented_plate(parts, f"_tmp_plate_{p_idx}", shell_center, dvec, prad, pthk, mat_prefix, m_key, pal)

    # 2. CABEÇA REPTILIANA DE TARTARUGA PROJETADA À FRENTE
    # Pescoço grosso emergindo do casco
    _add_part(
        parts,
        create_cylinder(
            "_tmp_neck",
            7,
            0.34,
            0.46,
            (0.0, -0.84, 1.32),
            rotation=(math.radians(82.0), 0.0, 0.0),
        ),
        mat_prefix,
        "skin_shade",
        pal,
    )
    # Crânio e focinho superior em rampa reptiliana
    _add_part(
        parts,
        create_icosphere(
            "_tmp_head_upper",
            2,
            0.36,
            (0.0, -1.12, 1.44),
            rotation=(math.radians(14.0), 0.0, 0.0),
            scale=(1.02, 1.38, 0.72),
        ),
        mat_prefix,
        "skin_taupe",
        pal,
    )
    # Ponta chata do focinho
    _add_part(
        parts,
        create_cone(
            "_tmp_snout_tip",
            6,
            0.28,
            0.16,
            0.34,
            (0.0, -1.46, 1.38),
            rotation=(math.radians(102.0), 0.0, 0.0),
            scale=(1.08, 0.68, 1.0),
        ),
        mat_prefix,
        "skin_taupe",
        pal,
    )
    # Mandíbula inferior aberta em rugido
    _add_part(
        parts,
        create_icosphere(
            "_tmp_jaw_lower",
            2,
            0.30,
            (0.0, -1.24, 1.12),
            rotation=(math.radians(24.0), 0.0, 0.0),
            scale=(0.94, 1.24, 0.50),
        ),
        mat_prefix,
        "skin_shade",
        pal,
    )
    # Interior da boca aberta + língua rosa + 2 presas inferiores brancas
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_inside",
            1,
            0.24,
            (0.0, -1.24, 1.24),
            scale=(0.88, 0.94, 0.66),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tongue",
            1,
            0.18,
            (0.0, -1.30, 1.18),
            scale=(0.86, 0.92, 0.42),
        ),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.048,
                0.010,
                0.14,
                (side * 0.14, -1.44, 1.22),
                rotation=(math.radians(-12.0), 0.0, 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # Olhos ferozes vermelhos com esclera branca e sobrancelha dura
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_brow_{tag}",
                (0.14, 0.30, 0.09),
                (side * 0.32, -1.22, 1.54),
                rotation=(math.radians(14.0), math.radians(side * -14.0), math.radians(side * 14.0)),
            ),
            mat_prefix,
            "skin_taupe",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_sclera_{tag}",
                (0.08, 0.24, 0.12),
                (side * 0.31, -1.22, 1.44),
                rotation=(math.radians(8.0), 0.0, math.radians(side * 16.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_iris_{tag}",
                (0.07, 0.13, 0.11),
                (side * 0.32, -1.28, 1.44),
                rotation=(math.radians(8.0), 0.0, math.radians(side * 16.0)),
            ),
            mat_prefix,
            "eye_red",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_pupil_{tag}",
                (0.06, 0.04, 0.09),
                (side * 0.34, -1.29, 1.44),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 3. BRAÇOS MUSCULOSOS REPTILIANOS COM 3 GARRAS BRANCAS AFIADAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Ombro + braço emergindo da lateral do casco
        _add_part(
            parts,
            create_icosphere(f"_tmp_arm_upper_{tag}", 2, 0.28, (side * 1.04, -0.34, 1.30), scale=(1.15, 0.92, 0.92)),
            mat_prefix,
            "skin_shade",
            pal,
        )
        # Antebraço erguido e pronto para golpe
        _add_part(
            parts,
            create_cone(
                f"_tmp_forearm_{tag}",
                7,
                0.24,
                0.26,
                0.56,
                (side * 1.18, -0.64, 1.54),
                rotation=(math.radians(44.0), math.radians(side * 18.0), 0.0),
            ),
            mat_prefix,
            "skin_taupe",
            pal,
        )
        hand_loc = (side * 1.24, -0.88, 1.76)
        _add_part(
            parts,
            create_icosphere(f"_tmp_hand_{tag}", 2, 0.26, hand_loc, scale=(1.08, 0.78, 1.05)),
            mat_prefix,
            "skin_taupe",
            pal,
        )
        # 3 garras cônicas brancas abertas em cada mão
        claw_specs = [
            (side * 0.18, -0.18, 0.16, 48.0, side * 32.0),
            (side * 0.00, -0.22, 0.22, 34.0, side * 6.0),
            (-side * 0.18, -0.20, 0.06, 62.0, side * -28.0),
        ]
        for c_i, (dx, dy, dz, rx_d, ry_d) in enumerate(claw_specs):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{tag}_{c_i}",
                    5,
                    0.075,
                    0.012,
                    0.26,
                    (hand_loc[0] + dx, hand_loc[1] + dy, hand_loc[2] + dz),
                    rotation=(math.radians(-rx_d), math.radians(ry_d), 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 4. PERNAS PESADAS DE PILAR + PÉS COM 4 GARRAS BRANCAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa musculosa
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.38,
                (side * 0.84, -0.08, 0.72),
                rotation=(math.radians(16.0), math.radians(side * -14.0), 0.0),
                scale=(0.94, 1.05, 1.12),
            ),
            mat_prefix,
            "skin_taupe",
            pal,
        )
        # Canela/tornozelo grosso
        _add_part(
            parts,
            create_cone(
                f"_tmp_shin_{tag}",
                7,
                0.34,
                0.28,
                0.56,
                (side * 0.90, -0.12, 0.34),
                scale=(1.04, 1.12, 1.0),
            ),
            mat_prefix,
            "skin_shade",
            pal,
        )
        # Pé largo achatado
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.34,
                (side * 0.92, -0.22, 0.14),
                scale=(1.12, 1.24, 0.44),
            ),
            mat_prefix,
            "skin_taupe",
            pal,
        )
        # 4 garras cônicas brancas apontando para frente
        for t_i, (tx, ty, rz_d) in enumerate([
            (-0.22, -0.34, -22.0),
            (-0.07, -0.40, -6.0),
            (0.08, -0.40, 6.0),
            (0.22, -0.34, 22.0),
        ]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_claw_{tag}_{t_i}",
                    5,
                    0.072,
                    0.012,
                    0.24,
                    (side * 0.92 + tx, -0.22 + ty, 0.10),
                    rotation=(math.radians(-82.0), 0.0, math.radians(rz_d)),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 076. Megaboulder lado a lado."""
    specs = [
        ("Megaboulder_Shiny", (-12.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Megaboulder_Normal", (-6.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Megaboulder_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Megaboulder_Gigante", (6.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Megaboulder_Dourada_SuperRara", (16.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_megaboulder(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
