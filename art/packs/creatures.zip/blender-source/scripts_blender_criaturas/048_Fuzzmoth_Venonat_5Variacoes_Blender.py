"""
048_Fuzzmoth_Venonat_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "048. Fuzzmoth — Mariposa Peluda (Ref: Venonat)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Fuzzmoth_Shiny (1.0x - Pelagem Violeta-Índigo + Grandes Olhos Compostos Azul-Céu Brilhante)
  2. Fuzzmoth_Normal (1.0x - Bola de Pelos Roxo-Violeta + Olhos Compostos Rubi + Antenas Brancas com Ponta Oval)
  3. Fuzzmoth_Grande (1.35x - Normal)
  4. Fuzzmoth_Gigante (1.85x - Normal)
  5. Fuzzmoth_Dourada_SuperRara (2.25x - Ouro Reluzente + Grandes Olhos Compostos e Antenas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icosphere subdiv=2 + coroa de tufos pontiagudos de pelo)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés alinhados exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "fur_purple": (0.45, 0.39, 0.66, 1.0),
        "fur_light": (0.56, 0.50, 0.78, 1.0),
        "eye_ruby": (0.88, 0.36, 0.56, 1.0),
        "eye_dot": (0.68, 0.20, 0.38, 1.0),
        "eye_dark": (0.14, 0.12, 0.18, 1.0),
        "nose_pink": (0.86, 0.48, 0.58, 1.0),
        "white_pure": (0.96, 0.97, 0.99, 1.0),
        "limb_tan": (0.78, 0.70, 0.58, 1.0),
    },
    "shiny_palette": {
        "fur_purple": (0.40, 0.35, 0.70, 1.0),
        "fur_light": (0.52, 0.46, 0.82, 1.0),
        "eye_ruby": (0.24, 0.66, 0.98, 1.0),
        "eye_dot": (0.12, 0.44, 0.78, 1.0),
        "eye_dark": (0.12, 0.14, 0.22, 1.0),
        "nose_pink": (0.46, 0.68, 0.90, 1.0),
        "white_pure": (0.96, 0.97, 0.99, 1.0),
        "limb_tan": (0.78, 0.70, 0.58, 1.0),
    },
    "golden_super_rare_palette": {
        "fur_purple": (0.98, 0.78, 0.14, 1.0),
        "fur_light": (1.00, 0.88, 0.34, 1.0),
        "eye_ruby": (0.10, 0.92, 1.00, 1.0),
        "eye_dot": (0.04, 0.62, 0.78, 1.0),
        "eye_dark": (0.52, 0.36, 0.06, 1.0),
        "nose_pink": (0.88, 0.64, 0.10, 1.0),
        "white_pure": (1.00, 0.99, 0.92, 1.0),
        "limb_tan": (0.86, 0.64, 0.10, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_fuzzmoth(
    name: str = "Fuzzmoth_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 048. Fuzzmoth (Ref: Venonat):
      - Esfera peluda roxo-violeta com tufos pontiagudos de pelos ao redor de toda a silhueta
        (incluindo os dois tufos longos arrepiados no topo da cabeça)
      - 2 antenas brancas longas e arqueadas terminando em pontas ovais brancas
      - 2 enormes olhos compostos rubi-rosa (azuis na Shiny) com textura de pontos compostos
      - Focinho rosa + 2 presinhas brancas curvadas para baixo
      - 2 mãozinhas curtas de 3 dedos no peito e 2 pés largos bege-areia em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Fuzz_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Fuzz_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Fuzz_Norm"

    parts = []

    # 1. CORPO EM BOLA DE PELOS ROXO-VIOLETA
    _add_part(
        parts,
        create_icosphere("_tmp_body_core", 2, 0.86, (0.0, 0.0, 1.04), scale=(1.02, 0.96, 1.00)),
        mat_prefix,
        "fur_purple",
        pal,
    )

    # Tufos pontiagudos de pelo ao redor do contorno (silhueta bem felpuda como na arte!)
    tuft_ring = [
        # (loc, rot_deg, r1, depth, key)
        ((-0.24, 0.12, 1.98), (12.0, -28.0, 0.0), 0.22, 0.62, "fur_light"),
        ((-0.56, 0.16, 1.82), (8.0, -56.0, 0.0), 0.20, 0.56, "fur_light"),
        ((0.20, 0.14, 1.92), (12.0, 22.0, 0.0), 0.18, 0.44, "fur_light"),
        ((0.52, 0.12, 1.76), (10.0, 48.0, 0.0), 0.18, 0.42, "fur_purple"),
        ((-0.86, 0.04, 1.44), (0.0, -76.0, 0.0), 0.20, 0.44, "fur_purple"),
        ((0.86, 0.04, 1.42), (0.0, 76.0, 0.0), 0.20, 0.42, "fur_purple"),
        ((-0.90, 0.02, 1.04), (0.0, -94.0, 0.0), 0.22, 0.46, "fur_purple"),
        ((0.90, 0.02, 1.04), (0.0, 94.0, 0.0), 0.22, 0.46, "fur_purple"),
        ((-0.82, 0.04, 0.66), (0.0, -118.0, 0.0), 0.20, 0.42, "fur_purple"),
        ((0.82, 0.04, 0.66), (0.0, 118.0, 0.0), 0.20, 0.42, "fur_purple"),
        ((0.0, 0.84, 1.24), (82.0, 0.0, 0.0), 0.24, 0.44, "fur_purple"),
        ((-0.44, 0.74, 1.38), (68.0, -34.0, 0.0), 0.20, 0.42, "fur_purple"),
        ((0.44, 0.74, 1.38), (68.0, 34.0, 0.0), 0.20, 0.42, "fur_purple"),
        ((0.0, -0.18, 1.88), (-18.0, 0.0, 0.0), 0.18, 0.36, "fur_light"),
    ]
    for t_i, (loc, rot_d, r1, depth, key) in enumerate(tuft_ring):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tuft_{t_i}",
                5,
                r1,
                0.02,
                depth,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
            ),
            mat_prefix,
            key,
            pal,
        )

    # 2. DUAS ANTENAS BRANCAS LONGAS E ARQUEADAS COM PONTA OVAL (CONEXÃO CONTÍNUA SEM VÃOS)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Segmento inferior da antena (entra fundo na cabeça em z=1.64 até a dobra em z=2.12)
        _add_part(
            parts,
            create_cone(
                f"_tmp_ant_base_{tag}",
                6,
                0.048,
                0.040,
                0.62,
                (side * 0.26, -0.22, 1.88),
                rotation=(math.radians(14.0), math.radians(side * 28.0), 0.0),
            ),
            mat_prefix,
            "white_pure",
            pal,
        )
        # Articulação suave da curva da antena
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ant_joint_{tag}",
                1,
                0.044,
                (side * 0.39, -0.28, 2.13),
            ),
            mat_prefix,
            "white_pure",
            pal,
        )
        # Segmento superior arqueado da dobra (0.39, -0.28, 2.13) até a ponta oval (0.82, -0.34, 2.42)
        _add_part(
            parts,
            create_cone(
                f"_tmp_ant_mid_{tag}",
                6,
                0.040,
                0.036,
                0.56,
                (side * 0.60, -0.31, 2.27),
                rotation=(math.radians(8.0), math.radians(side * 56.0), 0.0),
            ),
            mat_prefix,
            "white_pure",
            pal,
        )
        # Ponta oval gordinha da antena (marca registrada do Venonat!)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ant_bulb_{tag}",
                2,
                0.145,
                (side * 0.84, -0.34, 2.43),
                rotation=(0.0, math.radians(side * 60.0), 0.0),
                scale=(0.82, 0.72, 1.48),
            ),
            mat_prefix,
            "white_pure",
            pal,
        )

    # 3. GRANDES OLHOS COMPOSTOS RUBI-ROSA (AZUIS NA SHINY) + PONTINHOS COMPOSTOS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        eye_loc = (side * 0.42, -0.68, 1.24)
        eye_rot = (math.radians(-6.0), math.radians(side * 12.0), math.radians(side * -24.0))
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_rim_{tag}",
                2,
                0.34,
                (side * 0.41, -0.64, 1.24),
                rotation=eye_rot,
                scale=(1.02, 0.56, 1.08),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.32,
                eye_loc,
                rotation=eye_rot,
                scale=(1.00, 0.60, 1.06),
            ),
            mat_prefix,
            "eye_ruby",
            pal,
        )
        # Pequenos pontos escuros do olho composto
        for d_i, (dx, dz) in enumerate([(-0.10, 0.10), (0.08, 0.11), (0.0, 0.0), (-0.10, -0.10), (0.09, -0.10)]):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_edot_{tag}_{d_i}",
                    1,
                    0.028,
                    (eye_loc[0] + dx * 0.9, eye_loc[1] - 0.17, eye_loc[2] + dz),
                    scale=(1.0, 0.5, 1.0),
                ),
                mat_prefix,
                "eye_dot",
                pal,
            )

    # 4. FOCINHO ROSA + DUAS PRESINHAS BRANCAS CURVADAS PARA BAIXO
    _add_part(
        parts,
        create_icosphere("_tmp_nose", 2, 0.15, (0.0, -0.86, 1.02), scale=(1.12, 0.80, 0.72)),
        mat_prefix,
        "nose_pink",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                6,
                0.068,
                0.015,
                0.22,
                (side * 0.14, -0.88, 0.90),
                rotation=(math.radians(170.0), math.radians(side * 18.0), 0.0),
            ),
            mat_prefix,
            "white_pure",
            pal,
        )

    # 5. MÃOZINHAS CURTAS BEGE DE 3 DEDINHOS NO PEITO
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hand_{tag}",
                2,
                0.13,
                (side * 0.34, -0.80, 0.62),
                scale=(1.10, 0.76, 0.96),
            ),
            mat_prefix,
            "limb_tan",
            pal,
        )
        for f_i, fz in enumerate([-0.06, 0.0, 0.06]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_finger_{tag}_{f_i}",
                    5,
                    0.042,
                    0.012,
                    0.12,
                    (side * 0.24, -0.84, 0.62 + fz),
                    rotation=(0.0, math.radians(side * -82.0), 0.0),
                ),
                mat_prefix,
                "limb_tan",
                pal,
            )

    # 6. PÉS GRANDES BEGE-AREIA APOIADOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ankle_{tag}",
                6,
                0.15,
                0.18,
                0.24,
                (side * 0.36, -0.02, 0.24),
                rotation=(0.0, math.radians(side * -14.0), 0.0),
            ),
            mat_prefix,
            "limb_tan",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.26,
                (side * 0.44, -0.18, 0.12),
                rotation=(0.0, 0.0, math.radians(side * -24.0)),
                scale=(0.86, 1.46, 0.48),
            ),
            mat_prefix,
            "limb_tan",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 048. Fuzzmoth lado a lado."""
    specs = [
        ("Fuzzmoth_Shiny", (-8.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Fuzzmoth_Normal", (-5.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Fuzzmoth_Grande", (-1.0, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Fuzzmoth_Gigante", (4.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Fuzzmoth_Dourada_SuperRara", (11.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_fuzzmoth(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
