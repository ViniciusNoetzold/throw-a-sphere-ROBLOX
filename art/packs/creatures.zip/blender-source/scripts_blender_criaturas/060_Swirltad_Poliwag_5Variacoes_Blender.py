"""
060_Swirltad_Poliwag_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "060. Swirltad — Girino Espiral (Ref: Poliwag)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Swirltad_Shiny (1.0x - Paleta Shiny Azul-Gelo Claro + Barriga Branca + Boca Rosa-Bebê)
  2. Swirltad_Normal (1.0x - Corpo Redondo Azul-Vivo + Grande Espiral Preta + Boca Rosa + Cauda Translúcida)
  3. Swirltad_Grande (1.35x - Normal)
  4. Swirltad_Gigante (1.85x - Normal)
  5. Swirltad_Dourada_SuperRara (2.25x - Ouro Reluzente + Espiral, Olhos e Cauda Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + espiral 3D nítida em relevo na barriga)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e espiral/rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.31, 0.56, 0.82, 1.0),
        "body_dark": (0.22, 0.44, 0.70, 1.0),
        "belly_white": (0.97, 0.98, 1.00, 1.0),
        "spiral_black": (0.10, 0.11, 0.14, 1.0),
        "mouth_pink": (0.94, 0.56, 0.70, 1.0),
        "tail_fin": (0.76, 0.89, 0.97, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "shine_white": (1.00, 1.00, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.56, 0.80, 0.96, 1.0),
        "body_dark": (0.42, 0.68, 0.88, 1.0),
        "belly_white": (0.98, 0.99, 1.00, 1.0),
        "spiral_black": (0.12, 0.14, 0.18, 1.0),
        "mouth_pink": (0.97, 0.72, 0.82, 1.0),
        "tail_fin": (0.84, 0.94, 1.00, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "shine_white": (1.00, 1.00, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.98, 0.78, 0.14, 1.0),
        "body_dark": (0.86, 0.62, 0.09, 1.0),
        "belly_white": (1.00, 0.96, 0.76, 1.0),
        "spiral_black": (0.10, 0.92, 1.00, 1.0),
        "mouth_pink": (0.10, 0.92, 1.00, 1.0),
        "tail_fin": (0.48, 0.96, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "shine_white": (1.00, 1.00, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_belly_spiral(
    parts: list,
    mat_prefix: str,
    pal: dict,
    center_y: float,
    center_z: float,
    rx: float,
    ry: float,
    rz: float,
    max_r: float,
    turns: float = 2.6,
    direction: float = 1.0,
    tube_r: float = 0.038,
    steps: int = 38,
):
    """Esculpe a espiral preta em relevo 3D acompanhando perfeitamente a curvatura da barriga branca."""
    pts = []
    for i in range(steps + 1):
        t = i / float(steps)
        theta = t * turns * 2.0 * math.pi * direction + math.radians(15.0)
        r = max_r * (0.04 + 0.96 * t)
        x = r * math.cos(theta)
        z = center_z + r * math.sin(theta)
        u = x / rx
        w = (z - center_z) / rz
        inside = max(0.06, 1.0 - u * u - w * w)
        y = center_y - ry * math.sqrt(inside) - 0.015
        pts.append((x, y, z))

    for idx in range(len(pts) - 1):
        p0, p1 = pts[idx], pts[idx + 1]
        dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
        dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        if dist < 1e-5:
            continue
        mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
        horiz = math.sqrt(dx * dx + dy * dy)
        rot_x = math.atan2(horiz, dz)
        rot_z = math.atan2(dx, -dy)
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_spiral_{idx}",
                6,
                tube_r,
                dist + tube_r * 0.8,
                mid,
                rotation=(rot_x, 0.0, rot_z),
            ),
            mat_prefix,
            "spiral_black",
            pal,
        )


def build_swirltad(
    name: str = "Swirltad_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 060. Swirltad (Ref: Poliwag):
      - Corpo esférico liso azul-vivo sem braços (silhueta pura de girino!)
      - Grande barriga circular branca com espiral preta nítida em relevo 3D
      - Boquinha rosa redonda logo acima da barriga + olhos grandes fofos com brilho branco
      - Duas patinhas ovais curtas azuis apoiadas em Z = 0.0
      - Cauda longa curva para a direita com nadadeira azul-claro translúcida em folha
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Swirl_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Swirl_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Swirl_Norm"

    parts = []

    # 1. CORPO ESFÉRICO AZUL-VIVO
    _add_part(
        parts,
        create_icosphere("_tmp_body", 2, 0.84, (0.0, 0.0, 1.04), scale=(1.02, 0.96, 0.98)),
        mat_prefix,
        "body_blue",
        pal,
    )

    # 2. BARRIGA CIRCULAR BRANCA + ESPIRAL PRETA 3D NÍTIDA (SENTIDO HORÁRIO COMO NO POLIWAG)
    belly_cy, belly_cz = -0.36, 0.88
    belly_rx, belly_ry, belly_rz = 0.62, 0.52, 0.58
    _add_part(
        parts,
        create_icosphere(
            "_tmp_belly",
            2,
            1.0,
            (0.0, belly_cy, belly_cz),
            scale=(belly_rx, belly_ry, belly_rz),
        ),
        mat_prefix,
        "belly_white",
        pal,
    )
    _add_belly_spiral(
        parts,
        mat_prefix,
        pal,
        center_y=belly_cy,
        center_z=belly_cz,
        rx=belly_rx,
        ry=belly_ry,
        rz=belly_rz,
        max_r=0.47,
        turns=2.65,
        direction=-1.0,
        tube_r=0.036,
        steps=38,
    )

    # 3. BOQUINHA ROSA FOFA + OLHOS GRANDES EXPRESSIVOS NO TOPO
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_lips", 2, 0.17, (0.0, -0.78, 1.44), scale=(1.18, 0.72, 0.84)),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth_dot", (0.08, 0.04, 0.025), (0.0, -0.89, 1.44)),
        mat_prefix,
        "spiral_black",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.23,
                (side * 0.34, -0.58, 1.62),
                rotation=(math.radians(24.0), math.radians(side * 16.0), math.radians(side * -22.0)),
                scale=(1.04, 0.48, 1.12),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                2,
                0.15,
                (side * 0.32, -0.66, 1.63),
                rotation=(math.radians(24.0), math.radians(side * 16.0), math.radians(side * -22.0)),
                scale=(0.94, 0.42, 1.08),
            ),
            mat_prefix,
            "spiral_black",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_shine_{tag}",
                1,
                0.056,
                (side * 0.28, -0.71, 1.70),
            ),
            mat_prefix,
            "shine_white",
            pal,
        )

    # 4. DUAS PATINHAS OVAIS CURTAS AZUIS APOIADAS EM Z = 0.0 (SEM BRAÇOS)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_{tag}",
                8,
                0.17,
                0.15,
                0.30,
                (side * 0.38, -0.06, 0.22),
                rotation=(math.radians(10.0), math.radians(side * 14.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.21,
                (side * 0.44, -0.18, 0.11),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(0.92, 1.40, 0.54),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    # 5. CAUDA LONGA DE GIRINO COM NADADEIRA TRANSLÚCIDA AZUL-CLARO EM FOLHA
    # Eixo central escuro da cauda varrendo para a direita e trás (visível através da nadadeira!)
    tail_spine = [
        ((0.20, 0.72, 0.56), 0.13),
        ((0.62, 0.84, 0.48), 0.10),
        ((1.06, 0.78, 0.43), 0.075),
        ((1.44, 0.68, 0.41), 0.052),
        ((1.76, 0.56, 0.40), 0.024),
    ]
    for idx in range(len(tail_spine) - 1):
        p0, r0 = tail_spine[idx]
        p1, r1 = tail_spine[idx + 1]
        dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
        dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
        horiz = math.sqrt(dx * dx + dy * dy)
        rot_x = math.atan2(horiz, dz)
        rot_z = math.atan2(dx, -dy)
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_spine_{idx}",
                6,
                r0,
                r1,
                dist + 0.04,
                mid,
                rotation=(rot_x, 0.0, rot_z),
            ),
            mat_prefix,
            "body_dark",
            pal,
        )
    # Nadadeira translúcida em forma de folha larga fina ao redor do eixo central escuro
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tail_fin_main",
            2,
            0.52,
            (1.18, 0.80, 0.42),
            rotation=(math.radians(8.0), math.radians(-6.0), math.radians(-18.0)),
            scale=(1.44, 0.13, 0.72),
        ),
        mat_prefix,
        "tail_fin",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tail_fin_tip",
            2,
            0.36,
            (1.66, 0.64, 0.40),
            rotation=(math.radians(8.0), math.radians(-4.0), math.radians(-24.0)),
            scale=(1.12, 0.11, 0.68),
        ),
        mat_prefix,
        "tail_fin",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 060. Swirltad lado a lado."""
    specs = [
        ("Swirltad_Shiny", (-11.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Swirltad_Normal", (-6.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Swirltad_Grande", (-1.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Swirltad_Gigante", (5.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Swirltad_Dourada_SuperRara", (14.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_swirltad(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
