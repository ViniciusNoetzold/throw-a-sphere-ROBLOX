"""
072_Jellygem_Tentacool_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "072. Jellygem — Água-Viva Rubi (Ref: Tentacool)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Jellygem_Shiny (1.0x - Paleta Shiny Roxo-Lavanda + 3 Gemas Verde-Esmeralda)
  2. Jellygem_Normal (1.0x - Domo Azul-Oceano + 3 Gemas Vermelho-Rubi + 2 Tentáculos Longos)
  3. Jellygem_Grande (1.35x - Normal)
  4. Jellygem_Gigante (1.85x - Normal)
  5. Jellygem_Dourada_SuperRara (2.25x - Ouro Reluzente + Gemas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para domo e gemas, cones/cilindros 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base dos tentáculos alinhada exatamente em `Z = 0.0` e rosto/gema frontal apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "dome_blue": (0.36, 0.74, 0.92, 1.0),
        "dome_shade": (0.24, 0.56, 0.78, 1.0),
        "gem_ruby": (0.84, 0.20, 0.34, 1.0),
        "gem_shine": (0.98, 0.58, 0.68, 1.0),
        "under_dark": (0.10, 0.11, 0.14, 1.0),
        "tentacle_main": (0.60, 0.56, 0.50, 1.0),
        "tentacle_shade": (0.45, 0.42, 0.37, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "pupil_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "shiny_palette": {
        "dome_blue": (0.62, 0.50, 0.86, 1.0),
        "dome_shade": (0.46, 0.34, 0.70, 1.0),
        "gem_ruby": (0.18, 0.84, 0.44, 1.0),
        "gem_shine": (0.60, 0.98, 0.72, 1.0),
        "under_dark": (0.12, 0.10, 0.16, 1.0),
        "tentacle_main": (0.60, 0.58, 0.64, 1.0),
        "tentacle_shade": (0.44, 0.42, 0.50, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "pupil_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "dome_blue": (0.98, 0.78, 0.14, 1.0),
        "dome_shade": (0.86, 0.62, 0.10, 1.0),
        "gem_ruby": (0.10, 0.92, 1.00, 1.0),
        "gem_shine": (0.76, 0.99, 1.00, 1.0),
        "under_dark": (0.34, 0.24, 0.05, 1.0),
        "tentacle_main": (0.94, 0.74, 0.22, 1.0),
        "tentacle_shade": (0.78, 0.56, 0.12, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.38, 0.52, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_segment(parts: list, name: str, p0: tuple, p1: tuple, r0: float, r1: float, mat_prefix: str, mat_key: str, pal: dict, verts: int = 7):
    """Cria um segmento cônico orientado exatamente entre os pontos p0 e p1."""
    dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    if length < 1e-5:
        return None
    mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
    # Alinha eixo +Z do cone com o vetor (dx, dy, dz)
    horiz = math.sqrt(dx * dx + dy * dy)
    rx = math.atan2(horiz, dz)
    rz = math.atan2(dy, dx) + math.pi * 0.5
    # Usa vetor em plano local: rotação Rz(rz) @ Rx(rx) leva (0,0,1) para (sin(rx)*sin(rz), -sin(rx)*cos(rz), cos(rx))
    # Corrigindo sinal para que (0,0,1) -> (dx, dy, dz)/L:
    phi = math.atan2(dx, -dy)
    theta = math.acos(max(-1.0, min(1.0, dz / length)))
    obj = create_cone(
        name,
        verts,
        r0,
        r1,
        length + 0.04,
        mid,
        rotation=(theta, 0.0, phi),
    )
    return _add_part(parts, obj, mat_prefix, mat_key, pal)


def build_jellygem(
    name: str = "Jellygem_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 072. Jellygem (Ref: Tentacool):
      - Domo cefálico bulboso azul-oceano com saia/manto inferior ondulado e cavidade escura
      - 2 grandes gemas rubi ovais laterais + 1 gema rubi menor no centro da testa com brilhos
      - Crista nasal angular, olhos estreitos ferozes brancos com pupilas verticais e bico frontal
      - 2 longos tentáculos acinzentados fluidos e curvos com pontas achatadas em remo
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Jelly_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Jelly_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Jelly_Norm"

    parts = []

    # 1. DOMO BULBOSO PRINCIPAL E BASE DO MANTO
    _add_part(
        parts,
        create_icosphere("_tmp_dome_top", 2, 0.72, (0.0, 0.04, 1.56), scale=(0.94, 1.00, 1.06)),
        mat_prefix,
        "dome_blue",
        pal,
    )
    # Cintura levemente afunilada abaixo do domo
    _add_part(
        parts,
        create_cone("_tmp_dome_waist", 8, 0.62, 0.56, 0.58, (0.0, 0.04, 1.02), scale=(0.96, 1.02, 1.0)),
        mat_prefix,
        "dome_blue",
        pal,
    )
    # Aba/saia do manto ondulada projetada para os lados e para trás
    _add_part(
        parts,
        create_cone("_tmp_mantle_skirt", 8, 0.92, 0.56, 0.36, (0.0, 0.14, 0.74), scale=(1.04, 1.12, 0.85)),
        mat_prefix,
        "dome_blue",
        pal,
    )
    # Cavidade inferior escura sob o manto + núcleo azul arredondado
    _add_part(
        parts,
        create_icosphere("_tmp_under_cavity", 2, 0.68, (0.0, 0.14, 0.60), scale=(1.04, 1.10, 0.42)),
        mat_prefix,
        "under_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_under_core", 2, 0.38, (0.0, 0.00, 0.64), scale=(1.00, 0.94, 0.88)),
        mat_prefix,
        "dome_shade",
        pal,
    )

    # 2. AS 3 GEMAS VERMELHO-RUBI ICÔNICAS (2 GRANDES LATERAIS + 1 MENOR FRONTAL)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_side_gem_{tag}",
                2,
                0.42,
                (side * 0.46, -0.10, 1.72),
                rotation=(math.radians(12.0), math.radians(side * 28.0), math.radians(side * -14.0)),
                scale=(0.76, 1.04, 1.12),
            ),
            mat_prefix,
            "gem_ruby",
            pal,
        )
        # Faceta de brilho superior da gema lateral
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_side_gem_shine_{tag}",
                1,
                0.15,
                (side * 0.54, -0.32, 1.92),
                rotation=(math.radians(10.0), math.radians(side * 24.0), 0.0),
                scale=(0.62, 0.82, 0.95),
            ),
            mat_prefix,
            "gem_shine",
            pal,
        )

    # Gema frontal central na testa
    _add_part(
        parts,
        create_icosphere(
            "_tmp_front_gem",
            2,
            0.22,
            (0.0, -0.66, 1.48),
            scale=(0.86, 0.64, 1.12),
        ),
        mat_prefix,
        "gem_ruby",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_front_gem_shine",
            1,
            0.075,
            (-0.04, -0.78, 1.56),
            scale=(0.80, 0.50, 0.95),
        ),
        mat_prefix,
        "gem_shine",
        pal,
    )

    # 3. CRISTA FACIAL, BICO FRONTAL E OLHOS ESTREITOS FEROZES
    # Crista nasal triangular apontando para baixo entre os olhos
    _add_part(
        parts,
        create_cone(
            "_tmp_nose_ridge",
            4,
            0.26,
            0.05,
            0.52,
            (0.0, -0.62, 0.96),
            rotation=(math.radians(164.0), 0.0, math.radians(45.0)),
            scale=(0.88, 0.92, 1.0),
        ),
        mat_prefix,
        "dome_blue",
        pal,
    )
    # Placa/lábio inferior em arco sob os olhos
    _add_part(
        parts,
        create_cone(
            "_tmp_chin_flap",
            6,
            0.34,
            0.14,
            0.34,
            (0.0, -0.56, 0.72),
            rotation=(math.radians(162.0), 0.0, 0.0),
            scale=(1.22, 0.66, 1.0),
        ),
        mat_prefix,
        "dome_blue",
        pal,
    )

    # Olhos brancos ferozes sob a sobrancelha azul + pupilas verticais finas
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Sobrancelha angular azul cobrindo o topo do olho
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.32, 0.14, 0.10),
                (side * 0.28, -0.62, 1.12),
                rotation=(math.radians(10.0), math.radians(side * -18.0), math.radians(side * -22.0)),
            ),
            mat_prefix,
            "dome_blue",
            pal,
        )
        # Esclera branca
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.15,
                (side * 0.25, -0.60, 1.02),
                rotation=(0.0, 0.0, math.radians(side * -20.0)),
                scale=(1.15, 0.56, 0.62),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pupila escura vertical fina
        _add_part(
            parts,
            create_cube(
                f"_tmp_pupil_{tag}",
                (0.042, 0.06, 0.12),
                (side * 0.24, -0.68, 1.02),
                rotation=(0.0, 0.0, math.radians(side * -16.0)),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 4. DOIS LONGOS TENTÁCULOS FLUIDOS COM PONTAS ACHATADAS EM REMO
    # Tentáculo esquerdo descendo em onda graciosa até tocar o chão (Z=0.0)
    left_pts = [
        (-0.28, -0.08, 0.66),
        (-0.56, -0.22, 0.42),
        (-0.88, -0.34, 0.30),
        (-1.22, -0.36, 0.16),
        (-1.42, -0.34, 0.08),
    ]
    left_radii = [0.085, 0.078, 0.072, 0.095, 0.115]
    for i in range(len(left_pts) - 1):
        _add_segment(
            parts,
            f"_tmp_tent_L_{i}",
            left_pts[i],
            left_pts[i + 1],
            left_radii[i],
            left_radii[i + 1],
            mat_prefix,
            "tentacle_main",
            pal,
            verts=7,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_tent_Lj_{i}", 1, left_radii[i + 1] * 0.96, left_pts[i + 1]),
            mat_prefix,
            "tentacle_main",
            pal,
        )
    # Ponta em remo achatada do tentáculo esquerdo
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tent_L_paddle",
            2,
            0.16,
            (-1.48, -0.34, 0.09),
            rotation=(math.radians(10.0), math.radians(24.0), math.radians(-12.0)),
            scale=(1.42, 0.62, 0.56),
        ),
        mat_prefix,
        "tentacle_shade",
        pal,
    )

    # Tentáculo direito varrendo para baixo e depois curvando-se alegremente para cima!
    right_pts = [
        (0.28, -0.02, 0.66),
        (0.58, -0.10, 0.36),
        (0.96, -0.12, 0.24),
        (1.28, -0.08, 0.52),
        (1.36, -0.04, 0.94),
        (1.22, -0.08, 1.24),
    ]
    right_radii = [0.085, 0.078, 0.076, 0.084, 0.105, 0.115]
    for i in range(len(right_pts) - 1):
        _add_segment(
            parts,
            f"_tmp_tent_R_{i}",
            right_pts[i],
            right_pts[i + 1],
            right_radii[i],
            right_radii[i + 1],
            mat_prefix,
            "tentacle_main",
            pal,
            verts=7,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_tent_Rj_{i}", 1, right_radii[i + 1] * 0.96, right_pts[i + 1]),
            mat_prefix,
            "tentacle_main",
            pal,
        )
    # Ponta em remo erguida do tentáculo direito
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tent_R_paddle",
            2,
            0.15,
            (1.16, -0.10, 1.32),
            rotation=(math.radians(-10.0), math.radians(-38.0), 0.0),
            scale=(0.68, 0.62, 1.44),
        ),
        mat_prefix,
        "tentacle_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 072. Jellygem lado a lado."""
    specs = [
        ("Jellygem_Shiny", (-9.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Jellygem_Normal", (-5.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Jellygem_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Jellygem_Gigante", (5.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Jellygem_Dourada_SuperRara", (13.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_jellygem(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
