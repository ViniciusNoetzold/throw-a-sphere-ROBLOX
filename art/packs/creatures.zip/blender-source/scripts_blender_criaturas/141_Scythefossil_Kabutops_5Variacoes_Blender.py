"""
141_Scythefossil_Kabutops_5Variacoes_Blender.py
===============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "141. Scythefossil — Predador Fóssil (Ref: Kabutops)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Scythefossil_Shiny (1.0x - Paleta Shiny Carapaça Verde-Esmeralda + Foices Osso-Branco)
  2. Scythefossil_Normal (1.0x - Carapaça Marrom-Bronze + Placas Creme + 2 Enormes Braços-Foice Brancos)
  3. Scythefossil_Grande (1.35x - Normal)
  4. Scythefossil_Gigante (1.85x - Normal)
  5. Scythefossil_Dourada_SuperRara (2.25x - Armadura Ouro Reluzente + Foices e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para cabeça em crescente e coxas + cones curvados para as foices gigantes)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés com garras alinhados exatamente em `Z = 0.0` e rosto/foices apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "shell_brown": (0.68, 0.48, 0.30, 1.0),
        "shell_shade": (0.48, 0.32, 0.22, 1.0),
        "plate_cream": (0.86, 0.85, 0.84, 1.0),
        "plate_shade": (0.68, 0.66, 0.68, 1.0),
        "seam_dark": (0.10, 0.09, 0.12, 1.0),
        "blade_white": (0.95, 0.96, 0.98, 1.0),
        "blade_edge": (0.80, 0.82, 0.86, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_red": (0.76, 0.18, 0.32, 1.0),
    },
    "shiny_palette": {
        "shell_brown": (0.42, 0.78, 0.28, 1.0),
        "shell_shade": (0.28, 0.56, 0.18, 1.0),
        "plate_cream": (0.88, 0.90, 0.84, 1.0),
        "plate_shade": (0.68, 0.72, 0.66, 1.0),
        "seam_dark": (0.10, 0.12, 0.10, 1.0),
        "blade_white": (0.96, 0.97, 0.96, 1.0),
        "blade_edge": (0.78, 0.84, 0.78, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_red": (0.82, 0.18, 0.30, 1.0),
    },
    "golden_super_rare_palette": {
        "shell_brown": (0.98, 0.78, 0.14, 1.0),
        "shell_shade": (0.80, 0.58, 0.08, 1.0),
        "plate_cream": (1.00, 0.94, 0.64, 1.0),
        "plate_shade": (0.86, 0.70, 0.24, 1.0),
        "seam_dark": (0.44, 0.30, 0.04, 1.0),
        "blade_white": (0.10, 0.92, 1.00, 1.0),
        "blade_edge": (0.56, 0.98, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.94, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une primitivas, normaliza a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_scythefossil(
    name: str = "Scythefossil_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 141. Scythefossil (Ref: Kabutops):
      - Cabeça larga em capacete crescente/bumerangue marrom com 2 pontas laterais afiadas e olhos ferozes sob o visor
      - Tronco esguio com placas segmentadas prata/creme no peito/abdômen, juntas pretas e espinhos dorsais
      - Dois enormes braços-foice com lâminas brancas curvadas em crescente para frente e baixo
      - Pernas bípedes musculosas com garras duplas brancas em Z = 0.0 e cauda afiada atrás
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Scy_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Scy_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Scy_Norm"

    parts = []

    # 1. TRONCO SEGMENTADO ESGUIO COM PLACAS PEITORAIS CREME E COSTAS ESPINHOSAS
    # Núcleo escuro (juntas laterais visíveis como na referência)
    _add_part(
        parts,
        create_icosphere("_tmp_torso_core", 2, 0.34, (0.0, 0.04, 1.24), scale=(0.94, 0.84, 1.38)),
        mat_prefix,
        "seam_dark",
        pal,
    )
    # 3 placas peitorais/abdominais segmentadas
    _add_part(
        parts,
        create_icosphere("_tmp_chest_plate", 2, 0.32, (0.0, -0.08, 1.44), scale=(1.08, 0.72, 0.64)),
        mat_prefix,
        "plate_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_mid_plate", 2, 0.27, (0.0, -0.07, 1.18), scale=(0.96, 0.70, 0.56)),
        mat_prefix,
        "plate_shade",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_pelvis_plate",
            6,
            0.24,
            0.06,
            0.38,
            (0.0, -0.06, 0.90),
            rotation=(math.radians(180.0), 0.0, 0.0),
            scale=(0.94, 0.68, 1.0),
        ),
        mat_prefix,
        "plate_cream",
        pal,
    )
    # Armadura dorsal marrom + 4 espinhos dorsais escalonados atrás
    _add_part(
        parts,
        create_icosphere("_tmp_back_shell", 2, 0.34, (0.0, 0.14, 1.24), scale=(0.96, 0.78, 1.32)),
        mat_prefix,
        "shell_shade",
        pal,
    )
    dorsal_fins = [
        ((0.0, 0.42, 1.54), (72.0, 0.0, 0.0), 0.15, 0.44),
        ((0.0, 0.44, 1.32), (78.0, 0.0, 0.0), 0.15, 0.46),
        ((0.0, 0.44, 1.10), (84.0, 0.0, 0.0), 0.14, 0.44),
        ((0.0, 0.42, 0.90), (92.0, 0.0, 0.0), 0.13, 0.40),
    ]
    for idx, (loc, (rx, ry, rz), r1, dep) in enumerate(dorsal_fins):
        _add_part(
            parts,
            create_cone(
                f"_tmp_dorsal_fin_{idx}",
                5,
                r1,
                0.018,
                dep,
                loc,
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
                scale=(0.56, 1.0, 1.0),
            ),
            mat_prefix,
            "shell_shade",
            pal,
        )

    # 2. CABEÇA EM CAPACETE CRESCENTE / BUMERANGUE MARROM + OLHOS FEROZES
    # Escudo central inclinado para frente
    _add_part(
        parts,
        create_icosphere(
            "_tmp_head_dome",
            2,
            0.44,
            (0.0, -0.18, 1.84),
            rotation=(math.radians(24.0), 0.0, 0.0),
            scale=(1.12, 1.16, 0.74),
        ),
        mat_prefix,
        "shell_brown",
        pal,
    )
    # Ponta frontal / bico do capacete
    _add_part(
        parts,
        create_cone(
            "_tmp_head_snout",
            6,
            0.28,
            0.09,
            0.42,
            (0.0, -0.48, 1.66),
            rotation=(math.radians(-128.0), 0.0, 0.0),
            scale=(0.86, 0.72, 1.0),
        ),
        mat_prefix,
        "shell_brown",
        pal,
    )
    # Duas grandes asas/pontas em crescente da cabeça varrendo para cima e lados
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_horn_{tag}",
                6,
                0.28,
                0.025,
                0.86,
                (side * 0.56, 0.02, 2.02),
                rotation=(math.radians(34.0), math.radians(side * 58.0), math.radians(side * -14.0)),
                scale=(1.0, 0.52, 1.0),
            ),
            mat_prefix,
            "shell_brown",
            pal,
        )
        # Borda inferior do visor sobre os olhos
        _add_part(
            parts,
            create_cube(
                f"_tmp_visor_rim_{tag}",
                (0.32, 0.14, 0.07),
                (side * 0.24, -0.42, 1.78),
                rotation=(math.radians(16.0), math.radians(side * -22.0), math.radians(side * -28.0)),
            ),
            mat_prefix,
            "shell_shade",
            pal,
        )
        # Olho feroz branco com pupila rubi sob o capacete
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                1,
                0.105,
                (side * 0.24, -0.44, 1.71),
                rotation=(0.0, 0.0, math.radians(side * -28.0)),
                scale=(1.18, 0.50, 0.68),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.056,
                (side * 0.25, -0.49, 1.71),
                scale=(0.86, 0.45, 0.88),
            ),
            mat_prefix,
            "eye_red",
            pal,
        )

    # 3. DOIS ENORMES BRAÇOS-FOICE COM LÂMINAS BRANCAS CURVADAS EM CRESCENTE
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Ombro e braço superior marrom
        _add_part(
            parts,
            create_icosphere(f"_tmp_shoulder_{tag}", 2, 0.14, (side * 0.36, 0.02, 1.54)),
            mat_prefix,
            "shell_shade",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_upper_arm_{tag}",
                7,
                0.11,
                0.075,
                0.42,
                (side * 0.54, -0.06, 1.44),
                rotation=(math.radians(-16.0), math.radians(side * 66.0), 0.0),
            ),
            mat_prefix,
            "shell_brown",
            pal,
        )
        # Antebraço fino prata-osso subindo para o punho da foice
        _add_part(
            parts,
            create_cone(
                f"_tmp_forearm_{tag}",
                7,
                0.065,
                0.095,
                0.48,
                (side * 0.84, -0.18, 1.56),
                rotation=(math.radians(-24.0), math.radians(side * 58.0), 0.0),
            ),
            mat_prefix,
            "blade_edge",
            pal,
        )
        # Articulação superior da lâmina da foice
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_scythe_knuckle_{tag}",
                2,
                0.115,
                (side * 1.02, -0.28, 1.68),
                scale=(0.84, 1.14, 1.18),
            ),
            mat_prefix,
            "blade_white",
            pal,
        )
        # Lâmina principal superior da foice descendo em arco afiado
        _add_part(
            parts,
            create_cone(
                f"_tmp_scythe_top_{tag}",
                5,
                0.15,
                0.11,
                0.56,
                (side * 1.10, -0.34, 1.38),
                rotation=(math.radians(-12.0), math.radians(side * 12.0), 0.0),
                scale=(0.46, 1.16, 1.0),
            ),
            mat_prefix,
            "blade_white",
            pal,
        )
        # Lâmina média curvando para dentro e baixo
        _add_part(
            parts,
            create_cone(
                f"_tmp_scythe_mid_{tag}",
                5,
                0.115,
                0.075,
                0.52,
                (side * 1.08, -0.40, 0.94),
                rotation=(math.radians(174.0), math.radians(side * -10.0), 0.0),
                scale=(0.42, 1.14, 1.0),
            ),
            mat_prefix,
            "blade_white",
            pal,
        )
        # Ponta navalha da foice curvando para frente/baixo
        _add_part(
            parts,
            create_cone(
                f"_tmp_scythe_tip_{tag}",
                4,
                0.078,
                0.012,
                0.46,
                (side * 0.94, -0.44, 0.56),
                rotation=(math.radians(164.0), math.radians(side * -30.0), 0.0),
                scale=(0.38, 1.12, 1.0),
            ),
            mat_prefix,
            "blade_edge",
            pal,
        )

    # 4. PERNAS BÍPEDES ÁGEIS COM GARRAS BRANCAS (Z = 0.0) + CAUDA AFIADA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa musculosa marrom
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.22,
                (side * 0.34, -0.06, 0.90),
                rotation=(math.radians(-26.0), math.radians(side * 10.0), 0.0),
                scale=(0.82, 1.08, 1.48),
            ),
            mat_prefix,
            "shell_brown",
            pal,
        )
        # Joelho arredondado
        _add_part(
            parts,
            create_icosphere(f"_tmp_knee_{tag}", 1, 0.11, (side * 0.38, -0.18, 0.64)),
            mat_prefix,
            "shell_shade",
            pal,
        )
        # Canela esguia angulada para trás e depois ao pé
        _add_part(
            parts,
            create_cone(
                f"_tmp_shin_{tag}",
                7,
                0.085,
                0.115,
                0.56,
                (side * 0.44, -0.04, 0.36),
                rotation=(math.radians(-24.0), math.radians(side * 8.0), 0.0),
            ),
            mat_prefix,
            "shell_shade",
            pal,
        )
        # Pé marrom com 2 garras brancas firmes em Z = 0.0
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.14,
                (side * 0.48, -0.10, 0.10),
                scale=(1.04, 1.32, 0.66),
            ),
            mat_prefix,
            "shell_brown",
            pal,
        )
        for c_idx, (dx, rot_z) in enumerate([(-0.08, -18.0), (0.08, 18.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_toe_claw_{tag}_{c_idx}",
                    5,
                    0.056,
                    0.012,
                    0.26,
                    (side * 0.48 + dx, -0.32, 0.065),
                    rotation=(math.radians(-98.0), 0.0, math.radians(rot_z)),
                ),
                mat_prefix,
                "blade_white",
                pal,
            )

    # Cauda longa pontiaguda apontando para baixo e trás
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_main",
            6,
            0.16,
            0.02,
            1.10,
            (0.0, 0.56, 0.62),
            rotation=(math.radians(130.0), 0.0, 0.0),
            scale=(0.82, 0.88, 1.0),
        ),
        mat_prefix,
        "shell_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 141. Scythefossil lado a lado."""
    specs = [
        ("Scythefossil_Shiny", (-11.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Scythefossil_Normal", (-6.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Scythefossil_Grande", (-1.2, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Scythefossil_Gigante", (5.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Scythefossil_Dourada_SuperRara", (13.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_scythefossil(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
