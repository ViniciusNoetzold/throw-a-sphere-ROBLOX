"""
115_Pouchrex_Kangaskhan_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "115. Pouchrex — Mãe Canguru (Ref: Kangaskhan)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Pouchrex_Shiny (1.0x - Paleta Shiny Cinza-Oliva + Barriga Verde-Creme + Filhote Azul-Petróleo)
  2. Pouchrex_Normal (1.0x - Marrom-Taupe + Capacete Escuro + Bolsa Creme com Filhote Lilás)
  3. Pouchrex_Grande (1.35x - Normal)
  4. Pouchrex_Gigante (1.85x - Normal)
  5. Pouchrex_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Filhote Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para mãe e filhote na bolsa, placas blindadas)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e rosto/bolsa apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_brown": (0.66, 0.56, 0.52, 1.0),
        "body_shade": (0.50, 0.42, 0.40, 1.0),
        "helmet_dark": (0.28, 0.26, 0.30, 1.0),
        "belly_cream": (0.90, 0.84, 0.62, 1.0),
        "baby_lilac": (0.74, 0.70, 0.88, 1.0),
        "mouth_pink": (0.86, 0.56, 0.64, 1.0),
        "eye_red": (0.84, 0.22, 0.22, 1.0),
        "eye_dark": (0.10, 0.10, 0.14, 1.0),
        "claw_white": (0.97, 0.97, 0.99, 1.0),
    },
    "shiny_palette": {
        "body_brown": (0.60, 0.62, 0.52, 1.0),
        "body_shade": (0.44, 0.46, 0.38, 1.0),
        "helmet_dark": (0.26, 0.28, 0.28, 1.0),
        "belly_cream": (0.86, 0.88, 0.64, 1.0),
        "baby_lilac": (0.50, 0.68, 0.70, 1.0),
        "mouth_pink": (0.84, 0.54, 0.62, 1.0),
        "eye_red": (0.86, 0.22, 0.22, 1.0),
        "eye_dark": (0.10, 0.10, 0.14, 1.0),
        "claw_white": (0.98, 0.98, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "body_brown": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.80, 0.56, 0.08, 1.0),
        "helmet_dark": (0.58, 0.38, 0.04, 1.0),
        "belly_cream": (1.00, 0.94, 0.56, 1.0),
        "baby_lilac": (0.10, 0.92, 1.00, 1.0),
        "mouth_pink": (0.88, 0.58, 0.14, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.06, 0.56, 0.72, 1.0),
        "claw_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_pouchrex(
    name: str = "Pouchrex_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 115. Pouchrex (Ref: Kangaskhan):
      - Mãe canguru-dinossauro robusta marrom-taupe com placas nos ombros/coxas e espinhos dorsais
      - Cabeça blindada com capacete escuro na testa, orelhas creme largas e boca rugindo com presas
      - Grande barriga e bolsa creme frontal abrigando um adorável filhote lilás espiando para fora
      - Braços erguidos com 3 garras brancas, patas pesadas em Z = 0.0 e cauda grossa à esquerda
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Pouch_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Pouch_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Pouch_Norm"

    parts = []

    # 1. TRONCO MATERNO ROBUSTO + BARRIGA CREME + BOLSA PROEMINENTE
    _add_part(
        parts,
        create_icosphere("_tmp_hips_torso", 2, 0.78, (0.0, 0.14, 0.90), scale=(1.06, 0.94, 1.04)),
        mat_prefix,
        "body_brown",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_chest_upper", 2, 0.62, (0.0, 0.06, 1.50), scale=(1.06, 0.88, 0.92)),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Peito/barriga creme
    _add_part(
        parts,
        create_icosphere("_tmp_belly_cream", 2, 0.60, (0.0, -0.20, 1.12), scale=(1.00, 0.72, 1.06)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # Bolsa frontal saliente abraçando o filhote
    _add_part(
        parts,
        create_icosphere("_tmp_pouch_front", 2, 0.56, (0.0, -0.44, 0.78), scale=(1.12, 0.74, 0.78)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # Sombra interna na abertura superior da bolsa
    _add_part(
        parts,
        create_icosphere("_tmp_pouch_opening", 1, 0.42, (0.0, -0.46, 1.08), scale=(1.06, 0.44, 0.24)),
        mat_prefix,
        "body_shade",
        pal,
    )

    # 2. FILHOTE LILÁS ESPIANDO DE DENTRO DA BOLSA (DETALHE ASSINATURA!)
    _add_part(
        parts,
        create_icosphere("_tmp_baby_torso", 2, 0.18, (0.0, -0.48, 1.14), scale=(1.00, 0.88, 0.96)),
        mat_prefix,
        "baby_lilac",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_baby_head", 2, 0.21, (-0.02, -0.54, 1.36), scale=(0.94, 1.02, 0.96)),
        mat_prefix,
        "baby_lilac",
        pal,
    )
    # Capacetinho escuro do filhote
    _add_part(
        parts,
        create_icosphere("_tmp_baby_helmet", 2, 0.19, (-0.02, -0.52, 1.48), scale=(0.92, 0.96, 0.46)),
        mat_prefix,
        "helmet_dark",
        pal,
    )
    # Orelhinhas creme + olhinhos escuros + boquinha surpresa do filhote
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_baby_ear_{tag}",
                4,
                0.055,
                0.012,
                0.15,
                (-0.02 + side * 0.20, -0.50, 1.42),
                rotation=(0.0, math.radians(side * 72.0), 0.0),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_baby_eye_{tag}", 1, 0.044, (-0.02 + side * 0.10, -0.71, 1.38), scale=(0.76, 0.50, 1.12)),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_baby_shine_{tag}", 1, 0.016, (-0.02 + side * 0.095, -0.735, 1.40)),
            mat_prefix,
            "claw_white",
            pal,
        )
        # Bracinhos do filhote apoiados na borda da bolsa com mini garras brancas
        _add_part(
            parts,
            create_cone(
                f"_tmp_baby_arm_{tag}",
                6,
                0.070,
                0.045,
                0.24,
                (side * 0.20, -0.66, 1.12),
                rotation=(math.radians(-42.0), math.radians(side * 58.0), 0.0),
            ),
            mat_prefix,
            "baby_lilac",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_baby_claw_{tag}", 1, 0.036, (side * 0.26, -0.76, 1.08), scale=(1.1, 0.8, 0.6)),
            mat_prefix,
            "claw_white",
            pal,
        )
    _add_part(
        parts,
        create_icosphere("_tmp_baby_mouth", 1, 0.042, (-0.02, -0.73, 1.28), scale=(0.76, 0.45, 1.18)),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # 3. CABEÇA DA MÃE + CAPACETE ESCURO + ORELHAS CREME + BOCA RUGINDO
    _add_part(
        parts,
        create_icosphere("_tmp_head_base", 2, 0.48, (0.0, -0.08, 2.12), scale=(0.98, 1.10, 0.88)),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Capacete escuro liso sobre o topo da cabeça até a ponte do focinho
    _add_part(
        parts,
        create_icosphere(
            "_tmp_head_helmet",
            2,
            0.46,
            (0.0, -0.14, 2.34),
            rotation=(math.radians(12.0), 0.0, 0.0),
            scale=(1.02, 1.16, 0.56),
        ),
        mat_prefix,
        "helmet_dark",
        pal,
    )
    # Focinho superior + boca aberta rugindo + mandíbula inferior + 2 presas brancas
    _add_part(
        parts,
        create_icosphere("_tmp_snout_top", 2, 0.30, (0.0, -0.52, 2.10), scale=(1.06, 0.96, 0.64)),
        mat_prefix,
        "body_brown",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_open", 2, 0.30, (0.0, -0.46, 1.88), scale=(1.08, 0.88, 0.70)),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_jaw_bot", 2, 0.28, (0.0, -0.42, 1.76), scale=(1.06, 0.96, 0.42)),
        mat_prefix,
        "body_brown",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Orelha creme larga em folha nas laterais da cabeça
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{tag}",
                6,
                0.20,
                0.04,
                0.56,
                (side * 0.58, -0.02, 2.34),
                rotation=(math.radians(-6.0), math.radians(side * 72.0), 0.0),
                scale=(1.00, 0.54, 1.00),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )
        # Olho feroz branco com íris rubi sob o capacete
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_w_{tag}",
                2,
                0.11,
                (side * 0.28, -0.52, 2.22),
                rotation=(0.0, math.radians(side * -14.0), math.radians(side * 22.0)),
                scale=(1.12, 0.44, 0.68),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_eye_r_{tag}", 1, 0.062, (side * 0.28, -0.565, 2.21), scale=(0.82, 0.46, 1.00)),
            mat_prefix,
            "eye_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_eye_p_{tag}", 1, 0.030, (side * 0.28, -0.59, 2.21), scale=(0.70, 0.46, 1.04)),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Presas superiores brancas
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.052,
                0.010,
                0.14,
                (side * 0.22, -0.62, 1.98),
                rotation=(math.radians(174.0), 0.0, 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 4. PLACAS DE ARMADURA NOS OMBROS + ESPINHOS DORSAIS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_pauldron_{tag}",
                (0.46, 0.36, 0.20),
                (side * 0.66, -0.02, 1.74),
                rotation=(math.radians(8.0), math.radians(side * 18.0), 0.0),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )
    for sp_i, (sy, sz) in enumerate([(0.64, 1.84), (0.76, 1.44), (0.80, 1.04)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_back_plate_{sp_i}",
                4,
                0.18,
                0.04,
                0.34,
                (0.0, sy, sz),
                rotation=(math.radians(74.0), 0.0, 0.0),
                scale=(0.56, 1.00, 1.00),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )

    # 5. BRAÇOS PODEROSOS ERGUIDOS EM DEFESA COM 3 GARRAS BRANCAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_upper_arm_{tag}",
                8,
                0.28,
                0.24,
                0.62,
                (side * 0.96, -0.08, 1.56),
                rotation=(math.radians(-12.0), math.radians(side * 80.0), 0.0),
            ),
            mat_prefix,
            "body_brown",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_forearm_{tag}",
                8,
                0.24,
                0.22,
                0.62,
                (side * 1.18, -0.24, 1.88),
                rotation=(math.radians(-22.0), math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "body_brown",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_fist_{tag}", 2, 0.25, (side * 1.18, -0.34, 2.16), scale=(1.04, 0.88, 1.02)),
            mat_prefix,
            "body_brown",
            pal,
        )
        for c_idx, (dx, dz) in enumerate([(-0.14, 0.16), (0.0, 0.22), (0.14, 0.14)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hclaw_{tag}_{c_idx}",
                    5,
                    0.072,
                    0.016,
                    0.18,
                    (side * 1.18 + dx, -0.44, 2.18 + dz),
                    rotation=(math.radians(-26.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 6. PERNAS MUSCULOSAS COM PLACA NO QUADRIL E PATAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(f"_tmp_thigh_{tag}", 2, 0.44, (side * 0.64, -0.02, 0.58), scale=(0.94, 1.10, 1.12)),
            mat_prefix,
            "body_brown",
            pal,
        )
        # Placa protetora lateral na coxa/joelho
        _add_part(
            parts,
            create_cube(
                f"_tmp_knee_plate_{tag}",
                (0.18, 0.36, 0.34),
                (side * 0.94, -0.08, 0.56),
                rotation=(0.0, math.radians(side * -12.0), 0.0),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_foot_{tag}", 2, 0.30, (side * 0.68, -0.20, 0.16), scale=(1.10, 1.36, 0.60)),
            mat_prefix,
            "body_brown",
            pal,
        )
        for c_idx, dx in enumerate((-0.16, 0.0, 0.16)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_fclaw_{tag}_{c_idx}",
                    5,
                    0.076,
                    0.016,
                    0.22,
                    (side * 0.68 + dx, -0.52, 0.10),
                    rotation=(math.radians(-80.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 7. CAUDA PESADA DE CANGURU CURVADA PARA A ESQUERDA (-X) ATRÁS DO CORPO
    tail_nodes = [
        (0.46, (-0.12, 0.68, 0.44), (1.02, 1.04, 0.90)),
        (0.38, (-0.60, 0.80, 0.36), (1.06, 0.96, 0.84)),
        (0.30, (-1.04, 0.78, 0.30), (1.08, 0.88, 0.78)),
        (0.22, (-1.38, 0.68, 0.26), (1.08, 0.82, 0.72)),
    ]
    for tl_i, (rad, loc, sc) in enumerate(tail_nodes):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tail_{tl_i}", 2, rad, loc, scale=sc),
            mat_prefix,
            "body_shade",
            pal,
        )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_tip",
            6,
            0.16,
            0.03,
            0.40,
            (-1.66, 0.60, 0.26),
            rotation=(0.0, math.radians(-84.0), math.radians(-16.0)),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 115. Pouchrex lado a lado."""
    specs = [
        ("Pouchrex_Shiny", (-11.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Pouchrex_Normal", (-6.3, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Pouchrex_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Pouchrex_Gigante", (6.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Pouchrex_Dourada_SuperRara", (15.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_pouchrex(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
