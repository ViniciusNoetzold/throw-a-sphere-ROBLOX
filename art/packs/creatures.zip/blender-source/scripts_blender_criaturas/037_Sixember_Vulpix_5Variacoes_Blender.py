"""
037_Sixember_Vulpix_5Variacoes_Blender.py
=========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "037. Sixember — Raposa de 6 Caudas (Ref: Vulpix)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Sixember_Shiny (1.0x - Paleta Shiny Dourado-Âmbar + Caudas e Topete Dourado-Laranja)
  2. Sixember_Normal (1.0x - Canela-Avermelhado + 3 Cachos e 6 Caudas Laranja-Brasa)
  3. Sixember_Grande (1.35x - Normal)
  4. Sixember_Gigante (1.85x - Normal)
  5. Sixember_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Pontas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para cabeça, corpo e cachos; cones 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e focinho apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_fur": (0.76, 0.43, 0.32, 1.0),
        "paw_dark": (0.52, 0.28, 0.22, 1.0),
        "belly_cream": (0.95, 0.90, 0.74, 1.0),
        "flame_orange": (0.92, 0.50, 0.24, 1.0),
        "flame_shade": (0.74, 0.34, 0.16, 1.0),
        "ear_inner": (0.28, 0.16, 0.14, 1.0),
        "eye_brown": (0.38, 0.24, 0.22, 1.0),
        "eye_dark": (0.14, 0.10, 0.10, 1.0),
        "mouth_pink": (0.86, 0.46, 0.54, 1.0),
        "white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_fur": (0.90, 0.74, 0.28, 1.0),
        "paw_dark": (0.68, 0.50, 0.16, 1.0),
        "belly_cream": (0.98, 0.94, 0.78, 1.0),
        "flame_orange": (0.96, 0.62, 0.18, 1.0),
        "flame_shade": (0.78, 0.44, 0.12, 1.0),
        "ear_inner": (0.42, 0.28, 0.12, 1.0),
        "eye_brown": (0.46, 0.30, 0.16, 1.0),
        "eye_dark": (0.16, 0.12, 0.08, 1.0),
        "mouth_pink": (0.90, 0.52, 0.54, 1.0),
        "white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_fur": (0.98, 0.78, 0.14, 1.0),
        "paw_dark": (0.82, 0.58, 0.08, 1.0),
        "belly_cream": (1.00, 0.95, 0.64, 1.0),
        "flame_orange": (1.00, 0.88, 0.28, 1.0),
        "flame_shade": (0.10, 0.92, 1.00, 1.0),
        "ear_inner": (0.08, 0.64, 0.78, 1.0),
        "eye_brown": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.06, 0.58, 0.74, 1.0),
        "mouth_pink": (0.86, 0.52, 0.10, 1.0),
        "white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_sixember(
    name: str = "Sixember_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de alta fidelidade do 037. Sixember (Ref: Vulpix):
      - Raposinha quadrúpede graciosamente proporcionada com peito e barriga creme
      - Focinho pontiagudo delicado, nariz preto brilhante, grandes olhos castanhos expressivos
      - Orelhas grandes de raposa com interior marrom-escuro
      - Topete icônico de 3 cachos enrolados laranja-brasa com franja caída na testa
      - 6 caudas volumosas enroladas nas pontas em leque radiante atrás do dorso
      - 4 patinhas delicadas com meias/pontas marrom-escuras apoiadas em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Sixember_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Sixember_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Sixember_Norm"

    parts = []

    # 1. TRONCO DE RAPOSINHA + PEITO E BARRIGA CREME
    _add_part(
        parts,
        create_icosphere("_tmp_torso", 2, 0.52, (0.0, 0.14, 0.72), scale=(0.86, 1.32, 0.84)),
        mat_prefix,
        "body_fur",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_chest_cream", 2, 0.36, (0.0, -0.30, 0.68), scale=(0.82, 0.78, 0.92)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_belly_cream", 1, 0.38, (0.0, 0.12, 0.50), scale=(0.74, 1.24, 0.50)),
        mat_prefix,
        "belly_cream",
        pal,
    )

    # 2. PESCOÇO ESGUIO + CABEÇA DE RAPOSA + FOCINHO DELICADO
    _add_part(
        parts,
        create_cone(
            "_tmp_neck",
            8,
            0.30,
            0.24,
            0.52,
            (0.0, -0.34, 1.02),
            rotation=(math.radians(22.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_fur",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.48, (0.0, -0.46, 1.30), scale=(1.04, 1.02, 0.94)),
        mat_prefix,
        "body_fur",
        pal,
    )
    # Focinho pontiagudo
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            8,
            0.26,
            0.09,
            0.46,
            (0.0, -0.86, 1.20),
            rotation=(math.radians(-82.0), 0.0, 0.0),
            scale=(0.94, 0.82, 1.0),
        ),
        mat_prefix,
        "body_fur",
        pal,
    )
    # Narizinho escuro
    _add_part(
        parts,
        create_icosphere("_tmp_nose", 1, 0.068, (0.0, -1.08, 1.23), scale=(1.15, 0.85, 0.78)),
        mat_prefix,
        "eye_dark",
        pal,
    )
    # Boquinha pequena entreaberta fofa
    _add_part(
        parts,
        create_icosphere("_tmp_mouth", 1, 0.064, (0.0, -0.94, 1.09), scale=(0.86, 0.55, 0.88)),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # 3. OLHOS GRANDES E EXPRESSIVOS DE RAPOSA COM BRILHO
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.145,
                (side * 0.23, -0.79, 1.35),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(1.12, 0.56, 0.96),
            ),
            mat_prefix,
            "eye_brown",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.095,
                (side * 0.22, -0.85, 1.36),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(0.98, 0.44, 0.90),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.056,
                (side * 0.19, -0.89, 1.40),
                scale=(0.92, 0.46, 0.92),
            ),
            mat_prefix,
            "white",
            pal,
        )

    # 4. ORELHAS GRANDES TRIANGULARES DE RAPOSA COM INTERIOR ESCURO
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{tag}",
                6,
                0.22,
                0.025,
                0.62,
                (side * 0.44, -0.34, 1.66),
                rotation=(math.radians(-10.0), math.radians(side * 42.0), math.radians(side * -14.0)),
                scale=(1.0, 0.52, 1.0),
            ),
            mat_prefix,
            "body_fur",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_in_{tag}",
                5,
                0.145,
                0.018,
                0.46,
                (side * 0.43, -0.40, 1.64),
                rotation=(math.radians(-10.0), math.radians(side * 42.0), math.radians(side * -14.0)),
                scale=(1.0, 0.36, 1.0),
            ),
            mat_prefix,
            "ear_inner",
            pal,
        )

    # 5. TOPETE DE 3 CACHOS ENROLADOS LARANJA-BRASA + FRANJA CAÍDA
    # Franja caída na testa
    for b_idx, (bx, by, bz, ry) in enumerate([(-0.14, -0.72, 1.62, -26.0), (0.02, -0.76, 1.64, 4.0), (0.16, -0.70, 1.62, 28.0)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_bang_{b_idx}",
                6,
                0.15,
                0.025,
                0.34,
                (bx, by, bz),
                rotation=(math.radians(122.0), math.radians(ry), 0.0),
                scale=(1.0, 0.65, 1.0),
            ),
            mat_prefix,
            "flame_orange",
            pal,
        )
    # 3 grandes cachos enrolados no topo da cabeça
    crest_curls = [
        (-0.22, -0.44, 1.84, 0.21),
        (0.00, -0.48, 1.92, 0.25),
        (0.22, -0.44, 1.84, 0.21),
    ]
    for c_idx, (cx, cy, cz, cr) in enumerate(crest_curls):
        _add_part(
            parts,
            create_icosphere(f"_tmp_crest_{c_idx}", 2, cr, (cx, cy, cz), scale=(0.94, 1.12, 1.02)),
            mat_prefix,
            "flame_orange",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_crest_tip_{c_idx}",
                1,
                cr * 0.56,
                (cx * 1.08, cy - 0.14, cz - 0.04),
                scale=(0.88, 0.88, 0.88),
            ),
            mat_prefix,
            "flame_shade",
            pal,
        )

    # 6. 4 PATAS ESGUIAS COM MEIAS ESCURAS E DEDINHOS (Z = 0.0)
    leg_specs = [
        ("FL", -0.25, -0.26, 0.0),
        ("FR", 0.25, -0.26, 0.0),
        ("BL", -0.27, 0.50, 8.0),
        ("BR", 0.27, 0.50, 8.0),
    ]
    for tag, lx, ly, rx_deg in leg_specs:
        # Coxa / parte superior canela
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_up_{tag}",
                8,
                0.13,
                0.18,
                0.42,
                (lx, ly, 0.44),
                rotation=(math.radians(rx_deg), 0.0, 0.0),
            ),
            mat_prefix,
            "body_fur",
            pal,
        )
        # Canela inferior marrom-escuro
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_low_{tag}",
                8,
                0.11,
                0.13,
                0.28,
                (lx, ly - 0.02, 0.17),
            ),
            mat_prefix,
            "paw_dark",
            pal,
        )
        # Pata fofa arredondada
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_paw_{tag}",
                1,
                0.125,
                (lx, ly - 0.07, 0.07),
                scale=(1.02, 1.24, 0.62),
            ),
            mat_prefix,
            "paw_dark",
            pal,
        )

    # 7. SEIS CAUDAS ENROLADAS EM LEQUE VOLUMOSO LARANJA-BRASA (ASSINATURA DA VULPIX)
    # Distribuídas em 2 camadas (superior e lateral-inferior) para todas as 6 brilharem na vista frontal!
    tail_specs = [
        # (x_mid, y_mid, z_mid, x_curl, y_curl, z_curl, rad_mid, rad_curl, rot_y_deg)
        (-0.88, 0.82, 1.06, -1.04, 0.72, 0.90, 0.26, 0.22, -62.0),
        (-0.62, 0.92, 1.48, -0.78, 0.80, 1.62, 0.28, 0.24, -36.0),
        (-0.22, 0.98, 1.72, -0.26, 0.86, 1.92, 0.29, 0.25, -12.0),
        (0.22, 0.98, 1.72, 0.26, 0.86, 1.92, 0.29, 0.25, 12.0),
        (0.62, 0.92, 1.48, 0.78, 0.80, 1.62, 0.28, 0.24, 36.0),
        (0.88, 0.82, 1.06, 1.04, 0.72, 0.90, 0.26, 0.22, 62.0),
    ]
    for t_idx, (mx, my, mz, cx, cy, cz, rm, rc, ry_deg) in enumerate(tail_specs):
        # Haste conectora da base da cauda (0.0, 0.66, 0.78) até o bojo da cauda
        bx = mx * 0.42
        by = 0.68 + (my - 0.68) * 0.45
        bz = 0.78 + (mz - 0.78) * 0.45
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_stem_{t_idx}",
                7,
                0.12,
                rm * 0.85,
                0.68,
                (bx, by, bz),
                rotation=(math.radians(-28.0), math.radians(ry_deg), 0.0),
            ),
            mat_prefix,
            "flame_orange",
            pal,
        )
        # Bojo fofo principal da cauda
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_tail_puff_{t_idx}",
                2,
                rm,
                (mx, my, mz),
                scale=(0.94, 0.88, 1.16),
            ),
            mat_prefix,
            "flame_orange",
            pal,
        )
        # Ponta enrolada em caracol
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_tail_curl_{t_idx}",
                2,
                rc,
                (cx, cy, cz),
                scale=(0.96, 0.82, 0.96),
            ),
            mat_prefix,
            "flame_orange",
            pal,
        )
        # Marca sutil de espiral na face frontal do caracol
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_tail_mark_{t_idx}",
                1,
                rc * 0.46,
                (cx, cy - rc * 0.68, cz),
                scale=(0.90, 0.35, 0.90),
            ),
            mat_prefix,
            "flame_shade",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 037. Sixember lado a lado."""
    specs = [
        ("Sixember_Shiny", (-9.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Sixember_Normal", (-5.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Sixember_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Sixember_Gigante", (4.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Sixember_Dourada_SuperRara", (11.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_sixember(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
