"""
003_Jungleking_Venusaur_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "003. Jungleking — Colosso Florido (Ref: Venusaur)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Jungleking_Shiny (1.0x - Paleta Shiny / Shyne Verde-Lima + Flor Dourada)
  2. Jungleking_Normal (1.0x - Pele Verde-Água + Folhagem Palmeiras + Flor Vermelho-Coral)
  3. Jungleking_Grande (1.35x - Normal)
  4. Jungleking_Gigante (1.85x - Normal)
  5. Jungleking_Dourada_SuperRara (2.25x - Ouro Reluzente + Flor Ouro-Platina + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-8 lados, cilindros 8 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.020`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base das patas e garras alinhada exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Jungleking_Shiny`, `Jungleking_Normal`, `Jungleking_Grande`,
     `Jungleking_Gigante`, `Jungleking_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.020,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_teal": (0.32, 0.70, 0.64, 1.0),
        "spots_dark": (0.14, 0.42, 0.46, 1.0),
        "leaves_green": (0.12, 0.54, 0.22, 1.0),
        "trunk_brown": (0.38, 0.24, 0.16, 1.0),
        "petal_coral": (0.92, 0.26, 0.32, 1.0),
        "petal_dots": (0.97, 0.95, 0.96, 1.0),
        "crown_yellow": (0.98, 0.84, 0.24, 1.0),
        "ear_inner": (0.82, 0.32, 0.36, 1.0),
        "claws_white": (0.97, 0.97, 0.98, 1.0),
        "eyes_ruby": (0.86, 0.16, 0.22, 1.0),
    },
    "shiny_palette": {
        "body_teal": (0.56, 0.90, 0.36, 1.0),
        "spots_dark": (0.26, 0.60, 0.20, 1.0),
        "leaves_green": (0.20, 0.68, 0.24, 1.0),
        "trunk_brown": (0.48, 0.34, 0.18, 1.0),
        "petal_coral": (0.98, 0.80, 0.16, 1.0),
        "petal_dots": (1.00, 0.97, 0.82, 1.0),
        "crown_yellow": (1.00, 0.90, 0.36, 1.0),
        "ear_inner": (0.90, 0.64, 0.20, 1.0),
        "claws_white": (0.98, 0.98, 0.99, 1.0),
        "eyes_ruby": (0.92, 0.72, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "body_teal": (0.98, 0.78, 0.14, 1.0),
        "spots_dark": (0.72, 0.48, 0.06, 1.0),
        "leaves_green": (0.86, 0.64, 0.10, 1.0),
        "trunk_brown": (0.64, 0.42, 0.08, 1.0),
        "petal_coral": (1.00, 0.92, 0.46, 1.0),
        "petal_dots": (1.00, 0.99, 0.88, 1.0),
        "crown_yellow": (1.00, 0.86, 0.22, 1.0),
        "ear_inner": (0.88, 0.62, 0.12, 1.0),
        "claws_white": (1.00, 0.96, 0.82, 1.0),
        "eyes_ruby": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base das patas em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_jungleking(
    name: str = "Jungleking_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 003. Jungleking (Ref: Venusaur):
      - Frente apontando para -Y e base das 4 patas e garras em Z = 0.0
      - Torso colossal largo com pele verrugosa em blocos e 4 patas pesadas
      - Cabeça larga com mandíbula imponente, presas, orelhas internas e olhos rubi/diamante
      - 4 folhas largas de palmeira + tronco grosso + flor gigante de 6 pétalas com pintas brancas e coroa amarela
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Jungle_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Jungle_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Jungle"

    parts = []

    # 1. TORSO COLOSSAL + VERRUGAS / MANCHAS EM BLOCOS
    _add_part(
        parts,
        create_cube("_tmp_torso", (1.88, 2.10, 1.16), (0.0, 0.18, 0.96), (math.radians(6), 0.0, 0.0)),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_rump", (1.68, 0.92, 0.98), (0.0, 0.98, 0.84), (math.radians(-10), 0.0, 0.0)),
        mat_prefix,
        "body_teal",
        pal,
    )
    warts = [
        ((-0.94, 0.02, 1.06), 0.20, (0.5, 1.1, 0.9)),
        ((-0.90, 0.62, 0.92), 0.22, (0.5, 1.2, 1.0)),
        ((0.94, -0.06, 1.08), 0.19, (0.5, 1.0, 0.9)),
        ((0.92, 0.56, 0.94), 0.23, (0.5, 1.2, 1.0)),
        ((-0.82, 0.96, 0.60), 0.16, (0.6, 0.9, 0.8)),
        ((0.82, 0.96, 0.60), 0.16, (0.6, 0.9, 0.8)),
    ]
    for idx, (loc, rad, scl) in enumerate(warts):
        _add_part(
            parts,
            create_icosphere(f"_tmp_wart_{idx}", 1, rad, loc, scale=scl),
            mat_prefix,
            "spots_dark",
            pal,
        )

    # 2. QUATRO PATAS PESADAS DE COLOSSO + 3 GARRAS BRANCAS POR PATA
    legs = [
        (-0.78, -0.48, 0.44, 0.36, 0.30, 0.88),
        (0.78, -0.48, 0.44, 0.36, 0.30, 0.88),
        (-0.82, 0.82, 0.42, 0.38, 0.33, 0.84),
        (0.82, 0.82, 0.42, 0.38, 0.33, 0.84),
    ]
    for idx, (lx, ly, lz, r1, r2, dep) in enumerate(legs):
        _add_part(
            parts,
            create_cone(f"_tmp_leg_{idx}", 6, r1, r2, dep, (lx, ly, lz)),
            mat_prefix,
            "body_teal",
            pal,
        )
        for claw_i, cx_off in enumerate([-0.17, 0.0, 0.17]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_claw_{idx}_{claw_i}",
                    4,
                    0.085,
                    0.014,
                    0.25,
                    (lx + cx_off, ly - 0.36, 0.085),
                    (math.radians(86), 0.0, 0.0),
                ),
                mat_prefix,
                "claws_white",
                pal,
            )

    # 3. CABEÇA LARGA (-Y), BOCA COM PRESAS, ORELHAS E FOLHA FRONTAL
    _add_part(
        parts,
        create_cube("_tmp_head", (1.64, 1.20, 0.98), (0.0, -1.04, 1.18), (math.radians(-4), 0.0, 0.0)),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout", (1.36, 0.56, 0.48), (0.0, -1.62, 0.94)),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth_inner", (1.18, 0.12, 0.16), (0.0, -1.86, 0.86)),
        mat_prefix,
        "ear_inner",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_lower_jaw", (1.24, 0.24, 0.10), (0.0, -1.78, 0.75)),
        mat_prefix,
        "body_teal",
        pal,
    )
    # Folha frontal característica caindo sobre a testa
    _add_part(
        parts,
        create_cone(
            "_tmp_forehead_frond",
            4,
            0.42,
            0.05,
            0.92,
            (0.0, -0.92, 1.66),
            (0.0, math.radians(88), math.radians(-90)),
            scale=(0.24, 1.0, 1.0),
        ),
        mat_prefix,
        "leaves_green",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_outer_{side_idx}",
                4,
                0.28,
                0.04,
                0.50,
                (sx * 0.64, -0.88, 1.76),
                (math.radians(-10), math.radians(sx * 20), 0.0),
                scale=(0.90, 0.72, 1.0),
            ),
            mat_prefix,
            "body_teal",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_inner_{side_idx}",
                4,
                0.18,
                0.02,
                0.34,
                (sx * 0.63, -0.97, 1.72),
                (math.radians(-10), math.radians(sx * 20), 0.0),
                scale=(0.80, 0.50, 1.0),
            ),
            mat_prefix,
            "ear_inner",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{side_idx}",
                (0.34, 0.14, 0.08),
                (sx * 0.44, -1.62, 1.37),
                (0.0, math.radians(sx * 14), 0.0),
            ),
            mat_prefix,
            "spots_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_sclera_{side_idx}",
                (0.32, 0.10, 0.24),
                (sx * 0.44, -1.61, 1.22),
                (0.0, math.radians(sx * 12), 0.0),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_iris_{side_idx}",
                (0.18, 0.08, 0.19),
                (sx * 0.43, -1.64, 1.22),
                (0.0, math.radians(sx * 12), 0.0),
            ),
            mat_prefix,
            "eyes_ruby",
            pal,
        )
        # Presas superiores e inferiores na mandíbula larga
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_up_{side_idx}",
                4,
                0.070,
                0.012,
                0.18,
                (sx * 0.42, -1.87, 0.90),
                (math.radians(180), 0.0, 0.0),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_low_{side_idx}",
                4,
                0.058,
                0.010,
                0.15,
                (sx * 0.34, -1.88, 0.80),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )

    # 4. FOLHAS DE PALMEIRA + TRONCO GROSSO + FLOR GIGANTE DE 6 PÉTALAS COM PINTAS E COROA AMARELA
    _add_part(
        parts,
        create_cylinder("_tmp_crown_base", 8, 0.72, 0.24, (0.0, 0.28, 1.48), (math.radians(-4), 0.0, 0.0)),
        mat_prefix,
        "leaves_green",
        pal,
    )
    for idx, deg in enumerate([45.0, 135.0, 225.0, 315.0]):
        ang = math.radians(deg)
        lx = math.cos(ang) * 0.96
        ly = 0.28 + math.sin(ang) * 0.96
        _add_part(
            parts,
            create_cone(
                f"_tmp_palm_leaf_{idx}",
                4,
                0.56,
                0.04,
                1.68,
                (lx, ly, 1.60),
                (0.0, math.radians(76), ang),
                scale=(0.26, 1.0, 1.0),
            ),
            mat_prefix,
            "leaves_green",
            pal,
        )

    # Tronco de palmeira grosso sustentando a flor gigante
    _add_part(
        parts,
        create_cone("_tmp_palm_trunk", 8, 0.46, 0.38, 0.95, (0.0, 0.30, 1.88)),
        mat_prefix,
        "trunk_brown",
        pal,
    )

    # 6 Pétalas largas com 2 pintas brancas facetadas cada
    for idx in range(6):
        ang = math.radians(idx * 60.0 + 30.0)
        px = math.cos(ang) * 0.74
        py = 0.30 + math.sin(ang) * 0.74
        _add_part(
            parts,
            create_cone(
                f"_tmp_petal_{idx}",
                4,
                0.24,
                0.68,
                1.48,
                (px, py, 2.38),
                (0.0, math.radians(96), ang),
                scale=(0.20, 1.0, 1.0),
            ),
            mat_prefix,
            "petal_coral",
            pal,
        )
        # Duas pintas brancas assentadas sobre a superfície da pétala
        d1_x = math.cos(ang) * 0.58
        d1_y = 0.30 + math.sin(ang) * 0.58
        d2_x = math.cos(ang) * 1.02
        d2_y = 0.30 + math.sin(ang) * 1.02
        _add_part(
            parts,
            create_cube(f"_tmp_petal_dot_in_{idx}", (0.24, 0.22, 0.08), (d1_x, d1_y, 2.48), (0.0, math.radians(6), ang)),
            mat_prefix,
            "petal_dots",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_petal_dot_out_{idx}", (0.30, 0.28, 0.08), (d2_x, d2_y, 2.42), (0.0, math.radians(8), ang)),
            mat_prefix,
            "petal_dots",
            pal,
        )

    # Miolo / coroa amarela central no topo da flor
    _add_part(
        parts,
        create_cylinder("_tmp_crown_center", 8, 0.34, 0.32, (0.0, 0.30, 2.52)),
        mat_prefix,
        "crown_yellow",
        pal,
    )
    for tip_i in range(8):
        tang = math.radians(tip_i * 45.0)
        tx = math.cos(tang) * 0.27
        ty = 0.30 + math.sin(tang) * 0.27
        _add_part(
            parts,
            create_cone(f"_tmp_crown_tip_{tip_i}", 4, 0.11, 0.02, 0.24, (tx, ty, 2.72)),
            mat_prefix,
            "crown_yellow",
            pal,
        )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """
    Gera lado a lado os 5 modelos do 003. Jungleking (Venusaur):
      1. Shiny (1.0x) | 2. Normal (1.0x) | 3. Grande (1.35x) | 4. Gigante (1.85x) | 5. Dourada Super Rara (2.25x)
    """
    build_jungleking("Jungleking_Shiny", location=(-9.2, 0.0, 0.0), scale=CONFIG["scales"]["Shiny"], variant="Shiny")
    build_jungleking("Jungleking_Normal", location=(-5.5, 0.0, 0.0), scale=CONFIG["scales"]["Normal"], variant="Normal")
    build_jungleking("Jungleking_Grande", location=(-1.2, 0.0, 0.0), scale=CONFIG["scales"]["Grande"], variant="Normal")
    build_jungleking("Jungleking_Gigante", location=(4.4, 0.0, 0.0), scale=CONFIG["scales"]["Gigante"], variant="Normal")
    build_jungleking(
        "Jungleking_Dourada_SuperRara",
        location=(11.8, 0.0, 0.0),
        scale=CONFIG["scales"]["DouradaSuperRara"],
        variant="DouradaSuperRara",
    )


if __name__ == "__main__":
    generate_variations()
    print("003. Jungleking (5 variações: Shiny, Normal, Grande, Gigante e Dourada Super Rara) gerado com sucesso!")
