"""
120_Starcore_Staryu_5Variacoes_Blender.py
=========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "120. Starcore — Estrela Marinha (Ref: Staryu)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Starcore_Shiny (1.0x - Paleta Shiny Pérola-Prata + Armação Água-Marinha + Gema Safira)
  2. Starcore_Normal (1.0x - Estrela Marrom-Dourada + Armação Ouro + Gema Rubi Central)
  3. Starcore_Grande (1.35x - Normal)
  4. Starcore_Gigante (1.85x - Normal)
  5. Starcore_Dourada_SuperRara (2.25x - Ouro Reluzente + Núcleo e Gema Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada nítida (5 pontas em cones 4-lados com crista central para -Y, cúpula e garras douradas, gema rubi cabochão brilhante)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pontas inferiores apoiadas exatamente em `Z = 0.0` e gema central apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "star_brown": (0.64, 0.50, 0.34, 1.0),
        "star_shade": (0.48, 0.36, 0.22, 1.0),
        "gold_ring": (0.94, 0.84, 0.44, 1.0),
        "gold_band": (0.82, 0.72, 0.34, 1.0),
        "gem_ruby": (0.86, 0.24, 0.34, 1.0),
        "gem_deep": (0.64, 0.14, 0.24, 1.0),
        "gem_shine": (0.99, 0.96, 0.98, 1.0),
    },
    "shiny_palette": {
        "star_brown": (0.84, 0.86, 0.80, 1.0),
        "star_shade": (0.68, 0.70, 0.66, 1.0),
        "gold_ring": (0.36, 0.76, 0.78, 1.0),
        "gold_band": (0.26, 0.62, 0.66, 1.0),
        "gem_ruby": (0.20, 0.48, 0.94, 1.0),
        "gem_deep": (0.12, 0.32, 0.72, 1.0),
        "gem_shine": (0.96, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "star_brown": (0.98, 0.78, 0.14, 1.0),
        "star_shade": (0.84, 0.60, 0.08, 1.0),
        "gold_ring": (1.00, 0.92, 0.50, 1.0),
        "gold_band": (0.90, 0.72, 0.18, 1.0),
        "gem_ruby": (0.10, 0.92, 1.00, 1.0),
        "gem_deep": (0.04, 0.58, 0.76, 1.0),
        "gem_shine": (1.00, 1.00, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_starcore(
    name: str = "Starcore_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de 120. Starcore (Ref: Staryu):
      - Estrela-do-mar rígida de 5 pontas simétricas com cristas centrais nítidas (cones 4-lados)
      - Cúpula central dourada com 5 hastes radiais encaixadas entre os braços da estrela
      - Faixa dourada característica abraçando o braço lateral esquerdo/inferior (fiel à arte!)
      - Gema rubi redonda facetada protuberante no centro (-Y) com brilho especular branco
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Sty_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Sty_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Sty_Norm"

    parts = []
    center_z = 1.18

    # 1. NÚCLEO CENTRAL DA ESTRELA + 5 PONTAS SIMÉTRICAS COM CRISTA CENTRAL FACETADA
    _add_part(
        parts,
        create_icosphere(
            "_tmp_star_hub",
            2,
            0.54,
            (0.0, 0.02, center_z),
            scale=(1.02, 0.64, 1.02),
        ),
        mat_prefix,
        "star_brown",
        pal,
    )

    arm_len = 1.18
    arm_offset = 0.62
    for i in range(5):
        ang_deg = i * 72.0  # 0 (topo), 72, 144, 216, 288
        ang = math.radians(ang_deg)
        ax = arm_offset * math.sin(ang)
        az = center_z + arm_offset * math.cos(ang)
        _add_part(
            parts,
            create_cone(
                f"_tmp_star_arm_{i}",
                4,
                0.44,
                0.045,
                arm_len,
                (ax, 0.0, az),
                rotation=(0.0, ang, 0.0),
                scale=(1.0, 0.68, 1.0),
            ),
            mat_prefix,
            "star_brown",
            pal,
        )

    # 2. CÚPULA METÁLICA DOURADA CENTRAL + 5 GARRAS RADIAIS ENTRE OS BRAÇOS
    _add_part(
        parts,
        create_icosphere(
            "_tmp_gold_dome",
            2,
            0.54,
            (0.0, -0.10, center_z),
            scale=(1.02, 0.68, 1.02),
        ),
        mat_prefix,
        "gold_ring",
        pal,
    )
    # 5 hastes radiais douradas nos vales entre as pontas (36°, 108°, 180°, 252°, 324°)
    for i in range(5):
        ang = math.radians(36.0 + i * 72.0)
        sx = 0.44 * math.sin(ang)
        sz = center_z + 0.44 * math.cos(ang)
        _add_part(
            parts,
            create_cube(
                f"_tmp_gold_prong_{i}",
                (0.14, 0.46, 0.34),
                (sx, -0.12, sz),
                rotation=(0.0, ang, 0.0),
            ),
            mat_prefix,
            "gold_ring",
            pal,
        )

    # Anel dourado traseiro / trava envolvendo a base do braço lateral direito (72°, detalhe icônico!)
    band_ang = math.radians(108.0)
    _add_part(
        parts,
        create_cylinder(
            "_tmp_gold_arm_band",
            8,
            0.34,
            0.16,
            (0.46 * math.sin(math.radians(72.0)), 0.0, center_z + 0.46 * math.cos(math.radians(72.0))),
            rotation=(0.0, math.radians(72.0), 0.0),
            scale=(0.95, 0.72, 1.0),
        ),
        mat_prefix,
        "gold_band",
        pal,
    )
    # Trava inferior no vale de 180°
    _add_part(
        parts,
        create_cube(
            "_tmp_gold_bottom_clasp",
            (0.24, 0.56, 0.24),
            (0.0, 0.0, center_z - 0.48),
        ),
        mat_prefix,
        "gold_band",
        pal,
    )
    _ = band_ang

    # 3. GEMA RUBI CENTRAL PROEMINENTE + ARO + BRILHO ESPECULAR
    # Aro dourado emoldurando a gema
    _add_part(
        parts,
        create_cylinder(
            "_tmp_gem_bezel",
            8,
            0.30,
            0.14,
            (0.0, -0.40, center_z),
            rotation=(math.radians(90.0), 0.0, 0.0),
        ),
        mat_prefix,
        "gold_ring",
        pal,
    )
    # Gema rubi brilhante cabochão
    _add_part(
        parts,
        create_icosphere(
            "_tmp_gem_core",
            2,
            0.25,
            (0.0, -0.45, center_z),
            scale=(1.0, 0.62, 1.0),
        ),
        mat_prefix,
        "gem_ruby",
        pal,
    )
    # Brilhos brancos sobre a gema (superior esquerdo e pequeno ponto abaixo)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_gem_shine_main",
            1,
            0.072,
            (-0.08, -0.58, center_z + 0.09),
            scale=(1.0, 0.45, 0.85),
        ),
        mat_prefix,
        "gem_shine",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_gem_shine_sub",
            1,
            0.036,
            (-0.11, -0.59, center_z + 0.01),
            scale=(1.0, 0.45, 1.0),
        ),
        mat_prefix,
        "gem_shine",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 120. Starcore lado a lado."""
    specs = [
        ("Starcore_Shiny", (-10.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Starcore_Normal", (-6.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Starcore_Grande", (-1.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Starcore_Gigante", (4.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Starcore_Dourada_SuperRara", (11.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_starcore(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
