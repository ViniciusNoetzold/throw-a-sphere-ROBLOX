"""
086_Frostseal_Seel_5Variacoes_Blender.py
========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "086. Frostseal — Foca Glacial (Ref: Seel)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Frostseal_Shiny (1.0x - Paleta Shiny Branco-Marfim / Creme-Dourado + Focinho Dourado)
  2. Frostseal_Normal (1.0x - Foca Branco-Gelo + Chifre na Testa + Focinho Creme + Língua Rosa + Cauda em Leque)
  3. Frostseal_Grande (1.35x - Normal)
  4. Frostseal_Gigante (1.85x - Normal)
  5. Frostseal_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Chifre e Nariz Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2, nadadeiras recortadas, cauda bifurcada erguida)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Barriga e nadadeiras apoiadas exatamente em `Z = 0.0` e rosto/língua apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_white": (0.91, 0.94, 0.98, 1.0),
        "body_shade": (0.76, 0.83, 0.91, 1.0),
        "muzzle_tan": (0.94, 0.86, 0.68, 1.0),
        "tongue_pink": (0.94, 0.66, 0.78, 1.0),
        "eye_dark": (0.10, 0.14, 0.16, 1.0),
        "eye_teal": (0.14, 0.34, 0.32, 1.0),
        "tusk_white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_white": (0.98, 0.94, 0.78, 1.0),
        "body_shade": (0.86, 0.80, 0.60, 1.0),
        "muzzle_tan": (0.96, 0.82, 0.56, 1.0),
        "tongue_pink": (0.96, 0.62, 0.74, 1.0),
        "eye_dark": (0.12, 0.14, 0.16, 1.0),
        "eye_teal": (0.16, 0.36, 0.34, 1.0),
        "tusk_white": (1.00, 0.99, 0.94, 1.0),
    },
    "golden_super_rare_palette": {
        "body_white": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.62, 0.10, 1.0),
        "muzzle_tan": (1.00, 0.90, 0.44, 1.0),
        "tongue_pink": (0.14, 0.92, 1.00, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "eye_teal": (0.06, 0.68, 0.88, 1.0),
        "tusk_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel angular e Flat Shading."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_frostseal(
    name: str = "Frostseal_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 086. Frostseal (Ref: Seel):
      - Corpo rechonchudo de foca branco-gelo deitado em Z = 0.0 curvando para cima atrás
      - Cauda bifurcada em coração/leque erguida com lobos recortados visível por cima do dorso
      - Cabeça redonda frontal com chifre pontudo branco na testa, olhos fofos brilhantes e sobrancelhas
      - Focinho creme largo com nariz preto, duas presinhas brancas subindo e língua rosa alegre à mostra
      - Duas nadadeiras frontais largas com 3 lobos abertas para os lados apoiadas no chão
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Seal_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Seal_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Seal_Norm"

    parts = []

    # 1. CORPO DE FOCA ALONGADO E CURVADO PARA CIMA ATRÁS (EM C SUAVE)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_body_front",
            2,
            0.66,
            (0.0, -0.02, 0.56),
            scale=(1.04, 1.24, 0.84),
        ),
        mat_prefix,
        "body_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_body_mid",
            2,
            0.58,
            (0.06, 0.64, 0.72),
            rotation=(math.radians(24.0), 0.0, math.radians(-8.0)),
            scale=(0.94, 1.18, 0.82),
        ),
        mat_prefix,
        "body_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_body_rear",
            2,
            0.40,
            (0.14, 1.14, 1.12),
            rotation=(math.radians(52.0), 0.0, math.radians(-10.0)),
            scale=(0.82, 1.25, 0.76),
        ),
        mat_prefix,
        "body_white",
        pal,
    )
    # Pescoço da cauda afunilando para a nadadeira traseira
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_stem",
            8,
            0.34,
            0.22,
            0.56,
            (0.18, 1.38, 1.54),
            rotation=(math.radians(-22.0), math.radians(8.0), 0.0),
        ),
        mat_prefix,
        "body_white",
        pal,
    )

    # 2. CAUDA BIFURCADA EM LEQUE ERGUIDA ATRÁS (COM LOBOS RECORTADOS)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        base_x = 0.18 + side * 0.44
        base_z = 1.88
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_fluke_main_{tag}",
                2,
                0.38,
                (base_x, 1.46, base_z),
                rotation=(math.radians(16.0), math.radians(side * -24.0), math.radians(side * 10.0)),
                scale=(1.32, 0.34, 0.86),
            ),
            mat_prefix,
            "body_white",
            pal,
        )
        # 3 pontinhas recortadas em cada lobo da cauda
        for l_idx, (dx, dz, rad) in enumerate([
            (side * 0.34, 0.18, 0.21),
            (side * 0.44, -0.02, 0.20),
            (side * 0.32, -0.22, 0.18),
        ]):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_fluke_lobe_{tag}_{l_idx}",
                    1,
                    rad,
                    (base_x + dx, 1.44, base_z + dz),
                    scale=(1.15, 0.34, 0.82),
                ),
                mat_prefix,
                "body_shade" if l_idx == 2 else "body_white",
                pal,
            )

    # 3. CABEÇA REDONDA FOFA + CHIFRE NA TESTA + OLHOS + FOCINHO CREME + PRESAS + LÍNGUA ROSA
    _add_part(
        parts,
        create_icosphere(
            "_tmp_head",
            2,
            0.56,
            (-0.04, -0.66, 0.62),
            scale=(1.04, 1.00, 0.96),
        ),
        mat_prefix,
        "body_white",
        pal,
    )
    # Pequeno chifre branco cônico no alto da testa
    _add_part(
        parts,
        create_cone(
            "_tmp_horn",
            7,
            0.14,
            0.018,
            0.44,
            (-0.04, -0.78, 1.24),
            rotation=(math.radians(14.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_white" if variant != "DouradaSuperRara" else "eye_dark",
        pal,
    )

    # Olhos redondos brilhantes + íris azul-petróleo + sobrancelhas delicadas
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.115,
                (-0.04 + side * 0.26, -1.14, 0.72),
                scale=(0.86, 0.54, 1.15),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.068,
                (-0.04 + side * 0.26, -1.19, 0.67),
                scale=(0.82, 0.45, 0.72),
            ),
            mat_prefix,
            "eye_teal",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_sh_{tag}",
                1,
                0.044,
                (-0.04 + side * 0.24, -1.21, 0.78),
                scale=(0.80, 0.45, 1.00),
            ),
            mat_prefix,
            "tusk_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.14, 0.04, 0.03),
                (-0.04 + side * 0.27, -1.14, 0.90),
                rotation=(0.0, math.radians(side * 18.0), 0.0),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Focinho creme largo dividido em dois lobos fofos + nariz preto oval
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_muzzle_{tag}",
                2,
                0.24,
                (-0.04 + side * 0.22, -1.16, 0.44),
                scale=(1.15, 0.92, 0.82),
            ),
            mat_prefix,
            "muzzle_tan",
            pal,
        )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_muzzle_bridge",
            2,
            0.22,
            (-0.04, -1.16, 0.48),
            scale=(1.22, 0.86, 0.70),
        ),
        mat_prefix,
        "muzzle_tan",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_nose",
            1,
            0.09,
            (-0.04, -1.34, 0.56),
            scale=(1.25, 0.80, 0.72),
        ),
        mat_prefix,
        "eye_dark",
        pal,
    )

    # Duas presinhas brancas fofas apontando para cima nas laterais do focinho
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_tusk_{tag}",
                6,
                0.085,
                0.015,
                0.26,
                (-0.04 + side * 0.29, -1.32, 0.34),
                rotation=(math.radians(-16.0), math.radians(side * -14.0), 0.0),
            ),
            mat_prefix,
            "tusk_white",
            pal,
        )

    # Língua rosa achatada saindo alegremente da boca
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tongue",
            2,
            0.22,
            (-0.04, -1.34, 0.26),
            rotation=(math.radians(24.0), 0.0, 0.0),
            scale=(1.08, 1.12, 0.38),
        ),
        mat_prefix,
        "tongue_pink",
        pal,
    )

    # 4. DUAS NADADEIRAS FRONTAIS LARGAS COM 3 LOBOS ABERTAS LATERALMENTE EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_flipper_{tag}",
                2,
                0.42,
                (side * 0.92, -0.34, 0.20),
                rotation=(0.0, math.radians(side * 8.0), math.radians(side * -14.0)),
                scale=(1.42, 0.78, 0.34),
            ),
            mat_prefix,
            "body_white",
            pal,
        )
        # 3 dedinhos/lobos arredondados na ponta da nadadeira
        for f_idx, (dy, dz) in enumerate([(-0.18, 0.0), (0.0, -0.02), (0.18, 0.0)]):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_flip_lobe_{tag}_{f_idx}",
                    1,
                    0.16,
                    (side * 1.38, -0.38 + dy, 0.16 + dz),
                    scale=(1.18, 0.72, 0.38),
                ),
                mat_prefix,
                "body_white" if f_idx != 2 else "body_shade",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 086. Frostseal lado a lado."""
    specs = [
        ("Frostseal_Shiny", (-11.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Frostseal_Normal", (-6.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Frostseal_Grande", (-0.9, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Frostseal_Gigante", (6.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Frostseal_Dourada_SuperRara", (14.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_frostseal(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
