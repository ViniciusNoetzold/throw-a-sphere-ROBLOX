"""
023_Coilsnake_Ekans_5Variacoes_Blender.py
=========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "023. Coilsnake — Serpente Roxa (Ref: Ekans)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Coilsnake_Shiny (1.0x - Paleta Shiny / Shyne Verde-Tóxico + Colar/Chocalho Limão)
  2. Coilsnake_Normal (1.0x - Corpo Roxo-Real + Colar e Chocalho Amarelos + Olhos Amarelos)
  3. Coilsnake_Grande (1.35x - Normal)
  4. Coilsnake_Gigante (1.85x - Normal)
  5. Coilsnake_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Espiral inferior apoiada exatamente em `Z = 0.0` e frente/cabeça apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Coilsnake_Shiny`, `Coilsnake_Normal`, `Coilsnake_Grande`,
     `Coilsnake_Gigante`, `Coilsnake_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_purple": (0.62, 0.34, 0.68, 1.0),
        "band_yellow": (0.96, 0.84, 0.28, 1.0),
        "eye_yellow": (0.98, 0.90, 0.22, 1.0),
        "slit_black": (0.12, 0.10, 0.12, 1.0),
        "mouth_pink": (0.86, 0.54, 0.64, 1.0),
    },
    "shiny_palette": {
        "body_purple": (0.54, 0.78, 0.24, 1.0),
        "band_yellow": (0.96, 0.92, 0.34, 1.0),
        "eye_yellow": (0.99, 0.95, 0.28, 1.0),
        "slit_black": (0.12, 0.12, 0.10, 1.0),
        "mouth_pink": (0.88, 0.56, 0.62, 1.0),
    },
    "golden_super_rare_palette": {
        "body_purple": (0.98, 0.78, 0.14, 1.0),
        "band_yellow": (1.00, 0.94, 0.54, 1.0),
        "eye_yellow": (0.10, 0.92, 1.00, 1.0),
        "slit_black": (0.14, 0.12, 0.08, 1.0),
        "mouth_pink": (0.90, 0.64, 0.16, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base da espiral em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_coilsnake(
    name: str = "Coilsnake_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 023. Coilsnake (Ref: Ekans):
      - Frente/cabeça apontando para -Y e base da espiral apoiada em Z = 0.0
      - Duas camadas de espiral facetada roxa com ventre amarelo-claro
      - Pescoço erguido com colar amarelo chamativo e cabeça com boca aberta e olhos amarelos ferozes
      - Cauda erguida na lateral com chocalho segmentado amarelo em 4 contas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Coil_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Coil_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Coil_Norm"

    parts = []

    # 1. ESPIRAL BASE (ANEL INFERIOR LARGO + ANEL SUPERIOR EMPILHADO EM Z = 0.0)
    # Anel inferior (8 segmentos formando anel octogonal facetado)
    for idx in range(8):
        ang = math.radians(idx * 45.0)
        r_ring = 0.66
        x = r_ring * math.cos(ang)
        y = r_ring * math.sin(ang)
        _add_part(
            parts,
            create_cube(
                f"_tmp_coil_bot_{idx}",
                (0.58, 0.36, 0.34),
                (x, y, 0.19),
                rotation=(0.0, 0.0, ang + math.pi * 0.5),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_coil_bot_belly_{idx}",
                (0.56, 0.30, 0.08),
                (x, y, 0.04),
                rotation=(0.0, 0.0, ang + math.pi * 0.5),
            ),
            mat_prefix,
            "band_yellow",
            pal,
        )

    # Anel médio (6 segmentos empilhados)
    for idx in range(6):
        ang = math.radians(idx * 60.0 + 15.0)
        r_ring = 0.48
        x = r_ring * math.cos(ang)
        y = r_ring * math.sin(ang)
        _add_part(
            parts,
            create_cube(
                f"_tmp_coil_mid_{idx}",
                (0.54, 0.32, 0.32),
                (x, y, 0.50),
                rotation=(0.0, 0.0, ang + math.pi * 0.5),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_coil_mid_belly_{idx}",
                (0.50, 0.26, 0.07),
                (x, y, 0.36),
                rotation=(0.0, 0.0, ang + math.pi * 0.5),
            ),
            mat_prefix,
            "band_yellow",
            pal,
        )

    # 2. PESCOÇO ERGUIDO COM COLAR AMARELO + CABEÇA DE SERPENTE COM BOCA ABERTA
    _add_part(
        parts,
        create_cylinder(
            "_tmp_neck_base",
            6,
            0.24,
            0.40,
            (0.0, -0.02, 0.78),
            rotation=(math.radians(-8.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_purple",
        pal,
    )
    # Faixa/colar amarelo no pescoço (assinatura do Ekans)
    _add_part(
        parts,
        create_cylinder(
            "_tmp_neck_collar",
            6,
            0.255,
            0.24,
            (0.0, -0.06, 0.96),
            rotation=(math.radians(6.0), 0.0, 0.0),
        ),
        mat_prefix,
        "band_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_neck_upper",
            6,
            0.24,
            0.34,
            (0.0, -0.10, 1.22),
            rotation=(math.radians(14.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_purple",
        pal,
    )

    # Cabeça facetada apontando para -Y com boca aberta
    _add_part(
        parts,
        create_cube("_tmp_head_top", (0.58, 0.78, 0.34), (0.0, -0.34, 1.50), rotation=(math.radians(-6.0), 0.0, 0.0)),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_snout_front",
            4,
            0.26,
            0.15,
            0.28,
            (0.0, -0.78, 1.48),
            rotation=(math.radians(90.0), 0.0, math.radians(45.0)),
            scale=(1.15, 0.72, 1.0),
        ),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_jaw_lower", (0.44, 0.56, 0.16), (0.0, -0.44, 1.16), rotation=(math.radians(18.0), 0.0, 0.0)),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth_inner", (0.36, 0.38, 0.24), (0.0, -0.46, 1.30)),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # Olhos amarelos grandes com fenda vertical preta
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_eye_yellow_{tag}", (0.14, 0.26, 0.24), (side * 0.28, -0.44, 1.54)),
            mat_prefix,
            "eye_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_slit_{tag}", (0.15, 0.07, 0.22), (side * 0.30, -0.46, 1.54)),
            mat_prefix,
            "slit_black",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.16, 0.30, 0.09),
                (side * 0.27, -0.44, 1.66),
                rotation=(math.radians(12.0), math.radians(side * -12.0), 0.0),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )

    # 3. CAUDA ERGUIDA COM CHOCALHO AMARELO SEGMENTADO (4 CONTAS)
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_rise_1",
            6,
            0.16,
            0.13,
            0.52,
            (0.76, 0.16, 0.44),
            rotation=(math.radians(-12.0), math.radians(26.0), 0.0),
        ),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_rise_2",
            6,
            0.13,
            0.11,
            0.46,
            (0.90, 0.24, 0.84),
            rotation=(math.radians(-6.0), math.radians(12.0), 0.0),
        ),
        mat_prefix,
        "body_purple",
        pal,
    )
    rattle_beads = [
        (0.14, (0.94, 0.26, 1.12)),
        (0.125, (0.94, 0.26, 1.32)),
        (0.105, (0.90, 0.24, 1.50)),
        (0.082, (0.84, 0.22, 1.66)),
    ]
    for r_idx, (rad, loc) in enumerate(rattle_beads):
        _add_part(
            parts,
            create_icosphere(f"_tmp_rattle_{r_idx}", 1, rad, loc, scale=(0.92, 0.92, 1.15)),
            mat_prefix,
            "band_yellow",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 023. Coilsnake lado a lado."""
    specs = [
        ("Coilsnake_Shiny", (-6.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Coilsnake_Normal", (-3.5, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Coilsnake_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Coilsnake_Gigante", (3.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Coilsnake_Dourada_SuperRara", (7.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_coilsnake(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
