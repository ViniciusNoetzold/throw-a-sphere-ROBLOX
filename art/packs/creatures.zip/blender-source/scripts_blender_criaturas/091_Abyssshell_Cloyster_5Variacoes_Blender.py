"""
091_Abyssshell_Cloyster_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "091. Abyssshell — Fortaleza Bivalve (Ref: Cloyster)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Abyssshell_Shiny (1.0x - Paleta Shiny Azul-Safira Profundo + Chifre Gelo + Pérola Índigo)
  2. Abyssshell_Normal (1.0x - Concha Dupla Vertical Lavanda + Espinhos Longos + Pérola Sorridente)
  3. Abyssshell_Grande (1.35x - Normal)
  4. Abyssshell_Gigante (1.85x - Normal)
  5. Abyssshell_Dourada_SuperRara (2.25x - Ouro Reluzente + Chifre, Borda e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para pérola e conchas; cones 7 lados para espinhos)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base alinhada exatamente em `Z = 0.0` e rosto/chifre apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "shell_outer": (0.58, 0.52, 0.78, 1.0),
        "shell_shade": (0.44, 0.38, 0.64, 1.0),
        "shell_dark": (0.30, 0.27, 0.34, 1.0),
        "rim_ice": (0.76, 0.80, 0.88, 1.0),
        "pearl_indigo": (0.24, 0.20, 0.42, 1.0),
        "horn_ice": (0.76, 0.84, 0.92, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.08, 0.08, 0.12, 1.0),
    },
    "shiny_palette": {
        "shell_outer": (0.24, 0.44, 0.88, 1.0),
        "shell_shade": (0.16, 0.30, 0.68, 1.0),
        "shell_dark": (0.16, 0.22, 0.38, 1.0),
        "rim_ice": (0.74, 0.84, 0.96, 1.0),
        "pearl_indigo": (0.14, 0.18, 0.36, 1.0),
        "horn_ice": (0.80, 0.90, 0.98, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.06, 0.08, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "shell_outer": (0.98, 0.78, 0.14, 1.0),
        "shell_shade": (0.82, 0.58, 0.08, 1.0),
        "shell_dark": (0.46, 0.32, 0.06, 1.0),
        "rim_ice": (0.10, 0.92, 1.00, 1.0),
        "pearl_indigo": (0.30, 0.20, 0.05, 1.0),
        "horn_ice": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.28, 0.42, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_abyssshell(
    name: str = "Abyssshell_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 091. Abyssshell (Ref: Cloyster):
      - Núcleo facial em pérola índigo-escura com olhos raivosos inclinados e sorriso branco dentado
      - Chifre frontal afiado azul-gelo emergindo do topo da cabeça da pérola
      - Borda interna ondulada cinza-gelo contornando a cavidade escura
      - Concha bivalve vertical dupla lavanda cravejada de grandes espinhos cônicos em leque radial
      - Protuberâncias blindadas nas laterais e crista posterior segmentada
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Aby_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Aby_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Aby_Norm"

    parts = []

    # 1. PÉROLA FACIAL CENTRAL (CABEÇA ÍNDIGO-ESCURA)
    _add_part(
        parts,
        create_icosphere("_tmp_pearl_head", 2, 0.56, (0.0, -0.14, 1.24), scale=(0.98, 0.94, 1.04)),
        mat_prefix,
        "pearl_indigo",
        pal,
    )

    # 2. CHIFRE FRONTAL AFIADO AZUL-GELO
    _add_part(
        parts,
        create_cone(
            "_tmp_forehead_horn",
            7,
            0.16,
            0.022,
            0.76,
            (0.0, -0.44, 1.78),
            rotation=(math.radians(-46.0), 0.0, 0.0),
        ),
        mat_prefix,
        "horn_ice",
        pal,
    )

    # 3. OLHOS RAIVOSOS INCLINADOS + PUPILAS + SORRISO BRANCO DENTADO
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.15,
                (side * 0.24, -0.60, 1.32),
                rotation=(0.0, math.radians(side * -24.0), math.radians(side * -22.0)),
                scale=(1.12, 0.42, 0.72),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Sobrancelha furiosa cortando o topo interno do olho
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.28, 0.14, 0.09),
                (side * 0.22, -0.61, 1.41),
                rotation=(0.0, math.radians(side * -28.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "pearl_indigo",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.042,
                (side * 0.20, -0.67, 1.31),
                scale=(0.75, 0.55, 1.10),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # Sorriso largo branco curvado com divisórias de dentes
    for idx, (dx, dz, rz_deg) in enumerate([(-0.18, 1.04, 18.0), (-0.06, 1.00, 6.0), (0.06, 1.00, -6.0), (0.18, 1.04, -18.0)]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_tooth_{idx}",
                (0.115, 0.08, 0.12),
                (dx, -0.64, dz),
                rotation=(math.radians(10.0), math.radians(-dx * 42.0), math.radians(rz_deg)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
    for idx, dx in enumerate([-0.12, 0.0, 0.12]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_tooth_gap_{idx}",
                (0.018, 0.095, 0.125),
                (dx, -0.65, 1.01 + abs(dx) * 0.12),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 4. BORDA INTERNA ONDULADA CINZA-GELO (MOLDURA CONTÍNUA E SUAVE DA CAVIDADE DA PÉROLA)
    n_rim = 18
    for i in range(n_rim):
        ang = (2.0 * math.pi * i) / n_rim
        wave = 0.035 * math.sin(ang * 6.0)
        rx = (0.62 + wave) * math.sin(ang)
        rz = 1.24 + (0.86 + wave) * math.cos(ang)
        ry = -0.26 + 0.12 * abs(math.sin(ang))
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_inner_rim_{i}",
                2,
                0.15,
                (rx, ry, rz),
                rotation=(0.0, math.radians(-math.degrees(ang)), 0.0),
                scale=(1.25, 1.18, 0.58),
            ),
            mat_prefix,
            "rim_ice",
            pal,
        )

    # 5. PAREDE INTERNA ESCURA DA CONCHA (CAMADA PROFUNDA)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_dark_cavity_back",
            2,
            0.84,
            (0.0, 0.24, 1.24),
            scale=(0.94, 0.62, 1.26),
        ),
        mat_prefix,
        "shell_dark",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        for k, (z_off, x_off, y_off) in enumerate([(1.96, 0.50, -0.10), (1.62, 0.74, -0.06), (1.24, 0.80, -0.06), (0.84, 0.72, -0.08), (0.48, 0.46, -0.10)]):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_dark_wall_{tag}_{k}",
                    2,
                    0.26,
                    (side * x_off, y_off, z_off),
                    scale=(0.68, 1.48, 1.16),
                ),
                mat_prefix,
                "shell_dark",
                pal,
            )

    # 6. CONCHA BIVALVE VERTICAL EXTERNA LAVANDA (2 VALVAS LATERAIS LISAS E ARQUEADAS)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Corpo curvo principal da valva externa (mais alto e elegante como na referência)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_outer_valve_{tag}",
                2,
                0.88,
                (side * 0.48, 0.20, 1.24),
                rotation=(0.0, math.radians(side * 10.0), math.radians(side * -14.0)),
                scale=(0.62, 0.72, 1.36),
            ),
            mat_prefix,
            "shell_outer",
            pal,
        )
        # Borda frontal saliente contínua da valva externa (suavemente ondulada, sem aspecto de contas)
        lip_pts = [
            (0.40, -0.26, 2.12, 0.24, -26.0),
            (0.76, -0.24, 1.80, 0.28, -52.0),
            (0.90, -0.20, 1.42, 0.29, -82.0),
            (0.88, -0.20, 1.00, 0.29, -104.0),
            (0.70, -0.22, 0.60, 0.26, -132.0),
            (0.38, -0.24, 0.34, 0.24, -156.0),
        ]
        for idx, (lx, ly, lz, lrad, tilt_deg) in enumerate(lip_pts):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_outer_lip_{tag}_{idx}",
                    2,
                    lrad,
                    (side * lx, ly, lz),
                    rotation=(0.0, math.radians(side * tilt_deg), 0.0),
                    scale=(1.22, 1.12, 0.62),
                ),
                mat_prefix,
                "shell_outer",
                pal,
            )

        # 7. GRANDES ESPINHOS RADIAIS DA CONCHA (SILHUETA DE FORTALEZA DA REFERÊNCIA!)
        # 7a. Chifre superior gigante em ponta de lança (base estreita -> corpo largo -> ponta afiada)
        _add_part(
            parts,
            create_cone(
                f"_tmp_top_spike_base_{tag}",
                7,
                0.15,
                0.24,
                0.34,
                (side * 0.88, 0.04, 2.02),
                rotation=(math.radians(-6.0), math.radians(side * 44.0), 0.0),
            ),
            mat_prefix,
            "shell_outer",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_top_spike_tip_{tag}",
                7,
                0.24,
                0.032,
                0.76,
                (side * 1.26, 0.00, 2.40),
                rotation=(math.radians(-6.0), math.radians(side * 44.0), 0.0),
            ),
            mat_prefix,
            "shell_outer",
            pal,
        )

        # 7b. Grande espinho horizontal central
        _add_part(
            parts,
            create_cone(
                f"_tmp_mid_spike_{tag}",
                7,
                0.22,
                0.045,
                0.86,
                (side * 1.28, 0.14, 1.24),
                rotation=(0.0, math.radians(side * 86.0), 0.0),
            ),
            mat_prefix,
            "shell_outer",
            pal,
        )

        # 7c. Espinho diagonal inferior
        _add_part(
            parts,
            create_cone(
                f"_tmp_low_spike_{tag}",
                7,
                0.18,
                0.045,
                0.68,
                (side * 0.94, 0.12, 0.44),
                rotation=(0.0, math.radians(side * 136.0), 0.0),
            ),
            mat_prefix,
            "shell_outer",
            pal,
        )

        # 7d. Calombos/protuberâncias blindadas entre os espinhos nas faces externas da concha
        for b_idx, (bx, by, bz) in enumerate([(1.00, 0.16, 1.66), (0.98, 0.18, 0.84)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_knob_{tag}_{b_idx}",
                    7,
                    0.22,
                    0.13,
                    0.26,
                    (side * bx, by, bz),
                    rotation=(0.0, math.radians(side * (72.0 if b_idx == 0 else 108.0)), 0.0),
                ),
                mat_prefix,
                "shell_shade",
                pal,
            )

    # 8. CRISTA SEGMENTADA TRASEIRA E BASE ESTÁVEL
    for r_idx, rz in enumerate([0.62, 0.94, 1.26, 1.58, 1.88]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_rear_ridge_{r_idx}",
                (0.46, 0.42, 0.26),
                (0.0, 0.72, rz),
                rotation=(math.radians((rz - 1.24) * 18.0), 0.0, 0.0),
            ),
            mat_prefix,
            "shell_shade",
            pal,
        )
    # Ponta inferior da concha fechando em V para encostar firme em Z = 0.0
    _add_part(
        parts,
        create_icosphere(
            "_tmp_bottom_keel",
            1,
            0.34,
            (0.0, 0.02, 0.24),
            scale=(1.25, 1.05, 0.72),
        ),
        mat_prefix,
        "shell_outer",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 091. Abyssshell lado a lado."""
    specs = [
        ("Abyssshell_Shiny", (-12.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Abyssshell_Normal", (-7.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Abyssshell_Grande", (-2.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Abyssshell_Gigante", (4.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Abyssshell_Dourada_SuperRara", (12.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_abyssshell(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
