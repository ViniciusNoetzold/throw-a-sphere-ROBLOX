"""
052_Coinpurr_Meowth_5Variacoes_Blender.py
=========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "052. Coinpurr — Gato da Fortuna (Ref: Meowth)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Coinpurr_Shiny (1.0x - Pelagem Creme-Dourada + Patas, Orelhas Internas e Ponta da Cauda Rosa-Coral)
  2. Coinpurr_Normal (1.0x - Gato Creme + Moeda Koban Dourada na Testa + Orelhas Pretas + Cauda em Espiral)
  3. Coinpurr_Grande (1.35x - Normal)
  4. Coinpurr_Gigante (1.85x - Normal)
  5. Coinpurr_Dourada_SuperRara (2.25x - Ouro Reluzente + Moeda, Olhos e Pontas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (cabeça felina oval, moeda oval com frisos, 6 bigodes longos, cauda espiralada)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e sorriso apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "fur_cream": (0.95, 0.90, 0.74, 1.0),
        "fur_shade": (0.85, 0.78, 0.62, 1.0),
        "ear_black": (0.16, 0.15, 0.16, 1.0),
        "brown_accent": (0.68, 0.48, 0.28, 1.0),
        "coin_gold": (0.98, 0.80, 0.34, 1.0),
        "coin_ridge": (0.72, 0.50, 0.16, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_black": (0.10, 0.10, 0.12, 1.0),
        "mouth_deep": (0.66, 0.34, 0.44, 1.0),
        "tongue_pink": (0.94, 0.60, 0.70, 1.0),
    },
    "shiny_palette": {
        "fur_cream": (0.97, 0.91, 0.76, 1.0),
        "fur_shade": (0.88, 0.80, 0.66, 1.0),
        "ear_black": (0.18, 0.15, 0.18, 1.0),
        "brown_accent": (0.90, 0.46, 0.54, 1.0),
        "coin_gold": (1.00, 0.84, 0.22, 1.0),
        "coin_ridge": (0.78, 0.54, 0.12, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_black": (0.10, 0.10, 0.12, 1.0),
        "mouth_deep": (0.70, 0.32, 0.44, 1.0),
        "tongue_pink": (0.96, 0.62, 0.72, 1.0),
    },
    "golden_super_rare_palette": {
        "fur_cream": (0.98, 0.78, 0.14, 1.0),
        "fur_shade": (0.86, 0.64, 0.10, 1.0),
        "ear_black": (0.06, 0.48, 0.64, 1.0),
        "brown_accent": (0.10, 0.92, 1.00, 1.0),
        "coin_gold": (0.10, 0.92, 1.00, 1.0),
        "coin_ridge": (0.04, 0.56, 0.72, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "pupil_black": (0.10, 0.92, 1.00, 1.0),
        "mouth_deep": (0.76, 0.48, 0.08, 1.0),
        "tongue_pink": (1.00, 0.88, 0.38, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_coinpurr(
    name: str = "Coinpurr_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 052. Coinpurr (Ref: Meowth):
      - Cabeça larga e expressiva de gato creme com 2 orelhas triangulares pretas e interior marrom
      - Moeda oval dourada (Koban) na testa com 3 frisos horizontais + 2 bigodes eretos ladeando a moeda
      - 4 bigodes longos laterais nas bochechas + grandes olhos ovais brancos com pupilas em fenda vertical
      - Sorriso alegre aberto com língua rosa e 2 presinhas brancas nos cantos
      - Corpo esguio bípede em pose dinâmica (braço direito erguido em punho + esquerdo aberto)
      - Pernas finas com patas longas marrom-canela (rosa na Shiny) e longa cauda enrolada em espiral marrom
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Coin_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Coin_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Coin_Norm"

    parts = []

    # 1. TORSO ESGUIO E QUADRIL FELINO
    _add_part(
        parts,
        create_icosphere("_tmp_torso", 2, 0.34, (0.0, 0.02, 0.92), scale=(0.86, 0.76, 1.24)),
        mat_prefix,
        "fur_cream",
        pal,
    )
    _add_part(
        parts,
        create_cylinder("_tmp_neck", 8, 0.16, 0.22, (0.0, 0.0, 1.28)),
        mat_prefix,
        "fur_cream",
        pal,
    )

    # 2. CABEÇA GRANDE OVAL FELINA
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.56, (0.0, -0.04, 1.66), scale=(1.14, 0.88, 0.90)),
        mat_prefix,
        "fur_cream",
        pal,
    )

    # Orelhas triangulares pretas com interior marrom (rosa na Shiny)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_out_{tag}",
                5,
                0.28,
                0.05,
                0.50,
                (side * 0.44, -0.02, 2.08),
                rotation=(math.radians(-6.0), math.radians(side * 28.0), 0.0),
                scale=(1.00, 0.46, 1.00),
            ),
            mat_prefix,
            "ear_black",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_in_{tag}",
                5,
                0.18,
                0.03,
                0.34,
                (side * 0.42, -0.09, 2.04),
                rotation=(math.radians(-6.0), math.radians(side * 28.0), 0.0),
                scale=(1.00, 0.36, 1.00),
            ),
            mat_prefix,
            "brown_accent",
            pal,
        )

    # 3. MOEDA OVAL DOURADA (KOBAN) NA TESTA + 3 FRISOS HORIZONTAIS
    _add_part(
        parts,
        create_icosphere(
            "_tmp_coin_body",
            2,
            0.22,
            (0.0, -0.44, 1.98),
            rotation=(math.radians(-10.0), 0.0, 0.0),
            scale=(0.64, 0.38, 1.16),
        ),
        mat_prefix,
        "coin_gold",
        pal,
    )
    for r_i, rz in enumerate([1.88, 1.98, 2.08]):
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_coin_ridge_{r_i}",
                6,
                0.016,
                0.24,
                (0.0, -0.525, rz),
                rotation=(0.0, math.radians(90.0), 0.0),
            ),
            mat_prefix,
            "coin_ridge",
            pal,
        )

    # 6 BIGODES LONGOS (2 ERETOS NA TESTA + 2 DE CADA LADO NAS BOCHECHAS)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Bigode ereto da testa ladeando a moeda
        _add_part(
            parts,
            create_cone(
                f"_tmp_whisk_top_{tag}",
                5,
                0.036,
                0.008,
                0.62,
                (side * 0.22, -0.42, 2.24),
                rotation=(math.radians(-10.0), math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
        # Bigode superior da bochecha
        _add_part(
            parts,
            create_cone(
                f"_tmp_whisk_u_{tag}",
                5,
                0.032,
                0.008,
                0.60,
                (side * 0.78, -0.24, 1.72),
                rotation=(0.0, math.radians(side * 66.0), 0.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
        # Bigode inferior da bochecha
        _add_part(
            parts,
            create_cone(
                f"_tmp_whisk_d_{tag}",
                5,
                0.032,
                0.008,
                0.56,
                (side * 0.78, -0.24, 1.54),
                rotation=(0.0, math.radians(side * 86.0), 0.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )

    # 4. ROSTO EXPRESSIVO (OLHOS OVAIS DE GATO + SORRISO ABERTO + 2 PRESINHAS)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_w_{tag}",
                2,
                0.17,
                (side * 0.27, -0.47, 1.66),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(0.82, 0.42, 1.18),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pupila vertical estreita em fenda felina
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_pupil_{tag}",
                6,
                0.026,
                0.28,
                (side * 0.28, -0.535, 1.66),
                scale=(0.80, 0.60, 1.0),
            ),
            mat_prefix,
            "pupil_black",
            pal,
        )

    # Sorriso largo aberto rente ao rosto + língua rosa + 2 dentinhos brancos
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_bg", 2, 0.21, (0.0, -0.46, 1.40), scale=(1.12, 0.22, 0.70)),
        mat_prefix,
        "mouth_deep",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_tongue", 1, 0.15, (0.0, -0.49, 1.35), scale=(1.04, 0.20, 0.52)),
        mat_prefix,
        "tongue_pink",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.032,
                0.008,
                0.08,
                (side * 0.17, -0.51, 1.47),
                rotation=(math.radians(180.0), 0.0, 0.0),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # 5. BRAÇOS ESGUIOS EM POSE DINÂMICA (ESQUERDO ABERTO + DIREITO ERGUIDO COM PUNHO)
    # Braço esquerdo (lado -X) estendido para baixo/fora
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_L",
            6,
            0.095,
            0.075,
            0.66,
            (-0.52, -0.06, 0.94),
            rotation=(math.radians(-10.0), math.radians(-128.0), 0.0),
        ),
        mat_prefix,
        "fur_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_paw_L", 2, 0.15, (-0.78, -0.10, 0.72), scale=(1.15, 0.90, 0.84)),
        mat_prefix,
        "fur_cream",
        pal,
    )

    # Braço direito (lado +X) levantado alegremente como na arte oficial!
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R_up",
            6,
            0.095,
            0.080,
            0.52,
            (0.44, -0.02, 1.24),
            rotation=(math.radians(-6.0), math.radians(52.0), 0.0),
        ),
        mat_prefix,
        "fur_cream",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R_fore",
            6,
            0.082,
            0.076,
            0.44,
            (0.74, -0.04, 1.56),
            rotation=(math.radians(-8.0), math.radians(26.0), 0.0),
        ),
        mat_prefix,
        "fur_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_paw_R", 2, 0.16, (0.82, -0.08, 1.82), scale=(1.04, 0.92, 0.96)),
        mat_prefix,
        "fur_cream",
        pal,
    )

    # 6. PERNAS FINAS E PATAS LONGAS MARROM-CANELA APOIADAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa creme
        _add_part(
            parts,
            create_cone(
                f"_tmp_thigh_{tag}",
                6,
                0.10,
                0.08,
                0.42,
                (side * 0.24, 0.0, 0.44),
                rotation=(0.0, math.radians(side * -14.0), 0.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
        # Canela/meia marrom
        _add_part(
            parts,
            create_cone(
                f"_tmp_shin_{tag}",
                6,
                0.095,
                0.082,
                0.28,
                (side * 0.28, -0.04, 0.18),
                rotation=(math.radians(10.0), math.radians(side * -10.0), 0.0),
            ),
            mat_prefix,
            "brown_accent",
            pal,
        )
        # Pata alongada marrom apoiada no chão em Z = 0.0
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.16,
                (side * 0.31, -0.18, 0.08),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(0.86, 1.56, 0.52),
            ),
            mat_prefix,
            "brown_accent",
            pal,
        )

    # 7. CAUDA LONGA FINA TERMINANDO EM ESPIRAL MARROM-CANELA NA LATERAL DIREITA (+X)
    tail_segs = [
        # (loc, rot_deg, r1, r2, depth, key)
        ((0.28, 0.24, 0.54), (18.0, 118.0, -24.0), 0.060, 0.052, 0.50, "fur_cream"),
        ((0.68, 0.34, 0.40), (8.0, 96.0, -14.0), 0.054, 0.050, 0.50, "fur_cream"),
        ((1.06, 0.36, 0.44), (0.0, 62.0, -8.0), 0.058, 0.068, 0.40, "brown_accent"),
    ]
    for ts_i, (loc, rot_d, r1, r2, depth, key) in enumerate(tail_segs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_seg_{ts_i}",
                6,
                r1,
                r2,
                depth,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
            ),
            mat_prefix,
            key,
            pal,
        )
    # Espiral contínua e fluida marrom na ponta da cauda (8 pontos em espiral suave!)
    tail_curl = [
        (0.115, (1.24, 0.36, 0.58)),
        (0.120, (1.32, 0.36, 0.70)),
        (0.120, (1.28, 0.36, 0.84)),
        (0.118, (1.16, 0.36, 0.92)),
        (0.114, (1.02, 0.36, 0.88)),
        (0.108, (0.96, 0.36, 0.76)),
        (0.100, (1.04, 0.36, 0.68)),
        (0.092, (1.14, 0.36, 0.74)),
    ]
    for tc_i, (rad, loc) in enumerate(tail_curl):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tcurl_{tc_i}", 2, rad, loc, scale=(1.02, 0.84, 1.02)),
            mat_prefix,
            "brown_accent",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 052. Coinpurr lado a lado."""
    specs = [
        ("Coinpurr_Shiny", (-10.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Coinpurr_Normal", (-6.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Coinpurr_Grande", (-1.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Coinpurr_Gigante", (4.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Coinpurr_Dourada_SuperRara", (12.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_coinpurr(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
