"""
122_Barrierjester_Mr_Mime_5Variacoes_Blender.py
===============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "122. Barrierjester — Mímico Ilusionista (Ref: Mr. Mime)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Barrierjester_Shiny (1.0x - Paleta Shiny Esferas Verde-Limão Neon + Cabelo e Sapatos Azul-Petróleo)
  2. Barrierjester_Normal (1.0x - Tronco Branco + Esferas Rosa-Vivo + Cabelo Chifre e Sapatos Azuis + Mãos Grandes)
  3. Barrierjester_Grande (1.35x - Normal)
  4. Barrierjester_Gigante (1.85x - Normal)
  5. Barrierjester_Dourada_SuperRara (2.25x - Ouro Reluzente + Cabelo, Olhos e Sapatos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para cabeça, tronco, esferas de ombro/quadril e joelhos; cones/cilindros para braços, pernas, cabelo em chifres e sapatos enrolados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Sapatos de bobo alinhados exatamente em `Z = 0.0` e rosto/sorriso apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "skin_blush": (0.98, 0.87, 0.90, 1.0),
        "torso_white": (0.96, 0.97, 0.99, 1.0),
        "sphere_rose": (0.90, 0.44, 0.56, 1.0),
        "jester_blue": (0.18, 0.36, 0.52, 1.0),
        "mouth_deep": (0.58, 0.28, 0.36, 1.0),
        "tongue_pink": (0.92, 0.66, 0.74, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.09, 0.14, 0.22, 1.0),
    },
    "shiny_palette": {
        "skin_blush": (0.98, 0.90, 0.92, 1.0),
        "torso_white": (0.96, 0.98, 0.97, 1.0),
        "sphere_rose": (0.34, 0.86, 0.34, 1.0),
        "jester_blue": (0.16, 0.38, 0.50, 1.0),
        "mouth_deep": (0.52, 0.26, 0.34, 1.0),
        "tongue_pink": (0.90, 0.62, 0.70, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.09, 0.14, 0.22, 1.0),
    },
    "golden_super_rare_palette": {
        "skin_blush": (1.00, 0.90, 0.46, 1.0),
        "torso_white": (0.98, 0.78, 0.14, 1.0),
        "sphere_rose": (0.86, 0.58, 0.08, 1.0),
        "jester_blue": (0.10, 0.92, 1.00, 1.0),
        "mouth_deep": (0.62, 0.38, 0.04, 1.0),
        "tongue_pink": (1.00, 0.84, 0.34, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.04, 0.46, 0.64, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_barrierjester(
    name: str = "Barrierjester_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de 122. Barrierjester (Ref: Mr. Mime):
      - Tronco esférico branco com disco rosa-vivo central, 2 ombreiras esféricas rosa e 2 quadris esféricos rosa
      - Cabeça oval rosada com 2 grandes mechas laterais azul-petróleo em formato de chifres de bobo
      - Olhos ovais brancos expressivos, bochechas redondas rosa-vivo e sorriso aberto alegre
      - Braços esguios em pose clássica de mímica (direito erguido mostrando palma com 5 almofadinhas rosa, esquerdo aberto)
      - Pernas finas flexionadas com joelheiras esféricas brancas e sapatos azuis com ponta enrolada em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Bjs_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Bjs_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Bjs_Norm"

    parts = []

    # 1. TRONCO ESFÉRICO BRANCO + MARCA CENTRAL ROSA + OMBREIRAS E QUADRIS ESFÉRICOS
    _add_part(
        parts,
        create_icosphere("_tmp_torso_main", 2, 0.62, (0.0, 0.0, 1.18), scale=(0.98, 0.86, 1.02)),
        mat_prefix,
        "torso_white",
        pal,
    )
    # Grande círculo rosa-vivo na barriga frontal (-Y)
    _add_part(
        parts,
        create_icosphere("_tmp_belly_spot", 2, 0.30, (0.0, -0.44, 1.16), scale=(1.0, 0.44, 1.0)),
        mat_prefix,
        "sphere_rose",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Ombreiras esféricas grandes rosa-vivo
        _add_part(
            parts,
            create_icosphere(f"_tmp_shoulder_{tag}", 2, 0.28, (side * 0.56, -0.02, 1.54)),
            mat_prefix,
            "sphere_rose",
            pal,
        )
        # Quadris esféricos rosa-vivo
        _add_part(
            parts,
            create_icosphere(f"_tmp_hip_{tag}", 2, 0.22, (side * 0.44, -0.02, 0.78)),
            mat_prefix,
            "sphere_rose",
            pal,
        )

    # 2. CABEÇA OVAL ROSADA + CABELO EM DOIS CHIFRES DE BOBO AZUL-PETRÓLEO
    _add_part(
        parts,
        create_icosphere("_tmp_head_main", 2, 0.46, (0.0, -0.04, 2.02), scale=(1.00, 0.90, 1.06)),
        mat_prefix,
        "skin_blush",
        pal,
    )
    # Cabelo em chifres/asas laterais recortadas (azul-petróleo)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_hair_main_{tag}",
                6,
                0.28,
                0.04,
                0.86,
                (side * 0.66, 0.02, 2.34),
                rotation=(math.radians(-10.0), math.radians(side * 54.0), 0.0),
                scale=(1.0, 0.52, 1.0),
            ),
            mat_prefix,
            "jester_blue",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_hair_lobe_{tag}",
                5,
                0.22,
                0.04,
                0.56,
                (side * 0.54, 0.04, 2.08),
                rotation=(math.radians(-6.0), math.radians(side * 86.0), 0.0),
                scale=(1.0, 0.50, 1.0),
            ),
            mat_prefix,
            "jester_blue",
            pal,
        )

    # 3. ROSTO EXPRESSIVO: OLHOS OVAIS + BOCHECHAS REDONDAS ROSA + SORRISO ALEGRE
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.105,
                (side * 0.16, -0.40, 2.10),
                scale=(0.76, 0.46, 1.12),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.044,
                (side * 0.16, -0.45, 2.10),
                scale=(0.74, 0.44, 1.18),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.020,
                (side * 0.15, -0.47, 2.14),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Bochecha grande circular rosa-vivo
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_cheek_{tag}",
                2,
                0.15,
                (side * 0.35, -0.30, 1.88),
                rotation=(0.0, 0.0, math.radians(side * -34.0)),
                scale=(0.94, 0.40, 1.06),
            ),
            mat_prefix,
            "sphere_rose",
            pal,
        )

    # Boca sorridente aberta + língua
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_open",
            2,
            0.16,
            (0.0, -0.40, 1.86),
            scale=(1.18, 0.42, 0.72),
        ),
        mat_prefix,
        "mouth_deep",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tongue",
            1,
            0.11,
            (0.0, -0.44, 1.80),
            scale=(1.04, 0.38, 0.52),
        ),
        mat_prefix,
        "tongue_pink",
        pal,
    )

    # 4. BRAÇOS ESGUIOS E MÃOS GRANDES DE MÍMICO COM 5 DEDOS
    # Braço esquerdo na cena (-X, erguido exibindo a palma com almofadas rosa!)
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_upper_L",
            8,
            0.085,
            0.50,
            (-0.92, -0.06, 1.54),
            rotation=(0.0, math.radians(96.0), 0.0),
        ),
        mat_prefix,
        "skin_blush",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_elbow_L", 1, 0.095, (-1.14, -0.08, 1.54)),
        mat_prefix,
        "skin_blush",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_lower_L",
            8,
            0.080,
            0.54,
            (-1.14, -0.14, 1.80),
            rotation=(math.radians(10.0), math.radians(-8.0), 0.0),
        ),
        mat_prefix,
        "skin_blush",
        pal,
    )
    # Palma branca erguida (-X) + 5 dedos com almofadas rosa
    palm_l = (-1.12, -0.20, 2.16)
    _add_part(
        parts,
        create_icosphere("_tmp_palm_L", 2, 0.22, palm_l, scale=(1.06, 0.44, 0.94)),
        mat_prefix,
        "torso_white",
        pal,
    )
    fingers_l = [
        (-0.28, 0.08, -58.0),
        (-0.18, 0.24, -26.0),
        (-0.02, 0.29, -4.0),
        (0.14, 0.24, 22.0),
        (0.24, 0.06, 56.0),
    ]
    for f_idx, (fx, fz, fry) in enumerate(fingers_l):
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_finger_L_{f_idx}",
                6,
                0.052,
                0.20,
                (palm_l[0] + fx * 0.72, palm_l[1] - 0.02, palm_l[2] + fz * 0.72),
                rotation=(0.0, math.radians(fry), 0.0),
            ),
            mat_prefix,
            "torso_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_fingertip_L_{f_idx}",
                1,
                0.078,
                (palm_l[0] + fx, palm_l[1] - 0.03, palm_l[2] + fz),
                scale=(1.0, 0.56, 1.0),
            ),
            mat_prefix,
            "torso_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_fingerpad_L_{f_idx}",
                1,
                0.052,
                (palm_l[0] + fx, palm_l[1] - 0.08, palm_l[2] + fz),
                scale=(1.0, 0.42, 1.0),
            ),
            mat_prefix,
            "sphere_rose",
            pal,
        )

    # Braço direito na cena (+X, dobrado para baixo/fora com mão grande aberta)
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_upper_R",
            8,
            0.085,
            0.48,
            (0.90, -0.04, 1.56),
            rotation=(0.0, math.radians(84.0), 0.0),
        ),
        mat_prefix,
        "skin_blush",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_elbow_R", 1, 0.095, (1.12, -0.06, 1.58)),
        mat_prefix,
        "skin_blush",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_arm_lower_R",
            8,
            0.080,
            0.42,
            (1.14, -0.10, 1.38),
            rotation=(math.radians(-10.0), math.radians(-8.0), 0.0),
        ),
        mat_prefix,
        "skin_blush",
        pal,
    )
    palm_r = (1.16, -0.14, 1.12)
    _add_part(
        parts,
        create_icosphere("_tmp_palm_R", 2, 0.21, palm_r, scale=(1.08, 0.46, 0.88)),
        mat_prefix,
        "torso_white",
        pal,
    )
    fingers_r = [
        (-0.24, -0.08, -118.0),
        (-0.14, -0.24, -152.0),
        (0.02, -0.27, 178.0),
        (0.18, -0.22, 146.0),
        (0.28, -0.04, 108.0),
    ]
    for f_idx, (fx, fz, fry) in enumerate(fingers_r):
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_finger_R_{f_idx}",
                6,
                0.050,
                0.18,
                (palm_r[0] + fx * 0.72, palm_r[1] - 0.02, palm_r[2] + fz * 0.72),
                rotation=(0.0, math.radians(fry), 0.0),
            ),
            mat_prefix,
            "torso_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_fingertip_R_{f_idx}",
                1,
                0.072,
                (palm_r[0] + fx, palm_r[1] - 0.03, palm_r[2] + fz),
                scale=(1.0, 0.56, 1.0),
            ),
            mat_prefix,
            "torso_white",
            pal,
        )

    # 5. PERNAS FINAS COM JOELHEIRAS BRANCAS + SAPATOS DE BOBO ENROLADOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_thigh_{tag}",
                8,
                0.085,
                0.42,
                (side * 0.62, -0.04, 0.62),
                rotation=(math.radians(8.0), math.radians(side * -48.0), 0.0),
            ),
            mat_prefix,
            "skin_blush",
            pal,
        )
        # Joelheira esférica branca
        _add_part(
            parts,
            create_icosphere(f"_tmp_knee_{tag}", 2, 0.135, (side * 0.78, -0.08, 0.50)),
            mat_prefix,
            "torso_white",
            pal,
        )
        # Canela
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_shin_{tag}",
                8,
                0.080,
                0.38,
                (side * 0.78, -0.06, 0.30),
                rotation=(math.radians(-6.0), math.radians(side * 8.0), 0.0),
            ),
            mat_prefix,
            "skin_blush",
            pal,
        )
        # Sapato azul-petróleo alongado
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_shoe_main_{tag}",
                2,
                0.20,
                (side * 0.84, -0.14, 0.14),
                rotation=(0.0, 0.0, math.radians(side * -22.0)),
                scale=(1.42, 0.88, 0.72),
            ),
            mat_prefix,
            "jester_blue",
            pal,
        )
        # Ponta enrolada de sapato de bobo/duende apontando para cima/fora
        _add_part(
            parts,
            create_cone(
                f"_tmp_shoe_curl_1_{tag}",
                6,
                0.12,
                0.06,
                0.24,
                (side * 1.12, -0.22, 0.22),
                rotation=(math.radians(-14.0), math.radians(side * 24.0), 0.0),
            ),
            mat_prefix,
            "jester_blue",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_shoe_curl_tip_{tag}",
                1,
                0.075,
                (side * 1.06, -0.22, 0.34),
            ),
            mat_prefix,
            "jester_blue",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 122. Barrierjester lado a lado."""
    specs = [
        ("Barrierjester_Shiny", (-11.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Barrierjester_Normal", (-7.1, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Barrierjester_Grande", (-2.0, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Barrierjester_Gigante", (4.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Barrierjester_Dourada_SuperRara", (12.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_barrierjester(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
