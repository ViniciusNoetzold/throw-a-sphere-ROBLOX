"""
050_Molepod_Diglett_5Variacoes_Blender.py
=========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "050. Molepod — Toupeira da Terra (Ref: Diglett)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Molepod_Shiny (1.0x - Corpo Marrom-Terra + Icônico Nariz Azul-Céu Brilhante)
  2. Molepod_Normal (1.0x - Corpo Cilíndrico Arredondado Marrom + Nariz Oval Rosa + Base de Rochas Cinza)
  3. Molepod_Grande (1.35x - Normal)
  4. Molepod_Gigante (1.85x - Normal)
  5. Molepod_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Nariz Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (cilindro + cúpula icosphere subdiv=2 + coroa irregular de rochas facetadas)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base rochosa alinhada exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_brown": (0.68, 0.54, 0.44, 1.0),
        "nose_pink": (0.91, 0.54, 0.72, 1.0),
        "nose_shine": (0.98, 0.84, 0.92, 1.0),
        "soil_gray": (0.52, 0.53, 0.57, 1.0),
        "rock_light": (0.76, 0.78, 0.82, 1.0),
        "rock_dark": (0.38, 0.40, 0.44, 1.0),
        "eye_dark": (0.10, 0.10, 0.13, 1.0),
        "eye_shine": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_brown": (0.71, 0.56, 0.42, 1.0),
        "nose_pink": (0.20, 0.66, 0.98, 1.0),
        "nose_shine": (0.74, 0.92, 1.00, 1.0),
        "soil_gray": (0.52, 0.53, 0.57, 1.0),
        "rock_light": (0.76, 0.78, 0.82, 1.0),
        "rock_dark": (0.38, 0.40, 0.44, 1.0),
        "eye_dark": (0.10, 0.10, 0.13, 1.0),
        "eye_shine": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_brown": (0.98, 0.78, 0.14, 1.0),
        "nose_pink": (0.10, 0.92, 1.00, 1.0),
        "nose_shine": (0.78, 0.98, 1.00, 1.0),
        "soil_gray": (0.82, 0.60, 0.10, 1.0),
        "rock_light": (1.00, 0.88, 0.34, 1.0),
        "rock_dark": (0.68, 0.46, 0.08, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "eye_shine": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_molepod(
    name: str = "Molepod_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 050. Molepod (Ref: Diglett):
      - Corpo em cápsula vertical arredondada marrom-terra (cilindro 12 lados + cúpula subdiv=2)
      - Dois olhos ovais verticais escuros brilhantes com ponto de luz branco no topo
      - Grande nariz oval rosa-chiclete saliente no centro da face (azul na Shiny!)
      - Coroa irregular de terra revirada e pedras cinza-claro facetadas em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Mole_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Mole_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Mole_Norm"

    parts = []

    # 1. CORPO EM CÁPSULA VERTICAL ARREDONDADA
    _add_part(
        parts,
        create_cylinder("_tmp_body_cyl", 12, 0.56, 0.92, (0.0, 0.0, 0.62)),
        mat_prefix,
        "body_brown",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_body_dome", 2, 0.56, (0.0, 0.0, 1.08), scale=(1.00, 1.00, 0.96)),
        mat_prefix,
        "body_brown",
        pal,
    )

    # 2. ROSTO ICÔNICO (OLHOS OVAIS VERTICAIS + NARIZ OVAL SALIENTE)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.095,
                (side * 0.17, -0.52, 1.24),
                scale=(0.56, 0.44, 1.38),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.036,
                (side * 0.16, -0.56, 1.30),
                scale=(0.70, 0.45, 1.05),
            ),
            mat_prefix,
            "eye_shine",
            pal,
        )

    # Nariz oval rosa-chiclete grande e fofo (azul na Shiny!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_nose",
            2,
            0.22,
            (0.0, -0.57, 1.01),
            scale=(1.22, 0.72, 0.76),
        ),
        mat_prefix,
        "nose_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_nose_shine",
            1,
            0.075,
            (-0.07, -0.71, 1.07),
            scale=(1.35, 0.40, 0.65),
        ),
        mat_prefix,
        "nose_shine",
        pal,
    )

    # 3. BASE IRREGULAR DE TERRA REVIRADA E PEDRAS FACETADAS EM Z = 0.0
    # Anel principal de terra cinza
    _add_part(
        parts,
        create_cone("_tmp_soil_base", 10, 0.96, 0.72, 0.30, (0.0, 0.0, 0.15), scale=(1.08, 0.96, 1.0)),
        mat_prefix,
        "soil_gray",
        pal,
    )
    # 12 rochas e torrões facetados espalhados organicamente em volta da base
    rock_specs = [
        # (x, y, z, rad, rot_deg, scale, key)
        (-0.62, -0.44, 0.20, 0.24, (14.0, 18.0, 26.0), (1.28, 0.88, 0.78), "rock_light"),
        (-0.24, -0.66, 0.18, 0.20, (10.0, -14.0, 12.0), (1.16, 0.90, 0.82), "rock_light"),
        (0.24, -0.64, 0.19, 0.22, (-12.0, 16.0, -18.0), (1.36, 0.86, 0.72), "rock_light"),
        (0.68, -0.40, 0.18, 0.22, (16.0, -22.0, 32.0), (1.20, 0.90, 0.76), "soil_gray"),
        (0.80, -0.06, 0.17, 0.20, (8.0, 20.0, -24.0), (1.18, 0.92, 0.70), "rock_light"),
        (-0.82, -0.06, 0.19, 0.23, (-14.0, -18.0, 14.0), (1.14, 0.96, 0.80), "soil_gray"),
        (-0.68, 0.44, 0.20, 0.24, (18.0, 12.0, -28.0), (1.22, 0.94, 0.78), "rock_light"),
        (0.64, 0.46, 0.18, 0.23, (-16.0, -14.0, 22.0), (1.26, 0.90, 0.74), "rock_light"),
        (0.0, 0.72, 0.20, 0.26, (12.0, 8.0, 0.0), (1.32, 0.88, 0.78), "soil_gray"),
        (-0.46, -0.60, 0.12, 0.13, (22.0, 10.0, 40.0), (1.10, 0.90, 0.70), "rock_dark"),
        (0.50, -0.58, 0.13, 0.14, (-18.0, 14.0, -34.0), (1.22, 0.80, 0.68), "rock_light"),
        (0.02, -0.78, 0.11, 0.14, (8.0, -12.0, 16.0), (1.30, 0.84, 0.60), "rock_dark"),
    ]
    for r_i, (rx, ry, rz, rad, rot_d, sc, key) in enumerate(rock_specs):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_rock_{r_i}",
                1,
                rad,
                (rx, ry, rz),
                rotation=tuple(math.radians(a) for a in rot_d),
                scale=sc,
            ),
            mat_prefix,
            key,
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 050. Molepod lado a lado."""
    specs = [
        ("Molepod_Shiny", (-8.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Molepod_Normal", (-4.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Molepod_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Molepod_Gigante", (4.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Molepod_Dourada_SuperRara", (10.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_molepod(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
