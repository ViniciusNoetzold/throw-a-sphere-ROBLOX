"""
077_Blazecolt_Ponyta_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "077. Blazecolt — Potro de Fogo (Ref: Ponyta)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Blazecolt_Shiny (1.0x - Paleta Shiny Icônica Chamas Azul-Elétrico / Ciano!)
  2. Blazecolt_Normal (1.0x - Potro Creme-Marfim + Cascos Azul-Ardósia + Crina/Cauda/Patas de Fogo)
  3. Blazecolt_Grande (1.35x - Normal)
  4. Blazecolt_Gigante (1.85x - Normal)
  5. Blazecolt_Dourada_SuperRara (2.25x - Ouro Reluzente + Chamas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (corpo equino esguio + chamas multicamadas em cones/icospheres)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Cascos alinhados exatamente em `Z = 0.0` e cabeça/focinho apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "coat_cream": (0.96, 0.93, 0.78, 1.0),
        "coat_shade": (0.86, 0.82, 0.66, 1.0),
        "ear_inner": (0.68, 0.42, 0.44, 1.0),
        "hoof_slate": (0.28, 0.36, 0.50, 1.0),
        "flame_yellow": (1.00, 0.86, 0.16, 1.0),
        "flame_orange": (0.98, 0.42, 0.12, 1.0),
        "flame_red": (0.90, 0.22, 0.12, 1.0),
        "eye_dark": (0.14, 0.10, 0.08, 1.0),
        "eye_shine": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "coat_cream": (0.96, 0.95, 0.88, 1.0),
        "coat_shade": (0.84, 0.84, 0.78, 1.0),
        "ear_inner": (0.58, 0.46, 0.62, 1.0),
        "hoof_slate": (0.24, 0.32, 0.48, 1.0),
        "flame_yellow": (0.74, 0.96, 1.00, 1.0),
        "flame_orange": (0.20, 0.76, 1.00, 1.0),
        "flame_red": (0.14, 0.44, 0.94, 1.0),
        "eye_dark": (0.12, 0.14, 0.22, 1.0),
        "eye_shine": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "coat_cream": (0.98, 0.78, 0.14, 1.0),
        "coat_shade": (0.86, 0.64, 0.10, 1.0),
        "ear_inner": (0.64, 0.42, 0.08, 1.0),
        "hoof_slate": (0.56, 0.38, 0.06, 1.0),
        "flame_yellow": (0.78, 0.99, 1.00, 1.0),
        "flame_orange": (0.10, 0.92, 1.00, 1.0),
        "flame_red": (0.04, 0.66, 0.88, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "eye_shine": (1.00, 1.00, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha os cascos exatamente em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_segment(parts: list, name: str, p0: tuple, p1: tuple, r0: float, r1: float, mat_prefix: str, mat_key: str, pal: dict, verts: int = 7):
    dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    if length < 1e-5:
        return None
    mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
    phi = math.atan2(dx, -dy)
    theta = math.acos(max(-1.0, min(1.0, dz / length)))
    obj = create_cone(name, verts, r0, r1, length + 0.04, mid, rotation=(theta, 0.0, phi))
    return _add_part(parts, obj, mat_prefix, mat_key, pal)


def build_blazecolt(
    name: str = "Blazecolt_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 077. Blazecolt (Ref: Ponyta):
      - Tronco equino esguio creme-marfim, pescoço arqueado e cabeça de potro graciosa
      - Olhos grandes escuros expressivos com brilho branco e orelhas pontudas com interior rosado
      - 4 patas esguias elegantes terminando em cascos azul-ardósia apoiados em Z = 0.0
      - Topete/crina de chamas altas em camadas (amarelo/laranja/vermelho) varrendo para trás
      - Tufos de fogo ardendo atrás das patas e cauda flamejante volumosa curvada para cima e direita
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Pony_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Pony_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Pony_Norm"

    parts = []

    # 1. TRONCO EQUINO ESGUIO E PESCOÇO ARQUEADO
    # Peito dianteiro
    _add_part(
        parts,
        create_icosphere("_tmp_chest", 2, 0.36, (0.0, -0.34, 1.12), scale=(0.90, 1.08, 1.02)),
        mat_prefix,
        "coat_cream",
        pal,
    )
    # Barril central do tronco
    _add_part(
        parts,
        create_icosphere("_tmp_barrel", 2, 0.34, (0.0, 0.06, 1.14), scale=(0.86, 1.48, 0.96)),
        mat_prefix,
        "coat_cream",
        pal,
    )
    # Garupa traseira arredondada
    _add_part(
        parts,
        create_icosphere("_tmp_rump", 2, 0.36, (0.0, 0.48, 1.16), scale=(0.92, 1.06, 1.00)),
        mat_prefix,
        "coat_cream",
        pal,
    )
    # Pescoço esguio subindo elegante para frente
    _add_segment(parts, "_tmp_neck", (0.0, -0.44, 1.24), (0.0, -0.68, 1.84), 0.25, 0.17, mat_prefix, "coat_cream", pal, verts=8)

    # 2. CABEÇA EQUINA GRACIOSA, FOCINHO, OLHOS EXPRESSIVOS E ORELHAS PONTUDAS
    _add_part(
        parts,
        create_icosphere("_tmp_head_cranium", 2, 0.24, (0.0, -0.74, 1.94), scale=(0.88, 1.16, 0.96)),
        mat_prefix,
        "coat_cream",
        pal,
    )
    # Focinho equino afunilado para -Y
    _add_part(
        parts,
        create_cone(
            "_tmp_muzzle",
            7,
            0.19,
            0.11,
            0.40,
            (0.0, -1.02, 1.84),
            rotation=(math.radians(108.0), 0.0, 0.0),
            scale=(0.86, 0.86, 1.0),
        ),
        mat_prefix,
        "coat_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_muzzle_tip", 1, 0.11, (0.0, -1.19, 1.79), scale=(0.86, 0.80, 0.86)),
        mat_prefix,
        "coat_shade",
        pal,
    )

    # Olhos grandes escuros com brilho branco + orelhas apontadas para trás/lados
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.085,
                (side * 0.16, -0.88, 1.96),
                rotation=(0.0, 0.0, math.radians(side * 22.0)),
                scale=(0.56, 1.12, 1.06),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.032,
                (side * 0.19, -0.92, 1.99),
                scale=(0.60, 0.85, 0.95),
            ),
            mat_prefix,
            "eye_shine",
            pal,
        )
        # Orelha externa creme
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{tag}",
                5,
                0.10,
                0.015,
                0.34,
                (side * 0.18, -0.58, 2.12),
                rotation=(math.radians(-42.0), math.radians(side * 28.0), 0.0),
                scale=(0.76, 1.12, 1.0),
            ),
            mat_prefix,
            "coat_cream",
            pal,
        )
        # Interior rosado da orelha
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_in_{tag}",
                4,
                0.055,
                0.010,
                0.24,
                (side * 0.19, -0.62, 2.10),
                rotation=(math.radians(-42.0), math.radians(side * 28.0), 0.0),
            ),
            mat_prefix,
            "ear_inner",
            pal,
        )

    # 3. QUATRO PATAS ESGUIAS COM CASCOS AZUL-ARDÓSIA EM Z = 0.0
    leg_specs = [
        # (tag, hip, knee, ankle, hoof)
        ("FL", (-0.22, -0.36, 1.00), (-0.23, -0.40, 0.56), (-0.23, -0.42, 0.16), (-0.23, -0.44, 0.08)),
        ("FR", (0.22, -0.36, 1.00), (0.23, -0.40, 0.56), (0.23, -0.42, 0.16), (0.23, -0.44, 0.08)),
        ("BL", (-0.23, 0.48, 1.02), (-0.24, 0.58, 0.56), (-0.24, 0.50, 0.16), (-0.24, 0.48, 0.08)),
        ("BR", (0.23, 0.48, 1.02), (0.24, 0.58, 0.56), (0.24, 0.50, 0.16), (0.24, 0.48, 0.08)),
    ]
    for tag, hip, knee, ankle, hoof in leg_specs:
        _add_segment(parts, f"_tmp_thigh_{tag}", hip, knee, 0.145, 0.095, mat_prefix, "coat_cream", pal, verts=7)
        _add_part(parts, create_icosphere(f"_tmp_knee_{tag}", 1, 0.098, knee), mat_prefix, "coat_cream", pal)
        _add_segment(parts, f"_tmp_shin_{tag}", knee, ankle, 0.088, 0.072, mat_prefix, "coat_cream", pal, verts=7)
        # Casco escuro facetado tocando o solo
        _add_part(
            parts,
            create_cone(
                f"_tmp_hoof_{tag}",
                6,
                0.105,
                0.074,
                0.16,
                hoof,
                scale=(0.95, 1.24, 1.0),
            ),
            mat_prefix,
            "hoof_slate",
            pal,
        )

    # 4. CRISTA DE FOGO NA CABEÇA + CRINA ARDENTE PELO PESCOÇO E DORSO
    # Grande chama curvando acima da testa para trás (núcleo amarelo + corpo laranja + ponta vermelha)
    head_flames = [
        ((0.0, -0.82, 2.22), 0.24, (0.76, 1.24, 1.15), "flame_yellow"),
        ((0.0, -0.58, 2.40), 0.28, (0.78, 1.38, 1.10), "flame_orange"),
        ((0.0, -0.26, 2.54), 0.24, (0.68, 1.34, 0.96), "flame_orange"),
    ]
    for f_i, (loc, rad, sc, m_key) in enumerate(head_flames):
        _add_part(parts, create_icosphere(f"_tmp_hflame_{f_i}", 2, rad, loc, scale=sc), mat_prefix, m_key, pal)
    # Pontas de língua de fogo no topo da crista
    _add_part(
        parts,
        create_cone("_tmp_hflame_tip1", 6, 0.18, 0.015, 0.56, (0.0, -0.02, 2.74), rotation=(math.radians(-48.0), 0.0, 0.0)),
        mat_prefix,
        "flame_red",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_hflame_tip2", 6, 0.13, 0.015, 0.42, (0.04, -0.36, 2.66), rotation=(math.radians(-30.0), 0.0, 0.0)),
        mat_prefix,
        "flame_yellow",
        pal,
    )

    # Crina de fogo correndo atrás do pescoço e ao longo do dorso
    mane_flames = [
        ((0.0, -0.44, 1.84), 0.14, 0.44, -56.0, "flame_orange"),
        ((0.0, -0.32, 1.62), 0.13, 0.40, -60.0, "flame_yellow"),
        ((0.0, -0.16, 1.48), 0.14, 0.42, -52.0, "flame_orange"),
        ((0.0, 0.06, 1.46), 0.13, 0.36, -42.0, "flame_red"),
        ((0.0, 0.26, 1.46), 0.13, 0.36, -34.0, "flame_yellow"),
    ]
    for m_i, (loc, r1, dep, rx_d, m_key) in enumerate(mane_flames):
        _add_part(
            parts,
            create_cone(f"_tmp_mane_{m_i}", 6, r1, 0.015, dep, loc, rotation=(math.radians(rx_d), 0.0, 0.0), scale=(0.75, 1.0, 1.0)),
            mat_prefix,
            m_key,
            pal,
        )

    # 5. TUFOS DE FOGO NAS PATAS (COTOVELOS E JARRETES TRASEIROS)
    leg_flames = [
        ("FL", (-0.30, -0.20, 0.80), -34.0, -24.0),
        ("FR", (0.30, -0.20, 0.80), -34.0, 24.0),
        ("BL", (-0.34, 0.66, 0.92), -36.0, -28.0),
        ("BR", (0.34, 0.66, 0.92), -36.0, 28.0),
    ]
    for tag, loc, rx_d, ry_d in leg_flames:
        _add_part(
            parts,
            create_cone(
                f"_tmp_lflame_o_{tag}",
                6,
                0.155,
                0.015,
                0.52,
                loc,
                rotation=(math.radians(rx_d), math.radians(ry_d), 0.0),
            ),
            mat_prefix,
            "flame_orange",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_lflame_y_{tag}",
                5,
                0.105,
                0.012,
                0.38,
                (loc[0], loc[1] - 0.03, loc[2] + 0.06),
                rotation=(math.radians(rx_d + 10.0), math.radians(ry_d), 0.0),
            ),
            mat_prefix,
            "flame_yellow",
            pal,
        )

    # 6. CAUDA FLAMEJANTE VOLUMOSA ERGUIDA E LEVEMENTE ABERTA PARA A DIREITA (+X)
    tail_blobs = [
        ((0.08, 0.82, 1.38), 0.26, (0.94, 1.14, 1.08), "flame_orange"),
        ((0.26, 1.02, 1.66), 0.32, (0.96, 1.20, 1.16), "flame_orange"),
        ((0.40, 1.18, 1.96), 0.28, (0.90, 1.14, 1.10), "flame_yellow"),
        ((0.22, 0.96, 1.84), 0.24, (0.84, 1.06, 1.06), "flame_yellow"),
    ]
    for t_i, (loc, rad, sc, m_key) in enumerate(tail_blobs):
        _add_part(parts, create_icosphere(f"_tmp_tail_b_{t_i}", 2, rad, loc, scale=sc), mat_prefix, m_key, pal)
    tail_tips = [
        ((0.56, 1.34, 2.30), 0.17, 0.60, -26.0, 30.0, "flame_red"),
        ((0.28, 1.06, 2.24), 0.15, 0.48, -12.0, 14.0, "flame_yellow"),
        ((0.52, 1.24, 1.72), 0.15, 0.48, -54.0, 38.0, "flame_red"),
    ]
    for t_i, (loc, r1, dep, rx_d, ry_d, m_key) in enumerate(tail_tips):
        _add_part(
            parts,
            create_cone(f"_tmp_tail_tip_{t_i}", 6, r1, 0.015, dep, loc, rotation=(math.radians(rx_d), math.radians(ry_d), 0.0)),
            mat_prefix,
            m_key,
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 077. Blazecolt lado a lado."""
    specs = [
        ("Blazecolt_Shiny", (-7.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Blazecolt_Normal", (-4.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Blazecolt_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Blazecolt_Gigante", (3.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Blazecolt_Dourada_SuperRara", (9.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_blazecolt(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
