"""
035_Moonpuff_Clefairy_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "035. Moonpuff — Fada Lunar (Ref: Clefairy)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Moonpuff_Shiny (1.0x - Paleta Shiny / Shyne Rosa-Algodão + Pontas das Orelhas Verde-Menta)
  2. Moonpuff_Normal (1.0x - Rosa-Pastel + Pontas das Orelhas Marrom + Topete e Cauda em Espiral)
  3. Moonpuff_Grande (1.35x - Normal)
  4. Moonpuff_Gigante (1.85x - Normal)
  5. Moonpuff_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Pontas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para silhueta arredondada fiel, cones 8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e rosto/sorriso apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Moonpuff_Shiny`, `Moonpuff_Normal`, `Moonpuff_Grande`,
     `Moonpuff_Gigante`, `Moonpuff_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_pink": (0.98, 0.77, 0.85, 1.0),
        "body_shade": (0.86, 0.62, 0.72, 1.0),
        "ear_brown": (0.44, 0.28, 0.22, 1.0),
        "ear_dark": (0.18, 0.14, 0.14, 1.0),
        "cheek_rose": (0.96, 0.48, 0.66, 1.0),
        "mouth_deep": (0.72, 0.34, 0.46, 1.0),
        "tongue_pink": (0.94, 0.62, 0.72, 1.0),
        "eye_dark": (0.11, 0.12, 0.16, 1.0),
        "claw_white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_pink": (0.99, 0.82, 0.88, 1.0),
        "body_shade": (0.88, 0.68, 0.76, 1.0),
        "ear_brown": (0.36, 0.84, 0.54, 1.0),
        "ear_dark": (0.18, 0.52, 0.34, 1.0),
        "cheek_rose": (0.97, 0.52, 0.70, 1.0),
        "mouth_deep": (0.74, 0.36, 0.48, 1.0),
        "tongue_pink": (0.95, 0.64, 0.74, 1.0),
        "eye_dark": (0.11, 0.12, 0.16, 1.0),
        "claw_white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_pink": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.88, 0.64, 0.10, 1.0),
        "ear_brown": (0.10, 0.92, 1.00, 1.0),
        "ear_dark": (0.06, 0.58, 0.72, 1.0),
        "cheek_rose": (1.00, 0.92, 0.46, 1.0),
        "mouth_deep": (0.80, 0.50, 0.08, 1.0),
        "tongue_pink": (0.98, 0.84, 0.34, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "claw_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base das patinhas em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_moonpuff(
    name: str = "Moonpuff_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 035. Moonpuff (Ref: Clefairy):
      - Silhueta orgânica unificada rechonchuda (icosphere subdiv=2) sem aspecto de caixa
      - Topete em espiral volumosa bem no topo da testa com contorno de espiral visível
      - Orelhas triangulares largas com pontas marrons (verde-menta na Shiny) e borda escura
      - Rosto expressivo: olhos ovais verticais escuros com brilho, bochechas ovais rosas e sorriso com presinha
      - Braços rechonchudos em pose alegre (esquerdo erguido, direito aberto) com 2 garras brancas
      - Asinhas de fada recortadas nas costas e cauda grande enrolada aparecendo na lateral direita
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Moon_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Moon_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Moon_Norm"

    parts = []

    # 1. CORPO UNIFICADO RECHONCHUDO EM FORMA DE ESTRELA-ALGOÃO (ICOSPHERE SUBDIV=2)
    _add_part(
        parts,
        create_icosphere("_tmp_body_main", 2, 0.84, (0.0, 0.02, 0.96), scale=(1.04, 0.88, 1.04)),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Volume macio extra na barriguinha inferior para dar a curva fofa da referência
    _add_part(
        parts,
        create_icosphere("_tmp_belly_plump", 2, 0.72, (0.0, -0.06, 0.74), scale=(1.06, 0.90, 0.86)),
        mat_prefix,
        "body_pink",
        pal,
    )

    # 2. TOPETE ENROLADO EM ESPIRAL NA TESTA (ASSINATURA VISUAL DA CLEFAIRY)
    curl_spheres = [
        # (radius, (x, y, z), scale)
        (0.32, (0.02, -0.26, 1.72), (1.06, 0.86, 1.00)),
        (0.27, (-0.18, -0.34, 1.66), (1.00, 0.84, 1.02)),
        (0.24, (-0.12, -0.44, 1.48), (1.04, 0.82, 0.94)),
        (0.22, (0.08, -0.48, 1.46), (1.04, 0.82, 0.94)),
        (0.18, (0.14, -0.50, 1.60), (0.96, 0.80, 0.94)),
        (0.14, (0.02, -0.54, 1.62), (0.94, 0.78, 0.92)),
    ]
    for c_idx, (rad, loc, sc) in enumerate(curl_spheres):
        _add_part(
            parts,
            create_icosphere(f"_tmp_curl_{c_idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "body_pink",
            pal,
        )
    # Linha sutil de sombra interna da espiral para destacar o caracol na vista frontal
    _add_part(
        parts,
        create_cylinder(
            "_tmp_curl_accent",
            8,
            0.09,
            0.06,
            (0.02, -0.64, 1.56),
            rotation=(math.radians(90.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    # 3. ORELHAS TRIANGULARES LARGAS COM PONTAS MARRONS E BORDA ESCURA
    ear_specs = [
        # (tag, side, rz_tilt_deg, ry_deg, base_loc, tip_loc, dark_loc)
        ("L", -1.0, -8.0, -48.0, (-0.72, -0.02, 1.54), (-1.04, -0.02, 1.82), (-0.86, 0.02, 1.52)),
        ("R", 1.0, 10.0, 56.0, (0.74, -0.02, 1.50), (1.08, -0.02, 1.72), (0.88, 0.02, 1.44)),
    ]
    for tag, side, rz_deg, ry_deg, b_loc, t_loc, d_loc in ear_specs:
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_base_{tag}",
                6,
                0.38,
                0.20,
                0.56,
                b_loc,
                rotation=(math.radians(-6.0), math.radians(ry_deg), math.radians(rz_deg)),
                scale=(1.0, 0.56, 1.0),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_tip_{tag}",
                6,
                0.205,
                0.025,
                0.36,
                t_loc,
                rotation=(math.radians(-6.0), math.radians(ry_deg), math.radians(rz_deg)),
                scale=(1.0, 0.54, 1.0),
            ),
            mat_prefix,
            "ear_brown",
            pal,
        )
        # Borda lateral escura das orelhas (fiel ao contorno preto/marrom na referência)
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_edge_{tag}",
                4,
                0.10,
                0.03,
                0.68,
                d_loc,
                rotation=(math.radians(-6.0), math.radians(ry_deg + side * 6.0), math.radians(rz_deg)),
                scale=(0.65, 0.52, 1.0),
            ),
            mat_prefix,
            "ear_dark",
            pal,
        )

    # 4. ROSTO FOFO FIEL À REFERÊNCIA (OLHOS OVAIS VERTICAIS + BOCHECHAS + SORRISO + PRESINHA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Olho oval vertical escuro brilhante
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.11,
                (side * 0.22, -0.71, 1.18),
                scale=(0.62, 0.45, 1.24),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Brilho branco no topo do olho
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.042,
                (side * 0.21, -0.76, 1.24),
                scale=(0.75, 0.50, 1.10),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )
        # Bochecha oval horizontal rosa-vivo
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_cheek_{tag}",
                1,
                0.13,
                (side * 0.44, -0.66, 1.00),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(1.22, 0.42, 0.54),
            ),
            mat_prefix,
            "cheek_rose",
            pal,
        )

    # Boca aberta sorridente + língua rosa + dentinho único no canto direito superior
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_open",
            2,
            0.16,
            (0.0, -0.72, 0.94),
            scale=(0.94, 0.46, 1.06),
        ),
        mat_prefix,
        "mouth_deep",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tongue",
            1,
            0.11,
            (0.0, -0.76, 0.87),
            scale=(0.92, 0.42, 0.68),
        ),
        mat_prefix,
        "tongue_pink",
        pal,
    )
    # Presinha fofa no canto direito da boca (como na imagem original)
    _add_part(
        parts,
        create_cone(
            "_tmp_cute_fang",
            4,
            0.036,
            0.008,
            0.09,
            (0.08, -0.79, 1.02),
            rotation=(math.radians(180.0), 0.0, 0.0),
        ),
        mat_prefix,
        "claw_white",
        pal,
    )

    # 5. BRAÇOS RECHONCHUDOS EM POSE ALEGRE (ESQUERDO ERGUIDO + DIREITO ABERTO) COM GARRINHAS BRANCAS
    # Braço esquerdo levantado alegremente
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_L",
            8,
            0.26,
            0.19,
            0.64,
            (-0.92, -0.10, 1.18),
            rotation=(math.radians(-10.0), math.radians(-52.0), 0.0),
        ),
        mat_prefix,
        "body_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hand_L", 2, 0.20, (-1.14, -0.14, 1.38)),
        mat_prefix,
        "body_pink",
        pal,
    )
    for c_idx, (dx, dz, rot_y) in enumerate([(-0.14, 0.14, -42.0), (-0.02, 0.20, -14.0)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_claw_L_{c_idx}",
                5,
                0.058,
                0.014,
                0.15,
                (-1.14 + dx, -0.16, 1.38 + dz),
                rotation=(0.0, math.radians(rot_y), 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # Braço direito estendido para o lado
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R",
            8,
            0.26,
            0.19,
            0.62,
            (0.94, -0.10, 0.96),
            rotation=(math.radians(-8.0), math.radians(74.0), 0.0),
        ),
        mat_prefix,
        "body_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hand_R", 2, 0.20, (1.20, -0.14, 1.04)),
        mat_prefix,
        "body_pink",
        pal,
    )
    for c_idx, (dx, dz, rot_y) in enumerate([(0.16, 0.08, 68.0), (0.14, -0.06, 98.0)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_claw_R_{c_idx}",
                5,
                0.058,
                0.014,
                0.15,
                (1.20 + dx, -0.16, 1.04 + dz),
                rotation=(0.0, math.radians(rot_y), 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 6. PATINHAS CURTAS RECHONCHUDAS COM UNHA BRANCA APOIADAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_{tag}",
                8,
                0.20,
                0.30,
                0.42,
                (side * 0.42, -0.06, 0.21),
                rotation=(math.radians(8.0), math.radians(side * -14.0), 0.0),
                scale=(1.0, 1.14, 1.0),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_toenail_{tag}",
                1,
                0.15,
                (side * 0.44, -0.22, 0.09),
                scale=(1.08, 0.90, 0.56),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 7. ASINHAS DE FADA NAS COSTAS + CAUDA GRANDE EM ESPIRAL APARECENDO NA LATERAL DIREITA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_wing_top_{tag}",
                1,
                0.26,
                (side * 0.56, 0.66, 1.24),
                rotation=(math.radians(16.0), math.radians(side * -18.0), math.radians(side * -22.0)),
                scale=(1.22, 0.34, 0.86),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_wing_bot_{tag}",
                1,
                0.20,
                (side * 0.52, 0.68, 0.98),
                rotation=(math.radians(12.0), math.radians(side * -14.0), math.radians(side * -18.0)),
                scale=(1.10, 0.32, 0.78),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )

    # Cauda volumosa enrolada em caracol na traseira direita (visível pela lateral como na arte!)
    tail_curl = [
        (0.32, (0.58, 0.52, 0.54), (0.96, 1.00, 1.00)),
        (0.30, (0.86, 0.36, 0.56), (0.92, 0.98, 1.04)),
        (0.26, (0.94, 0.24, 0.74), (0.88, 0.92, 0.98)),
        (0.22, (0.80, 0.24, 0.82), (0.86, 0.88, 0.92)),
    ]
    for t_idx, (rad, loc, sc) in enumerate(tail_curl):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tail_curl_{t_idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "body_pink",
            pal,
        )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_tail_spiral_mark",
            8,
            0.12,
            0.08,
            (0.96, 0.28, 0.62),
            rotation=(math.radians(90.0), 0.0, math.radians(38.0)),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 035. Moonpuff lado a lado."""
    specs = [
        ("Moonpuff_Shiny", (-7.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Moonpuff_Normal", (-4.3, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Moonpuff_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Moonpuff_Gigante", (4.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Moonpuff_Dourada_SuperRara", (10.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_moonpuff(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
