"""
103_Palmtree_Exeggutor_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "103. Palmtree — Coqueiro Ambulante (Ref: Exeggutor)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Palmtree_Shiny (1.0x - Folhas Outonais Dourado-Âmbar + Tronco Castanho-Avermelhado)
  2. Palmtree_Normal (1.0x - Tronco Segmentado + 3 Cabeças Amarelo-Creme + Coroa de Folhas de Palmeira)
  3. Palmtree_Grande (1.35x - Normal)
  4. Palmtree_Gigante (1.85x - Normal)
  5. Palmtree_Dourada_SuperRara (2.25x - Ouro Reluzente + Folhas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (tronco segmentado com anéis, 3 cabeças expressivas, 11 folhas arqueadas)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés alinhados exatamente em `Z = 0.0` e cabeças frontais apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "trunk_brown": (0.70, 0.62, 0.52, 1.0),
        "trunk_ring": (0.44, 0.36, 0.28, 1.0),
        "leaf_green": (0.28, 0.72, 0.30, 1.0),
        "leaf_light": (0.48, 0.84, 0.36, 1.0),
        "head_cream": (0.95, 0.90, 0.58, 1.0),
        "mouth_pink": (0.86, 0.54, 0.60, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "eye_dark": (0.12, 0.12, 0.15, 1.0),
        "claw_white": (0.98, 0.98, 1.00, 1.0),
    },
    "shiny_palette": {
        "trunk_brown": (0.58, 0.44, 0.32, 1.0),
        "trunk_ring": (0.36, 0.26, 0.18, 1.0),
        "leaf_green": (0.88, 0.62, 0.16, 1.0),
        "leaf_light": (0.96, 0.78, 0.26, 1.0),
        "head_cream": (0.96, 0.90, 0.56, 1.0),
        "mouth_pink": (0.86, 0.54, 0.60, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "eye_dark": (0.12, 0.12, 0.15, 1.0),
        "claw_white": (0.98, 0.98, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "trunk_brown": (0.98, 0.78, 0.14, 1.0),
        "trunk_ring": (0.72, 0.50, 0.06, 1.0),
        "leaf_green": (0.10, 0.92, 1.00, 1.0),
        "leaf_light": (0.42, 0.96, 1.00, 1.0),
        "head_cream": (1.00, 0.93, 0.58, 1.0),
        "mouth_pink": (0.86, 0.62, 0.18, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.04, 0.42, 0.58, 1.0),
        "claw_white": (1.00, 0.98, 0.90, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_coconut_head(
    parts: list,
    tag: str,
    cx: float,
    cy: float,
    cz: float,
    rad: float,
    yaw_deg: float,
    open_mouth: bool,
    mat_prefix: str,
    pal: dict,
):
    """Constrói uma das 3 cabeças amarelo-creme expressivas do Exeggutor."""
    yaw = math.radians(yaw_deg)
    ca, sa = math.cos(yaw), math.sin(yaw)

    def place(lx, ly, lz):
        return (cx + lx * ca - ly * sa, cy + lx * sa + ly * ca, cz + lz)

    _add_part(
        parts,
        create_icosphere(
            f"_tmp_head_{tag}",
            2,
            rad,
            (cx, cy, cz),
            rotation=(0.0, 0.0, yaw),
            scale=(1.02, 0.96, 1.06),
        ),
        mat_prefix,
        "head_cream",
        pal,
    )

    # Olhos meio-cerrados simpáticos com pupilas escuras
    for side in (-1.0, 1.0):
        st = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_h_eye_{tag}_{st}",
                1,
                0.23 * rad,
                place(side * 0.34 * rad, -0.88 * rad, 0.14 * rad),
                rotation=(0.0, math.radians(side * -12.0), yaw + math.radians(side * -14.0)),
                scale=(1.22, 0.42, 0.62),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pálpebra superior sutil para olhar relaxado/alegre
        _add_part(
            parts,
            create_cube(
                f"_tmp_h_lid_{tag}_{st}",
                (0.46 * rad, 0.06, 0.08 * rad),
                place(side * 0.34 * rad, -0.92 * rad, 0.24 * rad),
                rotation=(0.0, math.radians(side * -14.0), yaw + math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_h_pup_{tag}_{st}",
                1,
                0.08 * rad,
                place(side * 0.32 * rad, -0.95 * rad, 0.11 * rad),
                scale=(0.85, 0.50, 1.15),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Boca aberta sorridente com presinhas ou sorriso fechado feliz
    if open_mouth:
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_h_mouth_bg_{tag}",
                2,
                0.34 * rad,
                place(0.0, -0.84 * rad, -0.30 * rad),
                rotation=(0.0, 0.0, yaw),
                scale=(1.22, 0.48, 0.96),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_h_mouth_in_{tag}",
                1,
                0.28 * rad,
                place(0.0, -0.89 * rad, -0.32 * rad),
                rotation=(0.0, 0.0, yaw),
                scale=(1.14, 0.44, 0.86),
            ),
            mat_prefix,
            "mouth_pink",
            pal,
        )
        # Duas presinhas brancas fofas nos cantos do sorriso
        for side in (-1.0, 1.0):
            st = "L" if side < 0 else "R"
            _add_part(
                parts,
                create_cone(
                    f"_tmp_h_fang_{tag}_{st}",
                    4,
                    0.075 * rad,
                    0.015 * rad,
                    0.20 * rad,
                    place(side * 0.28 * rad, -0.94 * rad, -0.16 * rad),
                    rotation=(math.radians(180.0), 0.0, yaw),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )
    else:
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_h_smile_bg_{tag}",
                1,
                0.28 * rad,
                place(0.0, -0.88 * rad, -0.26 * rad),
                rotation=(0.0, 0.0, yaw),
                scale=(1.35, 0.42, 0.42),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_h_smile_in_{tag}",
                1,
                0.22 * rad,
                place(0.0, -0.92 * rad, -0.26 * rad),
                rotation=(0.0, 0.0, yaw),
                scale=(1.24, 0.40, 0.34),
            ),
            mat_prefix,
            "mouth_pink",
            pal,
        )


def _add_palm_frond(
    parts: list,
    idx: int,
    origin: tuple,
    azim_deg: float,
    elev_deg: float,
    length: float,
    width: float,
    mat_prefix: str,
    mat_key: str,
    pal: dict,
):
    """Cria uma folha de palmeira arqueada em 2 segmentos facetados (base erguida + ponta caída)."""
    ox, oy, oz = origin
    az = math.radians(azim_deg)
    el1 = math.radians(elev_deg)
    el2 = math.radians(elev_deg - 38.0)

    dx, dy = math.cos(az), math.sin(az)

    # Segmento 1 (base saindo da coroa para cima/fora)
    l1 = length * 0.54
    p1x = ox + dx * math.cos(el1) * l1 * 0.5
    p1y = oy + dy * math.cos(el1) * l1 * 0.5
    p1z = oz + math.sin(el1) * l1 * 0.5
    tip1_x = ox + dx * math.cos(el1) * l1
    tip1_y = oy + dy * math.cos(el1) * l1
    tip1_z = oz + math.sin(el1) * l1

    _add_part(
        parts,
        create_cone(
            f"_tmp_frond_{idx}_a",
            4,
            width * 0.92,
            width * 1.15,
            l1 * 1.10,
            (p1x, p1y, p1z),
            rotation=(0.0, math.radians(90.0 - elev_deg), az),
            scale=(0.42, 1.0, 1.0),
        ),
        mat_prefix,
        mat_key,
        pal,
    )

    # Segmento 2 (ponta afunilada curvando para baixo)
    l2 = length * 0.62
    p2x = tip1_x + dx * math.cos(el2) * l2 * 0.5
    p2y = tip1_y + dy * math.cos(el2) * l2 * 0.5
    p2z = tip1_z + math.sin(el2) * l2 * 0.5

    _add_part(
        parts,
        create_cone(
            f"_tmp_frond_{idx}_b",
            4,
            width * 1.12,
            0.03,
            l2 * 1.10,
            (p2x, p2y, p2z),
            rotation=(0.0, math.radians(90.0 - (elev_deg - 38.0)), az),
            scale=(0.38, 1.0, 1.0),
        ),
        mat_prefix,
        "leaf_light" if idx % 2 == 0 else mat_key,
        pal,
    )


def build_palmtree(
    name: str = "Palmtree_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel do 103. Palmtree (Ref: Exeggutor):
      - Tronco grosso marrom-coqueiro levemente afunilado com anéis escuros segmentados
      - 2 pernas robustas atarracadas com solas creme e 2 garras brancas por pé em Z = 0.0
      - 3 cabeças de coco amarelo-creme expressivas aninhadas no topo do tronco
      - Coroa exuberante de 11 folhas longas de palmeira arqueadas em duas camadas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Palmtree_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Palmtree_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Palmtree_Norm"

    parts = []

    # 1. TRONCO GROSSO SEGMENTADO EM FORMATO DE COQUEIRO ROBUSTO
    trunk_segs = [
        # (r_bot, r_top, depth, z_center)
        (0.68, 0.72, 0.46, 0.48),
        (0.70, 0.60, 0.44, 0.88),
        (0.58, 0.46, 0.42, 1.26),
        (0.45, 0.36, 0.36, 1.60),
    ]
    for s_idx, (rb, rt, dep, zc) in enumerate(trunk_segs):
        _add_part(
            parts,
            create_cone(f"_tmp_trunk_seg_{s_idx}", 10, rb, rt, dep, (0.0, 0.04, zc)),
            mat_prefix,
            "trunk_brown",
            pal,
        )
    # Base arredondada inferior do tronco entre as pernas
    _add_part(
        parts,
        create_icosphere("_tmp_trunk_base", 2, 0.66, (0.0, 0.04, 0.36), scale=(1.04, 0.96, 0.62)),
        mat_prefix,
        "trunk_brown",
        pal,
    )
    # Anéis escuros horizontais marcando a casca segmentada da palmeira
    ring_specs = [
        (0.71, 0.68),
        (0.61, 1.07),
        (0.47, 1.44),
    ]
    for r_idx, (rad, rz) in enumerate(ring_specs):
        _add_part(
            parts,
            create_cylinder(f"_tmp_trunk_ring_{r_idx}", 10, rad, 0.055, (0.0, 0.04, rz)),
            mat_prefix,
            "trunk_ring",
            pal,
        )

    # 2. PERNAS ATARRACADAS COM SOLAS CREME E 2 GARRAS BRANCAS POR PÉ
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa/perna saindo para os lados e frente
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_{tag}",
                8,
                0.28,
                0.32,
                0.56,
                (side * 0.66, -0.14, 0.28),
                rotation=(math.radians(32.0), math.radians(side * 46.0), 0.0),
            ),
            mat_prefix,
            "trunk_brown",
            pal,
        )
        # Anel escuro no tornozelo
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_leg_ring_{tag}",
                8,
                0.295,
                0.05,
                (side * 0.64, -0.12, 0.28),
                rotation=(math.radians(32.0), math.radians(side * 46.0), 0.0),
            ),
            mat_prefix,
            "trunk_ring",
            pal,
        )
        # Pé largo achatado tocando o chão em Z = 0.0
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.30,
                (side * 0.84, -0.34, 0.22),
                rotation=(math.radians(-18.0), 0.0, math.radians(side * -24.0)),
                scale=(0.94, 1.12, 0.72),
            ),
            mat_prefix,
            "trunk_brown",
            pal,
        )
        # Sola creme visível na frente/base da pata (como na arte do Exeggutor sentado/andando!)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_sole_{tag}",
                1,
                0.22,
                (side * 0.88, -0.44, 0.16),
                rotation=(math.radians(-20.0), 0.0, math.radians(side * -24.0)),
                scale=(0.86, 0.72, 0.86),
            ),
            mat_prefix,
            "head_cream",
            pal,
        )
        # 2 garras brancas triangulares no topo do pé
        for c_idx, (dx, dy, rz_d) in enumerate([(-0.08, -0.10, 12.0), (0.10, -0.06, -16.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_toe_claw_{tag}_{c_idx}",
                    5,
                    0.072,
                    0.015,
                    0.22,
                    (side * (0.84 + dx), -0.32 + dy, 0.42),
                    rotation=(math.radians(-26.0), math.radians(side * 16.0), math.radians(side * rz_d)),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 3. TRÊS CABEÇAS AMARELO-CREME EXPRESSIVAS NO TOPO DO TRONCO
    # Cabeça 1: Frontal esquerda (principal, boca aberta sorridente com presinhas)
    _add_coconut_head(parts, "front_L", -0.34, -0.46, 1.56, 0.40, 18.0, True, mat_prefix, pal)
    # Cabeça 2: Frontal direita (sorriso sereno/confiante)
    _add_coconut_head(parts, "front_R", 0.42, -0.34, 1.62, 0.39, -24.0, False, mat_prefix, pal)
    # Cabeça 3: Lateral-traseira esquerda (espiando de lado com boca aberta!)
    _add_coconut_head(parts, "back_L", -0.58, 0.12, 1.66, 0.36, 74.0, True, mat_prefix, pal)

    # Núcleo verde central de onde brotam todas as folhas da coroa
    crown_origin = (0.0, 0.04, 1.84)
    _add_part(
        parts,
        create_icosphere("_tmp_crown_hub", 2, 0.34, crown_origin, scale=(1.10, 1.10, 0.76)),
        mat_prefix,
        "leaf_green",
        pal,
    )

    # 4. COROA EXUBERANTE DE 13 FOLHAS DE PALMEIRA ARQUEADAS EM 2 CAMADAS
    # Camada inferior: 7 folhas largas abrindo em leque tropical amplo
    lower_fronds = [
        (0.0, 28.0, 1.88, 0.34),
        (52.0, 30.0, 1.82, 0.33),
        (104.0, 32.0, 1.82, 0.33),
        (156.0, 30.0, 1.86, 0.34),
        (206.0, 28.0, 1.82, 0.33),
        (258.0, 32.0, 1.66, 0.30),
        (310.0, 30.0, 1.72, 0.31),
    ]
    for i, (az, el, ln, wd) in enumerate(lower_fronds):
        _add_palm_frond(parts, i, crown_origin, az, el, ln, wd, mat_prefix, "leaf_green", pal)

    # Camada superior: 6 folhas altas erguidas como crista tropical cheia
    upper_fronds = [
        (20.0, 60.0, 1.78, 0.31),
        (76.0, 68.0, 1.74, 0.30),
        (132.0, 64.0, 1.76, 0.31),
        (184.0, 60.0, 1.78, 0.31),
        (238.0, 62.0, 1.64, 0.29),
        (320.0, 62.0, 1.66, 0.29),
    ]
    for j, (az, el, ln, wd) in enumerate(upper_fronds):
        _add_palm_frond(parts, 10 + j, crown_origin, az, el, ln, wd, mat_prefix, "leaf_light", pal)

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 103. Palmtree lado a lado."""
    specs = [
        ("Palmtree_Shiny", (-13.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Palmtree_Normal", (-7.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Palmtree_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Palmtree_Gigante", (6.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Palmtree_Dourada_SuperRara", (16.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_palmtree(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
