"""
132_Morphgel_Ditto_5Variacoes_Blender.py
========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "132. Morphgel — Geleia Mutante (Ref: Ditto)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Morphgel_Shiny (1.0x - Paleta Shiny Clássica Azul-Ciano Vibrante)
  2. Morphgel_Normal (1.0x - Geleia Lilás-Rosado Ondulada + Bracinhos + Sorriso Minimalista)
  3. Morphgel_Grande (1.35x - Normal)
  4. Morphgel_Gigante (1.85x - Normal)
  5. Morphgel_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Sorriso Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (aglomerado harmonioso de icospheres subdiv=2 para forma amebóide fiel)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base gelatinosa alinhada exatamente em `Z = 0.0` e rosto minimalista apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "gel_lilac": (0.81, 0.65, 0.87, 1.0),
        "gel_shade": (0.68, 0.51, 0.76, 1.0),
        "gel_highlight": (0.91, 0.80, 0.96, 1.0),
        "eye_black": (0.10, 0.09, 0.12, 1.0),
        "mouth_line": (0.16, 0.12, 0.16, 1.0),
        "mouth_pink": (0.88, 0.58, 0.66, 1.0),
    },
    "shiny_palette": {
        "gel_lilac": (0.36, 0.78, 0.96, 1.0),
        "gel_shade": (0.24, 0.62, 0.84, 1.0),
        "gel_highlight": (0.64, 0.90, 1.00, 1.0),
        "eye_black": (0.09, 0.10, 0.13, 1.0),
        "mouth_line": (0.12, 0.18, 0.24, 1.0),
        "mouth_pink": (0.90, 0.62, 0.72, 1.0),
    },
    "golden_super_rare_palette": {
        "gel_lilac": (0.98, 0.78, 0.14, 1.0),
        "gel_shade": (0.84, 0.60, 0.08, 1.0),
        "gel_highlight": (1.00, 0.92, 0.48, 1.0),
        "eye_black": (0.10, 0.92, 1.00, 1.0),
        "mouth_line": (0.08, 0.74, 0.88, 1.0),
        "mouth_pink": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_morphgel(
    name: str = "Morphgel_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 132. Morphgel (Ref: Ditto):
      - Massa gelatinosa amebóide baixa e larga com base ondulada em 5 lobos macios (Z = 0.0)
      - 2 bracinhos curtos arredondados assimétricos (esquerdo mais alto, direito mais aberto)
      - 2 pequenos calombos suaves formando o topo ondulado da cabeça (assinatura da arte)
      - Rosto minimalista icônico: 2 pontinhos pretos afastados e sorriso fino curvado rosado
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Gel_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Gel_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Gel_Norm"

    parts = []

    # 1. CORPO PRINCIPAL GELATINOSO (SILHUETA TRAPEZOIDAL ONDULADA)
    _add_part(
        parts,
        create_icosphere("_tmp_gel_core", 2, 0.86, (0.0, 0.04, 0.88), scale=(1.10, 0.88, 0.94)),
        mat_prefix,
        "gel_lilac",
        pal,
    )
    # Frente macia ligeiramente mais plana para o rosto minimalista brilhar
    _add_part(
        parts,
        create_icosphere("_tmp_gel_face_pad", 2, 0.68, (0.0, -0.22, 1.04), scale=(1.04, 0.72, 0.86)),
        mat_prefix,
        "gel_lilac",
        pal,
    )

    # 2. BASE ONDULADA EM SAIA DE GELEIA (LOBOS ASSIMÉTRICOS APOIADOS EM Z = 0.0)
    base_lobes = [
        # (rad, (x, y, z), scale, mat_key)
        (0.56, (-0.78, -0.10, 0.34), (1.16, 1.04, 0.62), "gel_shade"),
        (0.52, (0.02, -0.34, 0.32), (1.18, 0.96, 0.58), "gel_shade"),
        (0.58, (0.84, -0.06, 0.34), (1.18, 1.06, 0.62), "gel_shade"),
        (0.54, (-0.52, 0.44, 0.34), (1.14, 1.08, 0.62), "gel_shade"),
        (0.54, (0.56, 0.42, 0.34), (1.14, 1.08, 0.62), "gel_shade"),
        # Ondas frontais superiores em lilás claro (efeito de derretimento sobre a base)
        (0.42, (-0.58, -0.34, 0.58), (1.06, 0.82, 0.78), "gel_lilac"),
        (0.40, (0.02, -0.44, 0.52), (1.04, 0.78, 0.76), "gel_lilac"),
        (0.42, (0.58, -0.32, 0.58), (1.06, 0.82, 0.78), "gel_lilac"),
    ]
    for b_idx, (rad, loc, sc, mkey) in enumerate(base_lobes):
        _add_part(
            parts,
            create_icosphere(f"_tmp_gel_lobe_{b_idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            mkey,
            pal,
        )

    # 3. BRACINHOS CURTOS ARREDONDADOS ASSIMÉTRICOS + 2 ONDAS NO TOPO DA CABEÇA
    # Braço esquerdo erguido fofo (como na referência!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_arm_L",
            2,
            0.34,
            (-0.92, -0.08, 1.38),
            rotation=(0.0, math.radians(-24.0), 0.0),
            scale=(1.22, 0.84, 0.86),
        ),
        mat_prefix,
        "gel_lilac",
        pal,
    )
    # Braço direito um pouco mais baixo e projetado para fora
    _add_part(
        parts,
        create_icosphere(
            "_tmp_arm_R",
            2,
            0.32,
            (0.96, -0.06, 1.06),
            rotation=(0.0, math.radians(16.0), 0.0),
            scale=(1.24, 0.84, 0.84),
        ),
        mat_prefix,
        "gel_lilac",
        pal,
    )
    # 2 calombos ondulados no topo da cabeça + leve brilho gelatinoso
    _add_part(
        parts,
        create_icosphere("_tmp_crown_L", 2, 0.36, (-0.22, 0.00, 1.62), scale=(1.04, 0.88, 0.88)),
        mat_prefix,
        "gel_lilac",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_crown_R", 2, 0.34, (0.28, 0.02, 1.56), scale=(1.02, 0.88, 0.84)),
        mat_prefix,
        "gel_lilac",
        pal,
    )
    # Brilhos suaves no topo (detalhe gelatinoso)
    _add_part(
        parts,
        create_icosphere("_tmp_gloss_L", 1, 0.13, (-0.24, -0.14, 1.84), scale=(1.20, 0.80, 0.42)),
        mat_prefix,
        "gel_highlight",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_gloss_arm", 1, 0.12, (-1.04, -0.18, 1.54), scale=(1.10, 0.78, 0.45)),
        mat_prefix,
        "gel_highlight",
        pal,
    )

    # 4. ROSTINHO MINIMALISTA ICÔNICO DO DITTO (2 PONTINHOS PRETOS + SORRISO FINO CURVADO)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                1,
                0.048,
                (side * 0.24, -0.69, 1.38),
                scale=(0.95, 0.65, 1.05),
            ),
            mat_prefix,
            "eye_black",
            pal,
        )

    # Sorriso largo fino em arco suave (5 segmentos conectados formando sorriso clássico)
    smile_pts = [
        (-0.28, -0.68, 1.24, 16.0),
        (-0.14, -0.71, 1.20, 8.0),
        (0.00, -0.72, 1.18, 0.0),
        (0.14, -0.71, 1.20, -8.0),
        (0.28, -0.68, 1.24, -16.0),
    ]
    for sm_idx, (sx, sy, sz, ry_deg) in enumerate(smile_pts):
        _add_part(
            parts,
            create_cube(
                f"_tmp_smile_out_{sm_idx}",
                (0.16, 0.055, 0.058),
                (sx, sy, sz),
                rotation=(0.0, math.radians(ry_deg), 0.0),
            ),
            mat_prefix,
            "mouth_line",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_smile_in_{sm_idx}",
                (0.14, 0.062, 0.030),
                (sx, sy - 0.008, sz),
                rotation=(0.0, math.radians(ry_deg), 0.0),
            ),
            mat_prefix,
            "mouth_pink",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 132. Morphgel lado a lado."""
    specs = [
        ("Morphgel_Shiny", (-9.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Morphgel_Normal", (-5.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Morphgel_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Morphgel_Gigante", (5.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Morphgel_Dourada_SuperRara", (12.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_morphgel(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
