"""
046_Sporecrab_Paras_5Variacoes_Blender.py
=========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "046. Sporecrab — Cigarra dos Fungos (Ref: Paras)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Sporecrab_Shiny (1.0x - Corpo Laranja-Avermelhado + Cogumelos Amarelo-Dourado com Pintas Creme)
  2. Sporecrab_Normal (1.0x - Corpo Laranja-Pêssego + Carapaça Segmentada + 2 Cogumelos Rosa-Rubi com Pintas Amarelas)
  3. Sporecrab_Grande (1.35x - Normal)
  4. Sporecrab_Gigante (1.85x - Normal)
  5. Sporecrab_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Pintas dos Cogumelos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + cones 6-8 lados para garras e patas articuladas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Garras e patas alinhadas exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_orange": (0.93, 0.56, 0.30, 1.0),
        "shell_brown": (0.72, 0.43, 0.27, 1.0),
        "leg_brown": (0.64, 0.38, 0.24, 1.0),
        "cap_rose": (0.84, 0.38, 0.52, 1.0),
        "cap_spot": (0.98, 0.86, 0.44, 1.0),
        "stalk_cream": (0.86, 0.82, 0.52, 1.0),
        "eye_white": (0.97, 0.98, 1.00, 1.0),
        "pupil_dark": (0.10, 0.10, 0.13, 1.0),
        "pore_tan": (0.76, 0.44, 0.22, 1.0),
    },
    "shiny_palette": {
        "body_orange": (0.92, 0.34, 0.19, 1.0),
        "shell_brown": (0.68, 0.23, 0.15, 1.0),
        "leg_brown": (0.58, 0.20, 0.14, 1.0),
        "cap_rose": (0.95, 0.65, 0.16, 1.0),
        "cap_spot": (0.99, 0.95, 0.62, 1.0),
        "stalk_cream": (0.88, 0.84, 0.50, 1.0),
        "eye_white": (0.97, 0.98, 1.00, 1.0),
        "pupil_dark": (0.10, 0.10, 0.13, 1.0),
        "pore_tan": (0.70, 0.22, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "body_orange": (0.98, 0.78, 0.14, 1.0),
        "shell_brown": (0.84, 0.62, 0.10, 1.0),
        "leg_brown": (0.76, 0.54, 0.08, 1.0),
        "cap_rose": (1.00, 0.84, 0.22, 1.0),
        "cap_spot": (0.10, 0.92, 1.00, 1.0),
        "stalk_cream": (0.96, 0.90, 0.52, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "pupil_dark": (0.10, 0.92, 1.00, 1.0),
        "pore_tan": (0.78, 0.56, 0.08, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_sporecrab(
    name: str = "Sporecrab_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 046. Sporecrab (Ref: Paras):
      - Corpo atarracado laranja-pêssego com carapaça segmentada marrom-terracota nas costas
      - Cabeça expressiva com 2 grandes olhos redondos brancos + pupilas escuras + brilho,
        5 pintinhas na testa, focinho laranja e mandíbulas brancas segmentadas
      - 2 grandes garras dianteiras curvas apontadas para o chão (Z = 0.0)
      - 4 patas finas de inseto articuladas atrás
      - 2 cogumelos tochukaso volumosos nas costas com talos creme e pintas amarelo-ouro
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Spore_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Spore_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Spore_Norm"

    parts = []

    # 1. CABEÇA E CORPO SEGMENTADO DE CIGARRA-CARANGUEJO
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.56, (0.0, -0.34, 0.66), scale=(1.04, 0.92, 0.86)),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Segmento 1 da carapaça dorsal
    _add_part(
        parts,
        create_icosphere("_tmp_seg1", 2, 0.60, (0.0, 0.08, 0.72), scale=(1.08, 0.92, 0.88)),
        mat_prefix,
        "shell_brown",
        pal,
    )
    # Segmento 2 (dorso principal)
    _add_part(
        parts,
        create_icosphere("_tmp_seg2", 2, 0.64, (0.0, 0.36, 0.74), scale=(1.10, 0.96, 0.90)),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Segmento traseiro arredondado
    _add_part(
        parts,
        create_icosphere("_tmp_seg3", 2, 0.54, (0.0, 0.66, 0.68), scale=(1.02, 0.86, 0.84)),
        mat_prefix,
        "shell_brown",
        pal,
    )

    # 2. ROSTO EXPRESSIVO: OLHOS ENORMES + 5 PINTINHAS NA TESTA + MANDÍBULAS BRANCAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.23,
                (side * 0.38, -0.68, 0.82),
                rotation=(0.0, 0.0, math.radians(side * -16.0)),
                scale=(0.94, 0.76, 1.00),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                2,
                0.14,
                (side * 0.40, -0.80, 0.81),
                scale=(0.90, 0.60, 0.94),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.055,
                (side * 0.34, -0.87, 0.88),
                scale=(0.95, 0.60, 0.95),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # 5 pintinhas/poros na testa (arco fiel à arte do Paras)
    forehead_dots = [
        (0.0, -0.76, 1.00),
        (-0.14, -0.78, 0.96),
        (0.14, -0.78, 0.96),
        (-0.10, -0.82, 0.86),
        (0.10, -0.82, 0.86),
    ]
    for d_idx, d_loc in enumerate(forehead_dots):
        _add_part(
            parts,
            create_icosphere(f"_tmp_dot_{d_idx}", 1, 0.036, d_loc, scale=(1.0, 0.6, 1.0)),
            mat_prefix,
            "pore_tan",
            pal,
        )

    # Focinho oval laranja + boca escura + 3 dentinhos/mandíbulas brancas de cada lado
    _add_part(
        parts,
        create_icosphere("_tmp_snout", 2, 0.16, (0.0, -0.84, 0.62), scale=(1.18, 0.82, 0.68)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_core", 1, 0.11, (0.0, -0.84, 0.50), scale=(1.05, 0.60, 0.82)),
        mat_prefix,
        "pupil_dark",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        for m_idx, (mx, my, mz) in enumerate([
            (side * 0.13, -0.87, 0.54),
            (side * 0.11, -0.88, 0.48),
            (side * 0.08, -0.87, 0.43),
        ]):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_mandible_{tag}_{m_idx}",
                    1,
                    0.068,
                    (mx, my, mz),
                    scale=(1.15, 0.85, 0.68),
                ),
                mat_prefix,
                "eye_white",
                pal,
            )

    # 3. DUAS GRANDES GARRAS DIANTEIRAS CURVAS EM PINÇA (APOIADAS EM Z = 0.0)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Ombro/articulação da garra
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_claw_sh_{tag}",
                2,
                0.22,
                (side * 0.62, -0.24, 0.56),
                scale=(0.95, 1.10, 0.95),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        # Braço volumoso oval da garra curvando para frente e para baixo
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_claw_arm_{tag}",
                2,
                0.34,
                (side * 0.82, -0.58, 0.44),
                rotation=(math.radians(32.0), math.radians(side * 18.0), math.radians(side * -14.0)),
                scale=(0.76, 1.48, 0.78),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        # Ponta cônica afiada da garra tocando Z = 0.0
        _add_part(
            parts,
            create_cone(
                f"_tmp_claw_tip_{tag}",
                6,
                0.15,
                0.02,
                0.38,
                (side * 0.82, -0.94, 0.17),
                rotation=(math.radians(150.0), math.radians(side * -14.0), 0.0),
                scale=(0.88, 1.0, 1.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )

    # 4. QUATRO PATAS TRASEIRAS FINAS E ARTICULADAS (2 PARES) APOIADAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        for l_idx, (ly_hip, ly_knee, ly_tip, rot_z) in enumerate([
            (0.24, 0.22, 0.16, 8.0),
            (0.56, 0.66, 0.74, -18.0),
        ]):
            # Coxa (subindo levemente do tronco para o joelho)
            _add_part(
                parts,
                create_cone(
                    f"_tmp_leg_up_{tag}_{l_idx}",
                    6,
                    0.095,
                    0.075,
                    0.44,
                    (side * 0.72, ly_hip, 0.56),
                    rotation=(0.0, math.radians(side * 72.0), math.radians(side * rot_z)),
                ),
                mat_prefix,
                "leg_brown",
                pal,
            )
            # Joelho
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_knee_{tag}_{l_idx}",
                    1,
                    0.085,
                    (side * 0.92, ly_knee, 0.60),
                ),
                mat_prefix,
                "leg_brown",
                pal,
            )
            # Tíbia/pata descendo até Z = 0.0
            _add_part(
                parts,
                create_cone(
                    f"_tmp_leg_dn_{tag}_{l_idx}",
                    6,
                    0.025,
                    0.082,
                    0.62,
                    (side * 1.02, ly_tip, 0.30),
                    rotation=(math.radians(6.0), math.radians(side * -16.0), 0.0),
                ),
                mat_prefix,
                "leg_brown",
                pal,
            )

    # 5. DOIS COGUMELOS TOCHUKASO NAS COSTAS (TALOS CREME + CHAPÉUS ROSA-RUBI + PINTAS AMARELAS)
    mush_specs = [
        # (tag, side, stalk_loc, cap_loc, rot_x, rot_y)
        ("L", -1.0, (-0.42, 0.16, 1.18), (-0.54, 0.14, 1.38), -8.0, -28.0),
        ("R", 1.0, (0.44, 0.32, 1.14), (0.56, 0.32, 1.34), 6.0, 30.0),
    ]
    for tag, side, st_loc, cp_loc, rx_d, ry_d in mush_specs:
        rx, ry = math.radians(rx_d), math.radians(ry_d)
        _add_part(
            parts,
            create_cone(
                f"_tmp_stalk_{tag}",
                8,
                0.14,
                0.11,
                0.32,
                st_loc,
                rotation=(rx, ry, 0.0),
            ),
            mat_prefix,
            "stalk_cream",
            pal,
        )
        # Chapéu bulboso arredondado do cogumelo
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_cap_{tag}",
                2,
                0.42,
                cp_loc,
                rotation=(rx, ry, 0.0),
                scale=(1.04, 1.00, 0.88),
            ),
            mat_prefix,
            "cap_rose",
            pal,
        )
        # Pintas amarelas distribuídas no topo e frente do chapéu
        spot_offsets = [
            (0.0, -0.34, 0.12, 0.11),
            (-0.24, -0.22, 0.18, 0.095),
            (0.24, -0.20, 0.16, 0.10),
            (0.02, 0.02, 0.34, 0.115),
            (side * 0.32, 0.10, 0.12, 0.095),
            (-side * 0.16, 0.28, 0.18, 0.09),
        ]
        for s_i, (ox, oy, oz, rad) in enumerate(spot_offsets):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_mspot_{tag}_{s_i}",
                    1,
                    rad,
                    (cp_loc[0] + ox, cp_loc[1] + oy, cp_loc[2] + oz),
                    scale=(1.05, 0.85, 0.72),
                ),
                mat_prefix,
                "cap_spot",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 046. Sporecrab lado a lado."""
    specs = [
        ("Sporecrab_Shiny", (-9.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Sporecrab_Normal", (-5.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Sporecrab_Grande", (-1.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Sporecrab_Gigante", (4.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Sporecrab_Dourada_SuperRara", (11.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_sporecrab(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
