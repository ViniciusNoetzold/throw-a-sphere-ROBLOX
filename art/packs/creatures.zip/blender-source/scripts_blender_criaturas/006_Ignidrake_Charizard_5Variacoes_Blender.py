"""
006_Ignidrake_Charizard_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "006. Ignidrake — Dragão Alado Solar (Ref: Charizard)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Ignidrake_Shiny (1.0x - Paleta Shiny / Shyne Preto-Obsidiana + Asas Carmesim)
  2. Ignidrake_Normal (1.0x - Corpo Laranja-Fogo + Asas Internas Azul-Petróleo + 2 Chifres)
  3. Ignidrake_Grande (1.35x - Normal)
  4. Ignidrake_Gigante (1.85x - Normal)
  5. Ignidrake_Dourada_SuperRara (2.25x - Ouro Reluzente + Asas Ouro-Platina + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cilindros 8 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base dos pés e garras alinhada exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Ignidrake_Shiny`, `Ignidrake_Normal`, `Ignidrake_Grande`,
     `Ignidrake_Gigante`, `Ignidrake_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_orange": (0.96, 0.48, 0.12, 1.0),
        "belly_cream": (0.98, 0.86, 0.54, 1.0),
        "wing_teal": (0.10, 0.44, 0.52, 1.0),
        "flame_outer": (1.00, 0.34, 0.08, 1.0),
        "flame_core": (1.00, 0.86, 0.14, 1.0),
        "eyes_teal": (0.12, 0.54, 0.64, 1.0),
        "brow_dark": (0.64, 0.26, 0.06, 1.0),
        "claws_white": (0.97, 0.97, 0.98, 1.0),
    },
    "shiny_palette": {
        "body_orange": (0.16, 0.16, 0.19, 1.0),
        "belly_cream": (0.94, 0.84, 0.56, 1.0),
        "wing_teal": (0.84, 0.16, 0.22, 1.0),
        "flame_outer": (1.00, 0.38, 0.08, 1.0),
        "flame_core": (1.00, 0.92, 0.28, 1.0),
        "eyes_teal": (0.94, 0.20, 0.24, 1.0),
        "brow_dark": (0.08, 0.08, 0.10, 1.0),
        "claws_white": (0.98, 0.98, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "body_orange": (0.98, 0.76, 0.12, 1.0),
        "belly_cream": (1.00, 0.92, 0.50, 1.0),
        "wing_teal": (1.00, 0.88, 0.36, 1.0),
        "flame_outer": (1.00, 0.86, 0.22, 1.0),
        "flame_core": (1.00, 0.98, 0.84, 1.0),
        "eyes_teal": (0.10, 0.92, 1.00, 1.0),
        "brow_dark": (0.74, 0.50, 0.06, 1.0),
        "claws_white": (1.00, 0.97, 0.84, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_ignidrake(
    name: str = "Ignidrake_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 006. Ignidrake (Ref: Charizard):
      - Frente apontando para -Y e base dos pés e garras em Z = 0.0
      - Torso dracônico largo com barriga creme, pescoço longo e cabeça com 2 chifres traseiros
      - Duas grandes asas membranosas com estrutura externa e painéis internos coloridos
      - Cauda longa e grossa terminando em grande chama bicolor vibrante
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Igni_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Igni_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Igni"

    parts = []

    # 1. TORSO DRACÔNICO + BARRIGA CREME + PESCOÇO LONGO ARTICULADO
    _add_part(
        parts,
        create_cube("_tmp_torso", (1.38, 1.12, 1.46), (0.0, 0.0, 1.32)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_pelvis", (1.48, 1.18, 0.92), (0.0, 0.08, 0.86)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_belly", (1.06, 0.16, 1.48), (0.0, -0.54, 1.16)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_neck_low", 6, 0.38, 0.30, 0.68, (0.0, -0.08, 2.24), (math.radians(8), 0.0, 0.0)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_neck_high", 6, 0.30, 0.26, 0.58, (0.0, -0.16, 2.74), (math.radians(10), 0.0, 0.0)),
        mat_prefix,
        "body_orange",
        pal,
    )

    # 2. PERNAS PODEROSAS (Z = 0) + BRAÇOS ESBELTOS + ASAS DRACÔNICAS
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_thigh_{side_idx}",
                (0.64, 0.74, 0.82),
                (sx * 0.68, 0.02, 0.74),
                (math.radians(8), 0.0, math.radians(sx * -8)),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{side_idx}", (0.54, 0.72, 0.40), (sx * 0.74, -0.10, 0.22)),
            mat_prefix,
            "body_orange",
            pal,
        )
        for claw_i, cx_off in enumerate([-0.15, 0.0, 0.15]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_claw_{side_idx}_{claw_i}",
                    4,
                    0.075,
                    0.014,
                    0.28,
                    (sx * 0.74 + cx_off, -0.54, 0.10),
                    (math.radians(86), 0.0, 0.0),
                ),
                mat_prefix,
                "claws_white",
                pal,
            )

        # Braços dianteiros + garras brancas
        _add_part(
            parts,
            create_cone(
                f"_tmp_upper_arm_{side_idx}",
                6,
                0.16,
                0.12,
                0.58,
                (sx * 0.84, -0.10, 1.78),
                (math.radians(12), math.radians(sx * 114), 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_forearm_{side_idx}",
                6,
                0.14,
                0.12,
                0.56,
                (sx * 1.10, -0.32, 1.48),
                (math.radians(130), math.radians(sx * 6), 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        for hx_i, hx_off in enumerate([-0.08, 0.0, 0.08]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{side_idx}_{hx_i}",
                    4,
                    0.044,
                    0.008,
                    0.18,
                    (sx * 1.10 + hx_off, -0.58, 1.22),
                    (math.radians(135), 0.0, 0.0),
                ),
                mat_prefix,
                "claws_white",
                pal,
            )

        # Grande asa dracônica (estrutura externa + membrana interna azul-petróleo/carmesim)
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_arm_{side_idx}",
                6,
                0.18,
                0.14,
                0.96,
                (sx * 0.80, 0.46, 2.15),
                (0.0, math.radians(sx * 49), 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_spar_{side_idx}",
                6,
                0.15,
                0.08,
                1.38,
                (sx * 1.80, 0.48, 2.25),
                (0.0, math.radians(sx * 107), 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_spike_{side_idx}",
                4,
                0.11,
                0.02,
                0.42,
                (sx * 1.16, 0.50, 2.66),
                (0.0, math.radians(sx * 16), 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_outer_{side_idx}",
                4,
                0.10,
                0.03,
                1.14,
                (sx * 2.40, 0.44, 1.50),
                (0.0, math.radians(sx * 175), 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_mem_in_{side_idx}",
                (1.10, 0.08, 1.15),
                (sx * 0.96, 0.48, 1.72),
                (0.0, math.radians(sx * -20), 0.0),
            ),
            mat_prefix,
            "wing_teal",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_mem_out_{side_idx}",
                (1.15, 0.08, 1.05),
                (sx * 1.82, 0.46, 1.66),
                (0.0, math.radians(sx * 12), 0.0),
            ),
            mat_prefix,
            "wing_teal",
            pal,
        )

    # 3. CABEÇA DRACÔNICA (-Y) + 2 CHIFRES TRASEIROS SIMÉTRICOS
    _add_part(
        parts,
        create_cube("_tmp_head", (0.88, 0.96, 0.74), (0.0, -0.28, 3.16)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout", (0.72, 0.64, 0.38), (0.0, -0.88, 3.04)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_nose_tip", (0.64, 0.26, 0.34), (0.0, -1.22, 3.06)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_lower_jaw", (0.66, 0.56, 0.16), (0.0, -0.84, 2.82)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth_line", (0.68, 0.42, 0.06), (0.0, -0.96, 2.90)),
        mat_prefix,
        "brow_dark",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_horn_{side_idx}",
                4,
                0.16,
                0.04,
                0.68,
                (sx * 0.34, 0.24, 3.48),
                (math.radians(-52), math.radians(sx * 18), 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{side_idx}",
                (0.26, 0.12, 0.07),
                (sx * 0.36, -0.84, 3.30),
                (0.0, math.radians(sx * 16), math.radians(sx * -18)),
            ),
            mat_prefix,
            "brow_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_sclera_{side_idx}",
                (0.22, 0.10, 0.18),
                (sx * 0.36, -0.82, 3.20),
                (0.0, 0.0, math.radians(sx * -18)),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_iris_{side_idx}",
                (0.14, 0.08, 0.14),
                (sx * 0.35, -0.85, 3.19),
                (0.0, 0.0, math.radians(sx * -18)),
            ),
            mat_prefix,
            "eyes_teal",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{side_idx}",
                4,
                0.042,
                0.008,
                0.11,
                (sx * 0.28, -1.20, 2.88),
                (math.radians(180), 0.0, 0.0),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )

    # 4. CAUDA LONGA E GROSSA CURVADA (+Y) + CHAMA SOLAR BICOLOR
    _add_part(
        parts,
        create_cone("_tmp_tail_base", 6, 0.38, 0.26, 0.92, (0.0, 0.88, 0.72), (math.radians(-74), 0.0, 0.0)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_tail_cream", (0.36, 0.78, 0.16), (0.0, 0.94, 0.56), (math.radians(-18), 0.0, 0.0)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_tail_mid", 6, 0.26, 0.16, 0.88, (0.0, 1.58, 0.96), (math.radians(-48), 0.0, 0.0)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_tail_tip", 6, 0.16, 0.09, 0.76, (0.0, 2.04, 1.48), (math.radians(-18), 0.0, 0.0)),
        mat_prefix,
        "body_orange",
        pal,
    )

    _add_part(
        parts,
        create_icosphere("_tmp_flame_orb", 1, 0.30, (0.0, 2.14, 1.92)),
        mat_prefix,
        "flame_outer",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_flame_main", 5, 0.32, 0.02, 0.88, (0.0, 2.16, 2.24)),
        mat_prefix,
        "flame_outer",
        pal,
    )
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_flame_side_{side_idx}",
                4,
                0.16,
                0.01,
                0.54,
                (sx * 0.18, 2.18, 2.10),
                (math.radians(10), math.radians(sx * 24), 0.0),
            ),
            mat_prefix,
            "flame_outer",
            pal,
        )
    _add_part(
        parts,
        create_cone("_tmp_flame_core", 4, 0.20, 0.02, 0.62, (0.0, 2.10, 2.14)),
        mat_prefix,
        "flame_core",
        pal,
    )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """
    Gera lado a lado os 5 modelos do 006. Ignidrake (Charizard):
      1. Shiny (1.0x) | 2. Normal (1.0x) | 3. Grande (1.35x) | 4. Gigante (1.85x) | 5. Dourada Super Rara (2.25x)
    """
    build_ignidrake("Ignidrake_Shiny", location=(-11.5, 0.0, 0.0), scale=CONFIG["scales"]["Shiny"], variant="Shiny")
    build_ignidrake("Ignidrake_Normal", location=(-6.8, 0.0, 0.0), scale=CONFIG["scales"]["Normal"], variant="Normal")
    build_ignidrake("Ignidrake_Grande", location=(-1.4, 0.0, 0.0), scale=CONFIG["scales"]["Grande"], variant="Normal")
    build_ignidrake("Ignidrake_Gigante", location=(5.4, 0.0, 0.0), scale=CONFIG["scales"]["Gigante"], variant="Normal")
    build_ignidrake(
        "Ignidrake_Dourada_SuperRara",
        location=(14.5, 0.0, 0.0),
        scale=CONFIG["scales"]["DouradaSuperRara"],
        variant="DouradaSuperRara",
    )


if __name__ == "__main__":
    generate_variations()
    print("006. Ignidrake (5 variações: Shiny, Normal, Grande, Gigante e Dourada Super Rara) gerado com sucesso!")
