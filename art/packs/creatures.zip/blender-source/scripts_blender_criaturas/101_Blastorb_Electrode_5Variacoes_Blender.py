"""
101_Blastorb_Electrode_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "101. Blastorb — Esfera Explosiva (Ref: Electrode)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Blastorb_Shiny (1.0x - Hemisfério Superior Branco + Inferior Azul-Elétrico)
  2. Blastorb_Normal (1.0x - Hemisfério Superior Branco + Inferior Vermelho + Sorriso Confiante)
  3. Blastorb_Grande (1.35x - Normal)
  4. Blastorb_Gigante (1.85x - Normal)
  5. Blastorb_Dourada_SuperRara (2.25x - Platina-Ouro + Base Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Esfera facetada limpa em dois hemisférios exatos com sobrancelhas arqueadas e sorrisão largo
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base alinhada exatamente em `Z = 0.0` e rosto/sorriso apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "top_white": (0.95, 0.96, 0.98, 1.0),
        "bottom_red": (0.88, 0.28, 0.28, 1.0),
        "teeth_white": (0.99, 0.99, 1.00, 1.0),
        "seam_dark": (0.11, 0.12, 0.15, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "shiny_palette": {
        "top_white": (0.96, 0.97, 0.99, 1.0),
        "bottom_red": (0.20, 0.46, 0.94, 1.0),
        "teeth_white": (0.99, 0.99, 1.00, 1.0),
        "seam_dark": (0.10, 0.12, 0.18, 1.0),
        "eye_dark": (0.10, 0.11, 0.16, 1.0),
    },
    "golden_super_rare_palette": {
        "top_white": (1.00, 0.95, 0.72, 1.0),
        "bottom_red": (0.98, 0.78, 0.14, 1.0),
        "teeth_white": (0.10, 0.92, 1.00, 1.0),
        "seam_dark": (0.44, 0.30, 0.05, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_faceted_hemisphere(
    parts: list,
    prefix: str,
    center_z: float,
    radius: float,
    is_upper: bool,
    mat_prefix: str,
    mat_key: str,
    pal: dict,
    ring_verts: int = 16,
):
    """Constrói um hemisfério facetado limpo por faixas latitudinais de cones (zero z-fighting)."""
    lat_degs = [0.0, 18.0, 36.0, 54.0, 72.0, 90.0]
    sign = 1.0 if is_upper else -1.0
    for i in range(len(lat_degs) - 1):
        a0 = math.radians(lat_degs[i])
        a1 = math.radians(lat_degs[i + 1])
        r0 = radius * math.cos(a0)
        r1 = max(0.015, radius * math.cos(a1))
        z0 = center_z + sign * radius * math.sin(a0)
        z1 = center_z + sign * radius * math.sin(a1)
        if is_upper:
            rb, rt = r0, r1
            dep = z1 - z0
        else:
            rb, rt = r1, r0
            dep = z0 - z1
        zc = (z0 + z1) * 0.5
        _add_part(
            parts,
            create_cone(f"_tmp_{prefix}_band_{i}", ring_verts, rb, rt, dep, (0.0, 0.0, zc)),
            mat_prefix,
            mat_key,
            pal,
        )


def build_blastorb(
    name: str = "Blastorb_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel do 101. Blastorb (Ref: Electrode):
      - Esfera maior com cores invertidas (metade superior branca e inferior vermelha/azul na Shiny)
      - Linha equatorial escura bem marcada abaixo dos olhos
      - Sobrancelhas arqueadas em "M/V" expressivas + olhinhos verticais escuros
      - Enorme sorriso confiante em arco branco na metade inferior com divisórias de dentes
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Blastorb_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Blastorb_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Blastorb_Norm"

    parts = []
    radius = 1.04
    cz = radius

    # 1. HEMISFÉRIO SUPERIOR BRANCO + HEMISFÉRIO INFERIOR VERMELHO
    # Divisão ligeiramente abaixo do equador (cz - 0.10) para dar a testa ampla da referência!
    split_z = cz - 0.04
    _add_faceted_hemisphere(parts, "top", split_z, radius, True, mat_prefix, "top_white", pal, ring_verts=16)
    _add_faceted_hemisphere(parts, "bot", split_z, radius, False, mat_prefix, "bottom_red", pal, ring_verts=16)

    # 2. ANEL EQUATORIAL ESCURO
    _add_part(
        parts,
        create_cylinder("_tmp_equator_seam", 16, radius + 0.012, 0.036, (0.0, 0.0, split_z)),
        mat_prefix,
        "seam_dark",
        pal,
    )

    # 3. OLHOS VERTICAIS ESCUROS + SOBRANCELHAS ALTAS ARQUEADAS (EXPRESSÃO MAROTA DO ELECTRODE)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"

        # Olho pequeno oval vertical escuro na metade branca
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                1,
                0.068,
                (side * 0.28, -0.99, split_z + 0.24),
                scale=(0.56, 0.45, 1.55),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

        # Sobrancelha em dois segmentos formando o arco pontudo alto da referência
        # Segmento interno (subindo do centro para o pico)
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_in_{tag}",
                (0.32, 0.055, 0.048),
                (side * 0.22, -0.90, split_z + 0.56),
                rotation=(math.radians(-26.0), math.radians(side * -42.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "seam_dark",
            pal,
        )
        # Segmento externo (descendo do pico para a lateral)
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_out_{tag}",
                (0.28, 0.055, 0.048),
                (side * 0.44, -0.82, split_z + 0.54),
                rotation=(math.radians(-26.0), math.radians(side * 46.0), math.radians(side * -26.0)),
            ),
            mat_prefix,
            "seam_dark",
            pal,
        )

    # Pequeno vinco vertical entre as sobrancelhas
    _add_part(
        parts,
        create_cube(
            "_tmp_brow_crease",
            (0.038, 0.05, 0.14),
            (0.0, -0.94, split_z + 0.46),
            rotation=(math.radians(-24.0), 0.0, 0.0),
        ),
        mat_prefix,
        "seam_dark",
        pal,
    )

    # 4. ENORME SORRISO CONFIANTE DE DENTES BRANCOS NA METADE INFERIOR VERMELHA
    # Arco contínuo e unido curvando para cima nos cantos (sorrisão clássico do Electrode!)
    smile_segments = [
        # (x, y, z, width, height, rx_deg, ry_deg, rz_deg)
        (-0.46, -0.84, split_z - 0.24, 0.28, 0.14, 18.0, 26.0, 26.0),
        (-0.24, -0.94, split_z - 0.33, 0.30, 0.21, 22.0, 12.0, 14.0),
        (0.00, -0.97, split_z - 0.36, 0.32, 0.24, 24.0, 0.0, 0.0),
        (0.24, -0.94, split_z - 0.33, 0.30, 0.21, 22.0, -12.0, -14.0),
        (0.46, -0.84, split_z - 0.24, 0.28, 0.14, 18.0, -26.0, -26.0),
    ]
    for idx, (sx, sy, sz, sw, sh, rx_d, ry_d, rz_d) in enumerate(smile_segments):
        # Contorno escuro atrás dos dentes
        _add_part(
            parts,
            create_cube(
                f"_tmp_mouth_bg_{idx}",
                (sw + 0.06, 0.07, sh + 0.06),
                (sx, sy + 0.015, sz),
                rotation=(math.radians(rx_d), math.radians(ry_d), math.radians(rz_d)),
            ),
            mat_prefix,
            "seam_dark",
            pal,
        )
        # Placa branca dos dentes
        _add_part(
            parts,
            create_cube(
                f"_tmp_mouth_teeth_{idx}",
                (sw + 0.02, 0.065, sh),
                (sx, sy - 0.015, sz),
                rotation=(math.radians(rx_d), math.radians(ry_d), math.radians(rz_d)),
            ),
            mat_prefix,
            "teeth_white",
            pal,
        )

    # Dois riscos verticais sutis dividindo os dentes na parte inferior do sorriso (como na arte!)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_tooth_line_{tag}",
                (0.030, 0.05, 0.11),
                (side * 0.16, -0.99, split_z - 0.39),
                rotation=(math.radians(24.0), 0.0, math.radians(side * -8.0)),
            ),
            mat_prefix,
            "seam_dark",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 101. Blastorb lado a lado."""
    specs = [
        ("Blastorb_Shiny", (-8.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Blastorb_Normal", (-4.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Blastorb_Grande", (-0.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Blastorb_Gigante", (4.7, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Blastorb_Dourada_SuperRara", (11.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_blastorb(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
