"""
062_Tidebrawler_Poliwrath_5Variacoes_Blender.py
===============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "062. Tidebrawler — Campeão Anfíbio (Ref: Poliwrath)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Tidebrawler_Shiny (1.0x - Paleta Shiny Sapo Verde-Esmeralda Vibrante + Luvas e Barriga Brancas)
  2. Tidebrawler_Normal (1.0x - Corpo Musculoso Largo Azul-Escuro + Olhar Furioso + Luvas Gigantes + Espiral)
  3. Tidebrawler_Grande (1.35x - Normal)
  4. Tidebrawler_Gigante (1.85x - Normal)
  5. Tidebrawler_Dourada_SuperRara (2.25x - Ouro Reluzente + Espiral, Olhos e Luvas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + ombros musculosos largos + espiral 3D nítida)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés largos em base atlética alinhados exatamente em `Z = 0.0` e rosto/espiral apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.26, 0.48, 0.78, 1.0),
        "body_dark": (0.19, 0.37, 0.65, 1.0),
        "glove_white": (0.94, 0.96, 0.99, 1.0),
        "belly_white": (0.97, 0.98, 1.00, 1.0),
        "spiral_black": (0.10, 0.11, 0.14, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.34, 0.74, 0.36, 1.0),
        "body_dark": (0.24, 0.56, 0.26, 1.0),
        "glove_white": (0.95, 0.98, 0.96, 1.0),
        "belly_white": (0.98, 0.99, 0.98, 1.0),
        "spiral_black": (0.10, 0.12, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.98, 0.78, 0.14, 1.0),
        "body_dark": (0.86, 0.62, 0.09, 1.0),
        "glove_white": (0.10, 0.92, 1.00, 1.0),
        "belly_white": (1.00, 0.96, 0.76, 1.0),
        "spiral_black": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_belly_spiral(
    parts: list,
    mat_prefix: str,
    pal: dict,
    center_y: float,
    center_z: float,
    rx: float,
    ry: float,
    rz: float,
    max_r: float,
    turns: float = 2.85,
    direction: float = 1.0,
    tube_r: float = 0.044,
    steps: int = 42,
):
    """Esculpe a espiral preta em relevo 3D acompanhando perfeitamente o peitoral branco."""
    pts = []
    for i in range(steps + 1):
        t = i / float(steps)
        theta = t * turns * 2.0 * math.pi * direction + math.radians(20.0)
        r = max_r * (0.04 + 0.96 * t)
        x = r * math.cos(theta)
        z = center_z + r * math.sin(theta)
        u = x / rx
        w = (z - center_z) / rz
        inside = max(0.06, 1.0 - u * u - w * w)
        y = center_y - ry * math.sqrt(inside) - 0.018
        pts.append((x, y, z))

    for idx in range(len(pts) - 1):
        p0, p1 = pts[idx], pts[idx + 1]
        dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
        dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        if dist < 1e-5:
            continue
        mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
        horiz = math.sqrt(dx * dx + dy * dy)
        rot_x = math.atan2(horiz, dz)
        rot_z = math.atan2(dx, -dy)
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_spiral_{idx}",
                6,
                tube_r,
                dist + tube_r * 0.8,
                mid,
                rotation=(rot_x, 0.0, rot_z),
            ),
            mat_prefix,
            "spiral_black",
            pal,
        )


def build_tidebrawler(
    name: str = "Tidebrawler_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 062. Tidebrawler (Ref: Poliwrath):
      - Tronco largo, atarracado e musculoso azul-escuro com trapézios e ombros poderosos
      - Olhos saltados com pálpebras pesadas zangadas em V e pupilas ferozes + 2 narinas
      - Grande barriga branca em escudo com espiral preta grossa em relevo 3D
      - Braços super musculosos curvados em guarda de luta com luvas de boxe gigantes brancas
      - Pernas robustas em base larga atlética apoiadas solidamente em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Tide_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Tide_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Tide_Norm"

    parts = []

    # 1. TRONCO LARGO E MUSCULOSO + TRAPÉZIOS PODEROSOS
    _add_part(
        parts,
        create_icosphere("_tmp_body", 2, 1.02, (0.0, 0.02, 1.32), scale=(1.14, 0.94, 0.94)),
        mat_prefix,
        "body_blue",
        pal,
    )
    # Trapézios e ombros largos (diferença chave de silhueta em relação ao Poliwhirl!)
    _add_part(
        parts,
        create_icosphere("_tmp_traps", 2, 0.88, (0.0, 0.04, 1.68), scale=(1.26, 0.82, 0.56)),
        mat_prefix,
        "body_blue",
        pal,
    )

    # 2. OLHOS SALTADOS COM SOBRANCELHAS GROSSAS FURIOSAS EM V + NARINAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Cúpula superior do olho
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_dome_{tag}",
                2,
                0.32,
                (side * 0.44, -0.34, 2.08),
                scale=(1.06, 0.98, 0.96),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Esclera branca
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.24,
                (side * 0.44, -0.58, 2.04),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(1.06, 0.46, 0.92),
            ),
            mat_prefix,
            "belly_white",
            pal,
        )
        # Pálpebra pesada zangada azul cobrindo o topo do olho em ângulo furioso em V
        _add_part(
            parts,
            create_cube(
                f"_tmp_eyelid_{tag}",
                (0.46, 0.24, 0.16),
                (side * 0.43, -0.58, 2.18),
                rotation=(math.radians(10.0), math.radians(side * -24.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "body_dark",
            pal,
        )
        # Pupila pequena e intensa focada à frente
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.068,
                (side * 0.42, -0.68, 2.03),
                scale=(0.68, 0.45, 1.12),
            ),
            mat_prefix,
            "spiral_black",
            pal,
        )
        # Narina
        _add_part(
            parts,
            create_icosphere(f"_tmp_nostril_{tag}", 1, 0.032, (side * 0.10, -0.86, 1.92)),
            mat_prefix,
            "spiral_black",
            pal,
        )

    # 3. BARRIGA BRANCA LARGA + ESPIRAL PRETA GROSSA EM RELEVO 3D
    belly_cy, belly_cz = -0.40, 1.24
    belly_rx, belly_ry, belly_rz = 0.80, 0.62, 0.68
    _add_part(
        parts,
        create_icosphere(
            "_tmp_belly",
            2,
            1.0,
            (0.0, belly_cy, belly_cz),
            scale=(belly_rx, belly_ry, belly_rz),
        ),
        mat_prefix,
        "belly_white",
        pal,
    )
    _add_belly_spiral(
        parts,
        mat_prefix,
        pal,
        center_y=belly_cy,
        center_z=belly_cz,
        rx=belly_rx,
        ry=belly_ry,
        rz=belly_rz,
        max_r=0.58,
        turns=2.85,
        direction=1.0,
        tube_r=0.046,
        steps=44,
    )

    # 4. BRAÇOS SUPER MUSCULOSOS + LUVAS DE BOXE GIGANTES EM POSTURA DE LUTADOR
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Ombro/deltoide maciço
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_shoulder_{tag}",
                2,
                0.38,
                (side * 1.06, -0.02, 1.56),
                scale=(1.10, 0.94, 0.98),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Bíceps grosso descendo para o lado
        _add_part(
            parts,
            create_cone(
                f"_tmp_bicep_{tag}",
                8,
                0.30,
                0.24,
                0.68,
                (side * 1.38, -0.10, 1.32),
                rotation=(math.radians(-16.0), math.radians(side * 124.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Cotovelo musculoso
        _add_part(
            parts,
            create_icosphere(f"_tmp_elbow_{tag}", 2, 0.25, (side * 1.62, -0.18, 1.12)),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Antebraço trazendo o punho à frente em guarda
        _add_part(
            parts,
            create_cone(
                f"_tmp_forearm_{tag}",
                8,
                0.25,
                0.22,
                0.44,
                (side * 1.68, -0.36, 1.20),
                rotation=(math.radians(74.0), math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Luva de boxe gigante branca + polegar cerrado para frente
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_glove_{tag}",
                2,
                0.46,
                (side * 1.72, -0.62, 1.28),
                rotation=(0.0, 0.0, math.radians(side * -12.0)),
                scale=(1.04, 1.10, 0.98),
            ),
            mat_prefix,
            "glove_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thumb_{tag}",
                2,
                0.22,
                (side * 1.48, -0.84, 1.38),
                scale=(0.95, 1.05, 0.88),
            ),
            mat_prefix,
            "glove_white",
            pal,
        )

    # 5. PERNAS ROBUSTAS EM BASE LARGA ATLÉTICA + PÉS LARGOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa grossa aberta para estabilidade de combate
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_{tag}",
                8,
                0.26,
                0.22,
                0.62,
                (side * 0.68, -0.02, 0.44),
                rotation=(math.radians(6.0), math.radians(side * 24.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Pé largo e plano apoiado em Z = 0.0
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.30,
                (side * 0.82, -0.18, 0.14),
                rotation=(0.0, 0.0, math.radians(side * -22.0)),
                scale=(1.18, 1.38, 0.50),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 062. Tidebrawler lado a lado."""
    specs = [
        ("Tidebrawler_Shiny", (-14.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Tidebrawler_Normal", (-7.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Tidebrawler_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Tidebrawler_Gigante", (8.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Tidebrawler_Dourada_SuperRara", (19.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_tidebrawler(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
