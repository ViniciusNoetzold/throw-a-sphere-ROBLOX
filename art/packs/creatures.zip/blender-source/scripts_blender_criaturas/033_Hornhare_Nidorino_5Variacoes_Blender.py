"""
033_Hornhare_Nidorino_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "033. Hornhare — Fera Chifruda Roxa (Ref: Nidorino)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Hornhare_Shiny (1.0x - Paleta Shiny / Shyne Azul-Cobalto + Manchas Azul-Marinho)
  2. Hornhare_Normal (1.0x - Roxo-Ameixa + Grande Chifre Marfim + 6 Espinhos Dorsais + Olhos Rubi)
  3. Hornhare_Grande (1.35x - Normal)
  4. Hornhare_Gigante (1.85x - Normal)
  5. Hornhare_Dourada_SuperRara (2.25x - Ouro Reluzente + Orelhas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.017`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e frente/chifre apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Hornhare_Shiny`, `Hornhare_Normal`, `Hornhare_Grande`,
     `Hornhare_Gigante`, `Hornhare_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.017,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_plum": (0.68, 0.42, 0.74, 1.0),
        "spot_dark": (0.44, 0.22, 0.50, 1.0),
        "horn_ivory": (0.95, 0.94, 0.90, 1.0),
        "ear_teal": (0.34, 0.66, 0.64, 1.0),
        "eye_ruby": (0.88, 0.20, 0.24, 1.0),
    },
    "shiny_palette": {
        "body_plum": (0.38, 0.68, 0.90, 1.0),
        "spot_dark": (0.20, 0.42, 0.66, 1.0),
        "horn_ivory": (0.97, 0.97, 0.94, 1.0),
        "ear_teal": (0.26, 0.54, 0.72, 1.0),
        "eye_ruby": (0.88, 0.22, 0.26, 1.0),
    },
    "golden_super_rare_palette": {
        "body_plum": (0.98, 0.78, 0.14, 1.0),
        "spot_dark": (0.82, 0.54, 0.08, 1.0),
        "horn_ivory": (1.00, 0.99, 0.90, 1.0),
        "ear_teal": (0.10, 0.92, 1.00, 1.0),
        "eye_ruby": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base das patas em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_hornhare(
    name: str = "Hornhare_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 033. Hornhare (Ref: Nidorino):
      - Frente/chifre longo apontando para -Y e 4 patas musculosas em Z = 0.0
      - Quadrúpede roxo-ameixa forte com manchas roxo-escuro e 6 grandes espinhos pontiagudos nas costas
      - Grande chifre afiado branco-marfim na testa, olhos rubi ferozes e orelhas longas com interior turquesa
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Horn_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Horn_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Horn_Norm"

    parts = []

    # 1. CORPO QUADRÚPEDE MUSCULOSO ROXO-AMEIXA + MANCHAS + 6 GRANDES ESPINHOS DORSAIS
    _add_part(
        parts,
        create_cube("_tmp_torso_main", (1.02, 1.48, 0.78), (0.0, 0.14, 0.68), rotation=(math.radians(-6.0), 0.0, 0.0)),
        mat_prefix,
        "body_plum",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_rump", 1, 0.56, (0.0, 0.68, 0.66), scale=(0.94, 0.98, 0.88)),
        mat_prefix,
        "body_plum",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_spot_1_{tag}", (0.14, 0.28, 0.24), (side * 0.52, 0.08, 0.78)),
            mat_prefix,
            "spot_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_spot_2_{tag}", (0.14, 0.24, 0.20), (side * 0.52, 0.52, 0.64)),
            mat_prefix,
            "spot_dark",
            pal,
        )

    # 6 grandes espinhos pontiagudos formando crista dorsal feroz
    spine_specs = [
        ((0.0, -0.34, 1.42), (-8.0, 0.0, 45.0), 0.14, 0.52),
        ((0.0, -0.06, 1.50), (-16.0, 0.0, 45.0), 0.17, 0.68),
        ((-0.22, 0.22, 1.40), (-26.0, -14.0, 45.0), 0.15, 0.62),
        ((0.22, 0.22, 1.40), (-26.0, 14.0, 45.0), 0.15, 0.62),
        ((0.0, 0.50, 1.38), (-36.0, 0.0, 45.0), 0.16, 0.64),
        ((0.0, 0.82, 1.18), (-54.0, 0.0, 45.0), 0.15, 0.54),
    ]
    for s_idx, (loc, rot, rad, depth) in enumerate(spine_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_dorsal_spine_{s_idx}",
                4,
                rad,
                0.02,
                depth,
                loc,
                rotation=tuple(math.radians(a) for a in rot),
            ),
            mat_prefix,
            "body_plum",
            pal,
        )

    # 2. CABEÇA FEROZ, GRANDE CHIFRE AFIADO MARFIM, OLHOS RUBI E ORELHAS LONGAS
    _add_part(
        parts,
        create_cube("_tmp_head_main", (0.90, 0.86, 0.68), (0.0, -0.68, 0.88), rotation=(math.radians(8.0), 0.0, 0.0)),
        mat_prefix,
        "body_plum",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            4,
            0.30,
            0.14,
            0.44,
            (0.0, -1.24, 0.80),
            rotation=(math.radians(98.0), 0.0, math.radians(45.0)),
            scale=(1.12, 0.78, 1.0),
        ),
        mat_prefix,
        "body_plum",
        pal,
    )
    # Grande chifre afiado branco-marfim (assinatura do Nidorino)
    _add_part(
        parts,
        create_cone(
            "_tmp_horn_main",
            5,
            0.16,
            0.02,
            0.76,
            (0.0, -1.32, 1.18),
            rotation=(math.radians(70.0), 0.0, 0.0),
        ),
        mat_prefix,
        "horn_ivory",
        pal,
    )

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.052,
                0.01,
                0.18,
                (side * 0.22, -1.20, 0.64),
                rotation=(math.radians(180.0), 0.0, 0.0),
            ),
            mat_prefix,
            "horn_ivory",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_white_{tag}", (0.16, 0.26, 0.20), (side * 0.36, -1.04, 0.94)),
            mat_prefix,
            "horn_ivory",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_ruby_{tag}", (0.16, 0.15, 0.16), (side * 0.38, -1.10, 0.94)),
            mat_prefix,
            "eye_ruby",
            pal,
        )
        # Grandes orelhas longas e pontudas com interior turquesa
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_outer_{tag}",
                4,
                0.38,
                0.05,
                1.22,
                (side * 0.56, -0.44, 1.62),
                rotation=(math.radians(-16.0), math.radians(side * 26.0), math.radians(45.0)),
                scale=(1.15, 0.44, 1.0),
            ),
            mat_prefix,
            "body_plum",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_teal_{tag}",
                4,
                0.26,
                0.04,
                0.88,
                (side * 0.56, -0.51, 1.58),
                rotation=(math.radians(-16.0), math.radians(side * 26.0), math.radians(45.0)),
                scale=(1.04, 0.34, 1.0),
            ),
            mat_prefix,
            "ear_teal",
            pal,
        )

    # 3. QUATRO PATAS MUSCULOSAS COM 3 GARRAS MARFIM EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_front_leg_{tag}", (0.36, 0.40, 0.56), (side * 0.48, -0.40, 0.28)),
            mat_prefix,
            "body_plum",
            pal,
        )
        for c_idx, dx in enumerate((-0.10, 0.0, 0.10)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_front_claw_{tag}_{c_idx}",
                    4,
                    0.055,
                    0.012,
                    0.18,
                    (side * 0.48 + dx, -0.66, 0.065),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "horn_ivory",
                pal,
            )

        _add_part(
            parts,
            create_cube(f"_tmp_back_leg_{tag}", (0.38, 0.46, 0.52), (side * 0.50, 0.60, 0.26)),
            mat_prefix,
            "body_plum",
            pal,
        )
        for c_idx, dx in enumerate((-0.10, 0.0, 0.10)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_back_claw_{tag}_{c_idx}",
                    4,
                    0.055,
                    0.012,
                    0.18,
                    (side * 0.50 + dx, 0.32, 0.065),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "horn_ivory",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 033. Hornhare lado a lado."""
    specs = [
        ("Hornhare_Shiny", (-7.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Hornhare_Normal", (-4.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Hornhare_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Hornhare_Gigante", (4.1, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Hornhare_Dourada_SuperRara", (10.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_hornhare(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
