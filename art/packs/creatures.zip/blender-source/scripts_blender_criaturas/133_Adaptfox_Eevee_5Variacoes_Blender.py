"""
133_Adaptfox_Eevee_5Variacoes_Blender.py
========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "133. Adaptfox — Raposa Evolutiva (Ref: Eevee)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Adaptfox_Shiny (1.0x - Paleta Shiny Clássica Raposa Prata-Neve + Gola Branca)
  2. Adaptfox_Normal (1.0x - Raposinha Caramelo + Grande Gola Creme + Orelhas Longas + Cauda Fofa)
  3. Adaptfox_Grande (1.35x - Normal)
  4. Adaptfox_Gigante (1.85x - Normal)
  5. Adaptfox_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Interior das Orelhas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para cabeça e gola fofa, cones 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e rosto adorável apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "fur_brown": (0.76, 0.54, 0.34, 1.0),
        "fur_shade": (0.62, 0.42, 0.25, 1.0),
        "ruff_cream": (0.95, 0.90, 0.74, 1.0),
        "ear_inner": (0.36, 0.21, 0.12, 1.0),
        "eye_dark": (0.12, 0.08, 0.07, 1.0),
        "eye_iris": (0.50, 0.30, 0.14, 1.0),
        "eye_shine": (0.99, 0.99, 1.00, 1.0),
        "nose_black": (0.11, 0.09, 0.09, 1.0),
    },
    "shiny_palette": {
        "fur_brown": (0.87, 0.87, 0.90, 1.0),
        "fur_shade": (0.70, 0.71, 0.76, 1.0),
        "ruff_cream": (0.99, 0.99, 1.00, 1.0),
        "ear_inner": (0.30, 0.28, 0.34, 1.0),
        "eye_dark": (0.11, 0.10, 0.12, 1.0),
        "eye_iris": (0.44, 0.34, 0.36, 1.0),
        "eye_shine": (1.00, 1.00, 1.00, 1.0),
        "nose_black": (0.12, 0.11, 0.13, 1.0),
    },
    "golden_super_rare_palette": {
        "fur_brown": (0.98, 0.78, 0.14, 1.0),
        "fur_shade": (0.82, 0.58, 0.08, 1.0),
        "ruff_cream": (1.00, 0.94, 0.56, 1.0),
        "ear_inner": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.06, 0.52, 0.68, 1.0),
        "eye_iris": (0.10, 0.92, 1.00, 1.0),
        "eye_shine": (1.00, 1.00, 0.94, 1.0),
        "nose_black": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_adaptfox(
    name: str = "Adaptfox_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 133. Adaptfox (Ref: Eevee):
      - Corpo compacto quadrúpede caramelo com 4 patinhas delicadas apoiadas em Z = 0.0
      - Grande colar de pelo fofo creme em tufos volumosos envolvendo todo o pescoço e peito
      - Cabeça fofa com topete espetadinho, olhos grandes ovais com brilho branco e sorriso doce
      - 2 orelhas longas e largas pontudas em formato de folha com interior marrom-escuro
      - Cauda enorme fofa marrom erguida para o lado direito com ponta creme pontuda
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Fox_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Fox_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Fox_Norm"

    parts = []

    # 1. CORPO QUADRÚPEDE COMPACTO + 4 PATINHAS FOFAS APOIADAS EM Z = 0.0
    _add_part(
        parts,
        create_icosphere("_tmp_body", 2, 0.44, (0.0, 0.14, 0.72), scale=(0.88, 1.34, 0.88)),
        mat_prefix,
        "fur_brown",
        pal,
    )
    leg_specs = [
        ("FL", -0.22, -0.26, False),
        ("FR", 0.22, -0.26, False),
        ("BL", -0.26, 0.50, True),
        ("BR", 0.26, 0.50, True),
    ]
    for tag, lx, ly, is_back in leg_specs:
        if is_back:
            _add_part(
                parts,
                create_icosphere(f"_tmp_thigh_{tag}", 2, 0.22, (lx, ly, 0.52), scale=(0.86, 1.08, 1.12)),
                mat_prefix,
                "fur_brown",
                pal,
            )
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_{tag}",
                7,
                0.105,
                0.14,
                0.56,
                (lx, ly, 0.30),
                rotation=(math.radians(4.0 if not is_back else -6.0), 0.0, 0.0),
            ),
            mat_prefix,
            "fur_shade" if is_back else "fur_brown",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_paw_{tag}",
                2,
                0.125,
                (lx, ly - 0.05, 0.08),
                scale=(0.94, 1.24, 0.64),
            ),
            mat_prefix,
            "fur_brown",
            pal,
        )

    # 2. GRANDE COLAR DE PELO FOFO CREME AO REDOR DO PESCOÇO E PEITO
    ruff_puffs = [
        # (x, y, z, rad, scale)
        (0.00, -0.44, 0.90, 0.36, (1.16, 0.92, 1.02)),
        (-0.34, -0.34, 0.96, 0.31, (1.06, 0.94, 1.02)),
        (0.34, -0.34, 0.96, 0.31, (1.06, 0.94, 1.02)),
        (-0.46, -0.10, 1.00, 0.28, (0.98, 1.04, 0.96)),
        (0.46, -0.10, 1.00, 0.28, (0.98, 1.04, 0.96)),
        (-0.28, 0.16, 1.02, 0.27, (1.04, 0.96, 0.92)),
        (0.28, 0.16, 1.02, 0.27, (1.04, 0.96, 0.92)),
        (0.00, 0.22, 1.04, 0.28, (1.14, 0.94, 0.90)),
    ]
    for r_idx, (rx, ry, rz, rad, rsc) in enumerate(ruff_puffs):
        _add_part(
            parts,
            create_icosphere(f"_tmp_ruff_{r_idx}", 2, rad, (rx, ry, rz), scale=rsc),
            mat_prefix,
            "ruff_cream",
            pal,
        )
    # Pontas de pelo fofas apontando para baixo no peito (assinatura da gola do Eevee!)
    chest_tufts = [
        (0.00, -0.56, 0.62, 0.20, 0.36, 170.0, 0.0),
        (-0.32, -0.46, 0.72, 0.17, 0.30, 166.0, -24.0),
        (0.32, -0.46, 0.72, 0.17, 0.30, 166.0, 24.0),
    ]
    for t_idx, (tx, ty, tz, rad, dep, rx_d, ry_d) in enumerate(chest_tufts):
        _add_part(
            parts,
            create_cone(
                f"_tmp_ruff_tip_{t_idx}",
                6,
                rad,
                0.02,
                dep,
                (tx, ty, tz),
                rotation=(math.radians(rx_d), math.radians(ry_d), 0.0),
            ),
            mat_prefix,
            "ruff_cream",
            pal,
        )

    # 3. CABEÇA FOFA + TOPETE + OLHOS GRANDES EXPRESSIVOS + NARIZINHO
    hx, hy, hz = 0.0, -0.34, 1.44
    _add_part(
        parts,
        create_icosphere("_tmp_head_main", 2, 0.48, (hx, hy, hz), scale=(1.04, 0.96, 0.94)),
        mat_prefix,
        "fur_brown",
        pal,
    )
    # Bochechas macias e focinho curto fofo
    _add_part(
        parts,
        create_icosphere("_tmp_muzzle", 2, 0.22, (hx, hy - 0.38, hz - 0.10), scale=(1.12, 0.76, 0.66)),
        mat_prefix,
        "fur_brown",
        pal,
    )
    # Topete de 3 mechinhas espetadinhas no topo da testa
    for f_idx, (fx, fz, ry_d) in enumerate([(-0.12, 0.44, -18.0), (0.00, 0.48, 0.0), (0.12, 0.44, 18.0)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_forehead_tuft_{f_idx}",
                5,
                0.095,
                0.014,
                0.22,
                (hx + fx, hy - 0.08, hz + fz),
                rotation=(math.radians(-12.0), math.radians(ry_d), 0.0),
            ),
            mat_prefix,
            "fur_brown",
            pal,
        )

    # Olhos grandes ovais adoráveis com íris âmbar e brilho branco
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_dark_{tag}",
                2,
                0.13,
                (hx + side * 0.22, hy - 0.41, hz + 0.02),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(0.74, 0.44, 1.24),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.085,
                (hx + side * 0.22, hy - 0.45, hz - 0.04),
                scale=(0.72, 0.44, 0.88),
            ),
            mat_prefix,
            "eye_iris",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.046,
                (hx + side * 0.20, hy - 0.47, hz + 0.08),
                scale=(0.78, 0.50, 1.08),
            ),
            mat_prefix,
            "eye_shine",
            pal,
        )

    # Narizinho triangular preto + sorriso doce
    _add_part(
        parts,
        create_icosphere("_tmp_nose", 1, 0.042, (hx, hy - 0.54, hz - 0.06), scale=(1.15, 0.72, 0.68)),
        mat_prefix,
        "nose_black",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_smile_{tag}",
                (0.11, 0.032, 0.026),
                (hx + side * 0.06, hy - 0.53, hz - 0.14),
                rotation=(0.0, math.radians(side * -14.0), math.radians(side * -12.0)),
            ),
            mat_prefix,
            "nose_black",
            pal,
        )

    # 4. DUAS ORELHAS LONGAS PONTUDAS DE RAPOSA COM INTERIOR MARROM-ESCURO
    ear_specs = [
        ("L", -1.0, -34.0, -0.52, 2.08),
        ("R", 1.0, 44.0, 0.58, 2.02),
    ]
    for tag, side, ry_deg, ex, ez in ear_specs:
        # Parte externa caramelo em formato de folha longa
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ear_outer_{tag}",
                2,
                0.24,
                (ex, hy - 0.02, ez),
                rotation=(math.radians(-6.0), math.radians(ry_deg), 0.0),
                scale=(0.84, 0.34, 2.25),
            ),
            mat_prefix,
            "fur_brown",
            pal,
        )
        # Ponta bem definida da orelha
        tip_dx = math.sin(math.radians(ry_deg)) * 0.44
        tip_dz = math.cos(math.radians(ry_deg)) * 0.44
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_tip_{tag}",
                6,
                0.15,
                0.015,
                0.42,
                (ex + tip_dx, hy - 0.02, ez + tip_dz),
                rotation=(math.radians(-6.0), math.radians(ry_deg), 0.0),
                scale=(0.90, 0.36, 1.0),
            ),
            mat_prefix,
            "fur_brown",
            pal,
        )
        # Interior marrom-escuro bem visível de frente
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ear_inner_{tag}",
                2,
                0.18,
                (ex, hy - 0.08, ez),
                rotation=(math.radians(-6.0), math.radians(ry_deg), 0.0),
                scale=(0.74, 0.24, 2.05),
            ),
            mat_prefix,
            "ear_inner",
            pal,
        )

    # 5. CAUDA VOLUMOSA FOFA DE RAPOSA ERGUIDA PARA +X COM PONTA CREME EM ZIGUE-ZAGUE
    _add_part(
        parts,
        create_icosphere("_tmp_tail_root", 2, 0.24, (0.16, 0.62, 0.86), scale=(1.0, 1.10, 1.0)),
        mat_prefix,
        "fur_brown",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tail_body",
            2,
            0.46,
            (0.58, 0.64, 1.08),
            rotation=(math.radians(10.0), math.radians(34.0), 0.0),
            scale=(1.08, 0.90, 1.24),
        ),
        mat_prefix,
        "fur_brown",
        pal,
    )
    # Transição fofa creme + ponta pontuda curva no alto da cauda
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tail_tip_mid",
            2,
            0.34,
            (0.84, 0.62, 1.44),
            rotation=(math.radians(8.0), math.radians(24.0), 0.0),
            scale=(0.98, 0.84, 1.12),
        ),
        mat_prefix,
        "ruff_cream",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_tip_end",
            7,
            0.28,
            0.02,
            0.56,
            (0.96, 0.60, 1.78),
            rotation=(math.radians(6.0), math.radians(18.0), 0.0),
            scale=(0.95, 0.78, 1.0),
        ),
        mat_prefix,
        "ruff_cream",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 133. Adaptfox lado a lado."""
    specs = [
        ("Adaptfox_Shiny", (-8.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Adaptfox_Normal", (-4.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Adaptfox_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Adaptfox_Gigante", (4.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Adaptfox_Dourada_SuperRara", (11.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_adaptfox(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
