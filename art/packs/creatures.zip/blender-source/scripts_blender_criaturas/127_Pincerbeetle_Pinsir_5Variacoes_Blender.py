"""
127_Pincerbeetle_Pinsir_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "127. Pincerbeetle — Besouro Tenaz (Ref: Pinsir)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Pincerbeetle_Shiny (1.0x - Paleta Shiny Roxo-Violeta + Pinças Lavanda-Osso)
  2. Pincerbeetle_Normal (1.0x - Carapaça Marrom-Terra Segmentada + Pinças Gigantes Espinhosas)
  3. Pincerbeetle_Grande (1.35x - Normal)
  4. Pincerbeetle_Gigante (1.85x - Normal)
  5. Pincerbeetle_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Espinhos das Pinças Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para carapaça robusta, cones 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés alinhados exatamente em `Z = 0.0` e boca vertical / olhos ferozes apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_brown": (0.62, 0.53, 0.49, 1.0),
        "body_dark": (0.40, 0.33, 0.31, 1.0),
        "pincer_bone": (0.84, 0.83, 0.87, 1.0),
        "pincer_spike": (0.94, 0.94, 0.97, 1.0),
        "mouth_dark": (0.14, 0.13, 0.15, 1.0),
        "tooth_white": (0.97, 0.98, 1.00, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.09, 0.09, 0.11, 1.0),
    },
    "shiny_palette": {
        "body_brown": (0.56, 0.43, 0.78, 1.0),
        "body_dark": (0.36, 0.26, 0.56, 1.0),
        "pincer_bone": (0.88, 0.86, 0.95, 1.0),
        "pincer_spike": (0.96, 0.95, 1.00, 1.0),
        "mouth_dark": (0.15, 0.12, 0.20, 1.0),
        "tooth_white": (0.97, 0.98, 1.00, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.09, 0.09, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "body_brown": (0.98, 0.78, 0.14, 1.0),
        "body_dark": (0.76, 0.54, 0.08, 1.0),
        "pincer_bone": (1.00, 0.92, 0.48, 1.0),
        "pincer_spike": (0.10, 0.92, 1.00, 1.0),
        "mouth_dark": (0.34, 0.22, 0.04, 1.0),
        "tooth_white": (1.00, 0.99, 0.90, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.42, 0.58, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_pincerbeetle(
    name: str = "Pincerbeetle_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 127. Pincerbeetle (Ref: Pinsir):
      - Carapaça oval robusta marrom-terra com 3 anéis de segmentação escura no abdômen
      - 2 enormes pinças cinza-osso curvadas para cima/dentro no topo da cabeça cheias de espinhos
      - Olhos triangulares brancos ferozes e boca vertical oval com 5 pares de dentes horizontais brancos
      - Braços articulados de inseto erguidos em pose de combate com 3 garras claras cada
      - Pernas grossas arredondadas apoiadas em Z = 0.0 com 3 garras largas achatadas por pé
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Pincer_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Pincer_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Pincer_Norm"

    parts = []

    # 1. CORPO OVAL ROBUSTO DE BESOURO + SEGMENTOS ESCUROS NO ABDÔMEN
    _add_part(
        parts,
        create_icosphere("_tmp_body_egg", 2, 0.80, (0.0, 0.02, 1.18), scale=(0.94, 0.88, 1.18)),
        mat_prefix,
        "body_brown",
        pal,
    )
    # 3 sulcos horizontais de segmentação da carapaça
    seg_specs = [
        (0.96, 0.75, 0.70),
        (0.76, 0.72, 0.67),
        (0.56, 0.64, 0.59),
    ]
    for s_idx, (sz, rx, ry) in enumerate(seg_specs):
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_body_groove_{s_idx}",
                12,
                rx,
                0.045,
                (0.0, 0.02, sz),
                scale=(1.0, ry / rx, 1.0),
            ),
            mat_prefix,
            "body_dark",
            pal,
        )

    # 2. DUAS ENORMES PINÇAS CURVAS CINZA-OSSO CHEIAS DE ESPINHOS NO TOPO DA CABEÇA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Base grossa da pinça saindo do topo lateral da cabeça
        _add_part(
            parts,
            create_cone(
                f"_tmp_pincer_s1_{tag}",
                8,
                0.28,
                0.26,
                0.56,
                (side * 0.56, -0.02, 2.04),
                rotation=(math.radians(-6.0), math.radians(side * 34.0), 0.0),
                scale=(1.0, 0.78, 1.0),
            ),
            mat_prefix,
            "pincer_bone",
            pal,
        )
        # Meio da pinça subindo quase vertical
        _add_part(
            parts,
            create_cone(
                f"_tmp_pincer_s2_{tag}",
                8,
                0.26,
                0.21,
                0.62,
                (side * 0.70, -0.04, 2.52),
                rotation=(math.radians(-6.0), math.radians(side * 4.0), 0.0),
                scale=(1.0, 0.76, 1.0),
            ),
            mat_prefix,
            "pincer_bone",
            pal,
        )
        # Ponta da pinça curvando agressivamente para dentro
        _add_part(
            parts,
            create_cone(
                f"_tmp_pincer_s3_{tag}",
                8,
                0.21,
                0.025,
                0.66,
                (side * 0.54, -0.06, 3.04),
                rotation=(math.radians(-6.0), math.radians(side * -34.0), 0.0),
                scale=(1.0, 0.72, 1.0),
            ),
            mat_prefix,
            "pincer_bone",
            pal,
        )
        # Espinhos cônicos ao longo das bordas internas e externas das pinças
        spike_specs = [
            # (x, y, z, ry_deg, rad, depth)
            (side * 0.36, -0.06, 2.16, side * -62.0, 0.075, 0.22),
            (side * 0.44, -0.08, 2.56, side * -86.0, 0.075, 0.22),
            (side * 0.34, -0.09, 2.94, side * -112.0, 0.065, 0.19),
            (side * 0.90, -0.04, 2.48, side * 84.0, 0.072, 0.20),
            (side * 0.74, -0.06, 2.96, side * 52.0, 0.065, 0.18),
        ]
        for sp_idx, (sx, sy, sz, sry, srad, sdep) in enumerate(spike_specs):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_pincer_spike_{tag}_{sp_idx}",
                    5,
                    srad,
                    0.014,
                    sdep,
                    (sx, sy, sz),
                    rotation=(0.0, math.radians(sry), 0.0),
                ),
                mat_prefix,
                "pincer_spike",
                pal,
            )

    # 3. ROSTO FEROZ: OLHOS TRIANGULARES BRANCOS + BOCA VERTICAL COM DENTES EM GRADE
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_eye_{tag}",
                4,
                0.18,
                0.02,
                0.28,
                (side * 0.28, -0.60, 1.66),
                rotation=(math.radians(82.0), math.radians(side * 126.0), math.radians(side * 18.0)),
                scale=(1.15, 0.42, 0.95),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.045,
                (side * 0.24, -0.67, 1.62),
                scale=(0.75, 0.55, 1.15),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # Cavidade vertical escura da boca
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_cavity",
            2,
            0.34,
            (0.0, -0.66, 1.18),
            scale=(0.82, 0.34, 1.14),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )
    # 5 pares de dentes brancos horizontais alinhados como zíper/pinça vertical
    tooth_rows = [1.42, 1.30, 1.18, 1.06, 0.94]
    for r_idx, tz in enumerate(tooth_rows):
        row_w = 0.17 if r_idx in (1, 2, 3) else 0.13
        for side in (-1.0, 1.0):
            tag = "L" if side < 0 else "R"
            _add_part(
                parts,
                create_cube(
                    f"_tmp_tooth_{tag}_{r_idx}",
                    (row_w, 0.08, 0.072),
                    (side * (row_w * 0.62 + 0.015), -0.76, tz),
                    rotation=(0.0, math.radians(side * -6.0), math.radians(side * -14.0)),
                ),
                mat_prefix,
                "tooth_white",
                pal,
            )

    # 4. BRAÇOS ARTICULADOS ERGUIDOS EM POSE DE COMBATE + MÃOS COM 3 GARRAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Bulbo do ombro
        _add_part(
            parts,
            create_icosphere(f"_tmp_shoulder_{tag}", 2, 0.25, (side * 0.78, -0.02, 1.24), scale=(1.08, 0.92, 0.92)),
            mat_prefix,
            "body_brown",
            pal,
        )
        # Braço superior fino saindo para fora
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_upper_arm_{tag}",
                7,
                0.085,
                0.56,
                (side * 1.08, -0.08, 1.28),
                rotation=(math.radians(-6.0), math.radians(side * 78.0), 0.0),
            ),
            mat_prefix,
            "body_brown",
            pal,
        )
        # Cotovelo articulado escuro
        _add_part(
            parts,
            create_icosphere(f"_tmp_elbow_{tag}", 1, 0.095, (side * 1.32, -0.10, 1.34)),
            mat_prefix,
            "body_dark",
            pal,
        )
        # Antebraço subindo alto
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_forearm_{tag}",
                7,
                0.09,
                0.68,
                (side * 1.44, -0.14, 1.66),
                rotation=(math.radians(8.0), math.radians(side * 18.0), 0.0),
            ),
            mat_prefix,
            "body_brown",
            pal,
        )
        # Mão larga arredondada
        hx, hy, hz = side * 1.54, -0.18, 2.02
        _add_part(
            parts,
            create_icosphere(f"_tmp_hand_{tag}", 2, 0.19, (hx, hy, hz), scale=(1.06, 0.84, 0.94)),
            mat_prefix,
            "body_brown",
            pal,
        )
        # 3 garras brancas-osso erguidas por mão
        for c_idx, (dx, dz, ry_deg) in enumerate([(-0.14, 0.14, -36.0), (0.0, 0.20, 0.0), (0.14, 0.14, 36.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{tag}_{c_idx}",
                    5,
                    0.062,
                    0.012,
                    0.20,
                    (hx + side * dx, hy - 0.03, hz + dz),
                    rotation=(math.radians(-8.0), math.radians(side * ry_deg), 0.0),
                ),
                mat_prefix,
                "pincer_spike",
                pal,
            )

    # 5. PERNAS GROSSAS ARREDONDADAS APOIADAS EM Z = 0.0 COM 3 GARRAS LARGAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_leg_upper_{tag}",
                2,
                0.36,
                (side * 0.56, -0.02, 0.52),
                scale=(1.02, 1.06, 0.98),
            ),
            mat_prefix,
            "body_brown",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.32,
                (side * 0.62, -0.10, 0.22),
                scale=(1.04, 1.18, 0.72),
            ),
            mat_prefix,
            "body_brown",
            pal,
        )
        # 3 garras largas achatadas cinza-osso no pé
        toe_specs = [
            (-0.16, -0.34, 0.12, -26.0),
            (0.00, -0.40, 0.12, 0.0),
            (0.16, -0.34, 0.12, 26.0),
        ]
        for t_idx, (dx, dy, tz, rz_deg) in enumerate(toe_specs):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_toe_{tag}_{t_idx}",
                    1,
                    0.11,
                    (side * 0.62 + dx, dy, tz),
                    rotation=(0.0, 0.0, math.radians(rz_deg)),
                    scale=(0.76, 1.32, 0.48),
                ),
                mat_prefix,
                "pincer_bone",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 127. Pincerbeetle lado a lado."""
    specs = [
        ("Pincerbeetle_Shiny", (-10.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Pincerbeetle_Normal", (-6.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Pincerbeetle_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Pincerbeetle_Gigante", (5.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Pincerbeetle_Dourada_SuperRara", (14.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_pincerbeetle(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
