"""
118_Fingold_Goldeen_5Variacoes_Blender.py
=========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "118. Fingold — Peixe Real (Ref: Goldeen)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Fingold_Shiny (1.0x - Paleta Shiny Branco-Pérola + Manchas Dourado-Âmbar)
  2. Fingold_Normal (1.0x - Branco-Pérola + Manchas Laranja-Coral + Chifre Marfim + Véus Ondulados)
  3. Fingold_Grande (1.35x - Normal)
  4. Fingold_Gigante (1.85x - Normal)
  5. Fingold_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Chifre Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para corpo e véus fluídos; cones 6-8 lados para chifre e nadadeiras)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base das nadadeiras/ventre alinhada em `Z = 0.0` e rosto/lábios apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_white": (0.97, 0.97, 0.99, 1.0),
        "fin_pearl": (0.91, 0.92, 0.97, 1.0),
        "coral_orange": (0.94, 0.36, 0.20, 1.0),
        "horn_ivory": (0.92, 0.88, 0.78, 1.0),
        "lip_pink": (0.96, 0.62, 0.72, 1.0),
        "mouth_dark": (0.48, 0.18, 0.28, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_teal": (0.14, 0.64, 0.66, 1.0),
        "eye_dark": (0.08, 0.12, 0.18, 1.0),
    },
    "shiny_palette": {
        "body_white": (0.99, 0.98, 0.95, 1.0),
        "fin_pearl": (0.96, 0.93, 0.86, 1.0),
        "coral_orange": (0.98, 0.68, 0.16, 1.0),
        "horn_ivory": (0.96, 0.92, 0.80, 1.0),
        "lip_pink": (0.98, 0.68, 0.74, 1.0),
        "mouth_dark": (0.50, 0.22, 0.28, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_teal": (0.18, 0.72, 0.68, 1.0),
        "eye_dark": (0.08, 0.12, 0.18, 1.0),
    },
    "golden_super_rare_palette": {
        "body_white": (0.98, 0.78, 0.14, 1.0),
        "fin_pearl": (1.00, 0.90, 0.44, 1.0),
        "coral_orange": (0.86, 0.56, 0.06, 1.0),
        "horn_ivory": (0.10, 0.92, 1.00, 1.0),
        "lip_pink": (1.00, 0.86, 0.36, 1.0),
        "mouth_dark": (0.54, 0.34, 0.04, 1.0),
        "eye_white": (1.00, 0.99, 0.90, 1.0),
        "eye_teal": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.04, 0.42, 0.58, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_fingold(
    name: str = "Fingold_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de 118. Fingold (Ref: Goldeen):
      - Corpo arredondado branco-pérola com mancha dorsal laranja-coral em coroa no topo
      - Chifre marfim cônico liso projetado na testa para cima e frente
      - Olhos grandes expressivos azul-turquesa com pálpebra superior laranja-coral e brilho branco
      - Lábios rosados arredondados em formato de beijo na frente (-Y)
      - Nadadeiras peitorais largas em véu ondulado abertas nas laterais (base laranja, véu branco)
      - Crista dorsal ondulada e grande cauda ornamental em véu duplo esvoaçante abrindo atrás
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Fgd_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Fgd_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Fgd_Norm"

    parts = []

    # 1. CORPO ARREDONDADO DE PEIXE REAL + MANCHA CORAL NO TOPO E DORSO
    _add_part(
        parts,
        create_icosphere(
            "_tmp_body_main",
            2,
            0.70,
            (0.0, -0.02, 0.88),
            scale=(0.94, 1.12, 0.90),
        ),
        mat_prefix,
        "body_white",
        pal,
    )
    # Mancha coral elegante no topo da testa e dorso
    _add_part(
        parts,
        create_icosphere(
            "_tmp_crown_patch",
            2,
            0.59,
            (0.0, -0.04, 1.18),
            scale=(0.98, 1.16, 0.56),
        ),
        mat_prefix,
        "coral_orange",
        pal,
    )
    # Pedúnculo da cauda afinando para trás (+Y)
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_stalk",
            8,
            0.40,
            0.18,
            0.64,
            (0.0, 0.72, 0.90),
            rotation=(math.radians(-84.0), 0.0, 0.0),
            scale=(0.76, 1.0, 1.0),
        ),
        mat_prefix,
        "coral_orange",
        pal,
    )

    # 2. CHIFRE MARFIM CÔNICO NA TESTA
    _add_part(
        parts,
        create_cone(
            "_tmp_horn",
            8,
            0.145,
            0.015,
            0.66,
            (0.0, -0.44, 1.66),
            rotation=(math.radians(26.0), 0.0, 0.0),
        ),
        mat_prefix,
        "horn_ivory",
        pal,
    )

    # 3. ROSTO CHARMOSO: OLHOS TURQUESA COM PÁLPEBRAS CORAL + LÁBIOS ROSAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Esclera branca
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.175,
                (side * 0.40, -0.56, 0.96),
                rotation=(0.0, 0.0, math.radians(side * -26.0)),
                scale=(0.82, 0.56, 1.02),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pálpebra superior laranja-coral curvada (assinatura da Goldeen!)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eyelid_{tag}",
                2,
                0.185,
                (side * 0.40, -0.57, 1.05),
                rotation=(math.radians(10.0), math.radians(side * 8.0), math.radians(side * -26.0)),
                scale=(0.90, 0.62, 0.54),
            ),
            mat_prefix,
            "coral_orange",
            pal,
        )
        # Íris azul-turquesa
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.095,
                (side * 0.43, -0.63, 0.94),
                scale=(0.76, 0.48, 0.94),
            ),
            mat_prefix,
            "eye_teal",
            pal,
        )
        # Pupila escura
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.052,
                (side * 0.44, -0.66, 0.94),
                scale=(0.72, 0.45, 0.90),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Brilho branco
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.028,
                (side * 0.41, -0.68, 0.97),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # Lábios rosados arredondados em biquinho na ponta frontal (-Y)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_lip_upper",
            2,
            0.16,
            (0.0, -0.80, 0.80),
            scale=(1.22, 0.62, 0.64),
        ),
        mat_prefix,
        "lip_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_lip_lower",
            2,
            0.145,
            (0.0, -0.79, 0.69),
            scale=(1.12, 0.58, 0.58),
        ),
        mat_prefix,
        "lip_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_inside",
            1,
            0.08,
            (0.0, -0.86, 0.74),
            scale=(0.98, 0.42, 0.56),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )

    # 4. NADADEIRAS PEITORAIS EM VÉU ONDULADO ABERTAS NAS LATERAIS (+/-X)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Base coral suave da nadadeira peitoral integrando no corpo
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pec_base_{tag}",
                2,
                0.24,
                (side * 0.68, -0.10, 0.64),
                rotation=(math.radians(14.0), math.radians(side * 118.0), math.radians(side * -14.0)),
                scale=(0.34, 0.86, 1.24),
            ),
            mat_prefix,
            "coral_orange",
            pal,
        )
        # Véu principal ondulado branco-pérola (3 lobos suaves formando saia fluída)
        pec_lobes = [
            (0.98, -0.16, 0.46, 18.0, 124.0, -24.0, 0.30, 0.54),
            (1.06, -0.02, 0.42, 12.0, 118.0, -10.0, 0.32, 0.62),
            (0.92, 0.12, 0.46, 8.0, 112.0, 8.0, 0.28, 0.52),
        ]
        for l_idx, (dx, dy, dz, rx, ry, rz, rad, dep) in enumerate(pec_lobes):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_pec_veil_{tag}_{l_idx}",
                    2,
                    rad,
                    (side * dx, dy, dz),
                    rotation=(math.radians(rx), math.radians(side * ry), math.radians(side * rz)),
                    scale=(0.30, 0.76, dep / rad * 0.72),
                ),
                mat_prefix,
                "fin_pearl",
                pal,
            )

    # 5. CRISTA DORSAL ONDULADA NO TOPO DAS COSTAS
    dorsal_lobes = [
        (0.18, 1.54, 0.24),
        (0.42, 1.58, 0.26),
        (0.64, 1.48, 0.23),
    ]
    for d_idx, (dy, dz, rad) in enumerate(dorsal_lobes):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_dorsal_{d_idx}",
                2,
                rad,
                (0.0, dy, dz),
                scale=(0.30, 0.96, 1.15),
            ),
            mat_prefix,
            "fin_pearl",
            pal,
        )

    # 6. GRANDE CAUDA ORNAMENTAL EM VÉU DUPLO ESVOAÇANTE (ABRINDO EM LEQUE ATRÁS)
    # Lóbulo superior esquerdo/central e direito em leque visível pela frente
    tail_veils = [
        # (x, y, z, rx, ry, rz, rad, sc, mat_key)
        (-0.24, 1.06, 1.38, -28.0, -18.0, -24.0, 0.38, (0.42, 1.18, 1.15), "coral_orange"),
        (-0.46, 1.32, 1.66, -32.0, -26.0, -28.0, 0.46, (0.36, 1.24, 1.18), "body_white"),
        (0.24, 1.06, 1.38, -28.0, 18.0, 24.0, 0.38, (0.42, 1.18, 1.15), "coral_orange"),
        (0.46, 1.32, 1.66, -32.0, 26.0, 28.0, 0.46, (0.36, 1.24, 1.18), "body_white"),
        # Véus laterais mais abertos na cauda esvoaçante
        (-0.56, 1.16, 1.02, -12.0, -34.0, -36.0, 0.40, (0.36, 1.26, 0.92), "coral_orange"),
        (-0.88, 1.44, 1.08, -10.0, -40.0, -40.0, 0.48, (0.32, 1.30, 0.96), "fin_pearl"),
        (0.56, 1.16, 1.02, -12.0, 34.0, 36.0, 0.40, (0.36, 1.26, 0.92), "coral_orange"),
        (0.88, 1.44, 1.08, -10.0, 40.0, 40.0, 0.48, (0.32, 1.30, 0.96), "fin_pearl"),
        # Véu central fluído conectando os lobos
        (0.0, 1.24, 1.28, -24.0, 0.0, 0.0, 0.42, (0.44, 1.22, 1.10), "body_white"),
    ]
    for t_idx, (tx, ty, tz, rx, ry, rz, rad, sc, mkey) in enumerate(tail_veils):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_tail_veil_{t_idx}",
                2,
                rad,
                (tx, ty, tz),
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
                scale=sc,
            ),
            mat_prefix,
            mkey,
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 118. Fingold lado a lado."""
    specs = [
        ("Fingold_Shiny", (-10.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Fingold_Normal", (-6.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Fingold_Grande", (-1.9, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Fingold_Gigante", (4.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Fingold_Dourada_SuperRara", (11.5, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_fingold(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
