"""
140_Trilocap_Kabuto_5Variacoes_Blender.py
=========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "140. Trilocap — Caranguejo Fóssil (Ref: Kabuto)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Trilocap_Shiny (1.0x - Paleta Shiny Carapaça Verde-Limão Fóssil + Patas Amarelo-Esverdeadas)
  2. Trilocap_Normal (1.0x - Carapaça Domo Marrom + Corpo Preto + Olhos Rubi Brilhantes + 4 Patas)
  3. Trilocap_Grande (1.35x - Normal)
  4. Trilocap_Gigante (1.85x - Normal)
  5. Trilocap_Dourada_SuperRara (2.25x - Carapaça Ouro Reluzente + Olhos e Patas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para o domo trilobita + cones curvados para as 4 patas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas curvadas alinhadas exatamente em `Z = 0.0` e olhos rubi apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "shell_brown": (0.72, 0.54, 0.34, 1.0),
        "shell_light": (0.82, 0.66, 0.44, 1.0),
        "shell_shade": (0.52, 0.36, 0.22, 1.0),
        "body_black": (0.07, 0.07, 0.09, 1.0),
        "under_navy": (0.10, 0.20, 0.34, 1.0),
        "eye_red": (0.94, 0.36, 0.44, 1.0),
        "eye_glow": (0.98, 0.72, 0.76, 1.0),
        "leg_tan": (0.94, 0.76, 0.42, 1.0),
        "leg_back": (0.64, 0.48, 0.34, 1.0),
        "eye_top_dark": (0.08, 0.08, 0.10, 1.0),
    },
    "shiny_palette": {
        "shell_brown": (0.48, 0.78, 0.24, 1.0),
        "shell_light": (0.62, 0.88, 0.34, 1.0),
        "shell_shade": (0.34, 0.58, 0.16, 1.0),
        "body_black": (0.07, 0.07, 0.09, 1.0),
        "under_navy": (0.10, 0.24, 0.22, 1.0),
        "eye_red": (0.96, 0.34, 0.42, 1.0),
        "eye_glow": (0.99, 0.72, 0.76, 1.0),
        "leg_tan": (0.78, 0.88, 0.34, 1.0),
        "leg_back": (0.48, 0.62, 0.22, 1.0),
        "eye_top_dark": (0.08, 0.08, 0.10, 1.0),
    },
    "golden_super_rare_palette": {
        "shell_brown": (0.98, 0.78, 0.14, 1.0),
        "shell_light": (1.00, 0.90, 0.40, 1.0),
        "shell_shade": (0.80, 0.58, 0.08, 1.0),
        "body_black": (0.18, 0.12, 0.04, 1.0),
        "under_navy": (0.06, 0.44, 0.58, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
        "eye_glow": (0.62, 0.98, 1.00, 1.0),
        "leg_tan": (0.10, 0.92, 1.00, 1.0),
        "leg_back": (0.06, 0.66, 0.80, 1.0),
        "eye_top_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une primitivas, normaliza a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_trilocap(
    name: str = "Trilocap_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 140. Trilocap (Ref: Kabuto):
      - Carapaça em domo trilobita marrom-fóssil larga com abas laterais arqueadas e 2 olhinhos pretos no topo
      - Corpo interno preto brilhante com reflexo azul-marinho sob o arco frontal da carapaça
      - 2 grandes olhos redondos rubi-rosa brilhantes voltados para frente (-Y)
      - 4 patinhas curvadas em gancho dourado-bege apoiadas em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Tri_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Tri_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Tri_Norm"

    parts = []

    # 1. CARAPAÇA ARREDONDADA EM DOMO DE TRILOBITA COM ABAS LATERAIS
    # Cúpula superior principal
    _add_part(
        parts,
        create_icosphere("_tmp_dome_main", 2, 0.78, (0.0, 0.08, 0.78), scale=(1.12, 1.18, 0.70)),
        mat_prefix,
        "shell_brown",
        pal,
    )
    # Aba frontal central em bico suave descendo entre os olhos
    _add_part(
        parts,
        create_cone(
            "_tmp_brow_peak",
            6,
            0.34,
            0.08,
            0.34,
            (0.0, -0.68, 0.88),
            rotation=(math.radians(-62.0), 0.0, 0.0),
            scale=(1.18, 0.56, 1.0),
        ),
        mat_prefix,
        "shell_light",
        pal,
    )
    # Abas laterais arqueadas formando o capacete do Kabuto
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_shell_wing_{tag}",
                2,
                0.50,
                (side * 0.62, 0.04, 0.56),
                rotation=(math.radians(8.0), math.radians(side * 24.0), math.radians(side * -14.0)),
                scale=(0.66, 1.38, 0.74),
            ),
            mat_prefix,
            "shell_brown",
            pal,
        )
        # Borda traseira pontuda da carapaça
        _add_part(
            parts,
            create_cone(
                f"_tmp_shell_rear_flange_{tag}",
                5,
                0.28,
                0.04,
                0.56,
                (side * 0.58, 0.68, 0.42),
                rotation=(math.radians(102.0), math.radians(side * 16.0), 0.0),
                scale=(0.76, 0.62, 1.0),
            ),
            mat_prefix,
            "shell_shade",
            pal,
        )

    # Placa traseira arredondada fechando o dorso
    _add_part(
        parts,
        create_icosphere("_tmp_shell_back", 2, 0.58, (0.0, 0.56, 0.62), scale=(1.12, 0.96, 0.68)),
        mat_prefix,
        "shell_brown",
        pal,
    )

    # Dois olhinhos pretos dorsais no topo da carapaça (detalhe icônico do Kabuto!)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_top_eye_{tag}",
                1,
                0.078,
                (side * 0.42, -0.22, 1.24),
                rotation=(math.radians(-16.0), math.radians(side * 22.0), 0.0),
                scale=(1.12, 0.84, 0.48),
            ),
            mat_prefix,
            "eye_top_dark",
            pal,
        )

    # 2. CORPO INTERNO ESCURO E OLHOS INFERIORES RUBI BRILHANTES
    _add_part(
        parts,
        create_icosphere("_tmp_body_dark", 2, 0.62, (0.0, -0.06, 0.52), scale=(1.10, 1.06, 0.72)),
        mat_prefix,
        "body_black",
        pal,
    )
    # Reflexo azul-marinho sutil na parte inferior do rosto escuro
    _add_part(
        parts,
        create_icosphere("_tmp_under_sheen", 2, 0.54, (0.0, -0.14, 0.36), scale=(1.08, 1.02, 0.48)),
        mat_prefix,
        "under_navy",
        pal,
    )

    # Dois grandes olhos brilhantes rubi-rosa com aro luminoso
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_glow_{tag}",
                2,
                0.185,
                (side * 0.28, -0.62, 0.56),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(1.04, 0.50, 1.04),
            ),
            mat_prefix,
            "eye_glow",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_red_{tag}",
                2,
                0.150,
                (side * 0.28, -0.67, 0.56),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(1.02, 0.46, 1.02),
            ),
            mat_prefix,
            "eye_red",
            pal,
        )

    # 3. QUATRO PATINHAS CURVADAS EM GANCHO APOIADAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Patas dianteiras dourado-bege curvando para dentro
        _add_part(
            parts,
            create_cone(
                f"_tmp_fleg_upper_{tag}",
                8,
                0.135,
                0.105,
                0.38,
                (side * 0.54, -0.44, 0.26),
                rotation=(math.radians(14.0), math.radians(side * 24.0), 0.0),
            ),
            mat_prefix,
            "leg_tan",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fleg_claw_{tag}",
                7,
                0.10,
                0.018,
                0.36,
                (side * 0.40, -0.54, 0.10),
                rotation=(math.radians(-16.0), math.radians(side * -64.0), 0.0),
            ),
            mat_prefix,
            "leg_tan",
            pal,
        )

        # Patas traseiras marrom-bege curvando para dentro
        _add_part(
            parts,
            create_cone(
                f"_tmp_hleg_upper_{tag}",
                8,
                0.125,
                0.095,
                0.34,
                (side * 0.52, 0.16, 0.24),
                rotation=(math.radians(-10.0), math.radians(side * 22.0), 0.0),
            ),
            mat_prefix,
            "leg_back",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_hleg_claw_{tag}",
                7,
                0.09,
                0.018,
                0.32,
                (side * 0.42, 0.10, 0.10),
                rotation=(math.radians(-10.0), math.radians(side * -60.0), 0.0),
            ),
            mat_prefix,
            "leg_back",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 140. Trilocap lado a lado."""
    specs = [
        ("Trilocap_Shiny", (-9.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Trilocap_Normal", (-5.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Trilocap_Grande", (-0.7, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Trilocap_Gigante", (4.9, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Trilocap_Dourada_SuperRara", (12.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_trilocap(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
