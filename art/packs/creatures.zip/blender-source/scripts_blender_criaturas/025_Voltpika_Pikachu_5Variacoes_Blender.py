"""
025_Voltpika_Pikachu_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "025. Voltpika — Ratinho Elétrico (Ref: Pikachu)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Voltpika_Shiny (1.0x - Paleta Shiny / Shyne Amarelo-Tangerina + Bochechas Rubi)
  2. Voltpika_Normal (1.0x - Amarelo-Raio + Bochechas Vermelhas + Orelhas Pontas Pretas + Cauda Raio)
  3. Voltpika_Grande (1.35x - Normal)
  4. Voltpika_Gigante (1.85x - Normal)
  5. Voltpika_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Bochechas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés alinhados exatamente em `Z = 0.0` e frente/rosto apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Voltpika_Shiny`, `Voltpika_Normal`, `Voltpika_Grande`,
     `Voltpika_Gigante`, `Voltpika_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_yellow": (0.98, 0.84, 0.14, 1.0),
        "cheek_red": (0.92, 0.20, 0.18, 1.0),
        "tip_black": (0.12, 0.12, 0.14, 1.0),
        "stripe_brown": (0.54, 0.30, 0.16, 1.0),
        "mouth_pink": (0.90, 0.48, 0.56, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_yellow": (0.96, 0.64, 0.10, 1.0),
        "cheek_red": (0.96, 0.24, 0.18, 1.0),
        "tip_black": (0.12, 0.12, 0.14, 1.0),
        "stripe_brown": (0.56, 0.28, 0.12, 1.0),
        "mouth_pink": (0.92, 0.50, 0.56, 1.0),
        "eye_white": (0.99, 0.99, 0.98, 1.0),
    },
    "golden_super_rare_palette": {
        "body_yellow": (0.98, 0.78, 0.14, 1.0),
        "cheek_red": (0.10, 0.92, 1.00, 1.0),
        "tip_black": (0.16, 0.12, 0.06, 1.0),
        "stripe_brown": (0.86, 0.58, 0.10, 1.0),
        "mouth_pink": (0.94, 0.68, 0.20, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_voltpika(
    name: str = "Voltpika_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 025. Voltpika (Ref: Pikachu):
      - Frente/rosto apontando para -Y e pés apoiados em Z = 0.0
      - Corpo compacto amarelo-raio com duas listras marrons nas costas
      - Cabeça expressiva com olhos brilhantes, boca sorridente e bochechas vermelhas circulares
      - Orelhas longas pontudas com pontas pretas e cauda em raio zigue-zague destacada
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Pika_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Pika_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Pika_Norm"

    parts = []

    # 1. CORPO COMPACTO AMARELO + DUAS LISTRAS MARRONS NAS COSTAS
    _add_part(
        parts,
        create_cube("_tmp_torso_lower", (0.86, 0.72, 0.78), (0.0, 0.04, 0.56)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_torso_belly", 1, 0.48, (0.0, -0.02, 0.54), scale=(0.98, 0.88, 0.96)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Listras marrons dorsais
    for s_idx, sz in enumerate((0.72, 0.48)):
        _add_part(
            parts,
            create_cube(f"_tmp_back_stripe_{s_idx}", (0.64, 0.10, 0.13), (0.0, 0.39, sz)),
            mat_prefix,
            "stripe_brown",
            pal,
        )

    # 2. CABEÇA EXPRESSIVA, BOCHECHAS VERMELHAS E ORELHAS LONGAS DE PONTAS PRETAS
    _add_part(
        parts,
        create_cube("_tmp_head_main", (0.90, 0.80, 0.76), (0.0, -0.04, 1.24)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_nose", (0.10, 0.07, 0.06), (0.0, -0.46, 1.22)),
        mat_prefix,
        "tip_black",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth_open", (0.24, 0.08, 0.18), (0.0, -0.44, 1.07)),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Olhos pretos grandes + ponto de brilho branco
        _add_part(
            parts,
            create_cube(f"_tmp_eye_{tag}", (0.18, 0.08, 0.20), (side * 0.24, -0.44, 1.32)),
            mat_prefix,
            "tip_black",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_shine_{tag}", (0.07, 0.06, 0.08), (side * 0.21, -0.47, 1.36)),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Bochechas vermelhas circulares (cilindros hexagonais achatados)
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_cheek_{tag}",
                6,
                0.15,
                0.08,
                (side * 0.34, -0.42, 1.08),
                rotation=(math.radians(90.0), 0.0, math.radians(side * 16.0)),
            ),
            mat_prefix,
            "cheek_red",
            pal,
        )

    # Orelhas longas com pontas pretas (esquerda mais erguida, direita mais aberta)
    ear_specs = [
        ("L", -0.34, 1.78, -18.0, -0.46, 2.18),
        ("R", 0.38, 1.74, 34.0, 0.64, 2.10),
    ]
    for tag, ex, ez, ry_deg, tx, tz in ear_specs:
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_base_{tag}",
                6,
                0.14,
                0.11,
                0.50,
                (ex, -0.02, ez),
                rotation=(math.radians(-6.0), math.radians(ry_deg), 0.0),
                scale=(1.0, 0.68, 1.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_tip_{tag}",
                6,
                0.11,
                0.015,
                0.36,
                (tx, 0.0, tz),
                rotation=(math.radians(-6.0), math.radians(ry_deg), 0.0),
                scale=(1.0, 0.68, 1.0),
            ),
            mat_prefix,
            "tip_black",
            pal,
        )

    # 3. BRAÇOS CURTOS + PÉS APOIADOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_arm_{tag}",
                (0.24, 0.42, 0.22),
                (side * 0.46, -0.28, 0.72),
                rotation=(math.radians(-18.0), 0.0, math.radians(side * -18.0)),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_leg_{tag}", (0.28, 0.30, 0.22), (side * 0.28, 0.02, 0.18)),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{tag}", (0.24, 0.44, 0.12), (side * 0.30, -0.14, 0.06)),
            mat_prefix,
            "body_yellow",
            pal,
        )

    # 4. CAUDA EM RAIO ZIGUE-ZAGUE (BASE MARROM + LÂMINA AMARELA LARGA)
    _add_part(
        parts,
        create_cube(
            "_tmp_tail_seg_1",
            (0.32, 0.10, 0.18),
            (0.26, 0.44, 0.48),
            rotation=(0.0, math.radians(-38.0), 0.0),
        ),
        mat_prefix,
        "stripe_brown",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_tail_seg_2",
            (0.22, 0.10, 0.36),
            (0.42, 0.44, 0.72),
            rotation=(0.0, math.radians(24.0), 0.0),
        ),
        mat_prefix,
        "stripe_brown",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_tail_seg_3",
            (0.46, 0.10, 0.26),
            (0.64, 0.44, 0.94),
            rotation=(0.0, math.radians(-32.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_tail_bolt_top",
            (0.76, 0.10, 0.46),
            (0.96, 0.44, 1.32),
            rotation=(0.0, math.radians(-26.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 025. Voltpika lado a lado."""
    specs = [
        ("Voltpika_Shiny", (-6.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Voltpika_Normal", (-3.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Voltpika_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Voltpika_Gigante", (3.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Voltpika_Dourada_SuperRara", (8.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_voltpika(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
