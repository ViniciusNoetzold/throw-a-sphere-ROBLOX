"""
021_Beakdart_Spearow_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "021. Beakdart — Gavião Pequeno (Ref: Spearow)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Beakdart_Shiny (1.0x - Paleta Shiny / Shyne Oliva-Dourado + Asas Verde-Musgo)
  2. Beakdart_Normal (1.0x - Cabeça/Dorso Marrom + Asas Vermelho-Tijolo + Peito Bege + Bico Rosa)
  3. Beakdart_Grande (1.35x - Normal)
  4. Beakdart_Gigante (1.85x - Normal)
  5. Beakdart_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Garras/pés alinhados exatamente em `Z = 0.0` e frente/bico apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Beakdart_Shiny`, `Beakdart_Normal`, `Beakdart_Grande`,
     `Beakdart_Gigante`, `Beakdart_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "head_brown": (0.66, 0.42, 0.28, 1.0),
        "wing_red": (0.86, 0.28, 0.28, 1.0),
        "wing_tip_pink": (0.96, 0.78, 0.74, 1.0),
        "belly_beige": (0.94, 0.84, 0.62, 1.0),
        "beak_pink": (0.90, 0.66, 0.60, 1.0),
        "eye_dark": (0.12, 0.10, 0.12, 1.0),
        "claw_white": (0.98, 0.98, 0.99, 1.0),
    },
    "shiny_palette": {
        "head_brown": (0.76, 0.72, 0.24, 1.0),
        "wing_red": (0.58, 0.68, 0.22, 1.0),
        "wing_tip_pink": (0.94, 0.92, 0.60, 1.0),
        "belly_beige": (0.98, 0.94, 0.68, 1.0),
        "beak_pink": (0.92, 0.72, 0.42, 1.0),
        "eye_dark": (0.14, 0.12, 0.10, 1.0),
        "claw_white": (0.98, 0.98, 0.94, 1.0),
    },
    "golden_super_rare_palette": {
        "head_brown": (0.98, 0.78, 0.14, 1.0),
        "wing_red": (0.94, 0.64, 0.10, 1.0),
        "wing_tip_pink": (1.00, 0.95, 0.62, 1.0),
        "belly_beige": (1.00, 0.94, 0.56, 1.0),
        "beak_pink": (0.90, 0.68, 0.18, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "claw_white": (1.00, 0.99, 0.90, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha as garras em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_beakdart(
    name: str = "Beakdart_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 021. Beakdart (Ref: Spearow):
      - Frente/bico apontando para -Y e garras/pés tocando Z = 0.0
      - Corpo atarracado bege com colarinho marrom eriçado sobre o peito
      - Cabeça marrom com crista serrilhada, olhos ferozes e bico curto curvado rosa
      - Asas curtas vermelho-tijolo com pontas rosadas e cauda em leque marrom
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Beak_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Beak_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Beak_Norm"

    parts = []

    # 1. CORPO ATARRACADO BEGE + MANTO/COLARINHO MARROM ERIÇADO
    _add_part(
        parts,
        create_icosphere("_tmp_body_beige", 1, 0.48, (0.0, 0.04, 0.66), scale=(0.94, 1.08, 0.92)),
        mat_prefix,
        "belly_beige",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_upper_mantle", (0.72, 0.72, 0.42), (0.0, -0.04, 0.94), rotation=(math.radians(-10.0), 0.0, 0.0)),
        mat_prefix,
        "head_brown",
        pal,
    )
    # Pontas eriçadas do colarinho marrom no peito
    for c_idx, (cx, cy, cz, rz) in enumerate([
        (-0.24, -0.38, 0.72, -16.0),
        (0.0, -0.44, 0.68, 0.0),
        (0.24, -0.38, 0.72, 16.0),
    ]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_collar_spike_{c_idx}",
                4,
                0.15,
                0.02,
                0.32,
                (cx, cy, cz),
                rotation=(math.radians(170.0), 0.0, math.radians(rz)),
            ),
            mat_prefix,
            "head_brown",
            pal,
        )

    # 2. CABEÇA MARROM, CRISTA SERRILHADA, OLHOS FEROZES E BICO CURVO ROSA
    _add_part(
        parts,
        create_cube("_tmp_head_main", (0.74, 0.72, 0.62), (0.0, -0.18, 1.32)),
        mat_prefix,
        "head_brown",
        pal,
    )
    # Crista serrilhada de 4 pontas no topo/nuca
    crest_specs = [
        ((0.0, -0.26, 1.74), (-14.0, 0.0, 45.0), 0.16, 0.34),
        ((0.0, -0.02, 1.78), (-34.0, 0.0, 45.0), 0.18, 0.40),
        ((-0.24, 0.14, 1.66), (-48.0, -18.0, 45.0), 0.15, 0.34),
        ((0.24, 0.14, 1.66), (-48.0, 18.0, 45.0), 0.15, 0.34),
        ((0.0, 0.24, 1.54), (-64.0, 0.0, 45.0), 0.16, 0.38),
    ]
    for idx, (loc, rot, rad, depth) in enumerate(crest_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_crest_{idx}",
                4,
                rad,
                0.02,
                depth,
                loc,
                rotation=tuple(math.radians(a) for a in rot),
            ),
            mat_prefix,
            "head_brown",
            pal,
        )

    # Bico curto curvo pontudo rosa (superior gancho + inferior)
    _add_part(
        parts,
        create_cone(
            "_tmp_beak_upper",
            4,
            0.18,
            0.03,
            0.40,
            (0.0, -0.66, 1.28),
            rotation=(math.radians(104.0), 0.0, math.radians(45.0)),
            scale=(0.95, 1.15, 1.0),
        ),
        mat_prefix,
        "beak_pink",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_beak_hook",
            4,
            0.09,
            0.015,
            0.18,
            (0.0, -0.82, 1.16),
            rotation=(math.radians(152.0), 0.0, math.radians(45.0)),
        ),
        mat_prefix,
        "beak_pink",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_beak_lower",
            4,
            0.12,
            0.03,
            0.24,
            (0.0, -0.60, 1.13),
            rotation=(math.radians(118.0), 0.0, math.radians(45.0)),
        ),
        mat_prefix,
        "beak_pink",
        pal,
    )

    # Olhos ferozes com sobrancelha inclinada
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_eye_white_{tag}", (0.14, 0.24, 0.18), (side * 0.32, -0.44, 1.36)),
            mat_prefix,
            "claw_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_pupil_{tag}", (0.14, 0.11, 0.14), (side * 0.34, -0.48, 1.35)),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.16, 0.28, 0.09),
                (side * 0.32, -0.44, 1.47),
                rotation=(math.radians(16.0), math.radians(side * -14.0), 0.0),
            ),
            mat_prefix,
            "head_brown",
            pal,
        )

    # 3. ASAS CURTAS VERMELHO-TIJOLO COM PONTAS ROSADAS + CAUDA EM LEQUE MARROM
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_base_{tag}",
                (0.68, 0.56, 0.22),
                (side * 0.68, 0.08, 0.88),
                rotation=(math.radians(10.0), math.radians(side * -24.0), math.radians(side * 16.0)),
            ),
            mat_prefix,
            "wing_red",
            pal,
        )
        for f_idx, (dy, dz, rot_z) in enumerate([(-0.14, 0.12, 10.0), (0.02, 0.04, 18.0), (0.18, -0.05, 26.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_wing_tip_{tag}_{f_idx}",
                    4,
                    0.12,
                    0.025,
                    0.46,
                    (side * 1.12, 0.14 + dy, 1.00 + dz),
                    rotation=(math.radians(12.0), math.radians(side * 66.0), math.radians(side * rot_z)),
                    scale=(0.55, 1.0, 1.0),
                ),
                mat_prefix,
                "wing_tip_pink",
                pal,
            )

    for t_idx, (tx, rz) in enumerate([(-0.18, -16.0), (0.0, 0.0), (0.18, 16.0)]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_tail_{t_idx}",
                (0.18, 0.68, 0.09),
                (tx, 0.72, 0.64),
                rotation=(math.radians(24.0), 0.0, math.radians(rz)),
            ),
            mat_prefix,
            "head_brown",
            pal,
        )

    # 4. PERNAS E GARRAS ROSA COM UNHAS BRANCAS TOCANDO Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_thigh_{tag}", (0.24, 0.26, 0.24), (side * 0.26, -0.02, 0.36)),
            mat_prefix,
            "belly_beige",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(f"_tmp_leg_{tag}", 6, 0.075, 0.32, (side * 0.26, -0.04, 0.20)),
            mat_prefix,
            "beak_pink",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{tag}", (0.26, 0.30, 0.09), (side * 0.26, -0.10, 0.045)),
            mat_prefix,
            "beak_pink",
            pal,
        )
        for c_idx, (dx, dy) in enumerate([(-0.10, -0.26), (0.0, -0.30), (0.10, -0.26)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_claw_{tag}_{c_idx}",
                    4,
                    0.042,
                    0.01,
                    0.15,
                    (side * 0.26 + dx, dy, 0.045),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 021. Beakdart lado a lado."""
    specs = [
        ("Beakdart_Shiny", (-6.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Beakdart_Normal", (-3.9, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Beakdart_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Beakdart_Gigante", (3.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Beakdart_Dourada_SuperRara", (8.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_beakdart(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
