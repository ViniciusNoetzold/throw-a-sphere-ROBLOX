"""
142_Skywyvern_Aerodactyl_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "142. Skywyvern — Pterossauro Antigo (Ref: Aerodactyl)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Skywyvern_Shiny (1.0x - Paleta Shiny Corpo Lavanda-Rosado + Membranas das Asas Azul-Céu)
  2. Skywyvern_Normal (1.0x - Corpo Cinza-Lavanda + Asas Roxas + Mandíbula Denteada + Cauda em Flecha)
  3. Skywyvern_Grande (1.35x - Normal)
  4. Skywyvern_Gigante (1.85x - Normal)
  5. Skywyvern_Dourada_SuperRara (2.25x - Corpo Ouro Reluzente + Asas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para tronco/cabeça + cones/cunhas para asas membranosas, dentes e cauda em flecha)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas com garras alinhadas exatamente em `Z = 0.0` e mandíbula rugindo voltada para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_grey": (0.68, 0.67, 0.76, 1.0),
        "body_light": (0.78, 0.78, 0.86, 1.0),
        "body_shade": (0.50, 0.49, 0.60, 1.0),
        "wing_purple": (0.66, 0.50, 0.78, 1.0),
        "wing_shade": (0.48, 0.34, 0.60, 1.0),
        "jaw_inside": (0.50, 0.24, 0.32, 1.0),
        "tongue_pink": (0.86, 0.60, 0.64, 1.0),
        "tooth_white": (0.98, 0.98, 1.00, 1.0),
        "eye_green": (0.28, 0.68, 0.44, 1.0),
        "eye_dark": (0.10, 0.12, 0.16, 1.0),
    },
    "shiny_palette": {
        "body_grey": (0.78, 0.58, 0.84, 1.0),
        "body_light": (0.88, 0.70, 0.92, 1.0),
        "body_shade": (0.58, 0.40, 0.66, 1.0),
        "wing_purple": (0.34, 0.64, 0.92, 1.0),
        "wing_shade": (0.22, 0.46, 0.74, 1.0),
        "jaw_inside": (0.52, 0.22, 0.34, 1.0),
        "tongue_pink": (0.90, 0.60, 0.68, 1.0),
        "tooth_white": (0.98, 0.98, 1.00, 1.0),
        "eye_green": (0.32, 0.74, 0.48, 1.0),
        "eye_dark": (0.10, 0.12, 0.16, 1.0),
    },
    "golden_super_rare_palette": {
        "body_grey": (0.98, 0.78, 0.14, 1.0),
        "body_light": (1.00, 0.90, 0.42, 1.0),
        "body_shade": (0.80, 0.58, 0.08, 1.0),
        "wing_purple": (0.10, 0.92, 1.00, 1.0),
        "wing_shade": (0.06, 0.64, 0.80, 1.0),
        "jaw_inside": (0.64, 0.36, 0.06, 1.0),
        "tongue_pink": (0.98, 0.80, 0.30, 1.0),
        "tooth_white": (1.00, 0.99, 0.94, 1.0),
        "eye_green": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.04, 0.44, 0.58, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une primitivas, normaliza a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_skywyvern(
    name: str = "Skywyvern_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 142. Skywyvern (Ref: Aerodactyl):
      - Tronco musculoso cinza-lavanda com crista dorsal e patas de raptor em Z = 0.0
      - Pescoço longo e cabeça angular de pterossauro com 2 chifres traseiros e olhos verdes ferozes
      - Mandíbula aberta em rugido feroz com língua rosa e fileiras de dentes brancos serrilhados
      - Grandes asas membranosas roxas erguidas em V com mãos de 3 dedos nos pulsos
      - Cauda longa terminando em ponta triangular de flecha
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Sky_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Sky_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Sky_Norm"

    parts = []

    # 1. TRONCO MUSCULOSO, CRISTA DORSAL E PERNAS DE RAPTOR EM Z = 0.0
    _add_part(
        parts,
        create_icosphere("_tmp_torso_main", 2, 0.48, (0.0, 0.06, 0.90), scale=(0.92, 0.96, 1.18)),
        mat_prefix,
        "body_grey",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_chest_light", 2, 0.40, (0.0, -0.06, 0.94), scale=(0.88, 0.82, 1.04)),
        mat_prefix,
        "body_light",
        pal,
    )
    # Crista dorsal nas costas
    _add_part(
        parts,
        create_cone(
            "_tmp_back_fin",
            5,
            0.16,
            0.025,
            0.38,
            (0.0, 0.44, 1.24),
            rotation=(math.radians(38.0), 0.0, 0.0),
            scale=(0.56, 1.0, 1.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    # Pernas de pterossauro com garras duplas em Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.22,
                (side * 0.28, 0.04, 0.50),
                rotation=(math.radians(-14.0), math.radians(side * 10.0), 0.0),
                scale=(0.86, 1.00, 1.22),
            ),
            mat_prefix,
            "body_grey",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_shin_{tag}",
                7,
                0.095,
                0.135,
                0.38,
                (side * 0.30, -0.04, 0.24),
                rotation=(math.radians(14.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )
        # Dois dedos/garras frontais apoiados no chão
        for t_idx, (dx, rz) in enumerate([(-0.06, -14.0), (0.06, 14.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_toe_{tag}_{t_idx}",
                    5,
                    0.060,
                    0.014,
                    0.24,
                    (side * 0.30 + dx, -0.18, 0.06),
                    rotation=(math.radians(-98.0), 0.0, math.radians(rz)),
                ),
                mat_prefix,
                "body_shade",
                pal,
            )

    # 2. PESCOÇO LONGO, CABEÇA DE PTEROSSAURO, CHIFRES E MANDÍBULA DENTEADA ABERTA
    _add_part(
        parts,
        create_cone(
            "_tmp_neck",
            8,
            0.22,
            0.16,
            0.54,
            (0.0, -0.12, 1.48),
            rotation=(math.radians(-18.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_grey",
        pal,
    )
    # Crânio angular
    _add_part(
        parts,
        create_icosphere("_tmp_head_skull", 2, 0.30, (0.0, -0.26, 1.82), scale=(0.84, 1.12, 0.94)),
        mat_prefix,
        "body_grey",
        pal,
    )
    # Dois chifres pontudos atrás da cabeça
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_horn_{tag}",
                5,
                0.11,
                0.015,
                0.44,
                (side * 0.20, 0.04, 1.98),
                rotation=(math.radians(56.0), math.radians(side * 22.0), 0.0),
                scale=(0.76, 1.0, 1.0),
            ),
            mat_prefix,
            "body_grey",
            pal,
        )
        # Olhos verdes ferozes nas laterais da testa
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                1,
                0.088,
                (side * 0.22, -0.40, 1.90),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(0.68, 1.08, 0.62),
            ),
            mat_prefix,
            "tooth_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_green_{tag}",
                1,
                0.056,
                (side * 0.24, -0.43, 1.90),
                scale=(0.60, 0.92, 0.66),
            ),
            mat_prefix,
            "eye_green",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.030,
                (side * 0.25, -0.46, 1.90),
                scale=(0.55, 0.72, 0.78),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Maxilar superior alongado com proeminência nasal típica do Aerodactyl
    _add_part(
        parts,
        create_cone(
            "_tmp_upper_jaw",
            6,
            0.22,
            0.12,
            0.62,
            (0.0, -0.60, 1.88),
            rotation=(math.radians(-78.0), 0.0, 0.0),
            scale=(0.94, 0.74, 1.0),
        ),
        mat_prefix,
        "body_grey",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_nose_crest", 2, 0.14, (0.0, -0.78, 1.98), scale=(0.86, 1.18, 0.92)),
        mat_prefix,
        "body_light",
        pal,
    )
    # Maxilar inferior escancarado em rugido
    _add_part(
        parts,
        create_cone(
            "_tmp_lower_jaw",
            6,
            0.22,
            0.13,
            0.62,
            (0.0, -0.54, 1.54),
            rotation=(math.radians(-128.0), 0.0, 0.0),
            scale=(0.94, 0.66, 1.0),
        ),
        mat_prefix,
        "body_grey",
        pal,
    )
    # Interior escuro da boca e língua rosa
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_cavity", 2, 0.21, (0.0, -0.48, 1.68), scale=(0.80, 1.08, 0.94)),
        mat_prefix,
        "jaw_inside",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tongue",
            2,
            0.14,
            (0.0, -0.56, 1.56),
            rotation=(math.radians(28.0), 0.0, 0.0),
            scale=(0.84, 1.32, 0.44),
        ),
        mat_prefix,
        "tongue_pink",
        pal,
    )

    # Fileiras de dentes brancos afiados nos dois maxilares
    for side in (-1.0, 1.0):
        for t_idx, (ty, tz_up, tz_lo) in enumerate([(-0.56, 1.78, 1.52), (-0.70, 1.80, 1.44), (-0.82, 1.82, 1.38)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_tooth_up_{side}_{t_idx}",
                    4,
                    0.028,
                    0.006,
                    0.09,
                    (side * 0.11, ty, tz_up),
                    rotation=(math.radians(174.0), 0.0, 0.0),
                ),
                mat_prefix,
                "tooth_white",
                pal,
            )
            _add_part(
                parts,
                create_cone(
                    f"_tmp_tooth_lo_{side}_{t_idx}",
                    4,
                    0.028,
                    0.006,
                    0.09,
                    (side * 0.11, ty, tz_lo),
                    rotation=(math.radians(-26.0), 0.0, 0.0),
                ),
                mat_prefix,
                "tooth_white",
                pal,
            )

    # 3. GRANDES ASAS MEMBRANOSAS ROXAS ERGUIDAS EM V COM MÃOS DE 3 GARRAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Braço superior da asa (ombro -> cotovelo)
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_humerus_{tag}",
                7,
                0.11,
                0.085,
                0.56,
                (side * 0.56, 0.06, 1.24),
                rotation=(0.0, math.radians(side * 66.0), 0.0),
            ),
            mat_prefix,
            "body_grey",
            pal,
        )
        # Antebraço subindo do cotovelo até o pulso com garras
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_radius_{tag}",
                7,
                0.085,
                0.075,
                0.68,
                (side * 0.90, 0.02, 1.66),
                rotation=(math.radians(-6.0), math.radians(side * 24.0), 0.0),
            ),
            mat_prefix,
            "body_grey",
            pal,
        )
        # Pulso + 3 dedinhos/garras no topo da asa
        _add_part(
            parts,
            create_icosphere(f"_tmp_wing_wrist_{tag}", 1, 0.10, (side * 1.00, -0.02, 1.98)),
            mat_prefix,
            "body_grey",
            pal,
        )
        for f_idx, (fx, fz, ry_f) in enumerate([(-0.08, 0.14, -22.0), (0.0, 0.18, 0.0), (0.09, 0.13, 28.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_wing_claw_{tag}_{f_idx}",
                    5,
                    0.036,
                    0.010,
                    0.18,
                    (side * (1.00 + fx), -0.04, 1.98 + fz),
                    rotation=(math.radians(-14.0), math.radians(side * ry_f), 0.0),
                ),
                mat_prefix,
                "tooth_white",
                pal,
            )
        # Longa haste óssea externa da asa (pulso -> ponta da asa)
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_spar_{tag}",
                6,
                0.068,
                0.016,
                0.78,
                (side * 1.36, 0.06, 1.84),
                rotation=(math.radians(8.0), math.radians(side * 112.0), 0.0),
            ),
            mat_prefix,
            "body_grey",
            pal,
        )
        # Membrana interna da asa (roxa, ligando tronco ao cotovelo e antebraço)
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_mem_in_{tag}",
                4,
                0.42,
                0.08,
                0.74,
                (side * 0.66, 0.12, 1.28),
                rotation=(math.radians(6.0), math.radians(side * 58.0), math.radians(45.0)),
                scale=(1.0, 0.16, 1.0),
            ),
            mat_prefix,
            "wing_shade",
            pal,
        )
        # Membrana principal externa da asa (roxa brilhante estendida até a ponta)
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_mem_out_{tag}",
                4,
                0.48,
                0.04,
                0.96,
                (side * 1.24, 0.10, 1.62),
                rotation=(math.radians(8.0), math.radians(side * 102.0), math.radians(45.0)),
                scale=(1.0, 0.14, 1.0),
            ),
            mat_prefix,
            "wing_purple",
            pal,
        )
        # Membrana média ligando o pulso ao recorte inferior da asa
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_wing_mem_mid_{tag}",
                1,
                0.38,
                (side * 0.96, 0.11, 1.48),
                rotation=(0.0, math.radians(side * -18.0), 0.0),
                scale=(1.22, 0.16, 0.88),
            ),
            mat_prefix,
            "wing_purple",
            pal,
        )

    # 4. CAUDA LONGA TERMINANDO EM PONTA TRIANGULAR DE FLECHA
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_base",
            7,
            0.18,
            0.10,
            0.66,
            (0.08, 0.62, 0.72),
            rotation=(math.radians(78.0), 0.0, math.radians(-14.0)),
        ),
        mat_prefix,
        "body_grey",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_mid",
            7,
            0.10,
            0.05,
            0.60,
            (0.26, 1.12, 0.88),
            rotation=(math.radians(66.0), 0.0, math.radians(-26.0)),
        ),
        mat_prefix,
        "body_grey",
        pal,
    )
    # Ponta de flecha triangular na extremidade da cauda
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_arrow",
            4,
            0.18,
            0.015,
            0.38,
            (0.42, 1.44, 1.02),
            rotation=(math.radians(60.0), 0.0, math.radians(-30.0)),
            scale=(1.08, 0.42, 1.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 142. Skywyvern lado a lado (sem sobrepor asas)."""
    specs = [
        ("Skywyvern_Shiny", (-14.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Skywyvern_Normal", (-10.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Skywyvern_Grande", (-4.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Skywyvern_Gigante", (2.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Skywyvern_Dourada_SuperRara", (11.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_skywyvern(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
