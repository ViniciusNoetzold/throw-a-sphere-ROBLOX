"""
03_Ignisovereign_Rei_Leao_Solar_Ignishishi_Blender.py
=====================================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera o modelo 3D
da criatura "03. Ignisovereign (Ignishishi) — Rei Leão Solar (Evolução Final Fogo - Estágio 3)"
no estilo Low-Poly / Voxel Blocky para o jogo Roblox "Jogue uma Orbe / Throw a Sphere".

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no modelo final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cilindros 6 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Variações automáticas (`Normal`, `Dourado`, `Huge`) geradas lado a lado
  - Base dos pés alinhada exatamente em `Z = 0.0` e frente apontando para `-Y` (pronto para FBX -> Roblox Studio)

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione um modelo (ex: `Ignisovereign_Normal`) e exporte via `File > Export > FBX (.fbx)`
     com `Selected Objects` marcado e `Apply Transform` para importar como `MeshPart` no Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "huge_scale": 1.85,
    "palette": {
        "smoke_dark": (0.20, 0.16, 0.17, 1.0),   # Nuvens da juba e cauda, ombros, orelhas e patas traseiras (#33292B)
        "body_ochre": (0.90, 0.58, 0.24, 1.0),   # Torso/coxas traseiras, rosto e patas dianteiras (#E6943D)
        "blast_gold": (1.00, 0.80, 0.14, 1.0),   # Colar incandescente, espinhos solares e borda das fitas (#FFCC24)
        "flame_red": (0.92, 0.22, 0.14, 1.0),    # Pontas dos espinhos, fitas em espiral da sobrancelha e nariz (#EB3824)
        "rust_amber": (0.68, 0.34, 0.16, 1.0),   # Transição das canelas dianteiras e sombreamento (#AD5729)
        "fang_white": (0.96, 0.95, 0.96, 1.0),   # Olhos brilhantes e presas de Shishi (#F5F2F5)
    },
    "golden_palette": {
        "smoke_dark": (0.74, 0.54, 0.12, 1.0),
        "body_ochre": (1.00, 0.84, 0.24, 1.0),
        "blast_gold": (1.00, 0.96, 0.58, 1.0),
        "flame_red": (1.00, 0.66, 0.08, 1.0),
        "rust_amber": (0.86, 0.62, 0.14, 1.0),
        "fang_white": (0.14, 0.96, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (ideal para acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, zera a origem na base dos pés (Z = 0.0),
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_blast_spike(
    parts: list,
    prefix: str,
    origin: tuple,
    angle_rad: float,
    radius_base: float,
    length: float,
    mat_prefix: str,
    pal: dict,
    tilt_x: float = 0.0,
):
    """Adiciona um espinho de explosão solar bicolor (base ouro + ponta vermelho-fogo)."""
    ox, oy, oz = origin
    dx = math.cos(tilt_x) * math.sin(angle_rad)
    dy = -math.sin(tilt_x)
    dz = math.cos(tilt_x) * math.cos(angle_rad)

    # Cone base amarelo-ouro saindo da nuvem
    gold_len = length * 0.62
    gx = ox + dx * (gold_len * 0.42)
    gy = oy + dy * (gold_len * 0.42)
    gz = oz + dz * (gold_len * 0.42)
    _add_part(
        parts,
        create_cone(
            f"_tmp_{prefix}_gold",
            4,
            radius_base,
            radius_base * 0.25,
            gold_len,
            (gx, gy, gz),
            (tilt_x, angle_rad, 0.0),
            scale=(1.0, 0.52, 1.0),
        ),
        mat_prefix,
        "blast_gold",
        pal,
    )

    # Ponta externa afilada vermelho-fogo
    red_len = length * 0.66
    rx = ox + dx * (length * 0.68)
    ry = oy + dy * (length * 0.68)
    rz = oz + dz * (length * 0.68)
    _add_part(
        parts,
        create_cone(
            f"_tmp_{prefix}_red",
            4,
            radius_base * 0.56,
            0.02,
            red_len,
            (rx, ry, rz),
            (tilt_x, angle_rad, 0.0),
            scale=(1.0, 0.48, 1.0),
        ),
        mat_prefix,
        "flame_red",
        pal,
    )


def build_ignisovereign(
    name: str = "Ignisovereign_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    is_golden: bool = False,
):
    """
    Constrói o modelo 3D completo do Rei Leão Solar (03. Ignisovereign / Estilo Ignishishi):
      - Frente apontando para -Y e base das 4 patas em Z = 0.0
      - Juba de nuvens vulcânicas escuras com colar incandescente e 9 espinhos solares radiais
      - Fitas flamejantes em espiral saindo das sobrancelhas com pontas estreladas
      - Cauda em nuvem explosiva com 4 espinhos de fogos de artifício
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    pal = CONFIG["golden_palette"] if is_golden else CONFIG["palette"]
    mat_prefix = "Mat_Igni_Gold" if is_golden else "Mat_Igni"
    parts = []

    # 1. TORSO MUSCULOSO BICOLOR (Ombros Escuros + Quadris Ocre)
    _add_part(
        parts,
        create_cube("_tmp_torso_front", (1.22, 1.05, 0.96), (0.0, -0.34, 1.08), (math.radians(6), 0.0, 0.0)),
        mat_prefix,
        "smoke_dark",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_torso_rear", (1.06, 1.08, 0.88), (0.0, 0.44, 1.04), (math.radians(-6), 0.0, 0.0)),
        mat_prefix,
        "body_ochre",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_torso_mid", (1.02, 0.65, 0.82), (0.0, 0.06, 1.02)),
        mat_prefix,
        "smoke_dark",
        pal,
    )
    # Tufo curto ocre na base do rabo
    _add_part(
        parts,
        create_cone("_tmp_rump_tuft", 4, 0.16, 0.02, 0.34, (0.0, 0.96, 1.38), (math.radians(-28), 0.0, 0.0)),
        mat_prefix,
        "body_ochre",
        pal,
    )

    # 2. QUATRO PATAS COM CONTRASTE INVERTIDO E BASE EM Z = 0
    # 2A. Patas Dianteiras (Braço superior escuro com esporão + canela/pata ocre-ferrugem)
    for side_idx, sx in enumerate([-1.0, 1.0]):
        lx = sx * 0.56
        _add_part(
            parts,
            create_cone(
                f"_tmp_fleg_upper_{side_idx}",
                6,
                0.21,
                0.29,
                0.76,
                (lx, -0.58, 0.78),
                (math.radians(16), math.radians(sx * -8), 0.0),
            ),
            mat_prefix,
            "smoke_dark",
            pal,
        )
        # Esporões escuros pontiagudos nos cotovelos (fiel à silhueta da imagem)
        _add_part(
            parts,
            create_cone(
                f"_tmp_fleg_elbow_spike_{side_idx}",
                4,
                0.13,
                0.02,
                0.38,
                (lx + sx * 0.14, -0.34, 0.66),
                (math.radians(-62), math.radians(sx * 24), 0.0),
            ),
            mat_prefix,
            "smoke_dark",
            pal,
        )
        # Canela inferior e pata dianteira (lado -X mais âmbar/ferrugem, +X mais ocre)
        paw_mat = "rust_amber" if sx < 0 else "body_ochre"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fleg_lower_{side_idx}",
                6,
                0.19,
                0.16,
                0.42,
                (lx, -0.78, 0.28),
                (math.radians(18), 0.0, 0.0),
            ),
            mat_prefix,
            paw_mat,
            pal,
        )
        # Pontas zig-zag subindo na canela dianteira
        _add_part(
            parts,
            create_cone(f"_tmp_fleg_zig_{side_idx}", 4, 0.11, 0.02, 0.26, (lx, -0.80, 0.52)),
            mat_prefix,
            paw_mat,
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_fpaw_{side_idx}", (0.36, 0.42, 0.18), (lx, -0.88, 0.09)),
            mat_prefix,
            paw_mat,
            pal,
        )
        for toe_i, tx_off in enumerate([-0.115, 0.0, 0.115]):
            _add_part(
                parts,
                create_cube(f"_tmp_ftoe_{side_idx}_{toe_i}", (0.10, 0.16, 0.13), (lx + tx_off, -1.10, 0.065)),
                mat_prefix,
                paw_mat,
                pal,
            )

    # 2B. Patas Traseiras (Coxa ocre + tornozelo/pata escura com recorte zig-zag)
    for side_idx, sx in enumerate([-1.0, 1.0]):
        lx = sx * 0.54
        _add_part(
            parts,
            create_cone(
                f"_tmp_bleg_upper_{side_idx}",
                6,
                0.22,
                0.31,
                0.76,
                (lx, 0.64, 0.80),
                (math.radians(-14), 0.0, 0.0),
            ),
            mat_prefix,
            "body_ochre",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_bleg_lower_{side_idx}",
                6,
                0.20,
                0.16,
                0.46,
                (lx, 0.72, 0.30),
                (math.radians(-8), 0.0, 0.0),
            ),
            mat_prefix,
            "smoke_dark",
            pal,
        )
        _add_part(
            parts,
            create_cone(f"_tmp_bleg_zig_{side_idx}", 4, 0.12, 0.02, 0.28, (lx, 0.66, 0.54)),
            mat_prefix,
            "smoke_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_bpaw_{side_idx}", (0.36, 0.40, 0.18), (lx, 0.68, 0.09)),
            mat_prefix,
            "smoke_dark",
            pal,
        )
        for toe_i, tx_off in enumerate([-0.115, 0.0, 0.115]):
            _add_part(
                parts,
                create_cube(f"_tmp_btoe_{side_idx}_{toe_i}", (0.10, 0.16, 0.13), (lx + tx_off, 0.46, 0.065)),
                mat_prefix,
                "smoke_dark",
                pal,
            )

    # 3. CABEÇA SHISHI FEROZ, PRESAS, ORELHAS E FITAS DE SOBRANCELHA EM ESPIRAL
    _add_part(
        parts,
        create_cube("_tmp_head_face", (0.76, 0.68, 0.62), (0.0, -1.04, 1.52)),
        mat_prefix,
        "body_ochre",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_head_crown", (0.78, 0.68, 0.28), (0.0, -1.02, 1.78)),
        mat_prefix,
        "smoke_dark",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout_lower", (0.56, 0.40, 0.24), (0.0, -1.36, 1.40)),
        mat_prefix,
        "body_ochre",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout_bridge", (0.44, 0.36, 0.18), (0.0, -1.38, 1.56)),
        mat_prefix,
        "smoke_dark",
        pal,
    )
    # Barba pontuda no queixo
    _add_part(
        parts,
        create_cone("_tmp_chin_beard", 4, 0.16, 0.02, 0.30, (0.0, -1.36, 1.18), (math.radians(168), 0.0, 0.0)),
        mat_prefix,
        "body_ochre",
        pal,
    )
    # Nariz vermelho
    _add_part(
        parts,
        create_cube("_tmp_nose", (0.14, 0.12, 0.10), (0.0, -1.58, 1.54)),
        mat_prefix,
        "flame_red",
        pal,
    )
    # Chifre central de chama dourado-vermelho na testa
    _add_blast_spike(parts, "brow_horn", (0.0, -1.24, 1.92), 0.0, 0.16, 0.58, mat_prefix, pal, tilt_x=math.radians(8))

    for side_idx, sx in enumerate([-1.0, 1.0]):
        # Olho feroz e presas brancas de Shishi
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_{side_idx}",
                (0.16, 0.09, 0.13),
                (sx * 0.22, -1.39, 1.60),
                (0.0, math.radians(sx * 16), math.radians(sx * -12)),
            ),
            mat_prefix,
            "fang_white",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{side_idx}",
                4,
                0.055,
                0.01,
                0.15,
                (sx * 0.18, -1.48, 1.44),
            ),
            mat_prefix,
            "fang_white",
            pal,
        )
        # Orelha pontuda escura saindo da nuvem
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{side_idx}",
                4,
                0.18,
                0.02,
                0.52,
                (sx * 0.44, -0.94, 1.94),
                (0.0, math.radians(sx * 32), 0.0),
                scale=(1.0, 0.55, 1.0),
            ),
            mat_prefix,
            "smoke_dark",
            pal,
        )

        # Sobrancelha em espiral + longa fita flamejante com ponta estrelada
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_brow_spiral_{side_idx}",
                6,
                0.11,
                0.10,
                (sx * 0.14, -1.41, 1.69),
                (math.radians(90), 0.0, 0.0),
            ),
            mat_prefix,
            "flame_red",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_spiral_gold_{side_idx}",
                (0.09, 0.06, 0.09),
                (sx * 0.14, -1.44, 1.69),
            ),
            mat_prefix,
            "blast_gold",
            pal,
        )
        # Segmentos da fita flamejante arqueando para cima e para os lados
        _add_part(
            parts,
            create_cube(
                f"_tmp_ribbon_seg1_{side_idx}",
                (0.38, 0.10, 0.12),
                (sx * 0.34, -1.32, 1.82),
                (0.0, math.radians(sx * -22), math.radians(sx * -18)),
            ),
            mat_prefix,
            "flame_red",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_ribbon_seg2_{side_idx}",
                (0.56, 0.10, 0.11),
                (sx * 0.72, -1.16, 1.68),
                (0.0, math.radians(sx * 28), math.radians(sx * 22)),
            ),
            mat_prefix,
            "flame_red",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_ribbon_gold_trim_{side_idx}",
                (0.50, 0.12, 0.045),
                (sx * 0.72, -1.18, 1.72),
                (0.0, math.radians(sx * 28), math.radians(sx * 22)),
            ),
            mat_prefix,
            "blast_gold",
            pal,
        )
        # Ponta estrelada de 3 pontas na extremidade da fita
        star_pos = (sx * 1.06, -1.04, 1.76)
        _add_part(
            parts,
            create_cone(
                f"_tmp_ribbon_star_up_{side_idx}",
                4,
                0.12,
                0.02,
                0.38,
                (star_pos[0], star_pos[1], star_pos[2] + 0.14),
                (0.0, math.radians(sx * 16), 0.0),
                scale=(1.0, 0.45, 1.0),
            ),
            mat_prefix,
            "blast_gold",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ribbon_star_out_{side_idx}",
                4,
                0.11,
                0.02,
                0.34,
                (star_pos[0] + sx * 0.14, star_pos[1], star_pos[2]),
                (0.0, math.radians(sx * 78), 0.0),
                scale=(1.0, 0.45, 1.0),
            ),
            mat_prefix,
            "blast_gold",
            pal,
        )

    # 4. JUBA COLOSSAL DE NUVEM DE FUMAÇA + COLAR INCANDESCENTE + 9 ESPINHOS SOLARES RADIAIS
    mane_center = (0.0, -0.78, 1.82)

    # Anel externo de nuvens de fumaça vulcânica escuras (10 puffs)
    smoke_ring_angles = [-128, -98, -68, -36, -12, 12, 36, 68, 98, 128]
    for idx, deg in enumerate(smoke_ring_angles):
        ang = math.radians(deg)
        px = mane_center[0] + math.sin(ang) * 0.92
        pz = mane_center[2] + math.cos(ang) * 0.88
        py = mane_center[1] + (0.06 if idx % 2 == 0 else -0.04)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_smoke_puff_{idx}",
                1,
                0.44,
                (px, py, pz),
                scale=(1.05, 0.78, 1.05),
            ),
            mat_prefix,
            "smoke_dark",
            pal,
        )
    # Volume traseiro da juba atrás da nuca
    _add_part(
        parts,
        create_icosphere("_tmp_smoke_back", 1, 0.76, (0.0, -0.58, 1.76), scale=(1.22, 0.75, 1.15)),
        mat_prefix,
        "smoke_dark",
        pal,
    )

    # Colar interno incandescente dourado ao redor do pescoço e peito (7 puffs + pontas)
    gold_collar_angles = [-115, -75, -35, 180, 35, 75, 115]
    for idx, deg in enumerate(gold_collar_angles):
        ang = math.radians(deg)
        px = 0.0 + math.sin(ang) * 0.56
        pz = 1.46 + math.cos(ang) * 0.44
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_gold_collar_{idx}",
                1,
                0.28,
                (px, -0.96, pz),
                scale=(1.0, 0.75, 0.95),
            ),
            mat_prefix,
            "blast_gold",
            pal,
        )

    # 9 Espinhos de explosão solar disparando radialmente da nuvem de fumaça
    mane_spike_angles = [-132, -96, -60, -28, 0, 28, 60, 96, 132]
    for idx, deg in enumerate(mane_spike_angles):
        ang = math.radians(deg)
        sx_pos = mane_center[0] + math.sin(ang) * 1.12
        sz_pos = mane_center[2] + math.cos(ang) * 1.08
        spike_len = 0.88 if deg == 0 else (0.76 if abs(deg) in (60, 96) else 0.64)
        _add_blast_spike(
            parts,
            f"mane_spike_{idx}",
            (sx_pos, mane_center[1] - 0.04, sz_pos),
            ang,
            0.18,
            spike_len,
            mat_prefix,
            pal,
        )

    # 5. CAUDA DE NUVEM DE FUMAÇA EXPLOSIVA + 4 ESPINHOS DE FOGOS DE ARTIFÍCIO
    _add_part(
        parts,
        create_cylinder("_tmp_tail_stem", 6, 0.11, 0.64, (0.0, 1.14, 1.38), (math.radians(-42), 0.0, 0.0)),
        mat_prefix,
        "body_ochre",
        pal,
    )
    tail_cloud_center = (0.0, 1.54, 1.72)
    tail_offsets = [
        (0.0, 0.0, 0.0, 0.42),
        (-0.22, 0.10, 0.14, 0.34),
        (0.22, 0.10, 0.14, 0.34),
        (0.0, 0.24, -0.10, 0.34),
        (0.0, -0.14, 0.22, 0.32),
    ]
    for idx, (ox, oy, oz, rad) in enumerate(tail_offsets):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_tail_smoke_{idx}",
                1,
                rad,
                (tail_cloud_center[0] + ox, tail_cloud_center[1] + oy, tail_cloud_center[2] + oz),
            ),
            mat_prefix,
            "smoke_dark",
            pal,
        )

    # Espinhos explosivos da cauda (topo alto, lateral traseiro e inferior)
    _add_blast_spike(parts, "tail_spike_top", (0.0, 1.48, 2.02), math.radians(0), 0.16, 0.82, mat_prefix, pal, tilt_x=math.radians(-8))
    _add_blast_spike(parts, "tail_spike_back", (0.0, 1.88, 1.80), math.radians(0), 0.15, 0.72, mat_prefix, pal, tilt_x=math.radians(-78))
    _add_blast_spike(parts, "tail_spike_low", (0.0, 1.66, 1.36), math.radians(0), 0.14, 0.62, mat_prefix, pal, tilt_x=math.radians(-148))
    _add_blast_spike(parts, "tail_spike_side", (-0.34, 1.54, 1.82), math.radians(-58), 0.13, 0.56, mat_prefix, pal)

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """Gera lado a lado as versões Normal, Dourada (Mutação 2x) e Enorme (Huge 1.85x)."""
    build_ignisovereign("Ignisovereign_Normal", location=(0.0, 0.0, 0.0), scale=1.0, is_golden=False)
    build_ignisovereign("Ignisovereign_Dourado", location=(4.4, 0.0, 0.0), scale=1.0, is_golden=True)
    build_ignisovereign("Ignisovereign_Huge", location=(-5.8, 0.0, 0.0), scale=CONFIG["huge_scale"], is_golden=False)


if __name__ == "__main__":
    generate_variations()
    print("Ignisovereign (Rei Leão Solar - Estilo Ignishishi) gerado com sucesso! Pronto para exportar em .FBX para o Roblox Studio.")
