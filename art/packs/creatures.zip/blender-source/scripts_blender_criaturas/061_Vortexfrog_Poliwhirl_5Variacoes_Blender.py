"""
061_Vortexfrog_Poliwhirl_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "061. Vortexfrog — Sapo Lutador (Ref: Poliwhirl)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Vortexfrog_Shiny (1.0x - Paleta Shiny Azul-Ciano Brilhante + Luvas e Barriga Brancas)
  2. Vortexfrog_Normal (1.0x - Sapo Redondo Azul-Cobalto + Olhos Saltados + Espiral Invertida + Luvas de Boxe)
  3. Vortexfrog_Grande (1.35x - Normal)
  4. Vortexfrog_Gigante (1.85x - Normal)
  5. Vortexfrog_Dourada_SuperRara (2.25x - Ouro Reluzente + Espiral, Olhos e Luvas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + espiral 3D invertida nítida + luvas de boxe)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés de sapo alinhados exatamente em `Z = 0.0` e espiral/olhos apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.31, 0.56, 0.82, 1.0),
        "body_dark": (0.22, 0.44, 0.70, 1.0),
        "glove_white": (0.94, 0.96, 0.99, 1.0),
        "belly_white": (0.97, 0.98, 1.00, 1.0),
        "spiral_black": (0.10, 0.11, 0.14, 1.0),
        "shine_white": (1.00, 1.00, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.44, 0.76, 0.94, 1.0),
        "body_dark": (0.32, 0.62, 0.84, 1.0),
        "glove_white": (0.96, 0.98, 1.00, 1.0),
        "belly_white": (0.98, 0.99, 1.00, 1.0),
        "spiral_black": (0.10, 0.12, 0.16, 1.0),
        "shine_white": (1.00, 1.00, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.98, 0.78, 0.14, 1.0),
        "body_dark": (0.86, 0.62, 0.09, 1.0),
        "glove_white": (0.10, 0.92, 1.00, 1.0),
        "belly_white": (1.00, 0.96, 0.76, 1.0),
        "spiral_black": (0.10, 0.92, 1.00, 1.0),
        "shine_white": (1.00, 1.00, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_belly_spiral(
    parts: list,
    mat_prefix: str,
    pal: dict,
    center_y: float,
    center_z: float,
    rx: float,
    ry: float,
    rz: float,
    max_r: float,
    turns: float = 2.8,
    direction: float = 1.0,
    tube_r: float = 0.040,
    steps: int = 40,
):
    """Esculpe a espiral preta em relevo 3D acompanhando a curvatura da barriga branca."""
    pts = []
    for i in range(steps + 1):
        t = i / float(steps)
        theta = t * turns * 2.0 * math.pi * direction + math.radians(20.0)
        r = max_r * (0.04 + 0.96 * t)
        x = r * math.cos(theta)
        z = center_z + r * math.sin(theta)
        u = x / rx
        w = (z - center_z) / rz
        inside = max(0.06, 1.0 - u * u - w * w)
        y = center_y - ry * math.sqrt(inside) - 0.016
        pts.append((x, y, z))

    for idx in range(len(pts) - 1):
        p0, p1 = pts[idx], pts[idx + 1]
        dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
        dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        if dist < 1e-5:
            continue
        mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
        horiz = math.sqrt(dx * dx + dy * dy)
        rot_x = math.atan2(horiz, dz)
        rot_z = math.atan2(dx, -dy)
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_spiral_{idx}",
                6,
                tube_r,
                dist + tube_r * 0.8,
                mid,
                rotation=(rot_x, 0.0, rot_z),
            ),
            mat_prefix,
            "spiral_black",
            pal,
        )


def build_vortexfrog(
    name: str = "Vortexfrog_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 061. Vortexfrog (Ref: Poliwhirl):
      - Corpo esférico rechonchudo azul-cobalto sem cauda e sem boca visível
      - Grandes olhos saltados de sapo em cúpulas no topo da cabeça + 2 narinas minúsculas
      - Grande barriga branca frontal com espiral preta invertida em relevo 3D
      - Braços em postura de boxe (direito erguido em soco vitorioso, esquerdo aberto) com grandes luvas brancas
      - Pernas curtas e pés ovais azuis apoiados em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Vort_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Vort_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Vort_Norm"

    parts = []

    # 1. CORPO ESFÉRICO AZUL-COBALTO
    _add_part(
        parts,
        create_icosphere("_tmp_body", 2, 0.90, (0.0, 0.0, 1.14), scale=(1.04, 0.94, 0.98)),
        mat_prefix,
        "body_blue",
        pal,
    )

    # 2. CÚPULAS DOS OLHOS SALTADOS DE SAPO NO TOPO + NARINAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_dome_{tag}",
                2,
                0.32,
                (side * 0.42, -0.34, 1.92),
                scale=(1.04, 0.96, 1.02),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.24,
                (side * 0.43, -0.56, 1.92),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(0.98, 0.48, 1.06),
            ),
            mat_prefix,
            "belly_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                2,
                0.155,
                (side * 0.43, -0.64, 1.92),
                scale=(0.92, 0.42, 1.04),
            ),
            mat_prefix,
            "spiral_black",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_shine_{tag}",
                1,
                0.058,
                (side * 0.40, -0.69, 1.99),
            ),
            mat_prefix,
            "shine_white",
            pal,
        )
        # Narina sutil entre os olhos
        _add_part(
            parts,
            create_icosphere(f"_tmp_nostril_{tag}", 1, 0.028, (side * 0.08, -0.78, 1.74)),
            mat_prefix,
            "spiral_black",
            pal,
        )

    # 3. BARRIGA BRANCA GRANDE + ESPIRAL PRETA INVERTIDA (SENTIDO ANTI-HORÁRIO COMO NO POLIWHIRL)
    belly_cy, belly_cz = -0.40, 1.06
    belly_rx, belly_ry, belly_rz = 0.69, 0.56, 0.65
    _add_part(
        parts,
        create_icosphere(
            "_tmp_belly",
            2,
            1.0,
            (0.0, belly_cy, belly_cz),
            scale=(belly_rx, belly_ry, belly_rz),
        ),
        mat_prefix,
        "belly_white",
        pal,
    )
    _add_belly_spiral(
        parts,
        mat_prefix,
        pal,
        center_y=belly_cy,
        center_z=belly_cz,
        rx=belly_rx,
        ry=belly_ry,
        rz=belly_rz,
        max_r=0.53,
        turns=2.85,
        direction=1.0,
        tube_r=0.040,
        steps=42,
    )

    # 4. BRAÇOS + GRANDES LUVAS BRANCAS DE BOXE (DIREITO ERGUIDO, ESQUERDO PRONTO PARA GOLPE)
    # Braço direito (-X) levantado em pose de boxe
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_L",
            8,
            0.18,
            0.15,
            0.52,
            (-0.96, -0.10, 1.56),
            rotation=(math.radians(-10.0), math.radians(-42.0), 0.0),
        ),
        mat_prefix,
        "body_blue",
        pal,
    )
    # Punho/manga da luva direita
    _add_part(
        parts,
        create_cylinder(
            "_tmp_cuff_L",
            8,
            0.19,
            0.16,
            (-1.12, -0.14, 1.76),
            rotation=(math.radians(-10.0), math.radians(-32.0), 0.0),
        ),
        mat_prefix,
        "glove_white",
        pal,
    )
    # Grande luva de boxe direita (-X) + polegar
    _add_part(
        parts,
        create_icosphere(
            "_tmp_glove_L",
            2,
            0.35,
            (-1.26, -0.22, 2.02),
            rotation=(0.0, math.radians(-18.0), 0.0),
            scale=(1.12, 0.94, 0.96),
        ),
        mat_prefix,
        "glove_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_thumb_L", 1, 0.16, (-1.02, -0.34, 1.94), scale=(1.05, 0.85, 0.92)),
        mat_prefix,
        "glove_white",
        pal,
    )

    # Braço esquerdo (+X) aberto na lateral
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R",
            8,
            0.18,
            0.15,
            0.52,
            (0.98, -0.10, 1.18),
            rotation=(math.radians(-8.0), math.radians(102.0), 0.0),
        ),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_cuff_R",
            8,
            0.19,
            0.16,
            (1.18, -0.14, 1.14),
            rotation=(math.radians(-8.0), math.radians(102.0), 0.0),
        ),
        mat_prefix,
        "glove_white",
        pal,
    )
    # Grande luva de boxe esquerda (+X) + polegar
    _add_part(
        parts,
        create_icosphere(
            "_tmp_glove_R",
            2,
            0.36,
            (1.44, -0.20, 1.06),
            rotation=(0.0, math.radians(14.0), 0.0),
            scale=(1.08, 0.94, 1.04),
        ),
        mat_prefix,
        "glove_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_thumb_R", 1, 0.16, (1.28, -0.36, 1.24), scale=(0.95, 0.85, 1.05)),
        mat_prefix,
        "glove_white",
        pal,
    )

    # 5. PERNAS CURTAS + PÉS OVAIS AZUIS APOIADOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_{tag}",
                8,
                0.18,
                0.15,
                0.36,
                (side * 0.42, -0.02, 0.24),
                rotation=(math.radians(6.0), math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.24,
                (side * 0.48, -0.16, 0.12),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(1.12, 1.38, 0.52),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 061. Vortexfrog lado a lado."""
    specs = [
        ("Vortexfrog_Shiny", (-11.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Vortexfrog_Normal", (-6.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Vortexfrog_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Vortexfrog_Gigante", (6.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Vortexfrog_Dourada_SuperRara", (15.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_vortexfrog(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
