"""
082_Trimagent_Magneton_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "082. Trimagent — Tríade Magnética (Ref: Magneton)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Trimagent_Shiny (1.0x - Paleta Shiny Ouro-Pálido + Pontas dos Ímãs Preto-Carvão)
  2. Trimagent_Normal (1.0x - 3 Esferas Aço-Azulado + 6 Ímãs em U Vermelho/Azul + Parafusos Phillips)
  3. Trimagent_Grande (1.35x - Normal)
  4. Trimagent_Gigante (1.85x - Normal)
  5. Trimagent_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Polos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (3 esferas icosphere subdiv=2 + 6 ímãs em U vazados + 7 parafusos)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base alinhada exatamente em `Z = 0.0` e frente/olhos apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_steel": (0.76, 0.84, 0.88, 1.0),
        "magnet_gray": (0.60, 0.63, 0.66, 1.0),
        "screw_silver": (0.72, 0.75, 0.79, 1.0),
        "screw_dark": (0.28, 0.30, 0.35, 1.0),
        "magnet_red": (0.86, 0.32, 0.30, 1.0),
        "magnet_blue": (0.22, 0.62, 0.88, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "shiny_palette": {
        "body_steel": (0.90, 0.84, 0.56, 1.0),
        "magnet_gray": (0.56, 0.55, 0.50, 1.0),
        "screw_silver": (0.76, 0.74, 0.62, 1.0),
        "screw_dark": (0.24, 0.24, 0.26, 1.0),
        "magnet_red": (0.18, 0.20, 0.22, 1.0),
        "magnet_blue": (0.22, 0.24, 0.27, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "body_steel": (0.98, 0.78, 0.14, 1.0),
        "magnet_gray": (0.86, 0.66, 0.12, 1.0),
        "screw_silver": (1.00, 0.86, 0.28, 1.0),
        "screw_dark": (0.10, 0.92, 1.00, 1.0),
        "magnet_red": (0.10, 0.92, 1.00, 1.0),
        "magnet_blue": (0.06, 0.72, 0.92, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel angular e Flat Shading."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _rot_pt(pt, rx, ry, rz):
    """Aplica rotação Euler XYZ a um ponto local (x, y, z)."""
    x, y, z = pt
    cx, sx = math.cos(rx), math.sin(rx)
    y, z = y * cx - z * sx, y * sx + z * cx
    cy, sy = math.cos(ry), math.sin(ry)
    x, z = x * cy + z * sy, -x * sy + z * cy
    cz, sz = math.cos(rz), math.sin(rz)
    x, y = x * cz - y * sz, x * sz + y * cz
    return (x, y, z)


def _add_eye(parts: list, tag: str, sphere_center: tuple, sphere_r: float, yaw_deg: float, pitch_deg: float, mat_prefix: str, pal: dict):
    """Adiciona olho circular branco com contorno escuro e pupila preta voltado na direção yaw/pitch."""
    rz = math.radians(yaw_deg)
    rx = math.radians(pitch_deg)
    ox, oy, oz = sphere_center

    def to_world(lx, ly, lz):
        wx, wy, wz = _rot_pt((lx, ly, lz), rx, 0.0, rz)
        return (ox + wx, oy + wy, oz + wz)

    eye_r = sphere_r * 0.48
    _add_part(
        parts,
        create_cylinder(
            f"_tmp_eye_rim_{tag}",
            12,
            eye_r * 1.05,
            0.045,
            to_world(0.0, -sphere_r * 0.92, 0.0),
            rotation=(math.radians(90.0) + rx, 0.0, rz),
        ),
        mat_prefix,
        "screw_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            f"_tmp_eye_w_{tag}",
            2,
            eye_r,
            to_world(0.0, -sphere_r * 0.89, 0.0),
            rotation=(rx, 0.0, rz),
            scale=(1.0, 0.34, 1.0),
        ),
        mat_prefix,
        "eye_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            f"_tmp_eye_p_{tag}",
            1,
            eye_r * 0.17,
            to_world(0.0, -sphere_r * 1.08, 0.0),
            rotation=(rx, 0.0, rz),
            scale=(1.0, 0.55, 1.0),
        ),
        mat_prefix,
        "eye_dark",
        pal,
    )


def _add_u_magnet_oriented(
    parts: list,
    tag: str,
    pivot: tuple,
    rot_deg: tuple,
    scale_m: float,
    top_mat: str,
    bot_mat: str,
    mat_prefix: str,
    pal: dict,
):
    """
    Constrói um ímã em U vazado orientado arbitrariamente em 3D.
    No espaço local, o U abre na direção +X, com polos em +Z (top_mat) e -Z (bot_mat).
    """
    rx, ry, rz = (math.radians(a) for a in rot_deg)
    px, py, pz = pivot

    def to_world(lx, ly, lz):
        wx, wy, wz = _rot_pt((lx * scale_m, ly * scale_m, lz * scale_m), rx, ry, rz)
        return (px + wx, py + wy, pz + wz)

    arch_cx = 0.38
    arch_r = 0.27
    thick = 0.19 * scale_m
    depth_y = 0.20 * scale_m

    # Pino de conexão com a esfera
    _add_part(
        parts,
        create_cube(
            f"_tmp_mag_pin_{tag}",
            (0.24 * scale_m, depth_y * 0.85, thick * 0.9),
            to_world(0.04, 0.0, 0.0),
            rotation=(rx, ry, rz),
        ),
        mat_prefix,
        "magnet_gray",
        pal,
    )

    # Arco curvo traseiro em 5 segmentos
    for idx, ang_deg in enumerate([108.0, 144.0, 180.0, 216.0, 252.0]):
        ang = math.radians(ang_deg)
        lx = arch_cx + arch_r * math.cos(ang)
        lz = arch_r * math.sin(ang)
        _add_part(
            parts,
            create_cube(
                f"_tmp_mag_arch_{tag}_{idx}",
                (thick, depth_y, 0.23 * scale_m),
                to_world(lx, 0.0, lz),
                rotation=(rx, ry + (ang - math.pi), rz),
            ),
            mat_prefix,
            "magnet_gray",
            pal,
        )

    # Braços metálicos paralelos
    for arm_tag, sz in (("top", 1.0), ("bot", -1.0)):
        _add_part(
            parts,
            create_cube(
                f"_tmp_mag_arm_{tag}_{arm_tag}",
                (0.42 * scale_m, depth_y, thick),
                to_world(0.56, 0.0, sz * arch_r),
                rotation=(rx, ry, rz),
            ),
            mat_prefix,
            "magnet_gray",
            pal,
        )

    # Pontas coloridas
    _add_part(
        parts,
        create_cube(
            f"_tmp_mag_tip_{tag}_top",
            (0.28 * scale_m, depth_y, thick),
            to_world(0.88, 0.0, arch_r),
            rotation=(rx, ry, rz),
        ),
        mat_prefix,
        top_mat,
        pal,
    )
    _add_part(
        parts,
        create_cube(
            f"_tmp_mag_tip_{tag}_bot",
            (0.28 * scale_m, depth_y, thick),
            to_world(0.88, 0.0, -arch_r),
            rotation=(rx, ry, rz),
        ),
        mat_prefix,
        bot_mat,
        pal,
    )


def _add_phillips_screw(
    parts: list,
    tag: str,
    location: tuple,
    rotation: tuple,
    head_r: float,
    shaft_len: float,
    is_top: bool,
    mat_prefix: str,
    pal: dict,
):
    """Cria parafuso Phillips facetado com rosca e fenda em cruz (+)."""
    rx, ry, rz = rotation
    ox, oy, oz = location

    def to_world(lx, ly, lz):
        wx, wy, wz = _rot_pt((lx, ly, lz), rx, ry, rz)
        return (ox + wx, oy + wy, oz + wz)

    _add_part(
        parts,
        create_cylinder(
            f"_tmp_screw_shaft_{tag}",
            8,
            head_r * 0.42,
            shaft_len,
            to_world(0.0, 0.0, shaft_len * 0.5),
            rotation=rotation,
        ),
        mat_prefix,
        "screw_dark",
        pal,
    )
    if is_top:
        for r_idx, frac in enumerate((0.28, 0.56, 0.82)):
            _add_part(
                parts,
                create_cylinder(
                    f"_tmp_screw_thr_{tag}_{r_idx}",
                    8,
                    head_r * 0.54,
                    0.04,
                    to_world(0.0, 0.0, shaft_len * frac),
                    rotation=rotation,
                ),
                mat_prefix,
                "screw_silver",
                pal,
            )

    head_z = shaft_len + head_r * 0.16
    _add_part(
        parts,
        create_icosphere(
            f"_tmp_screw_head_{tag}",
            2,
            head_r,
            to_world(0.0, 0.0, head_z),
            rotation=rotation,
            scale=(1.0, 1.0, 0.36),
        ),
        mat_prefix,
        "screw_silver",
        pal,
    )
    cross_z = head_z + head_r * 0.30
    _add_part(
        parts,
        create_cube(
            f"_tmp_screw_ca_{tag}",
            (head_r * 1.18, head_r * 0.30, head_r * 0.16),
            to_world(0.0, 0.0, cross_z),
            rotation=rotation,
        ),
        mat_prefix,
        "screw_dark",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            f"_tmp_screw_cb_{tag}",
            (head_r * 0.30, head_r * 1.18, head_r * 0.16),
            to_world(0.0, 0.0, cross_z),
            rotation=rotation,
        ),
        mat_prefix,
        "screw_dark",
        pal,
    )


def build_trimagent(
    name: str = "Trimagent_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 082. Trimagent (Ref: Magneton):
      - Tríade triangular de 3 esferas metálicas (1 topo + 2 base) unidas com firmeza
      - 3 grandes olhos circulares brancos com pupilas olhando em direções ligeiramente distintas
      - 6 ímãs em U (2 superiores inclinados para cima, 2 laterais externos, 2 inferiores pendentes)
      - 7 parafusos Phillips (1 grande no topo + 4 frontais/junções + 2 inferiores externos)
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Trim_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Trim_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Trim_Norm"

    parts = []

    # 1. TRÊS ESFERAS METÁLICAS EM TRIÂNGULO COMPACTO
    top_c = (0.0, 0.02, 1.98)
    bl_c = (-0.62, -0.02, 1.08)
    br_c = (0.62, -0.02, 1.08)

    _add_part(parts, create_icosphere("_tmp_sph_top", 2, 0.62, top_c), mat_prefix, "body_steel", pal)
    _add_part(parts, create_icosphere("_tmp_sph_bl", 2, 0.56, bl_c), mat_prefix, "body_steel", pal)
    _add_part(parts, create_icosphere("_tmp_sph_br", 2, 0.56, br_c), mat_prefix, "body_steel", pal)

    # Núcleo de conexão discreto atrás das 3 esferas para garantir 0 peças soltas sem vazar na frente
    _add_part(parts, create_icosphere("_tmp_core_bind", 1, 0.22, (0.0, 0.16, 1.40)), mat_prefix, "body_steel", pal)

    # 2. TRÊS OLHOS EXPRESSIVOS APONTANDO PARA FRENTE E LATERAIS
    _add_eye(parts, "top", top_c, 0.62, yaw_deg=0.0, pitch_deg=-4.0, mat_prefix=mat_prefix, pal=pal)
    _add_eye(parts, "bl", bl_c, 0.56, yaw_deg=-26.0, pitch_deg=-8.0, mat_prefix=mat_prefix, pal=pal)
    _add_eye(parts, "br", br_c, 0.56, yaw_deg=24.0, pitch_deg=-10.0, mat_prefix=mat_prefix, pal=pal)

    # 3. PARAFUSOS PHILLIPS (1 TOPO + 2 JUNÇÕES + 2 FRONTAIS + 2 INFERIORES EXTERNOS)
    _add_phillips_screw(
        parts,
        tag="top",
        location=(0.0, 0.02, 2.54),
        rotation=(0.0, math.radians(4.0), 0.0),
        head_r=0.28,
        shaft_len=0.24,
        is_top=True,
        mat_prefix=mat_prefix,
        pal=pal,
    )
    # Junções entre esfera superior e inferiores
    _add_phillips_screw(
        parts,
        tag="junc_L",
        location=(-0.38, -0.42, 1.56),
        rotation=(math.radians(92.0), 0.0, math.radians(-18.0)),
        head_r=0.16,
        shaft_len=0.12,
        is_top=False,
        mat_prefix=mat_prefix,
        pal=pal,
    )
    _add_phillips_screw(
        parts,
        tag="junc_R",
        location=(0.38, -0.42, 1.56),
        rotation=(math.radians(92.0), 0.0, math.radians(18.0)),
        head_r=0.16,
        shaft_len=0.12,
        is_top=False,
        mat_prefix=mat_prefix,
        pal=pal,
    )
    # Parafusos frontais nas esferas inferiores
    _add_phillips_screw(
        parts,
        tag="mid_L",
        location=(-0.36, -0.48, 1.06),
        rotation=(math.radians(96.0), 0.0, math.radians(12.0)),
        head_r=0.15,
        shaft_len=0.12,
        is_top=False,
        mat_prefix=mat_prefix,
        pal=pal,
    )
    _add_phillips_screw(
        parts,
        tag="mid_R",
        location=(0.36, -0.48, 1.06),
        rotation=(math.radians(96.0), 0.0, math.radians(-12.0)),
        head_r=0.15,
        shaft_len=0.12,
        is_top=False,
        mat_prefix=mat_prefix,
        pal=pal,
    )
    # Parafusos externos inferiores apontando para baixo-fora
    _add_phillips_screw(
        parts,
        tag="bot_L",
        location=(-0.94, -0.10, 0.72),
        rotation=(math.radians(12.0), math.radians(-136.0), 0.0),
        head_r=0.15,
        shaft_len=0.22,
        is_top=True,
        mat_prefix=mat_prefix,
        pal=pal,
    )
    _add_phillips_screw(
        parts,
        tag="bot_R",
        location=(0.94, -0.10, 0.72),
        rotation=(math.radians(12.0), math.radians(136.0), 0.0),
        head_r=0.15,
        shaft_len=0.22,
        is_top=True,
        mat_prefix=mat_prefix,
        pal=pal,
    )

    # 4. SEIS ÍMÃS EM U (2 SUPERIORES + 2 LATERAIS + 2 INFERIORES DE BASE)
    # Superior esquerdo (aberto para cima-esquerda, vermelho em cima/dentro, azul fora)
    _add_u_magnet_oriented(
        parts,
        tag="up_L",
        pivot=(-0.48, 0.04, 2.34),
        rot_deg=(0.0, -138.0, 0.0),
        scale_m=0.92,
        top_mat="magnet_blue",
        bot_mat="magnet_red",
        mat_prefix=mat_prefix,
        pal=pal,
    )
    # Superior direito (aberto para cima-direita, vermelho em cima/dentro, azul fora)
    _add_u_magnet_oriented(
        parts,
        tag="up_R",
        pivot=(0.48, 0.04, 2.34),
        rot_deg=(0.0, -42.0, 0.0),
        scale_m=0.92,
        top_mat="magnet_red",
        bot_mat="magnet_blue",
        mat_prefix=mat_prefix,
        pal=pal,
    )
    # Lateral esquerdo externo
    _add_u_magnet_oriented(
        parts,
        tag="side_L",
        pivot=(-1.08, 0.0, 1.24),
        rot_deg=(0.0, -168.0, 0.0),
        scale_m=0.88,
        top_mat="magnet_red",
        bot_mat="magnet_blue",
        mat_prefix=mat_prefix,
        pal=pal,
    )
    # Lateral direito externo
    _add_u_magnet_oriented(
        parts,
        tag="side_R",
        pivot=(1.08, 0.0, 1.24),
        rot_deg=(0.0, -12.0, 0.0),
        scale_m=0.88,
        top_mat="magnet_blue",
        bot_mat="magnet_red",
        mat_prefix=mat_prefix,
        pal=pal,
    )
    # Dois ímãs inferiores pendentes voltados para baixo/frente (formam a base em Z = 0.0)
    _add_u_magnet_oriented(
        parts,
        tag="low_L",
        pivot=(-0.38, -0.14, 0.62),
        rot_deg=(0.0, 92.0, -68.0),
        scale_m=0.82,
        top_mat="magnet_blue",
        bot_mat="magnet_red",
        mat_prefix=mat_prefix,
        pal=pal,
    )
    _add_u_magnet_oriented(
        parts,
        tag="low_R",
        pivot=(0.38, -0.14, 0.62),
        rot_deg=(0.0, 88.0, 68.0),
        scale_m=0.82,
        top_mat="magnet_blue",
        bot_mat="magnet_red",
        mat_prefix=mat_prefix,
        pal=pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 082. Trimagent lado a lado."""
    specs = [
        ("Trimagent_Shiny", (-13.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Trimagent_Normal", (-7.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Trimagent_Grande", (-1.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Trimagent_Gigante", (6.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Trimagent_Dourada_SuperRara", (17.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_trimagent(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
