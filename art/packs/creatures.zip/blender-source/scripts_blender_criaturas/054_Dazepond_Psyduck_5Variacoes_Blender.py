"""
054_Dazepond_Psyduck_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "054. Dazepond — Pato Tonto (Ref: Psyduck)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Dazepond_Shiny (1.0x - Paleta Shiny Azul-Turquesa Vibrante + Bico e Pés Creme)
  2. Dazepond_Normal (1.0x - Amarelo-Pato + Bico Largo Creme + 3 Fios Pretos + Pose de Dor de Cabeça)
  3. Dazepond_Grande (1.35x - Normal)
  4. Dazepond_Gigante (1.85x - Normal)
  5. Dazepond_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Bico Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para corpo e cabeça rechonchudos, cones 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés palmados alinhados exatamente em `Z = 0.0` e bico/rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_yellow": (0.96, 0.78, 0.34, 1.0),
        "body_shade": (0.85, 0.66, 0.26, 1.0),
        "beak_cream": (0.96, 0.92, 0.80, 1.0),
        "beak_shade": (0.86, 0.80, 0.68, 1.0),
        "hair_black": (0.12, 0.12, 0.14, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "pupil_black": (0.08, 0.08, 0.10, 1.0),
    },
    "shiny_palette": {
        "body_yellow": (0.28, 0.78, 0.95, 1.0),
        "body_shade": (0.20, 0.62, 0.82, 1.0),
        "beak_cream": (0.96, 0.92, 0.78, 1.0),
        "beak_shade": (0.84, 0.79, 0.66, 1.0),
        "hair_black": (0.12, 0.14, 0.18, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "pupil_black": (0.08, 0.08, 0.10, 1.0),
    },
    "golden_super_rare_palette": {
        "body_yellow": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.86, 0.62, 0.09, 1.0),
        "beak_cream": (0.10, 0.92, 1.00, 1.0),
        "beak_shade": (0.06, 0.68, 0.82, 1.0),
        "hair_black": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (1.00, 0.98, 0.88, 1.0),
        "pupil_black": (0.08, 0.76, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/low-poly)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_dazepond(
    name: str = "Dazepond_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 054. Dazepond (Ref: Psyduck):
      - Tronco rechonchudo em forma de pera (icosphere subdiv=2)
      - Cabeça arredondada apoiada no torso com 3 fios pretos espetados no topo
      - Bico largo, longo e achatado creme com duas narinas escuras
      - Olhos grandes ovais brancos esbugalhados com pupilas pontuais minúsculas
      - Braços/asas curvados segurando os lados da cabeça na pose clássica de dor de cabeça
      - Pés palmados creme apoiados em Z = 0.0 e cauda curta pontuda atrás
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Daze_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Daze_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Daze_Norm"

    parts = []

    # 1. TRONCO RECHONCHUDO EM FORMA DE PERA
    _add_part(
        parts,
        create_icosphere("_tmp_belly_lower", 2, 0.72, (0.0, 0.04, 0.74), scale=(1.04, 0.96, 0.96)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_chest_upper", 2, 0.58, (0.0, 0.02, 1.12), scale=(1.00, 0.90, 0.86)),
        mat_prefix,
        "body_yellow",
        pal,
    )

    # 2. CABEÇA ARREDONDADA + 3 FIOS PRETOS NO TOPO
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.62, (0.0, -0.02, 1.68), scale=(1.04, 0.94, 0.92)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # 3 fios pretos em leque no topo da cabeça
    hair_specs = [
        # (x_off, y_off, z_off, length, rot_x, rot_y)
        (-0.10, 0.04, 2.34, 0.34, math.radians(10.0), math.radians(-28.0)),
        (0.02, 0.05, 2.38, 0.40, math.radians(12.0), math.radians(6.0)),
        (0.16, 0.04, 2.32, 0.34, math.radians(10.0), math.radians(44.0)),
    ]
    for h_idx, (hx, hy, hz, hlen, rx, ry) in enumerate(hair_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_hair_{h_idx}",
                6,
                0.042,
                0.058,
                hlen,
                (hx, hy, hz),
                rotation=(rx, ry, 0.0),
                scale=(1.0, 0.65, 1.0),
            ),
            mat_prefix,
            "hair_black",
            pal,
        )

    # 3. BICO LARGO ACHATADO DE PATO COM NARINAS
    # Base do bico conectada ao rosto
    _add_part(
        parts,
        create_icosphere(
            "_tmp_beak_bridge",
            2,
            0.34,
            (0.0, -0.56, 1.48),
            rotation=(math.radians(18.0), 0.0, 0.0),
            scale=(1.06, 0.92, 0.56),
        ),
        mat_prefix,
        "beak_cream",
        pal,
    )
    # Ponta larga e achatada do bico (mais larga na frente!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_beak_front",
            2,
            0.42,
            (0.0, -0.84, 1.38),
            rotation=(math.radians(14.0), 0.0, 0.0),
            scale=(1.18, 1.02, 0.36),
        ),
        mat_prefix,
        "beak_cream",
        pal,
    )
    # Sombra/base inferior do bico
    _add_part(
        parts,
        create_icosphere(
            "_tmp_beak_under",
            2,
            0.32,
            (0.0, -0.76, 1.29),
            rotation=(math.radians(14.0), 0.0, 0.0),
            scale=(1.10, 0.96, 0.24),
        ),
        mat_prefix,
        "beak_shade",
        pal,
    )
    # Duas narinas finas no topo do bico
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_nostril_{tag}",
                (0.032, 0.09, 0.025),
                (side * 0.09, -0.68, 1.61),
                rotation=(math.radians(24.0), 0.0, math.radians(side * -14.0)),
            ),
            mat_prefix,
            "pupil_black",
            pal,
        )

    # 4. OLHOS GRANDES ESBUGALHADOS COM PUPILAS PONTUAIS (EXPRESSÃO TONTA ICÔNICA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.20,
                (side * 0.25, -0.52, 1.78),
                rotation=(0.0, 0.0, math.radians(side * -12.0)),
                scale=(1.04, 0.42, 0.84),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.036,
                (side * 0.25, -0.60, 1.78),
                scale=(1.0, 0.6, 1.0),
            ),
            mat_prefix,
            "pupil_black",
            pal,
        )

    # 5. BRAÇOS/ASAS RECHONCHUDOS SEGURANDO A CABEÇA (POSE CLÁSSICA DE DOR DE CABEÇA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Ombro / braço inferior saindo do torso
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_shoulder_{tag}",
                2,
                0.24,
                (side * 0.66, -0.02, 1.24),
                scale=(1.05, 0.85, 1.15),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # Antebraço subindo curvado até a têmpora
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_up_{tag}",
                8,
                0.22,
                0.17,
                0.66,
                (side * 0.72, -0.04, 1.56),
                rotation=(math.radians(-6.0), math.radians(side * -14.0), 0.0),
                scale=(0.95, 0.82, 1.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # Mão/palma apoiada na têmpora com 3 pontinhas de dedos
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hand_{tag}",
                2,
                0.17,
                (side * 0.60, -0.06, 1.88),
                scale=(0.82, 0.85, 1.05),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        for f_idx, (dy, dz, rx) in enumerate([(-0.08, 0.14, 24.0), (0.0, 0.17, 0.0), (0.08, 0.13, -24.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_finger_{tag}_{f_idx}",
                    5,
                    0.052,
                    0.012,
                    0.16,
                    (side * 0.56, -0.06 + dy, 1.92 + dz),
                    rotation=(math.radians(rx), math.radians(side * -24.0), 0.0),
                ),
                mat_prefix,
                "body_yellow",
                pal,
            )

    # 6. PÉS PALMADOS LARGOS CREME APOIADOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Tornozelo curto amarelo conectando o corpo ao pé
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ankle_{tag}",
                8,
                0.15,
                0.20,
                (side * 0.34, -0.04, 0.18),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )
        # Base do pé palmado
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_pad_{tag}",
                2,
                0.24,
                (side * 0.36, -0.18, 0.09),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(1.15, 1.25, 0.38),
            ),
            mat_prefix,
            "beak_cream",
            pal,
        )
        # 3 dedos palmados em leque apontando para -Y
        for t_idx, ang_deg in enumerate([-26.0, 0.0, 26.0]):
            ang = math.radians(ang_deg + side * -14.0)
            tx = side * 0.36 + math.sin(ang) * 0.24
            ty = -0.18 - math.cos(ang) * 0.26
            _add_part(
                parts,
                create_cone(
                    f"_tmp_toe_{tag}_{t_idx}",
                    5,
                    0.09,
                    0.02,
                    0.28,
                    (tx, ty, 0.075),
                    rotation=(math.radians(88.0), 0.0, ang),
                    scale=(1.0, 0.55, 1.0),
                ),
                mat_prefix,
                "beak_cream",
                pal,
            )

    # 7. CAUDA CURTA PONTUDA ATRÁS (LEVEMENTE APARECENDO NA LATERAL)
    _add_part(
        parts,
        create_cone(
            "_tmp_tail",
            6,
            0.24,
            0.03,
            0.66,
            (-0.28, 0.78, 0.58),
            rotation=(math.radians(-64.0), math.radians(-28.0), 0.0),
            scale=(0.82, 1.0, 1.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 054. Dazepond lado a lado."""
    specs = [
        ("Dazepond_Shiny", (-7.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Dazepond_Normal", (-4.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Dazepond_Grande", (-0.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Dazepond_Gigante", (4.3, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Dazepond_Dourada_SuperRara", (10.5, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_dazepond(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
