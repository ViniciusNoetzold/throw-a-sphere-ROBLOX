"""
034_Armorking_Nidoking_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "034. Armorking — Rei Blindado (Ref: Nidoking)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Armorking_Shiny (1.0x - Paleta Shiny / Shyne Azul-Safira Real + Peitoral Creme)
  2. Armorking_Normal (1.0x - Corpo Roxo-Violeta + Peitoral Creme + Grande Chifre + Cauda Blindada)
  3. Armorking_Grande (1.35x - Normal)
  4. Armorking_Gigante (1.85x - Normal)
  5. Armorking_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Orelhas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés blindados alinhados exatamente em `Z = 0.0` e frente/chifre apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Armorking_Shiny`, `Armorking_Normal`, `Armorking_Grande`,
     `Armorking_Gigante`, `Armorking_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_violet": (0.58, 0.36, 0.74, 1.0),
        "armor_cream": (0.92, 0.88, 0.74, 1.0),
        "ear_teal": (0.26, 0.52, 0.56, 1.0),
        "claw_white": (0.96, 0.96, 0.98, 1.0),
        "eye_dark": (0.14, 0.14, 0.18, 1.0),
        "mouth_pink": (0.86, 0.48, 0.56, 1.0),
    },
    "shiny_palette": {
        "body_violet": (0.28, 0.58, 0.88, 1.0),
        "armor_cream": (0.95, 0.92, 0.80, 1.0),
        "ear_teal": (0.24, 0.44, 0.64, 1.0),
        "claw_white": (0.98, 0.98, 1.00, 1.0),
        "eye_dark": (0.14, 0.14, 0.18, 1.0),
        "mouth_pink": (0.88, 0.50, 0.58, 1.0),
    },
    "golden_super_rare_palette": {
        "body_violet": (0.98, 0.78, 0.14, 1.0),
        "armor_cream": (1.00, 0.95, 0.64, 1.0),
        "ear_teal": (0.10, 0.92, 1.00, 1.0),
        "claw_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "mouth_pink": (0.92, 0.64, 0.18, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_armorking(
    name: str = "Armorking_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 034. Armorking (Ref: Nidoking):
      - Frente/chifre gigante apontando para -Y e pés blindados em Z = 0.0
      - Colosso bípede roxo-violeta com placa peitoral creme segmentada e crista dorsal de espinhos
      - Cabeça imponente com grande chifre afiado na testa, orelhas pontiagudas com interior turquesa
      - Braços grossos com garras brancas, pernas pesadas com garra frontal e cauda grossa blindada
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_King_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_King_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_King_Norm"

    parts = []

    # 1. TORSO IMPONENTE ROXO-VIOLETA + PLACA PEITORAL E BARRIGA CREME SEGMENTADA
    _add_part(
        parts,
        create_icosphere("_tmp_torso_lower", 1, 0.88, (0.0, 0.08, 0.94), scale=(0.98, 0.96, 1.02)),
        mat_prefix,
        "body_violet",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_torso_upper", (1.42, 1.08, 1.04), (0.0, 0.04, 1.62)),
        mat_prefix,
        "body_violet",
        pal,
    )
    # Placa peitoral e abdominal creme em 3 segmentos blindados
    for p_idx, (pw, py, pz, ph) in enumerate([
        (1.16, -0.54, 1.72, 0.34),
        (1.06, -0.56, 1.32, 0.30),
        (1.16, -0.60, 0.88, 0.44),
    ]):
        _add_part(
            parts,
            create_cube(f"_tmp_armor_chest_{p_idx}", (pw, 0.26, ph), (0.0, py, pz)),
            mat_prefix,
            "armor_cream",
            pal,
        )

    # Crista dorsal poderosa de 4 grandes espinhos
    for s_idx, (sy, sz, rx, depth) in enumerate([
        (0.46, 2.34, -22.0, 0.56),
        (0.68, 1.88, -38.0, 0.64),
        (0.84, 1.38, -56.0, 0.58),
        (0.90, 0.88, -70.0, 0.48),
    ]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_back_spine_{s_idx}",
                4,
                0.20,
                0.025,
                depth,
                (0.0, sy, sz),
                rotation=(math.radians(rx), 0.0, math.radians(45.0)),
            ),
            mat_prefix,
            "body_violet",
            pal,
        )

    # 2. CABEÇA DE KAIJU, GRANDE CHIFRE FRONTAL, PRESAS E ORELHAS PONTIAGUDAS TURQUESA
    _add_part(
        parts,
        create_cube("_tmp_head_main", (1.02, 0.96, 0.66), (0.0, -0.18, 2.46)),
        mat_prefix,
        "body_violet",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            4,
            0.34,
            0.16,
            0.44,
            (0.0, -0.82, 2.40),
            rotation=(math.radians(96.0), 0.0, math.radians(45.0)),
            scale=(1.15, 0.72, 1.0),
        ),
        mat_prefix,
        "body_violet",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_jaw_lower", (0.72, 0.62, 0.20), (0.0, -0.46, 2.04), rotation=(math.radians(16.0), 0.0, 0.0)),
        mat_prefix,
        "body_violet",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth_inner", (0.56, 0.42, 0.26), (0.0, -0.52, 2.20)),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # Grande chifre poderoso branco-marfim na testa (assinatura do Nidoking)
    _add_part(
        parts,
        create_cone(
            "_tmp_king_horn",
            5,
            0.18,
            0.02,
            0.88,
            (0.0, -0.88, 2.86),
            rotation=(math.radians(66.0), 0.0, 0.0),
        ),
        mat_prefix,
        "claw_white",
        pal,
    )
    # Picos da coroa atrás do chifre
    _add_part(
        parts,
        create_cone(
            "_tmp_crown_spike_mid",
            4,
            0.16,
            0.02,
            0.42,
            (0.0, -0.02, 2.94),
            rotation=(math.radians(-16.0), 0.0, math.radians(45.0)),
        ),
        mat_prefix,
        "body_violet",
        pal,
    )

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.055,
                0.01,
                0.18,
                (side * 0.24, -0.78, 2.18),
                rotation=(math.radians(180.0), 0.0, 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_white_{tag}", (0.16, 0.26, 0.18), (side * 0.44, -0.58, 2.52)),
            mat_prefix,
            "claw_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_dark_{tag}", (0.17, 0.14, 0.15), (side * 0.46, -0.64, 2.52)),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Grandes orelhas pontudas com interior turquesa escuro
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_outer_{tag}",
                4,
                0.42,
                0.05,
                1.08,
                (side * 0.72, -0.06, 2.96),
                rotation=(math.radians(-12.0), math.radians(side * 34.0), math.radians(45.0)),
                scale=(1.15, 0.46, 1.0),
            ),
            mat_prefix,
            "body_violet",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_teal_{tag}",
                4,
                0.28,
                0.04,
                0.76,
                (side * 0.72, -0.13, 2.92),
                rotation=(math.radians(-12.0), math.radians(side * 34.0), math.radians(45.0)),
                scale=(1.04, 0.36, 1.0),
            ),
            mat_prefix,
            "ear_teal",
            pal,
        )

    # 3. BRAÇOS GROSSOS COM GARRAS + PERNAS BLINDADAS EM Z = 0.0 + CAUDA PODEROSA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(f"_tmp_shoulder_{tag}", 1, 0.38, (side * 0.88, 0.0, 1.88)),
            mat_prefix,
            "body_violet",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_arm_{tag}",
                6,
                0.28,
                0.86,
                (side * 1.18, -0.26, 1.56),
                rotation=(math.radians(52.0), math.radians(side * 30.0), 0.0),
            ),
            mat_prefix,
            "body_violet",
            pal,
        )
        for c_idx, dz in enumerate((-0.10, 0.0, 0.10)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{tag}_{c_idx}",
                    4,
                    0.07,
                    0.015,
                    0.26,
                    (side * 1.42, -0.68, 1.32 + dz),
                    rotation=(math.radians(96.0), 0.0, math.radians(side * -18.0)),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

        # Pernas pesadas + garra única frontal grande em Z = 0.0
        _add_part(
            parts,
            create_cube(f"_tmp_thigh_{tag}", (0.60, 0.72, 0.76), (side * 0.72, 0.04, 0.58)),
            mat_prefix,
            "body_violet",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{tag}", (0.58, 0.68, 0.24), (side * 0.74, -0.10, 0.12)),
            mat_prefix,
            "body_violet",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_foot_claw_{tag}",
                4,
                0.18,
                0.03,
                0.42,
                (side * 0.74, -0.60, 0.11),
                rotation=(math.radians(90.0), 0.0, math.radians(45.0)),
                scale=(1.1, 0.75, 1.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # Grande cauda blindada erguida lateralmente para a direita
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_1",
            6,
            0.40,
            0.28,
            1.04,
            (0.42, 0.96, 0.48),
            rotation=(math.radians(-78.0), 0.0, math.radians(-30.0)),
        ),
        mat_prefix,
        "body_violet",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_2",
            6,
            0.28,
            0.14,
            0.96,
            (1.12, 1.24, 0.78),
            rotation=(math.radians(-48.0), math.radians(28.0), math.radians(-52.0)),
        ),
        mat_prefix,
        "body_violet",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_3",
            6,
            0.14,
            0.03,
            0.78,
            (1.48, 1.32, 1.38),
            rotation=(math.radians(-14.0), math.radians(16.0), 0.0),
        ),
        mat_prefix,
        "body_violet",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 034. Armorking lado a lado."""
    specs = [
        ("Armorking_Shiny", (-10.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Armorking_Normal", (-5.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Armorking_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Armorking_Gigante", (5.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Armorking_Dourada_SuperRara", (14.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_armorking(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
