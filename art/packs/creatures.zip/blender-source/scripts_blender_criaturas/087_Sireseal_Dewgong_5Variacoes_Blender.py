"""
087_Sireseal_Dewgong_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "087. Sireseal — Leão-Marinho Polar (Ref: Dewgong)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Sireseal_Shiny (1.0x - Paleta Shiny Branco-Marfim Dourado + Sombras Creme-Âmbar)
  2. Sireseal_Normal (1.0x - Corpo Esbelto Branco-Pérola em Curva Elegante + Chifre + Cauda em Véu)
  3. Sireseal_Grande (1.35x - Normal)
  4. Sireseal_Gigante (1.85x - Normal)
  5. Sireseal_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Chifre e Pontas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (corpo hidrodinâmico esbelto em S, longas nadadeiras em véu, cauda ondulada)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base alinhada exatamente em `Z = 0.0` e cabeça/rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_pearl": (0.94, 0.96, 1.00, 1.0),
        "body_ice": (0.78, 0.84, 0.94, 1.0),
        "eye_dark": (0.14, 0.11, 0.10, 1.0),
        "eye_warm": (0.34, 0.24, 0.18, 1.0),
        "shine_white": (1.00, 1.00, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_pearl": (0.99, 0.95, 0.78, 1.0),
        "body_ice": (0.88, 0.82, 0.62, 1.0),
        "eye_dark": (0.14, 0.11, 0.10, 1.0),
        "eye_warm": (0.36, 0.26, 0.18, 1.0),
        "shine_white": (1.00, 1.00, 0.96, 1.0),
    },
    "golden_super_rare_palette": {
        "body_pearl": (0.98, 0.78, 0.14, 1.0),
        "body_ice": (0.84, 0.62, 0.10, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "eye_warm": (0.06, 0.66, 0.88, 1.0),
        "shine_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel angular e Flat Shading."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_sireseal(
    name: str = "Sireseal_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 087. Sireseal (Ref: Dewgong):
      - Corpo hidrodinâmico esbelto branco-pérola em elegante arco em C/S
      - Pescoço erguido sustentando cabeça serena com chifre pontudo, olhos meigos e 2 presinhas delicadas
      - Duas longas nadadeiras dianteiras esvoaçantes em véu ondulado
      - Cauda longa que sobe em arco atrás e se abre em um grande leque ondulado (véu de sereia)
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Sire_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Sire_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Sire_Norm"

    parts = []

    # 1. CORPO HIDRODINÂMICO ESBELTO EM ARCO ELEGANTE (CABEÇA ALTA -> BARRIGA BAIXA -> CAUDA EM ARCO)
    spine_segments = [
        # (rad, loc, rot_deg, scale)
        (0.46, (-0.18, -0.58, 1.48), (18.0, 0.0, 8.0), (0.86, 0.92, 1.24)),   # Pescoço superior
        (0.60, (-0.14, -0.34, 0.98), (34.0, 0.0, 6.0), (0.94, 1.10, 1.12)),   # Peito elegante
        (0.64, (-0.02, 0.22, 0.64), (10.0, 0.0, -4.0), (0.94, 1.26, 0.86)),   # Barriga (base Z = 0)
        (0.54, (0.20, 0.82, 0.68), (-18.0, 0.0, -14.0), (0.86, 1.18, 0.82)),  # Quadril
        (0.42, (0.44, 1.26, 0.98), (-46.0, 0.0, -18.0), (0.78, 1.16, 0.78)),  # Arco traseiro baixo
        (0.30, (0.56, 1.48, 1.42), (-74.0, 0.0, -14.0), (0.76, 1.14, 0.76)),  # Arco traseiro médio
        (0.20, (0.50, 1.40, 1.84), (-118.0, 0.0, -10.0), (0.78, 1.10, 0.78)), # Raiz da cauda virando para frente
    ]
    for s_idx, (rad, loc, rot_d, sc) in enumerate(spine_segments):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_spine_{s_idx}",
                2,
                rad,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
                scale=sc,
            ),
            mat_prefix,
            "body_pearl",
            pal,
        )

    # 2. GRANDE CAUDA EM LEQUE ONDULADO (VÉU DE SEREIA VISÍVEL ACIMA DO DORSO)
    tail_fan_ribs = [
        ("top", (0.28, 1.24, 2.28), (12.0, -28.0, -14.0), (0.86, 0.22, 1.56), "body_pearl"),
        ("mid", (0.14, 1.14, 2.02), (18.0, -56.0, -18.0), (0.94, 0.22, 1.62), "body_pearl"),
        ("low", (0.22, 1.18, 1.76), (22.0, -82.0, -14.0), (0.78, 0.22, 1.28), "body_ice"),
    ]
    for tag, loc, rot_d, sc, mkey in tail_fan_ribs:
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_tail_veil_{tag}",
                2,
                0.34,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
                scale=sc,
            ),
            mat_prefix,
            mkey,
            pal,
        )
    # Borda ondulada de 4 pontas suaves no véu da cauda
    for r_idx, loc in enumerate([
        (0.10, 1.16, 2.62),
        (-0.18, 1.04, 2.34),
        (-0.24, 1.02, 1.98),
        (-0.08, 1.08, 1.68),
    ]):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_tail_ruffle_{r_idx}",
                1,
                0.18,
                loc,
                scale=(1.10, 0.28, 0.90),
            ),
            mat_prefix,
            "body_ice" if r_idx == 3 else "body_pearl",
            pal,
        )

    # 3. CABEÇA NOBRE SERENA + CHIFRE AFIADO + OLHOS GENTIS + FOCINHO + PRESINHAS
    head_c = (-0.22, -0.78, 1.88)
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.48, head_c, scale=(0.98, 1.06, 0.98)),
        mat_prefix,
        "body_pearl",
        pal,
    )
    # Chifre pontudo marfim no alto da testa
    _add_part(
        parts,
        create_cone(
            "_tmp_horn",
            6,
            0.12,
            0.015,
            0.38,
            (-0.22, -0.74, 2.44),
            rotation=(math.radians(-16.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_pearl" if variant != "DouradaSuperRara" else "eye_dark",
        pal,
    )
    # Focinho suave branco-pérola (sem almofada bege, todo pérola como na arte!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_snout",
            2,
            0.28,
            (-0.24, -1.20, 1.78),
            scale=(1.04, 1.18, 0.68),
        ),
        mat_prefix,
        "body_pearl",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_jaw",
            2,
            0.22,
            (-0.24, -1.12, 1.66),
            scale=(0.92, 0.96, 0.56),
        ),
        mat_prefix,
        "body_ice",
        pal,
    )
    # Nariz pequeno preto delicado
    _add_part(
        parts,
        create_icosphere(
            "_tmp_nose",
            1,
            0.068,
            (-0.24, -1.46, 1.84),
            scale=(1.25, 0.72, 0.55),
        ),
        mat_prefix,
        "eye_dark",
        pal,
    )
    # Duas presinhas delicadas apontando para baixo
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                5,
                0.055,
                0.012,
                0.18,
                (-0.24 + side * 0.18, -1.32, 1.60),
                rotation=(math.radians(172.0), math.radians(side * 10.0), 0.0),
            ),
            mat_prefix,
            "shine_white",
            pal,
        )

    # Olhos grandes expressivos serenos com brilho branco
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.13,
                (-0.22 + side * 0.27, -1.14, 1.98),
                rotation=(0.0, 0.0, math.radians(side * -16.0)),
                scale=(0.76, 0.54, 1.18),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_w_{tag}",
                1,
                0.072,
                (-0.22 + side * 0.27, -1.19, 1.92),
                scale=(0.72, 0.45, 0.65),
            ),
            mat_prefix,
            "eye_warm",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_sh_{tag}",
                1,
                0.052,
                (-0.22 + side * 0.25, -1.21, 2.04),
                scale=(0.78, 0.45, 1.00),
            ),
            mat_prefix,
            "shine_white",
            pal,
        )

    # 4. DUAS LONGAS NADADEIRAS DIANTEIRAS EM VÉU ONDULADO (100% ANCORADAS AO PEITO!)
    # Nadadeira direita (+X, grande e esvoaçante para fora/baixo)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_fin_R_base",
            2,
            0.38,
            (0.42, -0.20, 0.66),
            rotation=(math.radians(-14.0), math.radians(26.0), math.radians(-18.0)),
            scale=(1.54, 0.88, 0.28),
        ),
        mat_prefix,
        "body_pearl",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_fin_R_tip",
            2,
            0.34,
            (0.92, -0.08, 0.40),
            rotation=(math.radians(-16.0), math.radians(32.0), math.radians(-24.0)),
            scale=(1.38, 0.94, 0.24),
        ),
        mat_prefix,
        "body_ice",
        pal,
    )
    # Nadadeira esquerda (-X, erguida graciosamente e 100% contínua com o peito!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_fin_L_base",
            2,
            0.34,
            (-0.56, -0.34, 0.94),
            rotation=(math.radians(8.0), math.radians(22.0), math.radians(16.0)),
            scale=(1.44, 0.80, 0.28),
        ),
        mat_prefix,
        "body_pearl",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_fin_L_tip",
            2,
            0.29,
            (-0.90, -0.26, 1.08),
            rotation=(math.radians(10.0), math.radians(26.0), math.radians(20.0)),
            scale=(1.26, 0.86, 0.24),
        ),
        mat_prefix,
        "body_ice",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 087. Sireseal lado a lado."""
    specs = [
        ("Sireseal_Shiny", (-10.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Sireseal_Normal", (-6.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Sireseal_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Sireseal_Gigante", (6.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Sireseal_Dourada_SuperRara", (14.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_sireseal(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
