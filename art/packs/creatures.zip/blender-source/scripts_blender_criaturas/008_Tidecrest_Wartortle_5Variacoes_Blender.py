"""
008_Tidecrest_Wartortle_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "008. Tidecrest — Tartaruga Ondulada (Ref: Wartortle)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Tidecrest_Shiny (1.0x - Paleta Shiny / Shyne Azul-Violeta + Casco Esmeralda + Orelhas-Asas)
  2. Tidecrest_Normal (1.0x - Corpo Azul-Cobalto + Orelhas e Cauda Branco-Espuma)
  3. Tidecrest_Grande (1.35x - Normal)
  4. Tidecrest_Gigante (1.85x - Normal)
  5. Tidecrest_Dourada_SuperRara (2.25x - Ouro Reluzente + Plumas Platina-Ouro + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cilindros 6-8 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.017`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base dos pés alinhada exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Tidecrest_Shiny`, `Tidecrest_Normal`, `Tidecrest_Grande`,
     `Tidecrest_Gigante`, `Tidecrest_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.017,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_cobalt": (0.28, 0.56, 0.88, 1.0),
        "foam_white": (0.90, 0.96, 1.00, 1.0),
        "shell_brown": (0.48, 0.28, 0.16, 1.0),
        "shell_rim": (0.95, 0.96, 0.98, 1.0),
        "plastron_cream": (0.95, 0.86, 0.54, 1.0),
        "eyes_ruby": (0.58, 0.20, 0.18, 1.0),
        "brow_dark": (0.14, 0.28, 0.52, 1.0),
        "claws_white": (0.97, 0.98, 0.99, 1.0),
    },
    "shiny_palette": {
        "body_cobalt": (0.48, 0.44, 0.88, 1.0),
        "foam_white": (0.92, 0.94, 1.00, 1.0),
        "shell_brown": (0.20, 0.70, 0.34, 1.0),
        "shell_rim": (0.96, 0.98, 0.97, 1.0),
        "plastron_cream": (0.98, 0.90, 0.60, 1.0),
        "eyes_ruby": (0.76, 0.20, 0.28, 1.0),
        "brow_dark": (0.26, 0.22, 0.56, 1.0),
        "claws_white": (0.98, 0.98, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "body_cobalt": (0.98, 0.78, 0.14, 1.0),
        "foam_white": (1.00, 0.96, 0.76, 1.0),
        "shell_brown": (0.74, 0.48, 0.08, 1.0),
        "shell_rim": (1.00, 0.97, 0.84, 1.0),
        "plastron_cream": (1.00, 0.92, 0.50, 1.0),
        "eyes_ruby": (0.10, 0.92, 1.00, 1.0),
        "brow_dark": (0.70, 0.46, 0.06, 1.0),
        "claws_white": (1.00, 0.98, 0.88, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_tidecrest(
    name: str = "Tidecrest_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 008. Tidecrest (Ref: Wartortle):
      - Frente apontando para -Y e base dos pés em Z = 0.0
      - Casco dorsal escuro com aro branco e plastrão frontal creme
      - Cabeça feroz com 2 presas brancas e 2 grandes orelhas-asas de espuma branca
      - Braços com 3 garras brancas afiadas e grande cauda felpuda em dupla espiral branca
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Tide_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Tide_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Tide"

    parts = []

    # 1. CASCO ROBUSTO (PLASTRÃO CREME + ARO BRANCO + CARAPAÇA DORSAL)
    _add_part(
        parts,
        create_cube("_tmp_torso_core", (1.06, 0.82, 1.18), (0.0, 0.0, 1.06)),
        mat_prefix,
        "plastron_cream",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_plastron_front", (0.88, 0.16, 1.06), (0.0, -0.42, 1.06)),
        mat_prefix,
        "plastron_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_shell_rim", 1, 0.72, (0.0, 0.08, 1.06), scale=(0.88, 0.54, 0.98)),
        mat_prefix,
        "shell_rim",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_shell_back", 1, 0.74, (0.0, 0.26, 1.06), scale=(0.84, 0.60, 0.96)),
        mat_prefix,
        "shell_brown",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_shell_ridge", (0.68, 0.26, 0.82), (0.0, 0.54, 1.06)),
        mat_prefix,
        "shell_brown",
        pal,
    )

    # 2. PERNAS MUSCULOSAS (Z = 0) + BRAÇOS FORTES COM 3 GARRAS BRANCAS
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_thigh_{side_idx}",
                (0.48, 0.54, 0.58),
                (sx * 0.48, -0.02, 0.54),
                (math.radians(6), 0.0, math.radians(sx * -8)),
            ),
            mat_prefix,
            "body_cobalt",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{side_idx}", (0.46, 0.58, 0.30), (sx * 0.52, -0.10, 0.17)),
            mat_prefix,
            "body_cobalt",
            pal,
        )
        for toe_i, cx_off in enumerate([-0.12, 0.0, 0.12]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_toe_{side_idx}_{toe_i}",
                    4,
                    0.060,
                    0.012,
                    0.20,
                    (sx * 0.52 + cx_off, -0.42, 0.08),
                    (math.radians(86), 0.0, 0.0),
                ),
                mat_prefix,
                "body_cobalt",
                pal,
            )

        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_{side_idx}",
                6,
                0.22,
                0.17,
                0.68,
                (sx * 0.72, -0.12, 1.32),
                (math.radians(16), math.radians(sx * 72), 0.0),
            ),
            mat_prefix,
            "body_cobalt",
            pal,
        )
        for claw_i, fy_off in enumerate([-0.06, 0.0, 0.06]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{side_idx}_{claw_i}",
                    4,
                    0.048,
                    0.010,
                    0.16,
                    (sx * 1.04, -0.20 + fy_off, 1.44),
                    (math.radians(16), math.radians(sx * 74), 0.0),
                ),
                mat_prefix,
                "claws_white",
                pal,
            )

    # 3. CABEÇA FEROZ (-Y), PRESAS BRANCAS E 2 GRANDES ORELHAS-ASAS DE ESPUMA BRANCA
    _add_part(
        parts,
        create_icosphere("_tmp_cranium", 1, 0.64, (0.0, -0.10, 2.04), scale=(0.98, 0.96, 0.96)),
        mat_prefix,
        "body_cobalt",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_face_block", (1.04, 0.92, 0.80), (0.0, -0.12, 1.98)),
        mat_prefix,
        "body_cobalt",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout", (0.88, 0.40, 0.36), (0.0, -0.52, 1.82)),
        mat_prefix,
        "body_cobalt",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_smile_line", (0.72, 0.08, 0.05), (0.0, -0.71, 1.77)),
        mat_prefix,
        "brow_dark",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{side_idx}",
                (0.26, 0.12, 0.07),
                (sx * 0.32, -0.60, 2.15),
                (0.0, math.radians(sx * 16), math.radians(sx * -16)),
            ),
            mat_prefix,
            "brow_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_sclera_{side_idx}",
                (0.24, 0.10, 0.24),
                (sx * 0.32, -0.58, 2.02),
                (0.0, 0.0, math.radians(sx * -14)),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_iris_{side_idx}",
                (0.15, 0.08, 0.19),
                (sx * 0.31, -0.61, 2.01),
                (0.0, 0.0, math.radians(sx * -14)),
            ),
            mat_prefix,
            "eyes_ruby",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{side_idx}",
                4,
                0.042,
                0.008,
                0.10,
                (sx * 0.28, -0.71, 1.72),
                (math.radians(180), 0.0, 0.0),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )

        # Duas grandes orelhas em forma de asas de espuma branca
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_wing_main_{side_idx}",
                4,
                0.24,
                0.05,
                0.82,
                (sx * 0.56, -0.02, 2.52),
                (math.radians(-10), math.radians(sx * 24), 0.0),
                scale=(0.38, 1.0, 1.0),
            ),
            mat_prefix,
            "foam_white",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_wing_side_{side_idx}",
                4,
                0.18,
                0.04,
                0.58,
                (sx * 0.66, 0.04, 2.40),
                (math.radians(-12), math.radians(sx * 36), 0.0),
                scale=(0.35, 1.0, 1.0),
            ),
            mat_prefix,
            "foam_white",
            pal,
        )

    # 4. GRANDE CAUDA FELPUDA ENROLADA EM DUPLA ONDA DE ESPUMA (+Y)
    _add_part(
        parts,
        create_cone("_tmp_tail_base", 6, 0.30, 0.38, 0.82, (0.0, 0.66, 0.72), (math.radians(-58), 0.0, 0.0)),
        mat_prefix,
        "foam_white",
        pal,
    )
    _add_part(
        parts,
        create_cylinder("_tmp_tail_wave_top", 8, 0.46, 0.38, (0.0, 1.08, 1.38), (0.0, math.radians(90), 0.0)),
        mat_prefix,
        "foam_white",
        pal,
    )
    _add_part(
        parts,
        create_cylinder("_tmp_tail_wave_core", 6, 0.26, 0.42, (0.0, 1.12, 1.36), (0.0, math.radians(90), 0.0)),
        mat_prefix,
        "foam_white",
        pal,
    )
    _add_part(
        parts,
        create_cylinder("_tmp_tail_wave_low", 8, 0.36, 0.36, (0.0, 1.18, 0.82), (0.0, math.radians(90), 0.0)),
        mat_prefix,
        "foam_white",
        pal,
    )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """
    Gera lado a lado os 5 modelos do 008. Tidecrest (Wartortle):
      1. Shiny (1.0x) | 2. Normal (1.0x) | 3. Grande (1.35x) | 4. Gigante (1.85x) | 5. Dourada Super Rara (2.25x)
    """
    build_tidecrest("Tidecrest_Shiny", location=(-6.8, 0.0, 0.0), scale=CONFIG["scales"]["Shiny"], variant="Shiny")
    build_tidecrest("Tidecrest_Normal", location=(-4.0, 0.0, 0.0), scale=CONFIG["scales"]["Normal"], variant="Normal")
    build_tidecrest("Tidecrest_Grande", location=(-0.9, 0.0, 0.0), scale=CONFIG["scales"]["Grande"], variant="Normal")
    build_tidecrest("Tidecrest_Gigante", location=(2.9, 0.0, 0.0), scale=CONFIG["scales"]["Gigante"], variant="Normal")
    build_tidecrest(
        "Tidecrest_Dourada_SuperRara",
        location=(8.1, 0.0, 0.0),
        scale=CONFIG["scales"]["DouradaSuperRara"],
        variant="DouradaSuperRara",
    )


if __name__ == "__main__":
    generate_variations()
    print("008. Tidecrest (5 variações: Shiny, Normal, Grande, Gigante e Dourada Super Rara) gerado com sucesso!")
