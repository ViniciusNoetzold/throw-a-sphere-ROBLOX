"""
121_Prismstar_Starmie_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "121. Prismstar — Estrela Cósmica (Ref: Starmie)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Prismstar_Shiny (1.0x - Paleta Shiny Azul-Safira Cósmico + Coroa Ouro-Limão + Gema Rubi)
  2. Prismstar_Normal (1.0x - Duas Estrelas Roxo-Ametista em Defasagem + Coroa 8-Pontas Ouro + Gema Rubi Octagonal)
  3. Prismstar_Grande (1.35x - Normal)
  4. Prismstar_Gigante (1.85x - Normal)
  5. Prismstar_Dourada_SuperRara (2.25x - Ouro Reluzente + Gema Octagonal Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada prismática (10 braços em 2 camadas de cones 4-lados, moldura dourada de 8 garras, cristal octogonal)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pontas inferiores apoiadas exatamente em `Z = 0.0` e gema prismática apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "star_purple": (0.56, 0.54, 0.72, 1.0),
        "star_back": (0.44, 0.42, 0.62, 1.0),
        "gold_crown": (0.94, 0.84, 0.40, 1.0),
        "gem_ruby": (0.90, 0.34, 0.44, 1.0),
        "gem_core": (0.82, 0.20, 0.32, 1.0),
        "gem_shine": (1.00, 0.96, 0.98, 1.0),
    },
    "shiny_palette": {
        "star_purple": (0.24, 0.48, 0.88, 1.0),
        "star_back": (0.16, 0.34, 0.72, 1.0),
        "gold_crown": (0.86, 0.90, 0.38, 1.0),
        "gem_ruby": (0.96, 0.24, 0.44, 1.0),
        "gem_core": (0.82, 0.14, 0.32, 1.0),
        "gem_shine": (1.00, 0.97, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "star_purple": (0.98, 0.78, 0.14, 1.0),
        "star_back": (0.84, 0.60, 0.08, 1.0),
        "gold_crown": (1.00, 0.92, 0.52, 1.0),
        "gem_ruby": (0.10, 0.92, 1.00, 1.0),
        "gem_core": (0.04, 0.64, 0.82, 1.0),
        "gem_shine": (1.00, 1.00, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_prismstar(
    name: str = "Prismstar_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de 121. Prismstar (Ref: Starmie):
      - Estrela frontal de 5 pontas roxo-ametista com cristas centrais nítidas
      - Segunda estrela traseira de 5 pontas defasada em 36° (criando silhueta icônica de 10 pontas)
      - Coroa dourada espessa no núcleo com 8 garras simétricas radiais
      - Grande gema rubi octogonal lapidada no centro (-Y) com brilho prismático branco
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Pst_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Pst_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Pst_Norm"

    parts = []
    center_z = 1.32

    # 1. ESTRELA FRONTAL DE 5 PONTAS (0°, 72°, 144°, 216°, 288°)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_front_hub",
            2,
            0.58,
            (0.0, -0.06, center_z),
            scale=(1.04, 0.56, 1.04),
        ),
        mat_prefix,
        "star_purple",
        pal,
    )
    for i in range(5):
        ang = math.radians(i * 72.0)
        ax = 0.68 * math.sin(ang)
        az = center_z + 0.68 * math.cos(ang)
        _add_part(
            parts,
            create_cone(
                f"_tmp_front_arm_{i}",
                4,
                0.44,
                0.04,
                1.26,
                (ax, -0.06, az),
                rotation=(0.0, ang, 0.0),
                scale=(1.0, 0.58, 1.0),
            ),
            mat_prefix,
            "star_purple",
            pal,
        )

    # 2. ESTRELA TRASEIRA DE 5 PONTAS DEFASADA EM 36° (36°, 108°, 180°, 252°, 324°)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_back_hub",
            2,
            0.56,
            (0.0, 0.28, center_z),
            scale=(1.02, 0.54, 1.02),
        ),
        mat_prefix,
        "star_back",
        pal,
    )
    for i in range(5):
        ang = math.radians(36.0 + i * 72.0)
        bx = 0.66 * math.sin(ang)
        bz = center_z + 0.66 * math.cos(ang)
        _add_part(
            parts,
            create_cone(
                f"_tmp_back_arm_{i}",
                4,
                0.42,
                0.04,
                1.22,
                (bx, 0.28, bz),
                rotation=(0.0, ang, 0.0),
                scale=(1.0, 0.56, 1.0),
            ),
            mat_prefix,
            "star_back",
            pal,
        )

    # 3. ARMAÇÃO DOURADA COM 8 GARRAS RADIAIS AO REDOR DA GEMA
    _add_part(
        parts,
        create_cylinder(
            "_tmp_gold_bezel_base",
            8,
            0.52,
            0.22,
            (0.0, -0.34, center_z),
            rotation=(math.radians(90.0), 0.0, math.radians(22.5)),
        ),
        mat_prefix,
        "gold_crown",
        pal,
    )
    for i in range(8):
        ang = math.radians(i * 45.0)
        px = 0.56 * math.sin(ang)
        pz = center_z + 0.56 * math.cos(ang)
        _add_part(
            parts,
            create_cone(
                f"_tmp_crown_prong_{i}",
                4,
                0.13,
                0.085,
                0.34,
                (px, -0.36, pz),
                rotation=(0.0, ang, 0.0),
                scale=(1.0, 0.72, 1.0),
            ),
            mat_prefix,
            "gold_crown",
            pal,
        )

    # 4. GRANDE GEMA RUBI OCTOGONAL LAPIDADA EM CAMADAS + FAIXA DE BRILHO
    _add_part(
        parts,
        create_cone(
            "_tmp_gem_outer",
            8,
            0.41,
            0.28,
            0.22,
            (0.0, -0.48, center_z),
            rotation=(math.radians(90.0), 0.0, math.radians(22.5)),
        ),
        mat_prefix,
        "gem_core",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_gem_table",
            8,
            0.27,
            0.08,
            (0.0, -0.58, center_z),
            rotation=(math.radians(90.0), 0.0, math.radians(22.5)),
        ),
        mat_prefix,
        "gem_ruby",
        pal,
    )
    # Brilho diagonal branco característico na face da gema
    _add_part(
        parts,
        create_cube(
            "_tmp_gem_glint",
            (0.32, 0.04, 0.09),
            (-0.04, -0.63, center_z + 0.07),
            rotation=(0.0, math.radians(-38.0), 0.0),
        ),
        mat_prefix,
        "gem_shine",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 121. Prismstar lado a lado."""
    specs = [
        ("Prismstar_Shiny", (-11.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Prismstar_Normal", (-6.9, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Prismstar_Grande", (-2.0, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Prismstar_Gigante", (4.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Prismstar_Dourada_SuperRara", (12.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_prismstar(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
