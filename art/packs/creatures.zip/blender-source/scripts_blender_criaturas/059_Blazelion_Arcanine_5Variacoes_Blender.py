"""
059_Blazelion_Arcanine_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "059. Blazelion — Lenda Flamejante (Ref: Arcanine)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Blazelion_Shiny (1.0x - Paleta Shiny Pelagem Dourada-Âmbar + Juba Marfim + Listras Negras)
  2. Blazelion_Normal (1.0x - Felino-Canídeo Laranja-Fogo + Juba Monumental Creme + Listras Tigre + Pluma Gigante)
  3. Blazelion_Grande (1.35x - Normal)
  4. Blazelion_Gigante (1.85x - Normal)
  5. Blazelion_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Máscara e Listras Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + juba monumental e plumas em cones 5-6 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Quatro patas leoninas alinhadas exatamente em `Z = 0.0` e rosto/juba apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "fur_orange": (0.93, 0.54, 0.24, 1.0),
        "fur_shade": (0.80, 0.42, 0.16, 1.0),
        "mane_cream": (0.95, 0.89, 0.74, 1.0),
        "mane_shade": (0.84, 0.77, 0.62, 1.0),
        "stripe_black": (0.20, 0.23, 0.26, 1.0),
        "ear_inner": (0.76, 0.68, 0.58, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.16, 0.13, 0.12, 1.0),
        "fang_white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "fur_orange": (0.96, 0.78, 0.20, 1.0),
        "fur_shade": (0.84, 0.64, 0.12, 1.0),
        "mane_cream": (0.99, 0.96, 0.86, 1.0),
        "mane_shade": (0.88, 0.84, 0.72, 1.0),
        "stripe_black": (0.20, 0.23, 0.26, 1.0),
        "ear_inner": (0.82, 0.76, 0.62, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.16, 0.13, 0.12, 1.0),
        "fang_white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "fur_orange": (0.98, 0.78, 0.14, 1.0),
        "fur_shade": (0.86, 0.62, 0.09, 1.0),
        "mane_cream": (1.00, 0.95, 0.64, 1.0),
        "mane_shade": (0.92, 0.82, 0.40, 1.0),
        "stripe_black": (0.10, 0.92, 1.00, 1.0),
        "ear_inner": (0.08, 0.72, 0.88, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "fang_white": (1.00, 0.99, 0.94, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_blazelion(
    name: str = "Blazelion_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 059. Blazelion (Ref: Arcanine):
      - Grande felino-canídeo lendário quadrúpede laranja-fogo com listras pretas marcantes
      - Juba monumental arrepiada creme envolvendo toda a cabeça, bochechas, pescoço e peito
      - Máscara laranja característica ao redor dos olhos nobres + sorriso com 2 presinhas + orelhas pontudas
      - Tufos volumosos de pelo creme nas 4 patas (especialmente grandes atrás dos tornozelos)
      - Cauda em pluma gigantesca creme arqueada acima do dorso e 4 patas fortes em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Blaze_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Blaze_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Blaze_Norm"

    parts = []

    # 1. TRONCO ATLÉTICO PODEROSO + LISTRAS DE TIGRE PRETAS
    _add_part(
        parts,
        create_icosphere("_tmp_torso_chest", 2, 0.64, (0.0, -0.34, 1.32), scale=(0.94, 1.12, 0.98)),
        mat_prefix,
        "fur_orange",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_torso_mid", 2, 0.56, (0.0, 0.30, 1.24), scale=(0.90, 1.22, 0.90)),
        mat_prefix,
        "fur_orange",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_torso_rump", 2, 0.58, (0.0, 0.88, 1.22), scale=(0.94, 1.06, 0.94)),
        mat_prefix,
        "fur_orange",
        pal,
    )
    # Listras de tigre pretas ousadas no dorso e flancos
    for s_idx, (sy, sz, rx_d) in enumerate([(0.06, 1.32, 16.0), (0.42, 1.28, -14.0), (0.78, 1.26, -24.0)]):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_body_stripe_{s_idx}",
                1,
                0.54,
                (0.0, sy, sz),
                rotation=(math.radians(rx_d), 0.0, 0.0),
                scale=(1.02, 0.22, 0.88),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )

    # 2. JUBA MONUMENTAL CREME (PEITO, PESCOÇO, COROA DA CABEÇA E BOCHECHAS)
    _add_part(
        parts,
        create_icosphere("_tmp_chest_mane", 2, 0.68, (0.0, -0.68, 1.44), scale=(1.06, 0.82, 1.06)),
        mat_prefix,
        "mane_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_head_mane_core", 2, 0.64, (0.0, -0.78, 2.08), scale=(1.10, 0.94, 1.02)),
        mat_prefix,
        "mane_cream",
        pal,
    )
    # Raios espetados da juba ao redor da cabeça e peito (silhueta icônica do Arcanine!)
    mane_spikes = [
        # Coroa superior da juba
        ((-0.34, -0.74, 2.74), 0.20, 0.52, (6.0, -24.0, 0.0)),
        ((-0.08, -0.76, 2.86), 0.22, 0.58, (8.0, -6.0, 0.0)),
        ((0.20, -0.74, 2.82), 0.22, 0.56, (6.0, 18.0, 0.0)),
        ((0.46, -0.68, 2.66), 0.19, 0.48, (4.0, 40.0, 0.0)),
        # Laterais das bochechas
        ((-0.76, -0.78, 2.04), 0.20, 0.50, (0.0, -82.0, 0.0)),
        ((-0.70, -0.76, 1.72), 0.20, 0.48, (0.0, -108.0, 0.0)),
        ((0.76, -0.78, 2.04), 0.20, 0.50, (0.0, 82.0, 0.0)),
        ((0.70, -0.76, 1.72), 0.20, 0.48, (0.0, 108.0, 0.0)),
        # Cascata frontal no peito
        ((0.00, -1.08, 0.92), 0.22, 0.48, (162.0, 0.0, 0.0)),
        ((-0.32, -1.00, 1.04), 0.20, 0.44, (148.0, -24.0, 0.0)),
        ((0.32, -1.00, 1.04), 0.20, 0.44, (148.0, 24.0, 0.0)),
        ((-0.62, -0.78, 1.38), 0.20, 0.44, (112.0, -64.0, 0.0)),
        ((0.62, -0.78, 1.38), 0.20, 0.44, (112.0, 64.0, 0.0)),
        # Juba traseira na nuca
        ((0.00, -0.22, 2.30), 0.26, 0.58, (-64.0, 0.0, 0.0)),
        ((0.00, -0.14, 1.92), 0.24, 0.54, (-84.0, 0.0, 0.0)),
    ]
    for m_idx, (loc, r1, dep, rot_d) in enumerate(mane_spikes):
        _add_part(
            parts,
            create_cone(
                f"_tmp_mane_sp_{m_idx}",
                5,
                r1,
                0.015,
                dep,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
                scale=(1.0, 0.68, 1.0),
            ),
            mat_prefix,
            "mane_cream",
            pal,
        )

    # 3. ROSTO NOBRE: MÁSCARA LARANJA DOS OLHOS + FOCINHO CREME + PRESINHAS + ORELHAS PONTUDAS
    # Focinho creme largo
    _add_part(
        parts,
        create_icosphere("_tmp_muzzle", 2, 0.34, (0.0, -1.24, 1.94), scale=(1.18, 0.92, 0.72)),
        mat_prefix,
        "mane_cream",
        pal,
    )
    # Nariz escuro oval
    _add_part(
        parts,
        create_icosphere("_tmp_nose", 1, 0.095, (0.0, -1.54, 2.02), scale=(1.28, 0.76, 0.70)),
        mat_prefix,
        "eye_dark",
        pal,
    )
    # Sorriso heroico + 2 presinhas brancas
    _add_part(
        parts,
        create_cube("_tmp_mouth_line", (0.34, 0.05, 0.025), (0.0, -1.50, 1.84)),
        mat_prefix,
        "eye_dark",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.032,
                0.006,
                0.08,
                (side * 0.14, -1.50, 1.81),
                rotation=(math.radians(180.0), 0.0, 0.0),
            ),
            mat_prefix,
            "fang_white",
            pal,
        )
        # Máscara laranja característica ao redor de cada olho
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_mask_{tag}",
                2,
                0.20,
                (side * 0.26, -1.26, 2.15),
                rotation=(0.0, math.radians(side * -14.0), math.radians(side * -18.0)),
                scale=(1.22, 0.56, 0.72),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )
        # Olho branco determinado + íris escura + brilho
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.13,
                (side * 0.25, -1.34, 2.15),
                rotation=(0.0, math.radians(side * -14.0), math.radians(side * -18.0)),
                scale=(1.18, 0.40, 0.72),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_iris_{tag}",
                1,
                0.072,
                (side * 0.24, -1.39, 2.15),
                scale=(0.76, 0.40, 0.96),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.028,
                (side * 0.22, -1.42, 2.18),
            ),
            mat_prefix,
            "fang_white",
            pal,
        )
        # Orelha pontuda emergindo lateralmente da juba
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_out_{tag}",
                5,
                0.22,
                0.02,
                0.56,
                (side * 0.70, -0.78, 2.34),
                rotation=(math.radians(-6.0), math.radians(side * 66.0), math.radians(side * -12.0)),
                scale=(1.0, 0.44, 1.0),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_in_{tag}",
                5,
                0.14,
                0.014,
                0.40,
                (side * 0.70, -0.84, 2.33),
                rotation=(math.radians(-6.0), math.radians(side * 66.0), math.radians(side * -12.0)),
                scale=(1.0, 0.26, 1.0),
            ),
            mat_prefix,
            "ear_inner",
            pal,
        )

    # 4. QUATRO PATAS PODEROSAS COM LISTRAS, TUFOS DE PELO CREME E PATAS LEONINAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Pata dianteira longa e forte
        _add_part(
            parts,
            create_cone(
                f"_tmp_fleg_{tag}",
                8,
                0.22,
                0.18,
                1.14,
                (side * 0.44, -0.58, 0.62),
                rotation=(math.radians(4.0), 0.0, 0.0),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )
        # Faixa preta em chevron no joelho dianteiro
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_fleg_stripe_{tag}",
                8,
                0.21,
                0.18,
                (side * 0.44, -0.59, 0.64),
                rotation=(math.radians(16.0), math.radians(side * -16.0), 0.0),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )
        # Tufo de pelo creme atrás do tornozelo dianteiro
        _add_part(
            parts,
            create_cone(
                f"_tmp_ftuft_{tag}",
                5,
                0.18,
                0.02,
                0.50,
                (side * 0.46, -0.32, 0.42),
                rotation=(math.radians(-58.0), math.radians(side * 10.0), 0.0),
            ),
            mat_prefix,
            "mane_cream",
            pal,
        )
        # Pata dianteira leonina
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_fpaw_{tag}",
                2,
                0.23,
                (side * 0.44, -0.70, 0.13),
                scale=(1.08, 1.32, 0.62),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )

        # Coxa traseira musculosa com listras pretas
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hthigh_{tag}",
                2,
                0.36,
                (side * 0.50, 0.90, 0.92),
                scale=(0.82, 1.18, 1.14),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hstripe_{tag}",
                1,
                0.34,
                (side * 0.53, 0.92, 0.96),
                rotation=(math.radians(-26.0), 0.0, 0.0),
                scale=(0.86, 0.24, 0.94),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )
        # Canela traseira + grande pluma de pelo creme atrás da perna traseira!
        _add_part(
            parts,
            create_cone(
                f"_tmp_hshin_{tag}",
                8,
                0.18,
                0.15,
                0.68,
                (side * 0.48, 1.02, 0.42),
                rotation=(math.radians(-16.0), 0.0, 0.0),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hplume_base_{tag}",
                2,
                0.24,
                (side * 0.54, 1.24, 0.46),
                scale=(0.88, 1.28, 0.82),
            ),
            mat_prefix,
            "mane_cream",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_hplume_tip_{tag}",
                5,
                0.22,
                0.02,
                0.64,
                (side * 0.58, 1.54, 0.68),
                rotation=(math.radians(-52.0), math.radians(side * 14.0), 0.0),
            ),
            mat_prefix,
            "mane_cream",
            pal,
        )
        # Pata traseira leonina apoiada em Z = 0.0
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hpaw_{tag}",
                2,
                0.22,
                (side * 0.48, 0.88, 0.13),
                scale=(1.06, 1.30, 0.60),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )

    # 5. CAUDA EM PLUMA GIGANTESCA CREME ARQUEADA ACIMA DO DORSO
    _add_part(
        parts,
        create_icosphere("_tmp_tail_0", 2, 0.44, (0.04, 1.32, 1.64), scale=(0.92, 1.04, 1.18)),
        mat_prefix,
        "mane_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_tail_1", 2, 0.48, (0.24, 1.44, 2.18), scale=(0.96, 1.12, 1.12)),
        mat_prefix,
        "mane_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_tail_2", 2, 0.42, (0.48, 1.66, 2.02), scale=(0.94, 1.16, 0.96)),
        mat_prefix,
        "mane_cream",
        pal,
    )
    tail_plumes = [
        ((0.68, 1.88, 1.76), 0.24, 0.66, (-116.0, 34.0, 0.0)),
        ((0.52, 1.62, 2.58), 0.20, 0.52, (-26.0, 26.0, 0.0)),
        ((0.72, 1.94, 2.04), 0.22, 0.56, (-78.0, 40.0, 0.0)),
    ]
    for tp_idx, (loc, r1, dep, rot_d) in enumerate(tail_plumes):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_plume_{tp_idx}",
                5,
                r1,
                0.016,
                dep,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
            ),
            mat_prefix,
            "mane_cream",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 059. Blazelion lado a lado."""
    specs = [
        ("Blazelion_Shiny", (-10.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Blazelion_Normal", (-5.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Blazelion_Grande", (-0.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Blazelion_Gigante", (6.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Blazelion_Dourada_SuperRara", (14.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_blazelion(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
