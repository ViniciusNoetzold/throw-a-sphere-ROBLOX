"""
097_Pendulummage_Hypno_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "097. Pendulummage — Hipnotizador (Ref: Hypno)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Pendulummage_Shiny (1.0x - Paleta Shiny Corpo Magenta-Rosa + Gola Branca + Pêndulo Prata)
  2. Pendulummage_Normal (1.0x - Humanoide Amarelo + Nariz Longo + Gola Felpuda Branca + Pêndulo Circular)
  3. Pendulummage_Grande (1.35x - Normal)
  4. Pendulummage_Gigante (1.85x - Normal)
  5. Pendulummage_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Pêndulo Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para cabeça, corpo e gola felpuda; anel circular oco para pêndulo)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés apoiados exatamente em `Z = 0.0` e rosto/pêndulo apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_yellow": (0.95, 0.83, 0.30, 1.0),
        "body_shade": (0.80, 0.68, 0.22, 1.0),
        "ear_brown": (0.48, 0.38, 0.34, 1.0),
        "ruff_white": (0.96, 0.97, 0.99, 1.0),
        "pendulum_silver": (0.82, 0.85, 0.90, 1.0),
        "string_dark": (0.28, 0.30, 0.36, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.10, 0.10, 0.14, 1.0),
    },
    "shiny_palette": {
        "body_yellow": (0.92, 0.44, 0.68, 1.0),
        "body_shade": (0.74, 0.30, 0.54, 1.0),
        "ear_brown": (0.44, 0.18, 0.38, 1.0),
        "ruff_white": (0.98, 0.97, 0.99, 1.0),
        "pendulum_silver": (0.84, 0.88, 0.94, 1.0),
        "string_dark": (0.30, 0.26, 0.38, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.10, 0.08, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "body_yellow": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.82, 0.60, 0.08, 1.0),
        "ear_brown": (0.56, 0.38, 0.06, 1.0),
        "ruff_white": (1.00, 0.98, 0.88, 1.0),
        "pendulum_silver": (0.10, 0.92, 1.00, 1.0),
        "string_dark": (0.06, 0.56, 0.72, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.28, 0.42, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_pendulummage(
    name: str = "Pendulummage_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 097. Pendulummage (Ref: Hypno):
      - Humanoide magro amarelo-ocre em postura hipnótica semi-agachada
      - Cabeça arredondada com orelhas pontudas triangulares (interior marrom) e nariz longo curvado para baixo
      - Olhos estreitos astutos semicerrados + grande gola felpuda branca cheia de tufos ao redor do pescoço
      - Braço esquerdo dobrado para cima + braço direito segurando fio e o clássico Pêndulo Prateado em Anel Oco
      - Pernas dobradas atléticas com pés chatos de 3 dedos apoiados em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Pen_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Pen_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Pen_Norm"

    parts = []

    # 1. TRONCO ESBELTO HUMANOIDE + QUADRIL
    _add_part(
        parts,
        create_icosphere("_tmp_torso", 2, 0.46, (0.0, 0.04, 1.18), scale=(0.94, 0.80, 1.18)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_pelvis", 2, 0.42, (0.0, 0.06, 0.82), scale=(1.04, 0.84, 0.72)),
        mat_prefix,
        "body_yellow",
        pal,
    )

    # 2. GRANDE GOLA FELPUDA BRANCA EM VOLTA DO PESCOÇO E OMBROS (ASSINATURA DO HYPNO!)
    _add_part(
        parts,
        create_icosphere("_tmp_ruff_core", 2, 0.56, (0.0, -0.02, 1.62), scale=(1.18, 0.96, 0.58)),
        mat_prefix,
        "ruff_white",
        pal,
    )
    n_ruff = 14
    for i in range(n_ruff):
        ang = (2.0 * math.pi * i) / n_ruff
        rx = 0.62 * math.sin(ang)
        ry = -0.02 - 0.52 * math.cos(ang)
        rz = 1.60 + 0.05 * math.sin(ang * 3.0)
        _add_part(
            parts,
            create_cone(
                f"_tmp_ruff_tuft_{i}",
                5,
                0.18,
                0.024,
                0.36,
                (rx, ry, rz),
                rotation=(
                    math.radians(82.0 * math.cos(ang)),
                    math.radians(82.0 * math.sin(ang)),
                    0.0,
                ),
            ),
            mat_prefix,
            "ruff_white",
            pal,
        )

    # 3. CABEÇA ARREDONDADA + ORELHAS PONTUDAS + NARIZ LONGO CURVADO PARA BAIXO
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.46, (0.0, -0.06, 2.08), scale=(0.98, 1.00, 0.96)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Orelhas grandes pontudas triangulares com interior marrom
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_outer_{tag}",
                6,
                0.22,
                0.024,
                0.62,
                (side * 0.36, 0.02, 2.54),
                rotation=(math.radians(-6.0), math.radians(side * 24.0), 0.0),
                scale=(1.0, 0.56, 1.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_inner_{tag}",
                5,
                0.14,
                0.018,
                0.46,
                (side * 0.36, -0.04, 2.50),
                rotation=(math.radians(-6.0), math.radians(side * 24.0), 0.0),
                scale=(0.88, 0.38, 1.0),
            ),
            mat_prefix,
            "ear_brown",
            pal,
        )

    # Nariz longo e pontudo caído (assinatura inconfundível do Hypno!)
    _add_part(
        parts,
        create_cone(
            "_tmp_nose_base",
            7,
            0.16,
            0.11,
            0.34,
            (0.0, -0.54, 1.98),
            rotation=(math.radians(114.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_nose_tip",
            7,
            0.11,
            0.032,
            0.34,
            (0.0, -0.74, 1.82),
            rotation=(math.radians(138.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )

    # 4. OLHOS ESTREITOS ASTUTOS SEMICERRADOS + PUPILAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.13,
                (side * 0.22, -0.45, 2.10),
                rotation=(0.0, math.radians(side * -12.0), math.radians(side * -16.0)),
                scale=(1.22, 0.38, 0.42),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eyelid_{tag}",
                (0.30, 0.10, 0.05),
                (side * 0.22, -0.46, 2.15),
                rotation=(0.0, math.radians(side * -12.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.032,
                (side * 0.21, -0.50, 2.10),
                scale=(0.60, 0.50, 1.25),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 5. BRAÇO ESQUERDO DOBRADO PARA CIMA + PUNHO FECHADO
    _add_part(
        parts,
        create_cylinder(
            "_tmp_upper_arm_L",
            7,
            0.14,
            0.52,
            (-0.68, -0.02, 1.56),
            rotation=(0.0, math.radians(-80.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_elbow_L", 1, 0.15, (-0.94, -0.04, 1.58)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_forearm_L",
            7,
            0.135,
            0.58,
            (-1.00, -0.06, 1.88),
            rotation=(math.radians(-6.0), math.radians(-10.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_fist_L", 2, 0.16, (-1.04, -0.10, 2.18), scale=(1.12, 0.86, 0.84)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Dedos dobrados esculpidos no punho esquerdo
    for f_idx, (fx, fz) in enumerate([(-1.18, 2.22), (-1.12, 2.26), (-1.04, 2.26)]):
        _add_part(
            parts,
            create_icosphere(f"_tmp_knuckle_L_{f_idx}", 1, 0.075, (fx, -0.15, fz), scale=(0.85, 1.15, 0.95)),
            mat_prefix,
            "body_yellow",
            pal,
        )
    _add_part(
        parts,
        create_cone(
            "_tmp_thumb_L",
            5,
            0.068,
            0.032,
            0.18,
            (-1.18, -0.14, 2.10),
            rotation=(0.0, math.radians(-82.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )

    # 6. BRAÇO DIREITO ERGUIDO SEGURANDO O PÊNDULO PRATEADO EM ANEL OCO (ASSINATURA!)
    _add_part(
        parts,
        create_cylinder(
            "_tmp_upper_arm_R",
            7,
            0.14,
            0.52,
            (0.68, -0.04, 1.54),
            rotation=(0.0, math.radians(84.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_elbow_R", 1, 0.15, (0.94, -0.08, 1.54)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cylinder(
            "_tmp_forearm_R",
            7,
            0.135,
            0.60,
            (1.04, -0.18, 1.86),
            rotation=(math.radians(-18.0), math.radians(16.0), 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Mão direita com dedos articulados segurando o fio do pêndulo bem à frente
    _add_part(
        parts,
        create_icosphere("_tmp_fist_R", 2, 0.18, (1.10, -0.30, 2.18), scale=(1.18, 0.92, 0.88)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    for f_idx, fx in enumerate([1.02, 1.10, 1.18, 1.25]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_finger_R_{f_idx}",
                5,
                0.062,
                0.038,
                0.18,
                (fx, -0.38, 2.14),
                rotation=(math.radians(146.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
    # Dedo polegar pinçando a cordinha do pêndulo
    _add_part(
        parts,
        create_icosphere("_tmp_thumb_R", 1, 0.095, (0.95, -0.34, 2.08), scale=(0.95, 0.85, 1.15)),
        mat_prefix,
        "body_yellow",
        pal,
    )

    # Cordinha do pêndulo descendo verticalmente da mão direita
    px, py = (1.04, -0.36)
    _add_part(
        parts,
        create_cylinder(
            "_tmp_pendulum_string",
            6,
            0.020,
            0.78,
            (px, py, 1.72),
        ),
        mat_prefix,
        "string_dark",
        pal,
    )
    # Anel circular prateado oco do pêndulo (8 segmentos em círculo no plano XZ -> furo real no meio!)
    ring_r = 0.20
    ring_z = 1.16
    n_ring = 8
    for i in range(n_ring):
        a0 = (2.0 * math.pi * i) / n_ring
        a1 = (2.0 * math.pi * (i + 1)) / n_ring
        am = 0.5 * (a0 + a1)
        seg_x = px + ring_r * math.sin(am)
        seg_z = ring_z + ring_r * math.cos(am)
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_pendulum_ring_{i}",
                6,
                0.056,
                0.20,
                (seg_x, py, seg_z),
                rotation=(0.0, math.radians(math.degrees(am) + 90.0), 0.0),
                scale=(1.0, 0.72, 1.0),
            ),
            mat_prefix,
            "pendulum_silver",
            pal,
        )

    # 7. PERNAS DOBRADAS EM BASE ATLÉTICA + PÉS DE 3 DEDOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa angulada para fora e frente
        _add_part(
            parts,
            create_cone(
                f"_tmp_thigh_{tag}",
                7,
                0.18,
                0.24,
                0.56,
                (side * 0.44, -0.06, 0.66),
                rotation=(math.radians(24.0), math.radians(side * -42.0), 0.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # Joelho
        _add_part(
            parts,
            create_icosphere(f"_tmp_knee_{tag}", 1, 0.18, (side * 0.62, -0.18, 0.48)),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # Canela descendo firme ao tornozelo
        _add_part(
            parts,
            create_cone(
                f"_tmp_shin_{tag}",
                7,
                0.15,
                0.18,
                0.44,
                (side * 0.58, -0.08, 0.26),
                rotation=(math.radians(-18.0), math.radians(side * 8.0), 0.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # Pé chato largo com 3 dedos para frente apoiado em Z = 0.0
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                1,
                0.20,
                (side * 0.58, -0.16, 0.09),
                scale=(1.12, 1.38, 0.48),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        for t_idx, tx_off in enumerate([-0.10, 0.0, 0.10]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_toe_{tag}_{t_idx}",
                    5,
                    0.062,
                    0.028,
                    0.18,
                    (side * 0.58 + tx_off, -0.36, 0.07),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "body_yellow",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 097. Pendulummage lado a lado."""
    specs = [
        ("Pendulummage_Shiny", (-11.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Pendulummage_Normal", (-7.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Pendulummage_Grande", (-2.2, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Pendulummage_Gigante", (4.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Pendulummage_Dourada_SuperRara", (12.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_pendulummage(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
