"""
128_Stampbull_Tauros_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "128. Stampbull — Touro Bravio (Ref: Tauros)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Stampbull_Shiny (1.0x - Paleta Shiny Verde-Oliva + Juba Musgo + Chifres Prateados)
  2. Stampbull_Normal (1.0x - Touro Marrom-Ocre + Grande Juba Felpuda + 3 Caudas em Chicote)
  3. Stampbull_Grande (1.35x - Normal)
  4. Stampbull_Gigante (1.85x - Normal)
  5. Stampbull_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Bolinhas na Testa e Tufos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para musculatura bovina, cones 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Cascos alinhados exatamente em `Z = 0.0` e cabeça/chifres apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_tan": (0.79, 0.59, 0.36, 1.0),
        "body_shade": (0.64, 0.45, 0.26, 1.0),
        "mane_brown": (0.43, 0.36, 0.32, 1.0),
        "mane_dark": (0.31, 0.26, 0.23, 1.0),
        "horn_silver": (0.78, 0.81, 0.87, 1.0),
        "snout_grey": (0.36, 0.35, 0.39, 1.0),
        "hoof_slate": (0.28, 0.31, 0.42, 1.0),
        "tail_cord": (0.36, 0.31, 0.28, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.09, 0.09, 0.11, 1.0),
    },
    "shiny_palette": {
        "body_tan": (0.64, 0.74, 0.28, 1.0),
        "body_shade": (0.50, 0.60, 0.20, 1.0),
        "mane_brown": (0.38, 0.44, 0.20, 1.0),
        "mane_dark": (0.26, 0.32, 0.14, 1.0),
        "horn_silver": (0.82, 0.85, 0.89, 1.0),
        "snout_grey": (0.34, 0.36, 0.32, 1.0),
        "hoof_slate": (0.26, 0.32, 0.30, 1.0),
        "tail_cord": (0.32, 0.36, 0.20, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.09, 0.10, 0.11, 1.0),
    },
    "golden_super_rare_palette": {
        "body_tan": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.82, 0.60, 0.10, 1.0),
        "mane_brown": (0.86, 0.62, 0.10, 1.0),
        "mane_dark": (0.68, 0.46, 0.06, 1.0),
        "horn_silver": (0.10, 0.92, 1.00, 1.0),
        "snout_grey": (0.74, 0.50, 0.08, 1.0),
        "hoof_slate": (0.10, 0.92, 1.00, 1.0),
        "tail_cord": (0.88, 0.68, 0.16, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.40, 0.56, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_stampbull(
    name: str = "Stampbull_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 128. Stampbull (Ref: Tauros):
      - Touro quadrúpede musculoso com garupa ocre e peitoral coberto por enorme juba marrom-escuro felpuda
      - Cabeça bovina determinada com 3 bolinhas prateadas verticais na testa e 2 chifres curvos prateados
      - 4 patas fortes com cascos cinza-ardósia apoiados em Z = 0.0
      - 3 caudas longas em chicote erguidas em leque sobre o dorso com tufos azul-ardósia nas pontas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Bull_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Bull_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Bull_Norm"

    parts = []

    # 1. TRONCO BOVINO MUSCULOSO (BARRIL TORÁCICO + GARUPA AFIADA)
    _add_part(
        parts,
        create_icosphere("_tmp_torso_mid", 2, 0.64, (0.0, 0.28, 1.24), scale=(0.92, 1.38, 0.96)),
        mat_prefix,
        "body_tan",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_rump", 2, 0.56, (0.0, 0.96, 1.18), scale=(0.88, 1.02, 0.92)),
        mat_prefix,
        "body_tan",
        pal,
    )

    # 2. GRANDE JUBA FELPUDA MARROM-ESCURO NO PESCOÇO E OMBROS (ASSINATURA DO TAUROS)
    _add_part(
        parts,
        create_icosphere("_tmp_mane_core", 2, 0.72, (0.0, -0.34, 1.38), scale=(1.04, 1.02, 1.08)),
        mat_prefix,
        "mane_brown",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_mane_hump", 2, 0.54, (0.0, -0.14, 1.72), scale=(0.94, 1.14, 0.78)),
        mat_prefix,
        "mane_brown",
        pal,
    )
    # Tufos pontudos de pelo na borda inferior do peito e laterais da juba
    mane_tufts = [
        (0.00, -0.78, 0.76, 0.24, 0.44, 174.0, 0.0),
        (-0.34, -0.68, 0.84, 0.22, 0.42, 168.0, -24.0),
        (0.34, -0.68, 0.84, 0.22, 0.42, 168.0, 24.0),
        (-0.56, -0.34, 0.94, 0.22, 0.40, 166.0, -34.0),
        (0.56, -0.34, 0.94, 0.22, 0.40, 166.0, 34.0),
        (0.00, 0.04, 2.02, 0.16, 0.30, -28.0, 0.0),
    ]
    for m_idx, (mx, my, mz, rad, dep, rx, ry) in enumerate(mane_tufts):
        _add_part(
            parts,
            create_cone(
                f"_tmp_mane_tuft_{m_idx}",
                5,
                rad,
                0.02,
                dep,
                (mx, my, mz),
                rotation=(math.radians(rx), math.radians(ry), 0.0),
            ),
            mat_prefix,
            "mane_dark" if m_idx % 2 == 1 else "mane_brown",
            pal,
        )

    # 3. CABEÇA BOVINA + FOCINHO + 3 BOLINHAS PRATEADAS NA TESTA + 2 CHIFRES CURVOS
    _add_part(
        parts,
        create_icosphere(
            "_tmp_head",
            2,
            0.44,
            (0.0, -0.94, 1.38),
            rotation=(math.radians(16.0), 0.0, 0.0),
            scale=(0.88, 1.18, 0.92),
        ),
        mat_prefix,
        "body_tan",
        pal,
    )
    # Focinho largo cinza-escuro
    _add_part(
        parts,
        create_icosphere(
            "_tmp_snout",
            2,
            0.24,
            (0.0, -1.38, 1.16),
            rotation=(math.radians(12.0), 0.0, 0.0),
            scale=(1.10, 0.82, 0.68),
        ),
        mat_prefix,
        "snout_grey",
        pal,
    )
    # 3 bolinhas prateadas verticais no centro da testa (marca registrada do Tauros)
    stud_specs = [
        (0.0, -1.32, 1.46, 0.095),
        (0.0, -1.24, 1.62, 0.072),
        (0.0, -1.14, 1.74, 0.055),
    ]
    for st_idx, (sx, sy, sz, srad) in enumerate(stud_specs):
        _add_part(
            parts,
            create_icosphere(f"_tmp_forehead_stud_{st_idx}", 1, srad, (sx, sy, sz), scale=(0.85, 0.58, 1.12)),
            mat_prefix,
            "horn_silver",
            pal,
        )
    # Olhos ferozes inclinados
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                1,
                0.10,
                (side * 0.27, -1.20, 1.38),
                rotation=(0.0, math.radians(side * 16.0), math.radians(side * -28.0)),
                scale=(1.10, 0.50, 0.72),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_pupil_{tag}", 1, 0.042, (side * 0.28, -1.24, 1.38)),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 2 chifres curvos prateados com anel metálico na base
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Anel de base do chifre
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_horn_ring_{tag}",
                8,
                0.15,
                0.10,
                (side * 0.36, -0.96, 1.64),
                rotation=(0.0, math.radians(side * 76.0), 0.0),
            ),
            mat_prefix,
            "horn_silver",
            pal,
        )
        # Segmento 1 saindo para fora
        _add_part(
            parts,
            create_cone(
                f"_tmp_horn_s1_{tag}",
                8,
                0.13,
                0.11,
                0.42,
                (side * 0.56, -0.98, 1.68),
                rotation=(math.radians(-6.0), math.radians(side * 76.0), 0.0),
            ),
            mat_prefix,
            "horn_silver",
            pal,
        )
        # Segmento 2 curvando para cima
        _add_part(
            parts,
            create_cone(
                f"_tmp_horn_s2_{tag}",
                8,
                0.11,
                0.08,
                0.36,
                (side * 0.80, -1.00, 1.84),
                rotation=(math.radians(-8.0), math.radians(side * 34.0), 0.0),
            ),
            mat_prefix,
            "horn_silver",
            pal,
        )
        # Ponta afiada curvando para cima e levemente para dentro
        _add_part(
            parts,
            create_cone(
                f"_tmp_horn_s3_{tag}",
                8,
                0.08,
                0.014,
                0.34,
                (side * 0.84, -1.02, 2.12),
                rotation=(math.radians(-8.0), math.radians(side * -14.0), 0.0),
            ),
            mat_prefix,
            "horn_silver",
            pal,
        )

    # 4. QUATRO PATAS FORTES COM CASCOS AZUL-ARDÓSIA APOIADOS EM Z = 0.0
    leg_specs = [
        # (tag, x, y_top, y_bot, is_front)
        ("FL", -0.44, -0.34, -0.40, True),
        ("FR", 0.44, -0.34, -0.40, True),
        ("BL", -0.44, 0.94, 1.00, False),
        ("BR", 0.44, 0.94, 1.00, False),
    ]
    for tag, lx, y_top, y_bot, is_front in leg_specs:
        # Coxa/ombro musculoso
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_up_{tag}",
                7,
                0.16,
                0.24 if is_front else 0.26,
                0.62,
                (lx, y_top, 0.78),
                rotation=(math.radians(6.0 if is_front else -8.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_tan",
            pal,
        )
        # Canela firme
        _add_part(
            parts,
            create_cone(
                f"_tmp_leg_lo_{tag}",
                7,
                0.11,
                0.14,
                0.48,
                (lx, y_bot, 0.34),
                rotation=(math.radians(-4.0 if is_front else 6.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_shade" if not is_front else "body_tan",
            pal,
        )
        # Casco escuro apoiado em Z = 0.0
        _add_part(
            parts,
            create_cone(
                f"_tmp_hoof_{tag}",
                7,
                0.135,
                0.11,
                0.18,
                (lx, y_bot - 0.02, 0.09),
                scale=(1.0, 1.15, 1.0),
            ),
            mat_prefix,
            "hoof_slate",
            pal,
        )

    # 5. TRÊS CAUDAS LONGAS EM CHICOTE ERGUIDAS EM LEQUE COM TUFOS NA PONTA (VISÍVEIS DA FRENTE!)
    whip_paths = [
        # Cauda esquerda arqueando alto para -X
        [
            (0.00, 1.44, 1.30),
            (-0.14, 1.56, 1.66),
            (-0.36, 1.52, 2.04),
            (-0.74, 1.38, 2.28),
            (-1.08, 1.24, 2.22),
        ],
        # Cauda central subindo bem alto acima do dorso
        [
            (0.00, 1.46, 1.32),
            (0.06, 1.62, 1.72),
            (0.16, 1.58, 2.16),
            (0.28, 1.44, 2.52),
            (0.40, 1.32, 2.74),
        ],
        # Cauda direita abrindo em chicote largo para +X
        [
            (0.00, 1.44, 1.30),
            (0.22, 1.58, 1.60),
            (0.62, 1.54, 1.92),
            (0.98, 1.38, 1.98),
            (1.16, 1.24, 1.76),
        ],
    ]
    for w_idx, pts in enumerate(whip_paths):
        for s_idx in range(len(pts) - 1):
            p0 = pts[s_idx]
            p1 = pts[s_idx + 1]
            mx = (p0[0] + p1[0]) * 0.5
            my = (p0[1] + p1[1]) * 0.5
            mz = (p0[2] + p1[2]) * 0.5
            dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
            seg_len = math.sqrt(dx * dx + dy * dy + dz * dz) + 0.06
            # Orient cylinder along (dx, dy, dz)
            horiz = math.sqrt(dx * dx + dy * dy)
            pitch = math.atan2(horiz, dz)
            yaw = math.atan2(dx, -dy)
            _add_part(
                parts,
                create_cylinder(
                    f"_tmp_tail_{w_idx}_seg_{s_idx}",
                    6,
                    0.042,
                    seg_len,
                    (mx, my, mz),
                    rotation=(pitch, 0.0, yaw),
                ),
                mat_prefix,
                "tail_cord",
                pal,
            )
            _add_part(
                parts,
                create_icosphere(f"_tmp_tail_{w_idx}_joint_{s_idx}", 1, 0.046, p1),
                mat_prefix,
                "tail_cord",
                pal,
            )
        # Tufo peludo na ponta de cada chicote
        tip = pts[-1]
        prev = pts[-2]
        tdx, tdy, tdz = tip[0] - prev[0], tip[1] - prev[1], tip[2] - prev[2]
        t_hor = math.sqrt(tdx * tdx + tdy * tdy)
        t_pitch = math.atan2(t_hor, tdz)
        t_yaw = math.atan2(tdx, -tdy)
        _add_part(
            parts,
            create_icosphere(f"_tmp_tail_tuft_base_{w_idx}", 2, 0.14, tip, scale=(1.0, 0.85, 1.25)),
            mat_prefix,
            "hoof_slate",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_tuft_tip_{w_idx}",
                6,
                0.13,
                0.015,
                0.34,
                (tip[0] + tdx * 0.35, tip[1] + tdy * 0.35, tip[2] + tdz * 0.35),
                rotation=(t_pitch, 0.0, t_yaw),
            ),
            mat_prefix,
            "hoof_slate",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 128. Stampbull lado a lado."""
    specs = [
        ("Stampbull_Shiny", (-9.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Stampbull_Normal", (-5.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Stampbull_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Stampbull_Gigante", (5.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Stampbull_Dourada_SuperRara", (12.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_stampbull(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
