"""
116_Bubblehorse_Horsea_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "116. Bubblehorse — Cavalo-Marinho (Ref: Horsea)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Bubblehorse_Shiny (1.0x - Paleta Shiny Verde-Água Turquesa + Barriga Limão-Creme + Olhos Rubi)
  2. Bubblehorse_Normal (1.0x - Azul-Turquesa + Focinho Tubular + 3 Pares de Espinhos + Cauda Espiral)
  3. Bubblehorse_Grande (1.35x - Normal)
  4. Bubblehorse_Gigante (1.85x - Normal)
  5. Bubblehorse_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Barbatana Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para cabeça e espiral da cauda, cones 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Espiral inferior da cauda apoiada exatamente em `Z = 0.0` e focinho apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_aqua": (0.44, 0.80, 0.94, 1.0),
        "body_shade": (0.26, 0.62, 0.82, 1.0),
        "belly_cream": (0.95, 0.92, 0.72, 1.0),
        "fin_rib": (0.76, 0.72, 0.50, 1.0),
        "eye_red": (0.88, 0.32, 0.32, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "eye_black": (0.08, 0.08, 0.10, 1.0),
    },
    "shiny_palette": {
        "body_aqua": (0.24, 0.86, 0.78, 1.0),
        "body_shade": (0.14, 0.64, 0.58, 1.0),
        "belly_cream": (0.96, 0.94, 0.68, 1.0),
        "fin_rib": (0.74, 0.72, 0.44, 1.0),
        "eye_red": (0.92, 0.30, 0.28, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "eye_black": (0.08, 0.08, 0.10, 1.0),
    },
    "golden_super_rare_palette": {
        "body_aqua": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.80, 0.56, 0.08, 1.0),
        "belly_cream": (1.00, 0.95, 0.60, 1.0),
        "fin_rib": (0.10, 0.92, 1.00, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_black": (0.06, 0.54, 0.70, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_bubblehorse(
    name: str = "Bubblehorse_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 116. Bubblehorse (Ref: Horsea):
      - Silhueta graciosa em S de cavalo-marinho azul-turquesa com cauda firmemente enrolada em espiral
      - Cabeça redonda fofa com focinho tubular longo e abertura escura na ponta
      - Olhos grandes expressivos branco-e-rubi + 3 pares de espinhos pontudos atrás da cabeça
      - Barriga creme segmentada em 4 faixas horizontais + barbatana dorsal em leque creme
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Bubb_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Bubb_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Bubb_Norm"

    parts = []

    # 1. CORPO EM S E CAUDA ENROLADA EM ESPIRAL NA BASE (Z = 0.0)
    torso_nodes = [
        (0.28, (0.0, 0.02, 1.48), (0.86, 0.88, 1.02)),
        (0.34, (0.0, 0.12, 1.18), (0.88, 0.94, 1.06)),
        (0.36, (0.0, 0.16, 0.86), (0.88, 0.98, 1.04)),
        (0.32, (0.0, 0.10, 0.52), (0.86, 0.96, 0.98)),
        # Início da espiral da cauda curvando para baixo e para frente (-Y)
        (0.26, (0.0, -0.06, 0.28), (0.86, 0.98, 0.90)),
        (0.24, (0.0, -0.32, 0.24), (0.86, 1.02, 0.92)),
        (0.23, (0.0, -0.52, 0.38), (0.88, 0.96, 1.00)),
        (0.21, (0.0, -0.48, 0.56), (0.86, 0.92, 0.94)),
        (0.17, (0.0, -0.32, 0.56), (0.84, 0.88, 0.88)),
        (0.14, (0.0, -0.26, 0.42), (0.84, 0.84, 0.84)),
    ]
    for tn_i, (rad, loc, sc) in enumerate(torso_nodes):
        _add_part(
            parts,
            create_icosphere(f"_tmp_body_seg_{tn_i}", 2, rad, loc, scale=sc),
            mat_prefix,
            "body_aqua",
            pal,
        )
    # Marca lateral da espiral da cauda para destaque em vista 3/4
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_spiral_mark_{tag}",
                8,
                0.11,
                0.04,
                (side * 0.20, -0.38, 0.44),
                rotation=(0.0, math.radians(90.0), 0.0),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )

    # 2. BARRIGA CREME SEGMENTADA EM 4 PLACAS HORIZONTAIS
    belly_plates = [
        (0.22, (0.0, -0.14, 1.38), (0.94, 0.64, 0.42)),
        (0.28, (0.0, -0.14, 1.16), (0.96, 0.68, 0.40)),
        (0.30, (0.0, -0.12, 0.92), (0.96, 0.72, 0.40)),
        (0.27, (0.0, -0.12, 0.70), (0.92, 0.72, 0.36)),
    ]
    for bp_i, (rad, loc, sc) in enumerate(belly_plates):
        _add_part(
            parts,
            create_icosphere(f"_tmp_belly_plate_{bp_i}", 2, rad, loc, scale=sc),
            mat_prefix,
            "belly_cream",
            pal,
        )
        if bp_i < 3:
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_belly_line_{bp_i}",
                    1,
                    rad * 0.96,
                    (0.0, loc[1] - 0.02, loc[2] - 0.11),
                    scale=(sc[0] * 1.02, sc[1] * 1.04, 0.09),
                ),
                mat_prefix,
                "fin_rib",
                pal,
            )

    # 3. CABEÇA ARREDONDADA + FOCINHO TUBULAR LONGO + OLHOS RUBI EXPRESSIVOS
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.48, (0.0, -0.06, 1.88), scale=(0.92, 1.02, 1.00)),
        mat_prefix,
        "body_aqua",
        pal,
    )
    # Focinho tubular comprido apontando para -Y com leve abertura de corneta
    _add_part(
        parts,
        create_cone(
            "_tmp_snout_tube",
            8,
            0.16,
            0.19,
            0.66,
            (0.0, -0.74, 1.84),
            rotation=(math.radians(90.0), 0.0, 0.0),
            scale=(0.88, 1.06, 1.00),
        ),
        mat_prefix,
        "body_aqua",
        pal,
    )
    # Boca escura oval na extremidade do focinho
    _add_part(
        parts,
        create_cylinder(
            "_tmp_snout_mouth",
            8,
            0.115,
            0.06,
            (0.0, -1.06, 1.84),
            rotation=(math.radians(90.0), 0.0, 0.0),
            scale=(0.76, 1.08, 1.00),
        ),
        mat_prefix,
        "eye_black",
        pal,
    )

    # Olhos grandes expressivos branco + íris rubi + pupila vertical
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.18,
                (side * 0.34, -0.34, 1.94),
                rotation=(0.0, 0.0, math.radians(side * 42.0)),
                scale=(0.94, 0.42, 1.18),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                2,
                0.115,
                (side * 0.37, -0.38, 1.93),
                rotation=(0.0, 0.0, math.radians(side * 42.0)),
                scale=(0.82, 0.44, 1.14),
            ),
            mat_prefix,
            "eye_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.052,
                (side * 0.39, -0.41, 1.93),
                rotation=(0.0, 0.0, math.radians(side * 42.0)),
                scale=(0.56, 0.44, 1.24),
            ),
            mat_prefix,
            "eye_black",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.028,
                (side * 0.38, -0.42, 2.00),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # 4. 3 PARES DE ESPINHOS/BARBATANAS PONTUDAS ATRÁS DA CABEÇA (6 NO TOTAL)
    crown_spikes = [
        # (x_off, y_pos, z_pos, rx_deg, ry_deg, length, r_base)
        (0.32, 0.30, 2.24, 52.0, 34.0, 0.54, 0.11),
        (0.42, 0.38, 1.92, 86.0, 44.0, 0.56, 0.11),
        (0.34, 0.30, 1.62, 118.0, 38.0, 0.46, 0.10),
    ]
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        for sp_i, (xo, yp, zp, rx_d, ry_d, ln, rb) in enumerate(crown_spikes):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_head_fin_{tag}_{sp_i}",
                    6,
                    rb,
                    0.022,
                    ln,
                    (side * xo, yp, zp),
                    rotation=(math.radians(rx_d), math.radians(side * ry_d), 0.0),
                    scale=(0.72, 1.00, 1.00),
                ),
                mat_prefix,
                "body_aqua",
                pal,
            )

    # 5. BARBATANA DORSAL EM LEQUE CREME NAS COSTAS (LEVEMENTE ANGULADA PARA LEITURA EM 3/4)
    fan_blades = [
        ((0.06, 0.58, 1.20), (62.0, 12.0, 14.0), (0.14, 0.64, 0.46)),
        ((0.08, 0.64, 1.04), (82.0, 14.0, 16.0), (0.12, 0.72, 0.44)),
        ((0.06, 0.58, 0.88), (104.0, 12.0, 14.0), (0.12, 0.62, 0.42)),
    ]
    for fb_i, (loc, rot_d, sc) in enumerate(fan_blades):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_dorsal_fin_{fb_i}",
                2,
                0.38,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
                scale=sc,
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )
    # Nervuras finas da barbatana dorsal
    for r_i, (rz_off, rx_d) in enumerate([(1.14, 68.0), (0.96, 94.0)]):
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_fin_rib_{r_i}",
                5,
                0.020,
                0.56,
                (0.07, 0.58, rz_off),
                rotation=(math.radians(rx_d), math.radians(14.0), 0.0),
            ),
            mat_prefix,
            "fin_rib",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 116. Bubblehorse lado a lado."""
    specs = [
        ("Bubblehorse_Shiny", (-7.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Bubblehorse_Normal", (-4.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Bubblehorse_Grande", (-0.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Bubblehorse_Gigante", (4.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Bubblehorse_Dourada_SuperRara", (10.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_bubblehorse(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
