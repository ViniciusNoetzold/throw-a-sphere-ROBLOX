"""
002_Floradine_Ivysaur_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "002. Floradine — Sapo Botão Solar (Ref: Ivysaur)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Floradine_Shiny (1.0x - Paleta Shiny / Shyne Verde-Lima + Botão Ouro)
  2. Floradine_Normal (1.0x - Pele Azul-Turquesa + 4 Folhas + Botão Rosa-Magenta)
  3. Floradine_Grande (1.35x - Normal)
  4. Floradine_Gigante (1.85x - Normal)
  5. Floradine_Dourada_SuperRara (2.25x - Ouro Reluzente + Botão Platina-Ouro + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cilindros 8 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base das patas e garras alinhada exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Floradine_Shiny`, `Floradine_Normal`, `Floradine_Grande`,
     `Floradine_Gigante`, `Floradine_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_teal": (0.34, 0.74, 0.72, 1.0),     # Corpo Azul-Turquesa (#57BDB8)
        "spots_dark": (0.14, 0.42, 0.48, 1.0),    # Manchas e orelha interna Azul-Petróleo (#246B7A)
        "leaves_green": (0.16, 0.62, 0.26, 1.0),  # 4 Folhas Largas Verde-Esmeralda (#299E42)
        "bud_pink": (0.94, 0.34, 0.56, 1.0),      # Botão Floral Rosa-Magenta (#F0578F)
        "bud_top": (0.98, 0.52, 0.70, 1.0),       # Ponta Superior do Botão Rosa-Claro (#FA85B3)
        "claws_white": (0.97, 0.97, 0.98, 1.0),   # Garras, presas e esclera dos olhos
        "eyes_ruby": (0.86, 0.16, 0.22, 1.0),     # Íris Vermelho-Rubi (#DB2938)
    },
    "shiny_palette": {
        "body_teal": (0.54, 0.92, 0.38, 1.0),     # Shiny Verde-Lima Luminoso (#8AEB61)
        "spots_dark": (0.24, 0.62, 0.22, 1.0),    # Manchas Shiny Verde-Folha (#3D9E38)
        "leaves_green": (0.18, 0.70, 0.26, 1.0),  # Folhas Shiny Esmeralda (#2EB342)
        "bud_pink": (0.98, 0.80, 0.18, 1.0),      # Botão Shiny Amarelo-Ouro (#FACC2E)
        "bud_top": (1.00, 0.92, 0.44, 1.0),       # Ponta Shiny Ouro-Claro (#FFEB70)
        "claws_white": (0.98, 0.98, 0.99, 1.0),   # Garras e presas
        "eyes_ruby": (0.92, 0.22, 0.26, 1.0),     # Íris Rubi
    },
    "golden_super_rare_palette": {
        "body_teal": (0.98, 0.78, 0.14, 1.0),     # Ouro Reluzente Principal (#FAC724)
        "spots_dark": (0.72, 0.48, 0.06, 1.0),    # Manchas Âmbar-Real (#B87A0F)
        "leaves_green": (0.86, 0.64, 0.10, 1.0),  # Folhas Ouro-Antigo (#DBA31A)
        "bud_pink": (1.00, 0.92, 0.42, 1.0),      # Botão Ouro-Platina Brilhante (#FFEB6B)
        "bud_top": (1.00, 0.98, 0.76, 1.0),       # Ponta Platina-Solar (#FFFAC2)
        "claws_white": (1.00, 0.96, 0.82, 1.0),   # Garras/Presas Marfim-Dourado
        "eyes_ruby": (0.10, 0.92, 1.00, 1.0),     # Olhos Ciano-Diamante Brilhante (#1AEBFF)
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (ideal para acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, zera a origem na base das patas (Z = 0.0),
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_floradine(
    name: str = "Floradine_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 002. Floradine (Ref: Ivysaur):
      - Frente apontando para -Y e base das 4 patas e garras em Z = 0.0
      - Torso robusto com manchas, presas longas, orelhas escuras por dentro e olhos ferozes
      - Coroa de 4 folhas largas em cruz ao redor de um grande botão floral fechado
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Flora_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Flora_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Flora"

    parts = []

    # 1. TORSO ROBUSTO + MANCHAS ASSIMÉTRICAS
    _add_part(
        parts,
        create_cube("_tmp_torso", (1.42, 1.66, 0.98), (0.0, 0.14, 0.86), (math.radians(10), 0.0, 0.0)),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_rump", (1.22, 0.74, 0.82), (0.0, 0.80, 0.74), (math.radians(-12), 0.0, 0.0)),
        mat_prefix,
        "body_teal",
        pal,
    )
    spots = [
        ((-0.72, 0.04, 0.90), (0.08, 0.36, 0.30), (math.radians(15), 0.0, 0.0)),
        ((0.72, -0.10, 0.94), (0.08, 0.30, 0.24), (math.radians(-10), 0.0, 0.0)),
        ((0.70, 0.42, 0.82), (0.08, 0.24, 0.22), (math.radians(20), 0.0, 0.0)),
    ]
    for idx, (loc, sz, rot) in enumerate(spots):
        _add_part(parts, create_cube(f"_tmp_spot_{idx}", sz, loc, rot), mat_prefix, "spots_dark", pal)

    # 2. QUATRO PATAS MUSCULOSAS + 3 GARRAS BRANCAS TOCANDO Z = 0
    legs = [
        (-0.58, -0.40, 0.38, 0.27, 0.23, 0.76),
        (0.58, -0.40, 0.38, 0.27, 0.23, 0.76),
        (-0.62, 0.68, 0.36, 0.29, 0.26, 0.72),
        (0.62, 0.68, 0.36, 0.29, 0.26, 0.72),
    ]
    for idx, (lx, ly, lz, r1, r2, dep) in enumerate(legs):
        _add_part(
            parts,
            create_cone(f"_tmp_leg_{idx}", 6, r1, r2, dep, (lx, ly, lz)),
            mat_prefix,
            "body_teal",
            pal,
        )
        for claw_i, cx_off in enumerate([-0.13, 0.0, 0.13]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_claw_{idx}_{claw_i}",
                    4,
                    0.070,
                    0.012,
                    0.22,
                    (lx + cx_off, ly - 0.28, 0.07),
                    (math.radians(86), 0.0, 0.0),
                ),
                mat_prefix,
                "claws_white",
                pal,
            )

    # 3. CABEÇA FEROZ, ORELHAS PONTUDAS, PRESAS LONGAS E OLHOS (-Y)
    _add_part(
        parts,
        create_cube("_tmp_head", (1.28, 1.06, 0.92), (0.0, -0.84, 1.16), (math.radians(-5), 0.0, 0.0)),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout", (1.00, 0.44, 0.44), (0.0, -1.36, 0.96)),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth", (0.88, 0.08, 0.06), (0.0, -1.56, 0.92)),
        mat_prefix,
        "spots_dark",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_forehead_spot", (0.26, 0.08, 0.24), (-0.14, -1.37, 1.38), (0.0, math.radians(18), 0.0)),
        mat_prefix,
        "spots_dark",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        # Orelha externa + parte interna escura
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_outer_{side_idx}",
                4,
                0.24,
                0.03,
                0.48,
                (sx * 0.48, -0.72, 1.72),
                (math.radians(-12), math.radians(sx * 24), 0.0),
                scale=(0.85, 0.72, 1.0),
            ),
            mat_prefix,
            "body_teal",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_inner_{side_idx}",
                4,
                0.15,
                0.02,
                0.34,
                (sx * 0.47, -0.80, 1.68),
                (math.radians(-12), math.radians(sx * 24), 0.0),
                scale=(0.75, 0.50, 1.0),
            ),
            mat_prefix,
            "spots_dark",
            pal,
        )
        # Sobrancelha angular + olho rubi/diamante
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{side_idx}",
                (0.28, 0.12, 0.07),
                (sx * 0.34, -1.36, 1.32),
                (0.0, math.radians(sx * 16), 0.0),
            ),
            mat_prefix,
            "spots_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_sclera_{side_idx}",
                (0.26, 0.10, 0.24),
                (sx * 0.34, -1.35, 1.18),
                (0.0, math.radians(sx * 14), 0.0),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_iris_{side_idx}",
                (0.15, 0.08, 0.19),
                (sx * 0.33, -1.38, 1.18),
                (0.0, math.radians(sx * 14), 0.0),
            ),
            mat_prefix,
            "eyes_ruby",
            pal,
        )
        # Presas mais longas de Ivysaur
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{side_idx}",
                4,
                0.068,
                0.01,
                0.20,
                (sx * 0.28, -1.55, 0.84),
                (math.radians(180), 0.0, 0.0),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )

    # 4. COROA DE 4 FOLHAS LARGAS + GRANDE BOTÃO FLORAL NAS COSTAS
    _add_part(
        parts,
        create_cylinder("_tmp_crown_base", 8, 0.56, 0.22, (0.0, 0.24, 1.38), (math.radians(-10), 0.0, 0.0)),
        mat_prefix,
        "leaves_green",
        pal,
    )
    # 4 Grandes folhas largas abertas em X ao redor do botão
    for idx, deg in enumerate([45.0, 135.0, 225.0, 315.0]):
        ang = math.radians(deg)
        lx = math.cos(ang) * 0.82
        ly = 0.26 + math.sin(ang) * 0.82
        _add_part(
            parts,
            create_cone(
                f"_tmp_leaf_{idx}",
                4,
                0.46,
                0.04,
                1.35,
                (lx, ly, 1.54),
                (0.0, math.radians(66), ang),
                scale=(0.24, 1.0, 1.0),
            ),
            mat_prefix,
            "leaves_green",
            pal,
        )

    # Botão floral fechado em gomos convergindo para o topo
    _add_part(
        parts,
        create_icosphere("_tmp_bud_core", 1, 0.58, (0.0, 0.28, 1.78), (math.radians(-12), 0.0, 0.0), scale=(0.98, 0.98, 1.12)),
        mat_prefix,
        "bud_pink",
        pal,
    )
    for idx, (ox, oy, rx, ry) in enumerate([
        (0.0, -0.16, -24.0, 0.0),
        (0.0, 0.16, 16.0, 0.0),
        (-0.18, 0.0, -10.0, -22.0),
        (0.18, 0.0, -10.0, 22.0),
    ]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_bud_petal_{idx}",
                4,
                0.38,
                0.10,
                0.78,
                (ox, 0.30 + oy, 1.98),
                (math.radians(rx), math.radians(ry), 0.0),
            ),
            mat_prefix,
            "bud_pink",
            pal,
        )
    _add_part(
        parts,
        create_cone("_tmp_bud_tip", 6, 0.26, 0.04, 0.48, (0.0, 0.36, 2.38), (math.radians(-14), 0.0, 0.0)),
        mat_prefix,
        "bud_top",
        pal,
    )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """
    Gera lado a lado os 5 modelos do 002. Floradine (Ivysaur):
      1. Shiny (1.0x) | 2. Normal (1.0x) | 3. Grande (1.35x) | 4. Gigante (1.85x) | 5. Dourada Super Rara (2.25x)
    """
    build_floradine("Floradine_Shiny", location=(-7.2, 0.0, 0.0), scale=CONFIG["scales"]["Shiny"], variant="Shiny")
    build_floradine("Floradine_Normal", location=(-4.3, 0.0, 0.0), scale=CONFIG["scales"]["Normal"], variant="Normal")
    build_floradine("Floradine_Grande", location=(-1.1, 0.0, 0.0), scale=CONFIG["scales"]["Grande"], variant="Normal")
    build_floradine("Floradine_Gigante", location=(3.2, 0.0, 0.0), scale=CONFIG["scales"]["Gigante"], variant="Normal")
    build_floradine(
        "Floradine_Dourada_SuperRara",
        location=(9.0, 0.0, 0.0),
        scale=CONFIG["scales"]["DouradaSuperRara"],
        variant="DouradaSuperRara",
    )


if __name__ == "__main__":
    generate_variations()
    print("002. Floradine (5 variações: Shiny, Normal, Grande, Gigante e Dourada Super Rara) gerado com sucesso!")
