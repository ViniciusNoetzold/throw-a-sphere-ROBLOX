"""
089_Toxictide_Muk_5Variacoes_Blender.py
=======================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "089. Toxictide — Colosso de Lodo (Ref: Muk)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Toxictide_Shiny (1.0x - Paleta Shiny Lodo Verde-Musgo Tóxico + Listras Verde-Escuro)
  2. Toxictide_Normal (1.0x - Montanha de Lodo Roxo + Boca Cavernosa com Fio de Gosma + Braço Estendido)
  3. Toxictide_Grande (1.35x - Normal)
  4. Toxictide_Gigante (1.85x - Normal)
  5. Toxictide_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Listras e Língua Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (colosso derretido largo, olhos triangulares ferozes, fio de lodo na boca)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Poça base alinhada exatamente em `Z = 0.0` e boca/olhos apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "sludge_main": (0.61, 0.48, 0.69, 1.0),
        "sludge_stripe": (0.37, 0.29, 0.45, 1.0),
        "mouth_dark": (0.14, 0.11, 0.17, 1.0),
        "tongue_gray": (0.68, 0.72, 0.78, 1.0),
        "eye_white": (0.97, 0.98, 1.00, 1.0),
        "eye_dark": (0.09, 0.09, 0.12, 1.0),
    },
    "shiny_palette": {
        "sludge_main": (0.36, 0.66, 0.34, 1.0),
        "sludge_stripe": (0.20, 0.42, 0.22, 1.0),
        "mouth_dark": (0.12, 0.16, 0.14, 1.0),
        "tongue_gray": (0.76, 0.64, 0.78, 1.0),
        "eye_white": (0.97, 0.98, 1.00, 1.0),
        "eye_dark": (0.09, 0.09, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "sludge_main": (0.98, 0.78, 0.14, 1.0),
        "sludge_stripe": (0.10, 0.92, 1.00, 1.0),
        "mouth_dark": (0.46, 0.30, 0.06, 1.0),
        "tongue_gray": (0.22, 0.94, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel angular e Flat Shading."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_toxictide(
    name: str = "Toxictide_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 089. Toxictide (Ref: Muk):
      - Colosso largo e pesado de lodo viscoso roxo esparramado em ondas irregulares em Z = 0.0
      - Testa pesada inclinada para frente encobrindo olhos triangulares ferozes semicerrados
      - Boca imensa escancarada com língua acinzentada e fio vertical de gosma conectando os lábios
      - Um grande braço viscoso direito (+X) estendido para frente/lado com 3 dedos derretidos + pata esquerda baixa
      - Listras horizontais escuras de lodo atravessando corpo, testa, braço e poça
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Toxi_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Toxi_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Toxi_Norm"

    parts = []

    # 1. BASE COLOSSAL DE LODO ESPARRAMADO NO CHÃO (Z = 0.0)
    base_blobs = [
        (1.12, (-0.06, 0.14, 0.30), (1.28, 1.06, 0.30)),
        (0.74, (-0.98, 0.16, 0.24), (1.16, 0.94, 0.32)),
        (0.68, (0.72, 0.18, 0.24), (1.06, 0.96, 0.30)),
        (0.62, (-0.36, -0.58, 0.24), (1.22, 0.78, 0.32)),
        (0.58, (0.34, -0.52, 0.24), (1.12, 0.80, 0.30)),
        (0.76, (-0.18, 0.72, 0.26), (1.26, 0.96, 0.32)),
    ]
    for b_idx, (rad, loc, sc) in enumerate(base_blobs):
        _add_part(
            parts,
            create_icosphere(f"_tmp_base_{b_idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "sludge_main",
            pal,
        )

    # 2. CORPO COLOSSAL CORCUNDA INCLINADO PARA FRENTE
    _add_part(
        parts,
        create_icosphere("_tmp_body_low", 2, 0.94, (-0.08, 0.14, 0.72), scale=(1.18, 1.02, 0.74)),
        mat_prefix,
        "sludge_main",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_body_mid", 2, 0.80, (-0.04, 0.06, 1.16), scale=(1.10, 1.00, 0.76)),
        mat_prefix,
        "sludge_main",
        pal,
    )
    # Ombro esquerdo derretido em degraus (característica da arte do Muk!)
    _add_part(
        parts,
        create_icosphere("_tmp_slump_L1", 2, 0.62, (-0.72, 0.18, 0.66), scale=(1.08, 0.96, 0.74)),
        mat_prefix,
        "sludge_main",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_slump_L2", 2, 0.48, (-1.12, 0.10, 0.36), scale=(1.18, 0.90, 0.56)),
        mat_prefix,
        "sludge_main",
        pal,
    )
    # Pata esquerda baixa derretida junto ao chão (-X)
    _add_part(
        parts,
        create_icosphere("_tmp_paw_L", 2, 0.30, (-1.28, -0.34, 0.18), scale=(1.16, 1.08, 0.50)),
        mat_prefix,
        "sludge_main",
        pal,
    )

    # 3. TESTA PESADA PROJETADA + LÁBIO SUPERIOR + OLHOS TRIANGULARES FEROZES
    _add_part(
        parts,
        create_icosphere(
            "_tmp_brow_dome",
            2,
            0.66,
            (0.00, -0.14, 1.48),
            rotation=(math.radians(14.0), 0.0, 0.0),
            scale=(1.14, 1.16, 0.62),
        ),
        mat_prefix,
        "sludge_main",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_upper_lip",
            2,
            0.54,
            (0.02, -0.58, 1.32),
            rotation=(math.radians(8.0), 0.0, 0.0),
            scale=(1.20, 0.94, 0.34),
        ),
        mat_prefix,
        "sludge_main",
        pal,
    )

    # Olhos brancos estreitos ferozes semicerrados sob a testa pesada
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_w_{tag}",
                1,
                0.155,
                (0.02 + side * 0.28, -0.78, 1.50),
                rotation=(math.radians(-10.0), math.radians(side * -18.0), math.radians(side * -16.0)),
                scale=(1.18, 0.45, 0.44),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_p_{tag}",
                1,
                0.045,
                (0.02 + side * 0.28, -0.84, 1.49),
                scale=(0.9, 0.5, 0.8),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Sobrancelha pesada inclinada dando ar bravo
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_r_{tag}",
                (0.32, 0.14, 0.07),
                (0.02 + side * 0.28, -0.78, 1.57),
                rotation=(math.radians(8.0), math.radians(side * -18.0), math.radians(side * -12.0)),
            ),
            mat_prefix,
            "sludge_stripe",
            pal,
        )

    # 4. BOCA IMENSA ESCANCARADA + LÍNGUA + FIO DE GOSMA CONECTANDO OS LÁBIOS (ASSINATURA DO MUK!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_cav",
            2,
            0.54,
            (0.02, -0.52, 0.92),
            scale=(1.12, 0.72, 0.88),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tongue",
            2,
            0.40,
            (0.02, -0.58, 0.68),
            scale=(1.08, 0.76, 0.44),
        ),
        mat_prefix,
        "tongue_gray",
        pal,
    )
    # Lábio inferior largo e grosso
    _add_part(
        parts,
        create_icosphere(
            "_tmp_lower_lip",
            2,
            0.52,
            (0.02, -0.64, 0.52),
            scale=(1.18, 0.74, 0.34),
        ),
        mat_prefix,
        "sludge_main",
        pal,
    )
    # Fio vertical de gosma/lodo ligando o lábio superior ao inferior no lado esquerdo da boca
    _add_part(
        parts,
        create_cylinder(
            "_tmp_slime_strand",
            7,
            0.055,
            0.76,
            (-0.24, -0.84, 0.92),
            rotation=(math.radians(6.0), math.radians(4.0), 0.0),
            scale=(0.82, 0.70, 1.0),
        ),
        mat_prefix,
        "sludge_main",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_slime_top",
            6,
            0.13,
            0.055,
            0.22,
            (-0.24, -0.82, 1.24),
            rotation=(math.radians(180.0), 0.0, 0.0),
        ),
        mat_prefix,
        "sludge_main",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_slime_bot",
            6,
            0.13,
            0.055,
            0.22,
            (-0.24, -0.82, 0.60),
        ),
        mat_prefix,
        "sludge_main",
        pal,
    )

    # 5. LISTRAS HORIZONTAIS ESCURAS DE LODO ATRAVESSANDO O CORPO
    stripe_specs = [
        ((-0.06, 0.14, 0.32), (1.30, 1.08, 0.12), 1.06),
        ((-0.08, 0.14, 0.72), (1.20, 1.04, 0.13), 0.92),
        ((-0.04, 0.04, 1.18), (1.12, 1.02, 0.13), 0.78),
        ((0.00, -0.14, 1.54), (1.14, 1.16, 0.11), 0.62),
    ]
    for s_idx, (loc, sc, rad) in enumerate(stripe_specs):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_stripe_{s_idx}",
                2,
                rad,
                loc,
                rotation=(math.radians(6.0), math.radians(-5.0 if s_idx % 2 == 0 else 4.0), 0.0),
                scale=sc,
            ),
            mat_prefix,
            "sludge_stripe",
            pal,
        )

    # 6. GRANDE BRAÇO VISCOSO ESTENDIDO PARA DIREITA/FRENTE (+X, POSE ICÔNICA DO MUK!)
    _add_part(
        parts,
        create_icosphere("_tmp_armR_sh", 2, 0.42, (0.72, -0.02, 0.78), scale=(1.10, 0.96, 0.78)),
        mat_prefix,
        "sludge_main",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_armR_mid",
            2,
            0.40,
            (1.18, -0.22, 0.68),
            rotation=(0.0, math.radians(14.0), math.radians(-22.0)),
            scale=(1.44, 0.88, 0.66),
        ),
        mat_prefix,
        "sludge_main",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_armR_st",
            1,
            0.38,
            (1.18, -0.22, 0.72),
            rotation=(0.0, math.radians(14.0), math.radians(-22.0)),
            scale=(1.46, 0.90, 0.18),
        ),
        mat_prefix,
        "sludge_stripe",
        pal,
    )
    # Mão viscosa larga com 3 grandes dedos derretidos pendentes
    _add_part(
        parts,
        create_icosphere(
            "_tmp_armR_hand",
            2,
            0.36,
            (1.58, -0.38, 0.56),
            rotation=(0.0, math.radians(18.0), math.radians(-24.0)),
            scale=(1.18, 1.04, 0.56),
        ),
        mat_prefix,
        "sludge_main",
        pal,
    )
    for f_idx, (fx, fy, fz) in enumerate([
        (1.86, -0.34, 0.46),
        (1.78, -0.58, 0.44),
        (1.52, -0.68, 0.46),
    ]):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_armR_f_{f_idx}",
                1,
                0.17,
                (fx, fy, fz),
                scale=(1.18, 0.96, 0.68),
            ),
            mat_prefix,
            "sludge_main",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 089. Toxictide lado a lado."""
    specs = [
        ("Toxictide_Shiny", (-13.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Toxictide_Normal", (-8.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Toxictide_Grande", (-1.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Toxictide_Gigante", (7.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Toxictide_Dourada_SuperRara", (17.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_toxictide(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
