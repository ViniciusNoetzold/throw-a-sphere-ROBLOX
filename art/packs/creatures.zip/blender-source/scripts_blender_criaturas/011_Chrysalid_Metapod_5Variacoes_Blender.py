"""
011_Chrysalid_Metapod_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "011. Chrysalid — Crisálida Armada (Ref: Metapod)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Chrysalid_Shiny (1.0x - Paleta Shiny / Shyne Laranja-Avermelhado Vivo)
  2. Chrysalid_Normal (1.0x - Carapaça Verde-Esmeralda em Crescente + Olhos Severos)
  3. Chrysalid_Grande (1.35x - Normal)
  4. Chrysalid_Gigante (1.85x - Normal)
  5. Chrysalid_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 6 lados, cilindros 6-8 lados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base da quilha/cauda alinhada exatamente em `Z = 0.0` e frente/proa apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Chrysalid_Shiny`, `Chrysalid_Normal`, `Chrysalid_Grande`,
     `Chrysalid_Gigante`, `Chrysalid_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "shell_green": (0.32, 0.74, 0.26, 1.0),
        "shell_light": (0.48, 0.86, 0.34, 1.0),
        "seam_dark": (0.18, 0.48, 0.14, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "eye_dark": (0.10, 0.10, 0.14, 1.0),
    },
    "shiny_palette": {
        "shell_green": (0.96, 0.34, 0.18, 1.0),
        "shell_light": (1.00, 0.56, 0.30, 1.0),
        "seam_dark": (0.68, 0.18, 0.08, 1.0),
        "eye_white": (0.99, 0.98, 0.96, 1.0),
        "eye_dark": (0.14, 0.08, 0.08, 1.0),
    },
    "golden_super_rare_palette": {
        "shell_green": (0.98, 0.78, 0.14, 1.0),
        "shell_light": (1.00, 0.94, 0.54, 1.0),
        "seam_dark": (0.74, 0.50, 0.08, 1.0),
        "eye_white": (1.00, 0.98, 0.88, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base ventral em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_chrysalid(
    name: str = "Chrysalid_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 011. Chrysalid (Ref: Metapod):
      - Frente apontando para -Y e base da quilha alinhada em Z = 0.0
      - Silhueta em crescente blindada com placa peitoral saliente em -Y e dorso arqueado em +Y
      - Pontas superior e inferior afuniladas com costelas/costuras escuras entre placas quitinosas
      - Olhos triangulares brancos com pupilas pretas sob sobrancelhas angulares
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Chrysalid_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Chrysalid_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Chrysalid"

    parts = []

    # 1. BASE QUILHADA E PLACAS INFERIORES EM CRESCENTE
    _add_part(
        parts,
        create_cube("_tmp_base_keel", (0.76, 0.92, 0.34), (0.0, 0.08, 0.18), rotation=(math.radians(8.0), 0.0, 0.0)),
        mat_prefix,
        "seam_dark",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_tail_prow", 6, 0.34, 0.08, 0.72, (0.0, -0.58, 0.42), rotation=(math.radians(68.0), 0.0, 0.0)),
        mat_prefix,
        "shell_green",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_tail_tip", 6, 0.16, 0.02, 0.36, (0.0, -0.84, 0.60), rotation=(math.radians(42.0), 0.0, 0.0)),
        mat_prefix,
        "shell_light",
        pal,
    )

    # 2. BLOCO CENTRAL BLINDADO + COSTELAS DE QUITINA
    _add_part(
        parts,
        create_cube("_tmp_belly_low", (0.88, 0.96, 0.56), (0.0, 0.02, 0.52), rotation=(math.radians(14.0), 0.0, 0.0)),
        mat_prefix,
        "shell_green",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_belly_mid", (0.96, 1.02, 0.68), (0.0, 0.06, 0.96), rotation=(math.radians(-6.0), 0.0, 0.0)),
        mat_prefix,
        "shell_green",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_chest_plate", (0.74, 0.36, 0.54), (0.0, -0.44, 0.92), rotation=(math.radians(-14.0), 0.0, 0.0)),
        mat_prefix,
        "shell_light",
        pal,
    )

    # Sulcos e costuras escuras horizontais da armadura
    for idx, (rz, ry, rx, tilt) in enumerate(
        [(0.42, 0.02, 0.94, 12.0), (0.72, 0.04, 1.00, 2.0), (1.06, 0.06, 1.02, -8.0)]
    ):
        _add_part(
            parts,
            create_cube(
                f"_tmp_seam_{idx}",
                (rx, 0.98, 0.07),
                (0.0, ry, rz),
                rotation=(math.radians(tilt), 0.0, 0.0),
            ),
            mat_prefix,
            "seam_dark",
            pal,
        )

    # Placas laterais salientes na cintura (barbatanas quitinosas da crisálida)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_side_fin_{tag}",
                4,
                0.24,
                0.05,
                0.48,
                (side * 0.52, 0.14, 0.88),
                rotation=(math.radians(28.0), math.radians(side * 68.0), math.radians(side * 22.0)),
            ),
            mat_prefix,
            "shell_light",
            pal,
        )

    # 3. PROA/NARIZ ANGULAR EM -Y E CABEÇA ESCULPIDA
    _add_part(
        parts,
        create_cube("_tmp_head_block", (0.90, 0.98, 0.66), (0.0, -0.02, 1.46), rotation=(math.radians(-18.0), 0.0, 0.0)),
        mat_prefix,
        "shell_green",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_front_prow",
            6,
            0.34,
            0.06,
            0.72,
            (0.0, -0.58, 1.38),
            rotation=(math.radians(88.0), 0.0, 0.0),
            scale=(0.82, 1.10, 1.0),
        ),
        mat_prefix,
        "shell_light",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_prow_keel", (0.20, 0.48, 0.28), (0.0, -0.52, 1.24), rotation=(math.radians(-22.0), 0.0, 0.0)),
        mat_prefix,
        "seam_dark",
        pal,
    )

    # Crista dorsal e ponta superior dobrada para trás (+Y, +Z)
    _add_part(
        parts,
        create_cube("_tmp_back_ridge", (0.44, 0.42, 0.88), (0.0, 0.48, 1.26), rotation=(math.radians(-20.0), 0.0, 0.0)),
        mat_prefix,
        "seam_dark",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_crown_cone", 6, 0.42, 0.12, 0.72, (0.0, 0.18, 1.96), rotation=(math.radians(-26.0), 0.0, 0.0)),
        mat_prefix,
        "shell_green",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_crown_tip", 6, 0.14, 0.02, 0.44, (0.0, 0.40, 2.38), rotation=(math.radians(-38.0), 0.0, 0.0)),
        mat_prefix,
        "shell_light",
        pal,
    )

    # 4. OLHOS SEVEROS COM SOBRANCELHA ANGULAR E PUPILA PRETA (NOS LADOS DA PROA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_brow_{tag}",
                (0.18, 0.44, 0.11),
                (side * 0.44, -0.26, 1.62),
                rotation=(math.radians(-16.0), math.radians(side * 12.0), math.radians(side * -18.0)),
            ),
            mat_prefix,
            "seam_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_white_{tag}",
                (0.12, 0.34, 0.22),
                (side * 0.46, -0.26, 1.48),
                rotation=(math.radians(-12.0), 0.0, math.radians(side * -18.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_pupil_{tag}",
                (0.10, 0.16, 0.15),
                (side * 0.49, -0.32, 1.48),
                rotation=(math.radians(-12.0), 0.0, math.radians(side * -18.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 011. Chrysalid lado a lado."""
    specs = [
        ("Chrysalid_Shiny", (-5.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Chrysalid_Normal", (-3.3, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Chrysalid_Grande", (-0.7, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Chrysalid_Gigante", (2.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Chrysalid_Dourada_SuperRara", (6.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_chrysalid(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
