"""
017_Skytalon_Pidgeotto_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "017. Skytalon — Falcão de Crista (Ref: Pidgeotto)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Skytalon_Shiny (1.0x - Paleta Shiny / Shyne Ocre-Dourado + Crista/Cauda Âmbar-Ouro)
  2. Skytalon_Normal (1.0x - Marrom-Canela + Longa Crista Rosa-Rubi + Cauda Rubi/Ouro)
  3. Skytalon_Grande (1.35x - Normal)
  4. Skytalon_Gigante (1.85x - Normal)
  5. Skytalon_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.017`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Garras/pés alinhados exatamente em `Z = 0.0` e frente/bico apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Skytalon_Shiny`, `Skytalon_Normal`, `Skytalon_Grande`,
     `Skytalon_Gigante`, `Skytalon_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.017,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "back_cinnamon": (0.66, 0.46, 0.28, 1.0),
        "crest_ruby": (0.92, 0.32, 0.38, 1.0),
        "chest_cream": (0.96, 0.90, 0.72, 1.0),
        "tail_gold": (0.96, 0.82, 0.28, 1.0),
        "mask_black": (0.14, 0.12, 0.12, 1.0),
        "beak_pink": (0.90, 0.68, 0.66, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
    },
    "shiny_palette": {
        "back_cinnamon": (0.84, 0.72, 0.22, 1.0),
        "crest_ruby": (0.96, 0.76, 0.18, 1.0),
        "chest_cream": (0.99, 0.95, 0.64, 1.0),
        "tail_gold": (1.00, 0.92, 0.44, 1.0),
        "mask_black": (0.16, 0.14, 0.10, 1.0),
        "beak_pink": (0.94, 0.78, 0.38, 1.0),
        "eye_white": (0.99, 0.99, 0.96, 1.0),
    },
    "golden_super_rare_palette": {
        "back_cinnamon": (0.98, 0.78, 0.14, 1.0),
        "crest_ruby": (1.00, 0.88, 0.32, 1.0),
        "chest_cream": (1.00, 0.95, 0.58, 1.0),
        "tail_gold": (0.94, 0.70, 0.10, 1.0),
        "mask_black": (0.10, 0.92, 1.00, 1.0),
        "beak_pink": (0.88, 0.64, 0.14, 1.0),
        "eye_white": (1.00, 0.99, 0.90, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha as garras dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_skytalon(
    name: str = "Skytalon_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 017. Skytalon (Ref: Pidgeotto):
      - Frente/bico apontando para -Y e garras de rapina alinhadas em Z = 0.0
      - Corpo esbelto marrom-canela com peito e coxas creme
      - Longa crista rosa-rubi arqueada sobre a cabeça, máscara preta nos olhos e bico adunco
      - Grandes asas semiabertas com borda canela e penas creme + cauda em leque rubi e ouro
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Sky_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Sky_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Sky"

    parts = []

    # 1. TRONCO ESBELTO MARROM-CANELA + PEITO CREME + PESCOÇO
    _add_part(
        parts,
        create_icosphere("_tmp_torso_back", 1, 0.56, (0.0, 0.14, 1.06), scale=(0.84, 0.96, 1.24)),
        mat_prefix,
        "back_cinnamon",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_collar", (0.76, 0.72, 0.44), (0.0, -0.02, 1.48), rotation=(math.radians(10.0), 0.0, 0.0)),
        mat_prefix,
        "back_cinnamon",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_chest_cream", 1, 0.52, (0.0, -0.14, 1.02), scale=(0.82, 0.86, 1.18)),
        mat_prefix,
        "chest_cream",
        pal,
    )

    # 2. CABEÇA, BICO ADUNCO, MÁSCARA PRETA E LONGA CRISTA ROSA-RUBI
    _add_part(parts, create_cube("_tmp_head_main", (0.70, 0.74, 0.68), (0.0, -0.14, 1.88)), mat_prefix, "back_cinnamon", pal)
    _add_part(parts, create_cube("_tmp_cheek_cream", (0.64, 0.34, 0.40), (0.0, -0.38, 1.72)), mat_prefix, "chest_cream", pal)

    # Crista central em 2 blocos + ponta + 2 faixas laterais arqueadas para trás (+Y)
    _add_part(
        parts,
        create_cone("_tmp_crest_front", 4, 0.18, 0.04, 0.46, (0.0, -0.34, 2.30), rotation=(math.radians(-40.0), 0.0, 0.0)),
        mat_prefix,
        "crest_ruby",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_crest_mid", (0.34, 0.78, 0.24), (0.0, 0.04, 2.34), rotation=(math.radians(14.0), 0.0, 0.0)),
        mat_prefix,
        "crest_ruby",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_crest_tail", 4, 0.22, 0.03, 0.86, (0.0, 0.62, 2.14), rotation=(math.radians(-116.0), 0.0, 0.0)),
        mat_prefix,
        "crest_ruby",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_crest_wing_{tag}",
                (0.18, 0.82, 0.18),
                (side * 0.24, 0.02, 2.26),
                rotation=(math.radians(12.0), math.radians(side * 12.0), math.radians(side * 10.0)),
            ),
            mat_prefix,
            "crest_ruby",
            pal,
        )

    # Bico adunco rosa-pálido apontando para -Y
    _add_part(
        parts,
        create_cone(
            "_tmp_beak_upper",
            5,
            0.16,
            0.03,
            0.40,
            (0.0, -0.64, 1.84),
            rotation=(math.radians(98.0), 0.0, 0.0),
        ),
        mat_prefix,
        "beak_pink",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_beak_lower",
            4,
            0.11,
            0.03,
            0.26,
            (0.0, -0.58, 1.72),
            rotation=(math.radians(112.0), 0.0, 0.0),
        ),
        mat_prefix,
        "beak_pink",
        pal,
    )

    # Máscara preta angular + olhos afiados de falcão
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_mask_{tag}",
                (0.16, 0.44, 0.22),
                (side * 0.34, -0.26, 1.94),
                rotation=(math.radians(14.0), 0.0, math.radians(side * -10.0)),
            ),
            mat_prefix,
            "mask_black",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_white_{tag}", (0.12, 0.20, 0.14), (side * 0.36, -0.38, 1.97)),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_pupil_{tag}", (0.13, 0.11, 0.13), (side * 0.37, -0.41, 1.97)),
            mat_prefix,
            "mask_black",
            pal,
        )

    # 3. GRANDES ASAS SEMIABERTAS (BORDA CANELA + PENAS ESCALONADAS CREME)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Braço da asa marrom-canela saindo dos ombros para cima e fora
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_arm_{tag}",
                (0.84, 0.22, 0.26),
                (side * 0.72, 0.16, 1.56),
                rotation=(math.radians(10.0), math.radians(side * -38.0), math.radians(side * 12.0)),
            ),
            mat_prefix,
            "back_cinnamon",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_wing_tipbone_{tag}",
                4,
                0.15,
                0.03,
                0.56,
                (side * 1.18, 0.24, 1.98),
                rotation=(math.radians(8.0), math.radians(side * 44.0), math.radians(side * 12.0)),
            ),
            mat_prefix,
            "back_cinnamon",
            pal,
        )
        # Penas da asa (5 lâminas creme formando um grande leque aberto)
        feather_specs = [
            (0.56, 0.22, 1.18, 0.42, -55.0),
            (0.76, 0.24, 1.32, 0.56, -42.0),
            (0.94, 0.26, 1.48, 0.72, -32.0),
            (1.10, 0.28, 1.68, 0.84, -22.0),
            (1.22, 0.30, 1.88, 0.78, -14.0),
        ]
        for f_idx, (fx, fy, fz, flen, ry_deg) in enumerate(feather_specs):
            _add_part(
                parts,
                create_cube(
                    f"_tmp_wing_f_{tag}_{f_idx}",
                    (flen, 0.12, 0.22),
                    (side * fx, fy, fz),
                    rotation=(math.radians(12.0), math.radians(side * ry_deg), math.radians(side * 14.0)),
                ),
                mat_prefix,
                "chest_cream",
                pal,
            )

    # 4. CAUDA EM LEQUE DE 5 PENAS ALTERNANDO ROSA-RUBI E AMARELO-OURO (+Y)
    tail_specs = [
        (-0.34, -26.0, "crest_ruby"),
        (-0.17, -13.0, "tail_gold"),
        (0.00, 0.0, "crest_ruby"),
        (0.17, 13.0, "tail_gold"),
        (0.34, 26.0, "crest_ruby"),
    ]
    for t_idx, (tx, tz_rot, t_mat) in enumerate(tail_specs):
        _add_part(
            parts,
            create_cube(
                f"_tmp_tail_feather_{t_idx}",
                (0.20, 0.86, 0.10),
                (tx, 0.88, 0.62),
                rotation=(math.radians(-28.0), 0.0, math.radians(tz_rot)),
            ),
            mat_prefix,
            t_mat,
            pal,
        )

    # 5. COXAS CREME + PATAS DE RAPINA ROSA-PÁLIDO COM GARRAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(f"_tmp_thigh_{tag}", 1, 0.24, (side * 0.32, -0.02, 0.56)),
            mat_prefix,
            "chest_cream",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_leg_{tag}",
                6,
                0.085,
                0.42,
                (side * 0.32, -0.04, 0.26),
                rotation=(math.radians(-6.0), 0.0, 0.0),
            ),
            mat_prefix,
            "beak_pink",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_pad_{tag}", (0.28, 0.34, 0.10), (side * 0.32, -0.10, 0.05)),
            mat_prefix,
            "beak_pink",
            pal,
        )
        for c_idx, (dx, dy) in enumerate([(-0.11, -0.28), (0.0, -0.32), (0.11, -0.28)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_claw_{tag}_{c_idx}",
                    4,
                    0.045,
                    0.01,
                    0.18,
                    (side * 0.32 + dx, dy - 0.04, 0.05),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "eye_white",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 017. Skytalon lado a lado."""
    specs = [
        ("Skytalon_Shiny", (-9.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Skytalon_Normal", (-5.3, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Skytalon_Grande", (-1.1, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Skytalon_Gigante", (4.1, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Skytalon_Dourada_SuperRara", (11.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_skytalon(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
