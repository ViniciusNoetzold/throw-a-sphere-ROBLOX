"""
031_Armorqueen_Nidoqueen_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "031. Armorqueen — Rainha Blindada (Ref: Nidoqueen)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Armorqueen_Shiny (1.0x - Paleta Shiny / Shyne Verde-Esmeralda + Armadura Rosa)
  2. Armorqueen_Normal (1.0x - Corpo Azul-Turquesa + Placas Bege-Areia + Garras Brancas)
  3. Armorqueen_Grande (1.35x - Normal)
  4. Armorqueen_Gigante (1.85x - Normal)
  5. Armorqueen_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e frente/rosto apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Armorqueen_Shiny`, `Armorqueen_Normal`, `Armorqueen_Grande`,
     `Armorqueen_Gigante`, `Armorqueen_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_teal": (0.34, 0.66, 0.84, 1.0),
        "armor_beige": (0.92, 0.84, 0.64, 1.0),
        "ear_brown": (0.42, 0.34, 0.28, 1.0),
        "claw_white": (0.96, 0.96, 0.96, 1.0),
        "eye_dark": (0.14, 0.14, 0.18, 1.0),
        "mouth_pink": (0.88, 0.52, 0.60, 1.0),
    },
    "shiny_palette": {
        "body_teal": (0.36, 0.66, 0.38, 1.0),
        "armor_beige": (0.88, 0.48, 0.62, 1.0),
        "ear_brown": (0.38, 0.28, 0.32, 1.0),
        "claw_white": (0.98, 0.98, 0.98, 1.0),
        "eye_dark": (0.14, 0.14, 0.18, 1.0),
        "mouth_pink": (0.90, 0.52, 0.62, 1.0),
    },
    "golden_super_rare_palette": {
        "body_teal": (0.98, 0.78, 0.14, 1.0),
        "armor_beige": (1.00, 0.95, 0.62, 1.0),
        "ear_brown": (0.78, 0.52, 0.08, 1.0),
        "claw_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "mouth_pink": (0.92, 0.64, 0.18, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_armorqueen(
    name: str = "Armorqueen_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 031. Armorqueen (Ref: Nidoqueen):
      - Frente/rosto apontando para -Y e pés pesados apoiados em Z = 0.0
      - Colosso bípede azul-turquesa com armadura bege no queixo, peitoral duplo e barriga segmentada
      - Cabeça com chifre curto frontal, boca aberta rugindo e grandes orelhas arredondadas
      - Braços fortes, pernas blindadas com garras brancas, espinhos dorsais e cauda grossa
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Queen_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Queen_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Queen_Norm"

    parts = []

    # 1. TORSO COLOSSAL BLINDADO + PLACAS BEGE NO PEITO E BARRIGA SEGMENTADA
    _add_part(
        parts,
        create_icosphere("_tmp_torso_lower", 1, 0.86, (0.0, 0.08, 0.92), scale=(0.98, 0.94, 1.00)),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_torso_upper", (1.32, 1.04, 0.96), (0.0, 0.04, 1.54)),
        mat_prefix,
        "body_teal",
        pal,
    )
    # Placas peitorais duplas bege (assinatura visual da Nidoqueen)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_chest_plate_{tag}",
                (0.52, 0.24, 0.44),
                (side * 0.34, -0.50, 1.56),
                rotation=(math.radians(-8.0), 0.0, math.radians(side * 8.0)),
            ),
            mat_prefix,
            "armor_beige",
            pal,
        )
    # Barriga blindada segmentada em 3 faixas bege
    for b_idx, (bw, by, bz) in enumerate([(1.06, -0.58, 1.06), (1.16, -0.62, 0.82), (0.96, -0.54, 0.58)]):
        _add_part(
            parts,
            create_cube(f"_tmp_belly_plate_{b_idx}", (bw, 0.28, 0.21), (0.0, by, bz)),
            mat_prefix,
            "armor_beige",
            pal,
        )

    # Espinhos dorsais ao longo das costas
    for s_idx, (sy, sz, rx) in enumerate([(0.56, 1.98, -28.0), (0.72, 1.52, -46.0), (0.82, 1.04, -64.0)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_back_spine_{s_idx}",
                4,
                0.18,
                0.025,
                0.44,
                (0.0, sy, sz),
                rotation=(math.radians(rx), 0.0, math.radians(45.0)),
            ),
            mat_prefix,
            "body_teal",
            pal,
        )

    # 2. CABEÇA, CHIFRE CURTO, MANDÍBULA BEGE E GRANDES ORELHAS ARREDONDADAS
    _add_part(
        parts,
        create_cube("_tmp_head_upper", (0.98, 0.94, 0.58), (0.0, -0.14, 2.34)),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            4,
            0.34,
            0.18,
            0.38,
            (0.0, -0.72, 2.32),
            rotation=(math.radians(94.0), 0.0, math.radians(45.0)),
            scale=(1.15, 0.72, 1.0),
        ),
        mat_prefix,
        "body_teal",
        pal,
    )
    # Mandíbula bege + boca aberta rugindo
    _add_part(
        parts,
        create_cube("_tmp_jaw_beige", (0.78, 0.68, 0.24), (0.0, -0.38, 1.94), rotation=(math.radians(14.0), 0.0, 0.0)),
        mat_prefix,
        "armor_beige",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth_inner", (0.58, 0.44, 0.28), (0.0, -0.46, 2.12)),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    # Chifre curto frontal + pico na coroa
    _add_part(
        parts,
        create_cone(
            "_tmp_forehead_horn",
            4,
            0.13,
            0.02,
            0.34,
            (0.0, -0.52, 2.74),
            rotation=(math.radians(22.0), 0.0, math.radians(45.0)),
        ),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_crown_spike",
            4,
            0.14,
            0.02,
            0.32,
            (0.0, 0.14, 2.74),
            rotation=(math.radians(-18.0), 0.0, math.radians(45.0)),
        ),
        mat_prefix,
        "body_teal",
        pal,
    )

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_eye_white_{tag}", (0.16, 0.26, 0.18), (side * 0.42, -0.52, 2.40)),
            mat_prefix,
            "claw_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_dark_{tag}", (0.16, 0.14, 0.15), (side * 0.44, -0.58, 2.40)),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Grandes orelhas arredondadas com interior marrom
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ear_outer_{tag}",
                6,
                0.40,
                0.16,
                (side * 0.68, 0.02, 2.66),
                rotation=(math.radians(74.0), math.radians(side * -22.0), math.radians(side * 20.0)),
                scale=(1.10, 1.18, 1.0),
            ),
            mat_prefix,
            "body_teal",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ear_inner_{tag}",
                6,
                0.28,
                0.10,
                (side * 0.66, -0.05, 2.65),
                rotation=(math.radians(74.0), math.radians(side * -22.0), math.radians(side * 20.0)),
                scale=(1.02, 1.10, 1.0),
            ),
            mat_prefix,
            "ear_brown",
            pal,
        )

    # 3. BRAÇOS MUSCULOSOS + PERNAS PESADAS COM GARRAS EM Z = 0.0 + CAUDA GROSSA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(f"_tmp_shoulder_{tag}", 1, 0.34, (side * 0.82, 0.0, 1.78)),
            mat_prefix,
            "body_teal",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_arm_{tag}",
                6,
                0.24,
                0.76,
                (side * 1.04, -0.26, 1.48),
                rotation=(math.radians(52.0), math.radians(side * 24.0), 0.0),
            ),
            mat_prefix,
            "body_teal",
            pal,
        )
        for c_idx, dz in enumerate((-0.09, 0.0, 0.09)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{tag}_{c_idx}",
                    4,
                    0.06,
                    0.014,
                    0.22,
                    (side * 1.16, -0.64, 1.24 + dz),
                    rotation=(math.radians(96.0), 0.0, math.radians(side * -12.0)),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

        # Pernas robustas + pés blindados tocando Z = 0.0
        _add_part(
            parts,
            create_cube(f"_tmp_thigh_{tag}", (0.56, 0.68, 0.72), (side * 0.68, 0.04, 0.56)),
            mat_prefix,
            "body_teal",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{tag}", (0.54, 0.66, 0.22), (side * 0.70, -0.10, 0.11)),
            mat_prefix,
            "body_teal",
            pal,
        )
        for c_idx, dx in enumerate((-0.14, 0.0, 0.14)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_claw_{tag}_{c_idx}",
                    4,
                    0.075,
                    0.016,
                    0.26,
                    (side * 0.70 + dx, -0.50, 0.09),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # Cauda grossa curvando para a direita/trás
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_1",
            6,
            0.36,
            0.24,
            0.96,
            (0.32, 0.96, 0.44),
            rotation=(math.radians(-78.0), 0.0, math.radians(-24.0)),
        ),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_2",
            6,
            0.24,
            0.05,
            0.88,
            (0.84, 1.32, 0.54),
            rotation=(math.radians(-68.0), 0.0, math.radians(-52.0)),
        ),
        mat_prefix,
        "body_teal",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 031. Armorqueen lado a lado."""
    specs = [
        ("Armorqueen_Shiny", (-9.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Armorqueen_Normal", (-5.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Armorqueen_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Armorqueen_Gigante", (5.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Armorqueen_Dourada_SuperRara", (12.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_armorqueen(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
