"""
066_Ironkid_Machop_5Variacoes_Blender.py
========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "066. Ironkid — Aprendiz Forte (Ref: Machop)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Ironkid_Shiny (1.0x - Paleta Shiny Verde-Musgo + Cristas Ocre-Dourado)
  2. Ironkid_Normal (1.0x - Cinza-Azulado + 3 Cristas Bege + Olhos Rubi + 3 Riscos nas Costelas)
  3. Ironkid_Grande (1.35x - Normal)
  4. Ironkid_Gigante (1.85x - Normal)
  5. Ironkid_Dourada_SuperRara (2.25x - Ouro Reluzente + Cristas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2, cones/cilindros 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base dos pés alinhada exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_skin": (0.62, 0.72, 0.76, 1.0),
        "body_shade": (0.46, 0.56, 0.62, 1.0),
        "crest_beige": (0.80, 0.76, 0.68, 1.0),
        "eye_red": (0.88, 0.26, 0.24, 1.0),
        "mouth_pink": (0.88, 0.56, 0.64, 1.0),
        "mouth_deep": (0.46, 0.20, 0.26, 1.0),
        "white": (0.98, 0.98, 0.99, 1.0),
        "dark": (0.14, 0.16, 0.20, 1.0),
    },
    "shiny_palette": {
        "body_skin": (0.58, 0.66, 0.38, 1.0),
        "body_shade": (0.42, 0.50, 0.28, 1.0),
        "crest_beige": (0.76, 0.66, 0.44, 1.0),
        "eye_red": (0.90, 0.28, 0.24, 1.0),
        "mouth_pink": (0.90, 0.56, 0.64, 1.0),
        "mouth_deep": (0.48, 0.22, 0.28, 1.0),
        "white": (0.98, 0.98, 0.99, 1.0),
        "dark": (0.14, 0.16, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "body_skin": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.62, 0.10, 1.0),
        "crest_beige": (0.10, 0.92, 1.00, 1.0),
        "eye_red": (0.10, 0.92, 1.00, 1.0),
        "mouth_pink": (0.98, 0.86, 0.38, 1.0),
        "mouth_deep": (0.64, 0.42, 0.08, 1.0),
        "white": (1.00, 0.99, 0.92, 1.0),
        "dark": (0.06, 0.54, 0.70, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_segment(
    name: str,
    p1: tuple,
    p2: tuple,
    r1: float,
    r2: float,
    vertices: int = 8,
    extend: float = 1.05,
):
    """Cria um cone/segmento conectando exatamente p1 -> p2 sem folgas."""
    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    dz = p2[2] - p1[2]
    dist = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dist < 1e-6:
        dist = 1e-6
    mid = ((p1[0] + p2[0]) * 0.5, (p1[1] + p2[1]) * 0.5, (p1[2] + p2[2]) * 0.5)
    theta = math.acos(max(-1.0, min(1.0, dz / dist)))
    phi = math.atan2(dy, dx)
    return create_cone(
        name=name,
        vertices=vertices,
        radius1=r1,
        radius2=r2,
        depth=dist * extend,
        location=mid,
        rotation=(0.0, theta, phi),
    )


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_ironkid(
    name: str = "Ironkid_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 066. Ironkid (Ref: Machop):
      - Corpo humanoide compacto cinza-azulado (verde-musgo na Shiny) com 3 riscos nas costelas
      - Cabeça reptiliana simpática com focinho arredondado, olhos grandes vermelhos com íris
        e sorriso aberto energético mostrando a língua rosa
      - 3 cristas planas bege paralelas no topo da cabeça (central levemente mais alta)
      - Pose marcial dinâmica: braço esquerdo (-X) dando soco para frente com punho fechado robusto,
        braço direito (+X) recuado em guarda + cauda curta atrás
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Ironkid_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Ironkid_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Ironkid_Norm"

    parts = []

    # 1. TRONCO ATLÉTICO COMPACTO + 3 MARCAS LATERAIS NAS COSTELAS
    _add_part(
        parts,
        create_icosphere("_tmp_torso_lower", 2, 0.42, (0.0, 0.02, 0.80), scale=(1.02, 0.90, 1.08)),
        mat_prefix,
        "body_skin",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_torso_chest", 2, 0.42, (0.0, 0.00, 1.18), scale=(1.10, 0.88, 0.94)),
        mat_prefix,
        "body_skin",
        pal,
    )
    # 3 riscos escuros sutis em cada lado das costelas (marca registrada do Machop)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        for r_idx, rz in enumerate((1.16, 1.08, 1.00)):
            _add_part(
                parts,
                create_segment(
                    f"_tmp_rib_{tag}_{r_idx}",
                    (side * 0.14, -0.37, rz),
                    (side * 0.34, -0.32, rz - 0.03),
                    0.016,
                    0.014,
                    vertices=5,
                ),
                mat_prefix,
                "dark",
                pal,
            )

    # Pescoço forte
    _add_part(
        parts,
        create_cylinder("_tmp_neck", 8, 0.24, 0.28, (0.0, -0.02, 1.48)),
        mat_prefix,
        "body_skin",
        pal,
    )

    # 2. CABEÇA COM 3 CRISTAS PARALELAS BEGE, OLHOS VERMELHOS GRANDES E SORRISO ABERTO
    _add_part(
        parts,
        create_icosphere("_tmp_head_main", 2, 0.42, (0.0, -0.06, 1.84), scale=(0.98, 1.06, 1.04)),
        mat_prefix,
        "body_skin",
        pal,
    )
    # Focinho arredondado amigável para frente (-Y)
    _add_part(
        parts,
        create_icosphere("_tmp_snout", 2, 0.28, (0.0, -0.36, 1.72), scale=(1.08, 0.98, 0.72)),
        mat_prefix,
        "body_skin",
        pal,
    )
    # Narinas sutis na ponta do focinho
    for side in (-1.0, 1.0):
        _add_part(
            parts,
            create_icosphere(f"_tmp_nostril_{'L' if side < 0 else 'R'}", 1, 0.022, (side * 0.08, -0.62, 1.74)),
            mat_prefix,
            "dark",
            pal,
        )

    # 3 CRISTAS PARALELAS BEGE NO TOPO DA CABEÇA (central mais alta)
    crest_specs = [
        ("L", -0.14, 0.0, 0.32, 2.26),
        ("C", 0.00, -0.02, 0.36, 2.34),
        ("R", 0.14, 0.0, 0.32, 2.26),
    ]
    for c_tag, cx, cy, rad, cz in crest_specs:
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_crest_{c_tag}",
                2,
                rad,
                (cx, cy, cz),
                rotation=(math.radians(-16.0), 0.0, 0.0),
                scale=(0.24, 1.24, 0.96),
            ),
            mat_prefix,
            "crest_beige",
            pal,
        )

    # Olhos expressivos verticais (esclera branca + íris rubi + pupila escura + brilho)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.15,
                (side * 0.24, -0.38, 1.88),
                rotation=(0.0, 0.0, math.radians(side * -22.0)),
                scale=(0.76, 0.56, 1.18),
            ),
            mat_prefix,
            "white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                2,
                0.115,
                (side * 0.24, -0.43, 1.88),
                rotation=(0.0, 0.0, math.radians(side * -22.0)),
                scale=(0.68, 0.52, 1.14),
            ),
            mat_prefix,
            "eye_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.056,
                (side * 0.23, -0.47, 1.88),
                scale=(0.56, 0.48, 1.25),
            ),
            mat_prefix,
            "dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.028,
                (side * 0.21, -0.49, 1.93),
            ),
            mat_prefix,
            "white",
            pal,
        )

    # Sorriso aberto animado + língua rosa
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_cavity", 2, 0.21, (0.0, -0.42, 1.56), scale=(1.12, 0.62, 0.72)),
        mat_prefix,
        "mouth_deep",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_tongue", 2, 0.16, (0.0, -0.45, 1.50), scale=(1.04, 0.58, 0.52)),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # 3. BRAÇOS EM POSE DE SOCO MARCIAL (ESQUERDO -X SOCANDO À FRENTE, DIREITO +X EM GUARDA)
    # Braço esquerdo (-X): soco poderoso projetado para frente-esquerda
    l_sh = (-0.44, -0.02, 1.28)
    l_el = (-0.70, -0.26, 1.24)
    l_wr = (-0.86, -0.68, 1.32)
    _add_part(parts, create_icosphere("_tmp_sh_L", 2, 0.19, l_sh), mat_prefix, "body_skin", pal)
    _add_part(parts, create_segment("_tmp_arm_L_up", l_sh, l_el, 0.16, 0.15, vertices=8), mat_prefix, "body_skin", pal)
    _add_part(parts, create_icosphere("_tmp_el_L", 1, 0.15, l_el), mat_prefix, "body_skin", pal)
    _add_part(parts, create_segment("_tmp_arm_L_lo", l_el, l_wr, 0.16, 0.18, vertices=8), mat_prefix, "body_skin", pal)
    # Punho fechado volumoso com nós dos dedos
    fist_l = (-0.92, -0.82, 1.34)
    _add_part(parts, create_icosphere("_tmp_fist_L", 2, 0.24, fist_l, scale=(1.12, 1.05, 0.96)), mat_prefix, "body_skin", pal)
    for k_idx, kx in enumerate((-0.14, -0.05, 0.05, 0.14)):
        _add_part(
            parts,
            create_icosphere(f"_tmp_knuckle_L_{k_idx}", 1, 0.078, (fist_l[0] + kx, fist_l[1] - 0.18, fist_l[2] + 0.04)),
            mat_prefix,
            "body_skin",
            pal,
        )
    _add_part(
        parts,
        create_icosphere("_tmp_thumb_L", 1, 0.095, (fist_l[0] + 0.18, fist_l[1] - 0.10, fist_l[2] - 0.12), scale=(1.1, 1.2, 0.85)),
        mat_prefix,
        "body_skin",
        pal,
    )

    # Braço direito (+X): puxado para o lado/trás com punho cerrado
    r_sh = (0.44, -0.02, 1.28)
    r_el = (0.76, 0.04, 1.22)
    r_wr = (0.94, -0.14, 1.02)
    _add_part(parts, create_icosphere("_tmp_sh_R", 2, 0.19, r_sh), mat_prefix, "body_skin", pal)
    _add_part(parts, create_segment("_tmp_arm_R_up", r_sh, r_el, 0.16, 0.14, vertices=8), mat_prefix, "body_skin", pal)
    _add_part(parts, create_icosphere("_tmp_el_R", 1, 0.14, r_el), mat_prefix, "body_skin", pal)
    _add_part(parts, create_segment("_tmp_arm_R_lo", r_el, r_wr, 0.14, 0.15, vertices=8), mat_prefix, "body_skin", pal)
    _add_part(parts, create_icosphere("_tmp_fist_R", 2, 0.20, (1.00, -0.20, 0.96)), mat_prefix, "body_skin", pal)

    # 4. PERNAS ROBUSTAS EM BASE MARCIAL FIRME EM Z = 0.0
    leg_specs = [
        # (tag, hip, knee, ankle, foot_center)
        ("L", (-0.28, 0.02, 0.62), (-0.42, -0.14, 0.36), (-0.40, -0.06, 0.12), (-0.42, -0.18, 0.10)),
        ("R", (0.28, 0.02, 0.62), (0.38, -0.08, 0.34), (0.36, 0.02, 0.12), (0.38, -0.12, 0.10)),
    ]
    for tag, p_hip, p_knee, p_ankle, p_foot in leg_specs:
        _add_part(parts, create_segment(f"_tmp_thigh_{tag}", p_hip, p_knee, 0.21, 0.18, vertices=8), mat_prefix, "body_skin", pal)
        _add_part(parts, create_icosphere(f"_tmp_knee_{tag}", 1, 0.17, p_knee), mat_prefix, "body_skin", pal)
        _add_part(parts, create_segment(f"_tmp_shin_{tag}", p_knee, p_ankle, 0.17, 0.15, vertices=8), mat_prefix, "body_skin", pal)
        _add_part(
            parts,
            create_icosphere(f"_tmp_foot_{tag}", 2, 0.19, p_foot, scale=(1.08, 1.38, 0.62)),
            mat_prefix,
            "body_skin",
            pal,
        )

    # 5. CAUDA REPTILIANA CURTA ATRÁS
    _add_part(
        parts,
        create_segment("_tmp_tail_base", (0.0, 0.32, 0.58), (0.0, 0.72, 0.48), 0.18, 0.11, vertices=8),
        mat_prefix,
        "body_skin",
        pal,
    )
    _add_part(
        parts,
        create_segment("_tmp_tail_tip", (0.0, 0.72, 0.48), (0.0, 0.96, 0.54), 0.11, 0.025, vertices=7),
        mat_prefix,
        "body_skin",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 066. Ironkid lado a lado."""
    specs = [
        ("Ironkid_Shiny", (-10.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Ironkid_Normal", (-5.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Ironkid_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Ironkid_Gigante", (5.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Ironkid_Dourada_SuperRara", (13.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_ironkid(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
