"""
053_Velvetlynx_Persian_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "053. Velvetlynx — Pantera Real (Ref: Persian)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Velvetlynx_Shiny (1.0x - Pelagem Pérola-Marfim + Orelhas Internas Rosa-Suave + Joia Magenta-Rubi)
  2. Velvetlynx_Normal (1.0x - Felino Quadrúpede Bege-Creme + Joia Rubi na Testa + Bordas Pretas + Cauda Enrolada)
  3. Velvetlynx_Grande (1.35x - Normal)
  4. Velvetlynx_Gigante (1.85x - Normal)
  5. Velvetlynx_Dourada_SuperRara (2.25x - Ouro Reluzente + Joia, Olhos e Bordas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (corpo alongado de pantera, pescoço esguio, joia rubi, 6 bigodes, cauda espiralada)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas apoiadas alinhadas exatamente em `Z = 0.0` e cabeça/rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "fur_cream": (0.94, 0.88, 0.72, 1.0),
        "fur_shade": (0.83, 0.75, 0.58, 1.0),
        "ear_black": (0.15, 0.14, 0.16, 1.0),
        "ear_inner": (0.64, 0.56, 0.46, 1.0),
        "gem_ruby": (0.92, 0.18, 0.28, 1.0),
        "gem_shine": (1.00, 0.76, 0.82, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_red": (0.78, 0.16, 0.22, 1.0),
        "nose_black": (0.14, 0.13, 0.15, 1.0),
    },
    "shiny_palette": {
        "fur_cream": (0.98, 0.91, 0.88, 1.0),
        "fur_shade": (0.88, 0.78, 0.76, 1.0),
        "ear_black": (0.16, 0.14, 0.18, 1.0),
        "ear_inner": (0.94, 0.48, 0.64, 1.0),
        "gem_ruby": (0.88, 0.18, 0.54, 1.0),
        "gem_shine": (1.00, 0.76, 0.90, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_red": (0.84, 0.16, 0.44, 1.0),
        "nose_black": (0.16, 0.13, 0.17, 1.0),
    },
    "golden_super_rare_palette": {
        "fur_cream": (0.98, 0.78, 0.14, 1.0),
        "fur_shade": (0.86, 0.64, 0.10, 1.0),
        "ear_black": (0.06, 0.48, 0.64, 1.0),
        "ear_inner": (1.00, 0.88, 0.36, 1.0),
        "gem_ruby": (0.10, 0.92, 1.00, 1.0),
        "gem_shine": (0.84, 0.99, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "pupil_red": (0.10, 0.92, 1.00, 1.0),
        "nose_black": (0.06, 0.52, 0.68, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_velvetlynx(
    name: str = "Velvetlynx_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 053. Velvetlynx (Ref: Persian):
      - Corpo felino quadrúpede elegante, alongado e musculoso (peito, cintura esbelta, garupa)
      - Pescoço longo erguido com altivez levando à cabeça felina régia voltada para -Y
      - Joia rubi brilhante redonda bem no centro da testa + orelhas arredondadas com bordas pretas
      - Olhos amendoados altivos com fendas rubi, focinho preto, presinhas e 6 bigodes finos
      - 3 patas firmes em Z = 0.0 + pata dianteira esquerda erguida com elegância no passo felino
      - Longa cauda sinuosa erguida atrás com ponta enrolada em espiral bem visível na lateral
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Velv_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Velv_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Velv_Norm"

    parts = []

    # 1. CORPO QUADRÚPEDE ELEGANTE DE PANTERA (PEITO -> CINTURA -> GARUPA)
    # Peito dianteiro
    _add_part(
        parts,
        create_icosphere("_tmp_chest", 2, 0.36, (0.0, -0.44, 0.94), scale=(0.94, 1.12, 1.04)),
        mat_prefix,
        "fur_cream",
        pal,
    )
    # Tronco/cintura esbelta
    _add_part(
        parts,
        create_cone(
            "_tmp_waist",
            10,
            0.31,
            0.28,
            0.84,
            (0.0, 0.06, 0.92),
            rotation=(math.radians(92.0), 0.0, 0.0),
            scale=(0.92, 0.94, 1.0),
        ),
        mat_prefix,
        "fur_cream",
        pal,
    )
    # Garupa traseira musculosa
    _add_part(
        parts,
        create_icosphere("_tmp_rump", 2, 0.35, (0.0, 0.56, 0.90), scale=(0.92, 1.12, 1.00)),
        mat_prefix,
        "fur_cream",
        pal,
    )

    # 2. PESCOÇO ESGUIO E CABEÇA FELINA RÉGIA VOLTADA PARA -Y (TRANSIÇÃO SUAVE COM O PEITO)
    _add_part(
        parts,
        create_icosphere("_tmp_shoulder_blend", 2, 0.30, (0.0, -0.50, 1.12), scale=(0.94, 1.04, 0.92)),
        mat_prefix,
        "fur_cream",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_neck",
            8,
            0.29,
            0.21,
            0.66,
            (0.0, -0.58, 1.34),
            rotation=(math.radians(-16.0), 0.0, 0.0),
            scale=(0.92, 1.02, 1.0),
        ),
        mat_prefix,
        "fur_cream",
        pal,
    )
    # Crânio felino
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.36, (0.0, -0.68, 1.68), scale=(1.10, 0.98, 0.92)),
        mat_prefix,
        "fur_cream",
        pal,
    )
    # Focinho refinado de pantera
    _add_part(
        parts,
        create_icosphere("_tmp_muzzle", 2, 0.21, (0.0, -0.96, 1.57), scale=(1.08, 0.88, 0.72)),
        mat_prefix,
        "fur_cream",
        pal,
    )
    # Narizinho preto triangular
    _add_part(
        parts,
        create_icosphere("_tmp_nose", 1, 0.055, (0.0, -1.14, 1.60), scale=(1.22, 0.72, 0.78)),
        mat_prefix,
        "nose_black",
        pal,
    )
    # Linha sutil da boca + 2 presinhas delicadas
    _add_part(
        parts,
        create_cylinder(
            "_tmp_mouth_line",
            6,
            0.015,
            0.22,
            (0.0, -1.09, 1.50),
            rotation=(0.0, math.radians(90.0), 0.0),
        ),
        mat_prefix,
        "nose_black",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.024,
                0.006,
                0.06,
                (side * 0.09, -1.10, 1.47),
                rotation=(math.radians(180.0), 0.0, 0.0),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # 3. JOIA RUBI REDONDA NA TESTA (ASSINATURA DO PERSIAN!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_gem_rim",
            2,
            0.096,
            (0.0, -0.96, 1.84),
            rotation=(math.radians(-18.0), 0.0, 0.0),
            scale=(1.02, 0.56, 1.12),
        ),
        mat_prefix,
        "nose_black",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_gem_ruby",
            2,
            0.088,
            (0.0, -0.99, 1.84),
            rotation=(math.radians(-18.0), 0.0, 0.0),
            scale=(0.98, 0.60, 1.08),
        ),
        mat_prefix,
        "gem_ruby",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_gem_shine",
            1,
            0.032,
            (-0.028, -1.04, 1.88),
            scale=(0.90, 0.50, 0.90),
        ),
        mat_prefix,
        "gem_shine",
        pal,
    )

    # 4. ORELHAS FELINAS ELEGANTES COM BORDAS PRETAS E INTERIOR SUAVE
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ear_black_{tag}",
                2,
                0.20,
                (side * 0.32, -0.66, 1.98),
                rotation=(math.radians(-8.0), math.radians(side * 34.0), math.radians(side * -16.0)),
                scale=(0.86, 0.38, 1.18),
            ),
            mat_prefix,
            "ear_black",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ear_in_{tag}",
                2,
                0.145,
                (side * 0.30, -0.71, 1.94),
                rotation=(math.radians(-8.0), math.radians(side * 34.0), math.radians(side * -16.0)),
                scale=(0.82, 0.30, 1.04),
            ),
            mat_prefix,
            "ear_inner",
            pal,
        )

    # 5. OLHOS AMENDOADOS ALTIVOS + FENDAS RUBI + 6 BIGODES LONGOS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_w_{tag}",
                2,
                0.11,
                (side * 0.21, -0.98, 1.71),
                rotation=(0.0, math.radians(side * -14.0), math.radians(side * -22.0)),
                scale=(1.14, 0.44, 0.78),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_pupil_{tag}",
                6,
                0.020,
                0.14,
                (side * 0.21, -1.03, 1.71),
                scale=(0.85, 0.65, 1.0),
            ),
            mat_prefix,
            "pupil_red",
            pal,
        )
        # 3 bigodes longos em leque de cada lado da bochecha
        for w_i, (wz, rot_y) in enumerate([
            (1.62, 82.0),
            (1.56, 98.0),
            (1.50, 114.0),
        ]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_whisk_{tag}_{w_i}",
                    5,
                    0.020,
                    0.005,
                    0.46,
                    (side * 0.42, -0.94, wz),
                    rotation=(math.radians(8.0), math.radians(side * rot_y), 0.0),
                ),
                mat_prefix,
                "fur_cream",
                pal,
            )

    # 6. QUATRO PERNAS ESGUIAS DE PANTERA (3 APOIADAS EM Z = 0.0 + DIANTEIRA DIREITA EM PASSO ELEGANTE)
    # Pata dianteira esquerda (-X) firme no chão
    _add_part(
        parts,
        create_cone("_tmp_fleg_u_L", 7, 0.13, 0.10, 0.54, (-0.24, -0.44, 0.62), rotation=(math.radians(8.0), 0.0, 0.0)),
        mat_prefix,
        "fur_cream",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_fleg_d_L", 7, 0.09, 0.10, 0.44, (-0.24, -0.50, 0.24), rotation=(math.radians(-6.0), 0.0, 0.0)),
        mat_prefix,
        "fur_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_fpaw_L", 2, 0.14, (-0.24, -0.58, 0.08), scale=(0.94, 1.32, 0.58)),
        mat_prefix,
        "fur_cream",
        pal,
    )

    # Pata dianteira direita (+X) estendida com elegância em passo felino (como na arte!)
    _add_part(
        parts,
        create_cone(
            "_tmp_fleg_u_R",
            7,
            0.13,
            0.10,
            0.52,
            (0.24, -0.56, 0.66),
            rotation=(math.radians(38.0), 0.0, 0.0),
        ),
        mat_prefix,
        "fur_cream",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_fleg_d_R",
            7,
            0.085,
            0.095,
            0.46,
            (0.26, -0.84, 0.42),
            rotation=(math.radians(52.0), 0.0, 0.0),
        ),
        mat_prefix,
        "fur_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_fpaw_R",
            2,
            0.135,
            (0.26, -1.04, 0.28),
            rotation=(math.radians(24.0), 0.0, 0.0),
            scale=(0.94, 1.28, 0.58),
        ),
        mat_prefix,
        "fur_cream",
        pal,
    )

    # Duas patas traseiras musculosas firmes em Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa traseira forte
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.24,
                (side * 0.24, 0.58, 0.72),
                rotation=(math.radians(18.0), 0.0, 0.0),
                scale=(0.66, 1.04, 1.26),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
        # Jarrete/canela descendo até o chão
        _add_part(
            parts,
            create_cone(
                f"_tmp_hleg_{tag}",
                7,
                0.085,
                0.105,
                0.56,
                (side * 0.24, 0.66, 0.32),
                rotation=(math.radians(-12.0), 0.0, 0.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
        # Pata traseira em Z = 0.0
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hpaw_{tag}",
                2,
                0.14,
                (side * 0.24, 0.56, 0.08),
                scale=(0.94, 1.32, 0.58),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )

    # 7. CAUDA LONGA ELEGANTE ENROLADA EM ESPIRAL (CURVADA PARA A DIREITA +X PARA APARECER NA VISTA FRONTAL)
    tail_path = [
        ((0.06, 0.92, 0.84), (72.0, 12.0, -16.0), 0.082, 0.074, 0.42),
        ((0.28, 1.18, 0.78), (38.0, 42.0, -34.0), 0.074, 0.070, 0.44),
        ((0.60, 1.16, 0.88), (-18.0, 58.0, -18.0), 0.072, 0.074, 0.42),
        ((0.86, 1.04, 1.14), (-14.0, 18.0, 0.0), 0.076, 0.082, 0.36),
    ]
    for tp_i, (loc, rot_d, r1, r2, depth) in enumerate(tail_path):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_p_{tp_i}",
                7,
                r1,
                r2,
                depth,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
    # Espiral felina fluida e contínua na ponta da cauda (8 pontos suaves)
    tail_curl = [
        (0.095, (0.94, 1.00, 1.32)),
        (0.098, (0.96, 0.98, 1.46)),
        (0.096, (0.86, 0.96, 1.56)),
        (0.094, (0.72, 0.95, 1.56)),
        (0.090, (0.62, 0.94, 1.46)),
        (0.086, (0.64, 0.94, 1.34)),
        (0.082, (0.74, 0.94, 1.30)),
        (0.078, (0.82, 0.94, 1.38)),
    ]
    for tc_i, (rad, loc) in enumerate(tail_curl):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tcurl_{tc_i}", 2, rad, loc, scale=(1.02, 0.88, 1.02)),
            mat_prefix,
            "fur_cream",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 053. Velvetlynx lado a lado."""
    specs = [
        ("Velvetlynx_Shiny", (-10.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Velvetlynx_Normal", (-6.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Velvetlynx_Grande", (-1.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Velvetlynx_Gigante", (4.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Velvetlynx_Dourada_SuperRara", (12.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_velvetlynx(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
