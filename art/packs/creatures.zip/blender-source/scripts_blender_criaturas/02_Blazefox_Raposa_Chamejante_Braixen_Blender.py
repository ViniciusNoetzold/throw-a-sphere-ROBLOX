"""
02_Blazefox_Raposa_Chamejante_Braixen_Blender.py
================================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera o modelo 3D
da criatura "02. Blazefox — Raposa Chamejante (Evolução Fogo - Estágio 2 / Estilo Braixen)"
no estilo Low-Poly / Voxel Blocky para o jogo Roblox "Jogue uma Orbe / Throw a Sphere".

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no modelo final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cilindros 6 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Variações automáticas (`Normal`, `Dourado`, `Huge`) geradas lado a lado
  - Base dos pés alinhada exatamente em `Z = 0.0` e frente apontando para `-Y` (pronto para FBX -> Roblox Studio)

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione um modelo (ex: `Blazefox_Normal`) e exporte via `File > Export > FBX (.fbx)`
     com `Selected Objects` marcado e `Apply Transform` para importar como `MeshPart` no Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "huge_scale": 1.85,
    "palette": {
        "fur_yellow": (0.98, 0.89, 0.42, 1.0),    # Túnica/saia, topo da cabeça, orelhas e cauda amarelo-sol (#FAE36B)
        "fur_white": (0.97, 0.97, 0.98, 1.0),     # Focinho, bochechas, gola felpuda e braços brancos (#F8F8FA)
        "flame_red": (0.91, 0.31, 0.16, 1.0),     # Tufos de chama nas orelhas, nariz e ponta da cauda (#E84F29)
        "legs_dark": (0.24, 0.23, 0.25, 1.0),     # Pernas bípedes e quadris cinza-carvão (#3D3B40)
        "wood_wand": (0.44, 0.28, 0.16, 1.0),     # Galho/varinha bifurcada em 'Y' na cauda (#704729)
        "eyes_amber": (0.88, 0.22, 0.12, 1.0),    # Olhos âmbar-avermelhados expressivos
        "outline_dark": (0.12, 0.09, 0.08, 1.0),  # Cílios/sobrancelhas e detalhes escuros
    },
    "golden_palette": {
        "fur_yellow": (1.00, 0.88, 0.24, 1.0),
        "fur_white": (1.00, 0.96, 0.68, 1.0),
        "flame_red": (1.00, 0.64, 0.08, 1.0),
        "legs_dark": (0.72, 0.52, 0.10, 1.0),
        "wood_wand": (0.86, 0.68, 0.22, 1.0),
        "eyes_amber": (0.12, 0.94, 1.00, 1.0),
        "outline_dark": (0.26, 0.18, 0.04, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (ideal para acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, zera a origem na base dos pés (Z = 0.0),
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_blazefox(
    name: str = "Blazefox_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    is_golden: bool = False,
):
    """
    Constrói o modelo 3D completo da Raposa Chamejante (02. Blazefox / Estilo Braixen):
      - Postura bípede ágil apontando para -Y
      - Base das patas alinhada em Z = 0.0
      - Pernas carvão, saia/túnica amarela, gola branca, chamas nas orelhas e varinha em 'Y' na cauda
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    pal = CONFIG["golden_palette"] if is_golden else CONFIG["palette"]
    mat_prefix = "Mat_Blazefox_Gold" if is_golden else "Mat_Blazefox"
    parts = []

    # 1. PERNAS BÍPEDES E QUADRIS (Cinza-Carvão Escuro)
    _add_part(
        parts,
        create_cube("_tmp_pelvis", (0.82, 0.52, 0.34), (0.0, 0.04, 0.86)),
        mat_prefix,
        "legs_dark",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        lx = sx * 0.28
        # Ponta lateral escura estilizada do quadril
        _add_part(
            parts,
            create_cone(
                f"_tmp_hip_flare_{side_idx}",
                4,
                0.15,
                0.02,
                0.32,
                (sx * 0.48, 0.04, 0.88),
                (0.0, math.radians(sx * 75), 0.0),
                scale=(1.0, 0.65, 1.0),
            ),
            mat_prefix,
            "legs_dark",
            pal,
        )
        # Coxa superior inclinada
        _add_part(
            parts,
            create_cone(
                f"_tmp_thigh_{side_idx}",
                6,
                0.13,
                0.21,
                0.44,
                (lx, 0.00, 0.66),
                (math.radians(-12), 0.0, 0.0),
            ),
            mat_prefix,
            "legs_dark",
            pal,
        )
        # Canela esguia inclinada
        _add_part(
            parts,
            create_cone(
                f"_tmp_shin_{side_idx}",
                6,
                0.085,
                0.12,
                0.44,
                (lx, 0.02, 0.28),
                (math.radians(15), 0.0, 0.0),
            ),
            mat_prefix,
            "legs_dark",
            pal,
        )
        # Pé com 3 dedos em Z = 0
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{side_idx}", (0.18, 0.26, 0.12), (lx, -0.04, 0.06)),
            mat_prefix,
            "legs_dark",
            pal,
        )
        for toe_i, tx_off in enumerate([-0.055, 0.0, 0.055]):
            _add_part(
                parts,
                create_cube(
                    f"_tmp_toe_{side_idx}_{toe_i}",
                    (0.048, 0.10, 0.08),
                    (lx + tx_off, -0.19, 0.04),
                ),
                mat_prefix,
                "legs_dark",
                pal,
            )

    # 2. TORSO ESGUIO E SAIA/TÚNICA FLAMEJANTE (Amarelo-Sol)
    _add_part(
        parts,
        create_cone("_tmp_torso_waist", 6, 0.26, 0.19, 0.52, (0.0, 0.02, 1.32)),
        mat_prefix,
        "fur_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_skirt_cone", 6, 0.62, 0.25, 0.46, (0.0, 0.02, 1.03)),
        mat_prefix,
        "fur_yellow",
        pal,
    )

    # Pontas laterais e frontais arrebitadas na barra da túnica/saia
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_skirt_tip_side_{side_idx}",
                4,
                0.18,
                0.02,
                0.44,
                (sx * 0.58, 0.00, 0.90),
                (0.0, math.radians(sx * 68), 0.0),
                scale=(1.0, 0.65, 1.0),
            ),
            mat_prefix,
            "fur_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_skirt_tip_front_{side_idx}",
                4,
                0.14,
                0.02,
                0.32,
                (sx * 0.26, -0.34, 0.88),
                (math.radians(52), math.radians(sx * 24), 0.0),
            ),
            mat_prefix,
            "fur_yellow",
            pal,
        )

    # 3. PESCOÇO, GOLA FELPUDA DE 4 PONTAS E BRAÇOS ESGUIOS (Branco)
    _add_part(
        parts,
        create_cylinder("_tmp_neck", 6, 0.11, 0.34, (0.0, -0.01, 1.72)),
        mat_prefix,
        "fur_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_collar_core", 1, 0.28, (0.0, -0.04, 1.56), scale=(1.18, 0.88, 0.65)),
        mat_prefix,
        "fur_white",
        pal,
    )
    # Ponta frontal inferior da gola sobre o peito
    _add_part(
        parts,
        create_cone(
            "_tmp_collar_front",
            4,
            0.16,
            0.02,
            0.34,
            (0.0, -0.22, 1.44),
            (math.radians(146), 0.0, 0.0),
        ),
        mat_prefix,
        "fur_white",
        pal,
    )
    # Ponta traseira da gola
    _add_part(
        parts,
        create_cone(
            "_tmp_collar_back",
            4,
            0.15,
            0.02,
            0.36,
            (0.0, 0.18, 1.62),
            (math.radians(-42), 0.0, 0.0),
        ),
        mat_prefix,
        "fur_white",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        # Pontas laterais da gola sobre os ombros
        _add_part(
            parts,
            create_cone(
                f"_tmp_collar_wing_{side_idx}",
                4,
                0.16,
                0.02,
                0.40,
                (sx * 0.28, -0.04, 1.66),
                (0.0, math.radians(sx * 46), 0.0),
                scale=(1.0, 0.68, 1.0),
            ),
            mat_prefix,
            "fur_white",
            pal,
        )
        # Braço superior fino
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_arm_upper_{side_idx}",
                6,
                0.062,
                0.38,
                (sx * 0.29, -0.04, 1.38),
                (0.0, math.radians(sx * -18), 0.0),
            ),
            mat_prefix,
            "fur_white",
            pal,
        )
        # Antebraço descendo junto à saia
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_forearm_{side_idx}",
                6,
                0.056,
                0.32,
                (sx * 0.31, -0.10, 1.08),
                (math.radians(-18), math.radians(sx * 10), 0.0),
            ),
            mat_prefix,
            "fur_white",
            pal,
        )
        # Mão/pata dianteira branca
        _add_part(
            parts,
            create_cube(
                f"_tmp_hand_{side_idx}",
                (0.10, 0.13, 0.10),
                (sx * 0.29, -0.18, 0.90),
            ),
            mat_prefix,
            "fur_white",
            pal,
        )

    # 4. CABEÇA DE RAPOSA, FOCINHO, BOCHECHAS, ORELHAS E CHAMAS DAS ORELHAS
    _add_part(
        parts,
        create_cube("_tmp_head_base", (0.56, 0.54, 0.46), (0.0, -0.04, 1.98)),
        mat_prefix,
        "fur_white",
        pal,
    )
    # Máscara/capacete amarelo no topo da cabeça
    _add_part(
        parts,
        create_cube("_tmp_head_cap", (0.52, 0.52, 0.22), (0.0, -0.03, 2.18)),
        mat_prefix,
        "fur_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_brow_crest", (0.14, 0.18, 0.14), (0.0, -0.26, 2.08), (math.radians(18), 0.0, 0.0)),
        mat_prefix,
        "fur_yellow",
        pal,
    )
    # Focinho fino pontudo para -Y
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            4,
            0.22,
            0.05,
            0.38,
            (0.0, -0.38, 1.90),
            (math.radians(88), 0.0, 0.0),
            scale=(0.85, 0.72, 1.0),
        ),
        mat_prefix,
        "fur_white",
        pal,
    )
    # Nariz vermelho-laranja na ponta do focinho
    _add_part(
        parts,
        create_cube("_tmp_nose", (0.08, 0.09, 0.07), (0.0, -0.57, 1.91)),
        mat_prefix,
        "flame_red",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        # Tufos pontiagudos das bochechas brancas
        _add_part(
            parts,
            create_cone(
                f"_tmp_cheek_low_{side_idx}",
                4,
                0.15,
                0.02,
                0.38,
                (sx * 0.36, -0.03, 1.93),
                (0.0, math.radians(sx * 74), 0.0),
                scale=(1.0, 0.62, 1.0),
            ),
            mat_prefix,
            "fur_white",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_cheek_up_{side_idx}",
                4,
                0.12,
                0.02,
                0.32,
                (sx * 0.32, 0.03, 2.02),
                (0.0, math.radians(sx * 58), 0.0),
                scale=(1.0, 0.58, 1.0),
            ),
            mat_prefix,
            "fur_white",
            pal,
        )
        # Olho âmbar angular e contorno superior escuro
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_{side_idx}",
                (0.13, 0.08, 0.12),
                (sx * 0.17, -0.30, 2.01),
                (0.0, math.radians(sx * 12), math.radians(sx * -10)),
            ),
            mat_prefix,
            "eyes_amber",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eyeliner_{side_idx}",
                (0.15, 0.09, 0.04),
                (sx * 0.17, -0.31, 2.07),
                (0.0, math.radians(sx * 16), math.radians(sx * -10)),
            ),
            mat_prefix,
            "outline_dark",
            pal,
        )
        # Risco vertical da testa (marca característica)
        _add_part(
            parts,
            create_cube(
                f"_tmp_forehead_mark_{side_idx}",
                (0.025, 0.05, 0.11),
                (sx * 0.055, -0.31, 2.13),
                (math.radians(-12), math.radians(sx * 10), 0.0),
            ),
            mat_prefix,
            "outline_dark",
            pal,
        )

        # Grandes orelhas triangulares altas amarelas
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{side_idx}",
                4,
                0.20,
                0.03,
                0.72,
                (sx * 0.24, -0.02, 2.52),
                (0.0, math.radians(sx * 16), 0.0),
                scale=(1.0, 0.55, 1.0),
            ),
            mat_prefix,
            "fur_yellow",
            pal,
        )

        # Volumosos tufos de chama vermelho-laranja saindo das orelhas
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_flame_base_{side_idx}",
                4,
                0.19,
                0.04,
                0.56,
                (sx * 0.36, -0.04, 2.34),
                (0.0, math.radians(sx * 64), 0.0),
                scale=(0.85, 0.45, 1.0),
            ),
            mat_prefix,
            "flame_red",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_flame_mid_{side_idx}",
                4,
                0.21,
                0.05,
                0.52,
                (sx * 0.58, -0.02, 2.36),
                (0.0, math.radians(sx * 82), 0.0),
                scale=(0.80, 0.42, 1.0),
            ),
            mat_prefix,
            "flame_red",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_flame_tip_{side_idx}",
                4,
                0.15,
                0.02,
                0.50,
                (sx * 0.80, 0.00, 2.48),
                (0.0, math.radians(sx * 54), 0.0),
                scale=(0.75, 0.38, 1.0),
            ),
            mat_prefix,
            "flame_red",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_flame_spike_{side_idx}",
                4,
                0.10,
                0.02,
                0.28,
                (sx * 0.50, -0.03, 2.52),
                (0.0, math.radians(sx * 36), 0.0),
                scale=(0.75, 0.38, 1.0),
            ),
            mat_prefix,
            "flame_red",
            pal,
        )

    # 5. CAUDA VOLUMOSA AMARELA COM PONTA FLAMEJANTE + VARINHA DE MADEIRA EM 'Y'
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_base",
            6,
            0.22,
            0.34,
            0.52,
            (0.0, 0.48, 0.86),
            (math.radians(-78), 0.0, 0.0),
        ),
        mat_prefix,
        "fur_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tail_bulb",
            1,
            0.46,
            (0.0, 0.88, 0.92),
            scale=(0.92, 1.18, 1.08),
        ),
        mat_prefix,
        "fur_yellow",
        pal,
    )
    # Colarinho de pontas no encaixe superior do galho na cauda
    _add_part(
        parts,
        create_cone("_tmp_tail_socket_front", 4, 0.16, 0.02, 0.28, (0.0, 0.78, 1.44), (math.radians(18), 0.0, 0.0)),
        mat_prefix,
        "fur_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cone("_tmp_tail_socket_back", 4, 0.16, 0.02, 0.28, (0.0, 0.94, 1.44), (math.radians(-22), 0.0, 0.0)),
        mat_prefix,
        "fur_yellow",
        pal,
    )

    # Ponta traseira da cauda em chamas vermelho-laranja curvada para cima
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_flame_main",
            4,
            0.28,
            0.03,
            0.58,
            (0.0, 1.38, 0.88),
            (math.radians(-58), 0.0, 0.0),
            scale=(0.82, 1.0, 1.0),
        ),
        mat_prefix,
        "flame_red",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_flame_top",
            4,
            0.18,
            0.02,
            0.42,
            (0.0, 1.44, 1.08),
            (math.radians(-32), 0.0, 0.0),
            scale=(0.75, 1.0, 1.0),
        ),
        mat_prefix,
        "flame_red",
        pal,
    )

    # Galho / Varinha Mágica bifurcada em 'Y' cravada no topo da cauda
    _add_part(
        parts,
        create_cylinder(
            "_tmp_wand_shaft",
            6,
            0.042,
            0.72,
            (0.0, 0.96, 1.72),
            (math.radians(-18), 0.0, 0.0),
        ),
        mat_prefix,
        "wood_wand",
        pal,
    )
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_wand_fork_{side_idx}",
                6,
                0.036,
                0.022,
                0.28,
                (sx * 0.06, 1.10, 2.15),
                (math.radians(-14), math.radians(sx * 28), 0.0),
            ),
            mat_prefix,
            "wood_wand",
            pal,
        )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """Gera lado a lado as versões Normal, Dourada (Mutação 2x) e Enorme (Huge 1.85x)."""
    build_blazefox("Blazefox_Normal", location=(0.0, 0.0, 0.0), scale=1.0, is_golden=False)
    build_blazefox("Blazefox_Dourado", location=(3.6, 0.0, 0.0), scale=1.0, is_golden=True)
    build_blazefox("Blazefox_Huge", location=(-4.6, 0.0, 0.0), scale=CONFIG["huge_scale"], is_golden=False)


if __name__ == "__main__":
    generate_variations()
    print("Blazefox (Raposa Chamejante - Estilo Braixen) gerado com sucesso! Pronto para exportar em .FBX para o Roblox Studio.")
