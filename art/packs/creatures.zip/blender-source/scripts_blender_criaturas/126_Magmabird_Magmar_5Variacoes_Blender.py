"""
126_Magmabird_Magmar_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "126. Magmabird — Pato Vulcânico (Ref: Magmar)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Magmabird_Shiny (1.0x - Paleta Shiny Magenta-Fúcsia + Barriga Rosa-Pêssego + Chamas Vivas)
  2. Magmabird_Normal (1.0x - Corpo Vermelho-Magma + Barriga/Ombros Amarelos + Chamas Duplas + Bico)
  3. Magmabird_Grande (1.35x - Normal)
  4. Magmabird_Gigante (1.85x - Normal)
  5. Magmabird_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Colar e Pontas de Chama Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para silhueta vulcânica fiel, cones 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e rosto/bico apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_red": (0.91, 0.34, 0.18, 1.0),
        "body_dark": (0.68, 0.24, 0.15, 1.0),
        "belly_yellow": (0.94, 0.80, 0.38, 1.0),
        "flame_orange": (0.98, 0.48, 0.14, 1.0),
        "flame_yellow": (0.99, 0.88, 0.40, 1.0),
        "beak_tan": (0.91, 0.75, 0.64, 1.0),
        "mouth_pink": (0.82, 0.44, 0.50, 1.0),
        "ring_black": (0.13, 0.17, 0.22, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.09, 0.10, 0.13, 1.0),
        "claw_white": (0.96, 0.97, 0.99, 1.0),
    },
    "shiny_palette": {
        "body_red": (0.88, 0.24, 0.56, 1.0),
        "body_dark": (0.64, 0.16, 0.40, 1.0),
        "belly_yellow": (0.98, 0.66, 0.78, 1.0),
        "flame_orange": (0.96, 0.36, 0.62, 1.0),
        "flame_yellow": (1.00, 0.84, 0.48, 1.0),
        "beak_tan": (0.94, 0.78, 0.72, 1.0),
        "mouth_pink": (0.84, 0.36, 0.54, 1.0),
        "ring_black": (0.14, 0.15, 0.22, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.09, 0.10, 0.13, 1.0),
        "claw_white": (0.97, 0.97, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "body_red": (0.98, 0.78, 0.14, 1.0),
        "body_dark": (0.82, 0.58, 0.08, 1.0),
        "belly_yellow": (1.00, 0.92, 0.46, 1.0),
        "flame_orange": (0.98, 0.82, 0.22, 1.0),
        "flame_yellow": (0.10, 0.92, 1.00, 1.0),
        "beak_tan": (1.00, 0.94, 0.68, 1.0),
        "mouth_pink": (0.84, 0.54, 0.10, 1.0),
        "ring_black": (0.08, 0.68, 0.82, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.40, 0.56, 1.0),
        "claw_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_magmabird(
    name: str = "Magmabird_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 126. Magmabird (Ref: Magmar):
      - Tronco vulcânico em pera vermelho-magma + barriga amarela com chamas subindo no peito
      - Colar preto metálico no pescoço e braceletes pretos nos tornozelos
      - Cabeça com 2 bulbos icônicos na testa encimados por 2 labaredas altas amarelas/laranjas
      - Olhos semi-cerrados ferozes sob a testa e bico largo de pato com boca sorridente
      - Ombros redondos amarelos, antebraços emplumados de escamas vermelhas e 4 garras brancas por mão
      - Fileira de 4 espinhos dorsais marrom-avermelhados e cauda amarela curvada com chama viva
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Magma_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Magma_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Magma_Norm"

    parts = []

    # 1. TRONCO VULCÂNICO EM PERA (PEITO VERMELHO + BARRIGA AMARELA COM LABAREDAS)
    _add_part(
        parts,
        create_icosphere("_tmp_chest", 2, 0.62, (0.0, 0.04, 1.24), scale=(0.98, 0.86, 1.02)),
        mat_prefix,
        "body_red",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_belly", 2, 0.66, (0.0, -0.02, 0.86), scale=(1.04, 0.92, 0.86)),
        mat_prefix,
        "belly_yellow",
        pal,
    )
    # Línguas de chama amarela subindo no peito vermelho (detalhe icônico da arte)
    chest_flames = [
        (-0.22, -0.52, 1.14, 0.16, 0.34, 14.0),
        (0.00, -0.56, 1.20, 0.18, 0.40, -6.0),
        (0.24, -0.50, 1.16, 0.16, 0.36, -16.0),
    ]
    for idx, (fx, fy, fz, rad, dep, ry) in enumerate(chest_flames):
        _add_part(
            parts,
            create_cone(
                f"_tmp_chest_flame_{idx}",
                6,
                rad,
                0.02,
                dep,
                (fx, fy, fz),
                rotation=(math.radians(-12.0), math.radians(ry), 0.0),
                scale=(1.0, 0.42, 1.0),
            ),
            mat_prefix,
            "belly_yellow",
            pal,
        )

    # 2. COLAR PRETO NO PESCOÇO
    _add_part(
        parts,
        create_cylinder("_tmp_neck_collar", 10, 0.30, 0.20, (0.0, -0.02, 1.76), scale=(1.04, 0.94, 1.0)),
        mat_prefix,
        "ring_black",
        pal,
    )

    # 3. CABEÇA VULCÂNICA + 2 BULBOS NA TESTA + 2 LABAREDAS ALTAS + BICO DE PATO
    _add_part(
        parts,
        create_icosphere("_tmp_head_base", 2, 0.46, (0.0, -0.04, 2.08), scale=(1.04, 0.96, 0.88)),
        mat_prefix,
        "body_red",
        pal,
    )
    # 2 bulbos arredondados da testa + chamas altas bifurcadas
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_brow_bulb_{tag}",
                2,
                0.31,
                (side * 0.25, -0.18, 2.34),
                scale=(1.04, 0.98, 0.92),
            ),
            mat_prefix,
            "body_red",
            pal,
        )
        # Base laranja da chama na testa
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_flame_base_{tag}",
                7,
                0.24,
                0.14,
                0.34,
                (side * 0.28, -0.14, 2.62),
                rotation=(math.radians(6.0), math.radians(side * 12.0), 0.0),
                scale=(1.0, 0.72, 1.0),
            ),
            mat_prefix,
            "flame_orange",
            pal,
        )
        # Ponta principal amarela da chama ondulada
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_flame_tip_{tag}",
                6,
                0.18,
                0.02,
                0.48,
                (side * 0.34, -0.10, 2.94),
                rotation=(math.radians(8.0), math.radians(side * 16.0), 0.0),
                scale=(1.0, 0.56, 1.0),
            ),
            mat_prefix,
            "flame_yellow",
            pal,
        )
        # Língua secundária da chama para silhueta recortada
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_flame_sub_{tag}",
                5,
                0.11,
                0.015,
                0.30,
                (side * 0.19, -0.12, 2.86),
                rotation=(math.radians(4.0), math.radians(side * -14.0), 0.0),
                scale=(1.0, 0.55, 1.0),
            ),
            mat_prefix,
            "flame_yellow",
            pal,
        )
        # Pequeno tufo lateral na bochecha
        _add_part(
            parts,
            create_cone(
                f"_tmp_cheek_tuft_{tag}",
                5,
                0.10,
                0.015,
                0.22,
                (side * 0.48, 0.02, 2.12),
                rotation=(0.0, math.radians(side * 68.0), 0.0),
            ),
            mat_prefix,
            "body_red",
            pal,
        )

    # Olhos semi-cerrados sob os bulbos da testa
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.12,
                (side * 0.22, -0.44, 2.13),
                rotation=(0.0, math.radians(side * 10.0), math.radians(side * -14.0)),
                scale=(1.22, 0.46, 0.72),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.048,
                (side * 0.20, -0.50, 2.13),
                scale=(0.75, 0.55, 1.10),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # Bico largo de pato com boca sorridente aberta
    _add_part(
        parts,
        create_icosphere(
            "_tmp_beak_upper",
            2,
            0.28,
            (0.0, -0.56, 2.00),
            rotation=(math.radians(8.0), 0.0, 0.0),
            scale=(1.12, 1.18, 0.36),
        ),
        mat_prefix,
        "beak_tan",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_beak_lower",
            2,
            0.22,
            (0.0, -0.52, 1.88),
            rotation=(math.radians(-16.0), 0.0, 0.0),
            scale=(0.94, 0.98, 0.28),
        ),
        mat_prefix,
        "beak_tan",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_inner",
            1,
            0.14,
            (0.0, -0.50, 1.93),
            scale=(0.95, 0.65, 0.52),
        ),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # 4. OMBROS AMARELOS + BRAÇOS COM ESCAMAS VERMELHAS + MÃOS COM 4 GARRAS BRANCAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Ombro redondo amarelo musculoso
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_shoulder_{tag}",
                2,
                0.31,
                (side * 0.60, -0.02, 1.50),
                scale=(1.02, 0.96, 1.00),
            ),
            mat_prefix,
            "belly_yellow",
            pal,
        )
        # Antebraço com anéis de escamas/penas vulcânicas (3 camadas sobrepostas)
        for seg_idx, sx_off in enumerate((0.86, 1.04, 1.20)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_arm_seg_{tag}_{seg_idx}",
                    7,
                    0.24 - seg_idx * 0.02,
                    0.18 - seg_idx * 0.015,
                    0.28,
                    (side * sx_off, -0.08 - seg_idx * 0.03, 1.44 - seg_idx * 0.04),
                    rotation=(math.radians(-8.0), math.radians(side * 96.0), 0.0),
                ),
                mat_prefix,
                "body_dark" if seg_idx % 2 == 1 else "body_red",
                pal,
            )
        # Mão vermelha-magma
        hx, hy, hz = side * 1.38, -0.16, 1.34
        _add_part(
            parts,
            create_icosphere(f"_tmp_hand_{tag}", 2, 0.20, (hx, hy, hz), scale=(1.12, 0.90, 0.92)),
            mat_prefix,
            "body_red",
            pal,
        )
        # 4 garras brancas afiadas em leque
        claw_offsets = [
            (0.18, -0.04, 0.14, 62.0),
            (0.22, -0.04, 0.03, 84.0),
            (0.20, -0.04, -0.09, 108.0),
            (0.10, -0.14, -0.12, 126.0),
        ]
        for c_idx, (dx, dy, dz, ry_deg) in enumerate(claw_offsets):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{tag}_{c_idx}",
                    5,
                    0.055,
                    0.010,
                    0.22,
                    (hx + side * dx, hy + dy, hz + dz),
                    rotation=(math.radians(-10.0), math.radians(side * ry_deg), 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 5. ESPINHOS DORSAIS NAS COSTAS (4 TRIÂNGULOS ESCUROS)
    back_spikes = [
        (0.54, 1.56, 0.16, 0.44, -52.0),
        (0.62, 1.30, 0.15, 0.40, -64.0),
        (0.66, 1.04, 0.14, 0.36, -74.0),
        (0.64, 0.78, 0.13, 0.32, -84.0),
    ]
    for s_idx, (by, bz, rad, dep, rx_deg) in enumerate(back_spikes):
        _add_part(
            parts,
            create_cone(
                f"_tmp_back_spike_{s_idx}",
                5,
                rad,
                0.018,
                dep,
                (0.0, by, bz),
                rotation=(math.radians(rx_deg), 0.0, 0.0),
                scale=(0.56, 1.0, 1.0),
            ),
            mat_prefix,
            "body_dark",
            pal,
        )

    # 6. COXAS AMARELAS MUSCULOSAS + TORNOZELEIRAS PRETAS + PÉS COM 2 GARRAS BRANCAS (Z = 0.0)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.38,
                (side * 0.56, -0.02, 0.68),
                scale=(0.98, 1.04, 1.02),
            ),
            mat_prefix,
            "belly_yellow",
            pal,
        )
        # Bracelete preto no tornozelo
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ankle_{tag}",
                8,
                0.17,
                0.26,
                (side * 0.64, -0.04, 0.34),
                rotation=(math.radians(-6.0), math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "ring_black",
            pal,
        )
        # Pé vermelho largo apoiado no chão
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.28,
                (side * 0.70, -0.18, 0.16),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(0.94, 1.38, 0.58),
            ),
            mat_prefix,
            "body_red",
            pal,
        )
        # 2 garras brancas grandes nos pés
        for f_idx, f_off in enumerate((-0.10, 0.10)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_claw_{tag}_{f_idx}",
                    5,
                    0.072,
                    0.012,
                    0.26,
                    (side * 0.70 + f_off, -0.52, 0.11),
                    rotation=(math.radians(-86.0), 0.0, math.radians(side * -14.0 + f_off * 1.4)),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 7. CAUDA AMARELA CURVADA PARA O LADO ESQUERDO (-X) COM CHAMA VIVA NA PONTA
    tail_nodes = [
        ((0.00, 0.54, 0.58), 0.32, "belly_yellow"),
        ((-0.34, 0.68, 0.48), 0.26, "belly_yellow"),
        ((-0.72, 0.62, 0.46), 0.21, "belly_yellow"),
        ((-1.08, 0.44, 0.54), 0.16, "belly_yellow"),
        ((-1.36, 0.24, 0.72), 0.12, "body_red"),
        ((-1.54, 0.12, 0.94), 0.09, "flame_orange"),
    ]
    for t_idx, (loc, rad, mkey) in enumerate(tail_nodes):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tail_seg_{t_idx}", 2, rad, loc, scale=(1.08, 0.96, 0.96)),
            mat_prefix,
            mkey,
            pal,
        )
    # Labareda viva na ponta da cauda (visível perfeitamente na câmera frontal 3/4)
    _add_part(
        parts,
        create_icosphere("_tmp_tail_flame_core", 2, 0.24, (-1.62, 0.08, 1.16), scale=(0.86, 0.66, 1.18)),
        mat_prefix,
        "flame_orange",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_flame_tip1",
            6,
            0.20,
            0.02,
            0.52,
            (-1.68, 0.06, 1.46),
            rotation=(0.0, math.radians(-16.0), 0.0),
            scale=(0.95, 0.58, 1.0),
        ),
        mat_prefix,
        "flame_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_flame_tip2",
            5,
            0.12,
            0.015,
            0.34,
            (-1.52, 0.08, 1.38),
            rotation=(0.0, math.radians(18.0), 0.0),
            scale=(0.90, 0.55, 1.0),
        ),
        mat_prefix,
        "flame_yellow",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 126. Magmabird lado a lado."""
    specs = [
        ("Magmabird_Shiny", (-10.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Magmabird_Normal", (-6.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Magmabird_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Magmabird_Gigante", (5.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Magmabird_Dourada_SuperRara", (14.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_magmabird(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
