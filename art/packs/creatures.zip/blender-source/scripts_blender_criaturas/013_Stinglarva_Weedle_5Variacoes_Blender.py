"""
013_Stinglarva_Weedle_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "013. Stinglarva — Larva Ferrão (Ref: Weedle)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Stinglarva_Shiny (1.0x - Paleta Shiny / Shyne Amarelo-Dourado Luminoso + Nariz Ameixa)
  2. Stinglarva_Normal (1.0x - Corpo Ocre Segmentado + Chifre e Ferrão Marfim + Nariz Rosa)
  3. Stinglarva_Grande (1.35x - Normal)
  4. Stinglarva_Gigante (1.85x - Normal)
  5. Stinglarva_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (icosphere subdiv=1, cones 6 lados, cubos escalonados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés ventrais alinhados exatamente em `Z = 0.0` e cabeça/chifre apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Stinglarva_Shiny`, `Stinglarva_Normal`, `Stinglarva_Grande`,
     `Stinglarva_Gigante`, `Stinglarva_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_ochre": (0.80, 0.62, 0.32, 1.0),
        "belly_tan": (0.92, 0.78, 0.48, 1.0),
        "nose_pink": (0.95, 0.56, 0.64, 1.0),
        "sting_ivory": (0.96, 0.94, 0.88, 1.0),
        "eye_dark": (0.10, 0.10, 0.12, 1.0),
        "white_shine": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_ochre": (0.98, 0.82, 0.22, 1.0),
        "belly_tan": (1.00, 0.92, 0.54, 1.0),
        "nose_pink": (0.86, 0.38, 0.68, 1.0),
        "sting_ivory": (0.98, 0.96, 0.90, 1.0),
        "eye_dark": (0.12, 0.10, 0.14, 1.0),
        "white_shine": (1.00, 0.99, 0.95, 1.0),
    },
    "golden_super_rare_palette": {
        "body_ochre": (0.98, 0.76, 0.12, 1.0),
        "belly_tan": (1.00, 0.92, 0.52, 1.0),
        "nose_pink": (1.00, 0.84, 0.32, 1.0),
        "sting_ivory": (1.00, 0.98, 0.88, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "white_shine": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha as patas em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_stinglarva(
    name: str = "Stinglarva_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 013. Stinglarva (Ref: Weedle):
      - Frente apontando para -Y e pares de pezinhos alinhados em Z = 0.0
      - 6 segmentos ocre curvados em arco com pezinhos rosados pareados em cada segmento
      - Cabeça grande com nariz redondo rosa e olhos escuros laterais
      - Chifre cônico marfim na testa e ferrão pontiagudo marfim na ponta da cauda
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Sting_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Sting_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Sting"

    parts = []

    # 1. SEGMENTOS DO CORPO DE LARVA EM ARCO SUAVE (-Y PARA +Y)
    seg_specs = [
        (0.00, -0.32, 0.72, 0.42, True),
        (0.00, -0.02, 0.48, 0.40, True),
        (0.00, 0.34, 0.38, 0.37, True),
        (0.00, 0.68, 0.36, 0.34, True),
        (0.00, 1.00, 0.40, 0.30, True),
        (0.00, 1.28, 0.50, 0.25, False),
    ]
    for i, (sx, sy, sz, rad, has_feet) in enumerate(seg_specs):
        _add_part(parts, create_icosphere(f"_tmp_seg_{i}", 1, rad, (sx, sy, sz)), mat_prefix, "body_ochre", pal)
        _add_part(
            parts,
            create_cube(f"_tmp_seg_belly_{i}", (rad * 1.15, rad * 1.15, rad * 0.75), (sx, sy - 0.04, sz - rad * 0.42)),
            mat_prefix,
            "belly_tan",
            pal,
        )
        if has_feet:
            for side in (-1.0, 1.0):
                tag = "L" if side < 0 else "R"
                fy_pos = sy - 0.08 if i > 0 else sy - 0.14
                fz_pos = max(0.09, sz - rad * 0.74)
                _add_part(
                    parts,
                    create_icosphere(f"_tmp_foot_{i}_{tag}", 1, 0.10, (side * (rad * 0.72), fy_pos, fz_pos)),
                    mat_prefix,
                    "nose_pink",
                    pal,
                )

    # 2. CABEÇA GRANDE, NARIZ ROSA, OLHOS ESCUROS E CHIFRE DE TESTA MARFIM
    _add_part(parts, create_cube("_tmp_head_block", (0.86, 0.80, 0.78), (0.0, -0.48, 1.26)), mat_prefix, "body_ochre", pal)
    _add_part(parts, create_icosphere("_tmp_head_dome", 1, 0.48, (0.0, -0.48, 1.30)), mat_prefix, "body_ochre", pal)
    _add_part(
        parts,
        create_icosphere("_tmp_nose", 1, 0.21, (0.0, -0.94, 1.16), scale=(1.15, 0.90, 0.90)),
        mat_prefix,
        "nose_pink",
        pal,
    )

    # Chifre cônico na testa apontando para cima e levemente para frente
    _add_part(
        parts,
        create_cone(
            "_tmp_forehead_horn",
            6,
            0.16,
            0.02,
            0.62,
            (0.0, -0.56, 1.88),
            rotation=(math.radians(14.0), 0.0, 0.0),
        ),
        mat_prefix,
        "sting_ivory",
        pal,
    )

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_eye_{tag}", (0.14, 0.12, 0.16), (side * 0.34, -0.84, 1.38)),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_glint_{tag}", (0.06, 0.05, 0.06), (side * 0.37, -0.89, 1.43)),
            mat_prefix,
            "white_shine",
            pal,
        )

    # 3. FERRÃO DE CAUDA EM +Y
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_stinger",
            6,
            0.14,
            0.015,
            0.54,
            (0.0, 1.54, 0.66),
            rotation=(math.radians(-58.0), 0.0, 0.0),
        ),
        mat_prefix,
        "sting_ivory",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 013. Stinglarva lado a lado."""
    specs = [
        ("Stinglarva_Shiny", (-5.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Stinglarva_Normal", (-3.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Stinglarva_Grande", (-0.7, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Stinglarva_Gigante", (2.5, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Stinglarva_Dourada_SuperRara", (6.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_stinglarva(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
