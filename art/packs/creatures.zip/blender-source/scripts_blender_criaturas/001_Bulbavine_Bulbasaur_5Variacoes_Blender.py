"""
001_Bulbavine_Bulbasaur_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "001. Bulbavine — Sapo-Dinossauro Broto (Ref: Bulbasaur)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Bulbavine_Shiny (1.0x - Paleta Shiny / Shyne Verde-Limão + Bulbo Ouro-Esmeralda)
  2. Bulbavine_Normal (1.0x)
  3. Bulbavine_Grande (1.35x)
  4. Bulbavine_Gigante (1.85x)
  5. Bulbavine_Colossal (2.60x)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 4-6 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base das patas e garras alinhada exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Bulbavine_Normal`, `Bulbavine_Grande`, `Bulbavine_Gigante`,
     `Bulbavine_Colossal`, `Bulbavine_Shiny`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "Colossal": 2.60,
    },
    "palette": {
        "body_teal": (0.42, 0.80, 0.66, 1.0),    # Corpo Verde-Água (#6BCCA8)
        "spots_dark": (0.14, 0.44, 0.38, 1.0),   # Manchas Azul-Petróleo e linha da boca (#247061)
        "bulb_green": (0.24, 0.76, 0.28, 1.0),   # Bulbo Dorsal Verde-Folha (#3DC247)
        "bulb_tip": (0.34, 0.86, 0.36, 1.0),     # Ponta superior do bulbo (#57DB5C)
        "claws_white": (0.97, 0.97, 0.98, 1.0),  # Garras, presas e esclera dos olhos
        "eyes_ruby": (0.86, 0.16, 0.22, 1.0),    # Íris Vermelho-Rubi (#DB2938)
    },
    "shiny_palette": {
        "body_teal": (0.58, 0.94, 0.42, 1.0),    # Shiny Verde-Limão Luminoso (#94F06B)
        "spots_dark": (0.26, 0.64, 0.22, 1.0),   # Manchas Shiny Verde-Folha (#42A338)
        "bulb_green": (0.64, 0.86, 0.14, 1.0),   # Bulbo Shiny Verde-Dourado (#A3DB24)
        "bulb_tip": (0.88, 0.94, 0.24, 1.0),     # Ponta Shiny Ouro-Lima (#E0F03D)
        "claws_white": (0.98, 0.98, 0.99, 1.0),  # Garras, presas e esclera
        "eyes_ruby": (0.94, 0.22, 0.28, 1.0),    # Íris Rubi Brilhante
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (ideal para acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, zera a origem na base das patas (Z = 0.0),
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_bulbavine(
    name: str = "Bulbavine_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    is_shiny: bool = False,
):
    """
    Constrói o modelo 3D completo do 001. Bulbavine (Ref: Bulbasaur):
      - Frente apontando para -Y e base das 4 patas e garras em Z = 0.0
      - Torso quadrúpede com manchas poligonais, orelhas curtas, presas e olhos rubi
      - Grande bulbo dorsal em camadas facetadas convergindo no topo
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    pal = CONFIG["shiny_palette"] if is_shiny else CONFIG["palette"]
    mat_prefix = "Mat_Bulba_Shiny" if is_shiny else "Mat_Bulba"
    parts = []

    # 1. TORSO QUADRÚPEDE ROBUSTO + MANCHAS ASSIMÉTRICAS
    _add_part(
        parts,
        create_cube("_tmp_torso", (1.36, 1.48, 0.92), (0.0, 0.14, 0.78), (math.radians(8), 0.0, 0.0)),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_rump", (1.14, 0.68, 0.76), (0.0, 0.74, 0.66), (math.radians(-12), 0.0, 0.0)),
        mat_prefix,
        "body_teal",
        pal,
    )
    # Manchas poligonais nos flancos
    spots = [
        ((-0.68, 0.04, 0.80), (0.08, 0.34, 0.28), (math.radians(15), 0.0, 0.0)),
        ((0.68, -0.08, 0.84), (0.08, 0.28, 0.24), (math.radians(-10), 0.0, 0.0)),
        ((0.68, 0.36, 0.74), (0.08, 0.22, 0.20), (math.radians(20), 0.0, 0.0)),
    ]
    for idx, (loc, sz, rot) in enumerate(spots):
        _add_part(parts, create_cube(f"_tmp_spot_{idx}", sz, loc, rot), mat_prefix, "spots_dark", pal)

    # 2. QUATRO PATAS ROBUSTAS + GARRAS BRANCAS TOCANDO Z = 0
    legs = [
        (-0.56, -0.36, 0.33, 0.26, 0.22),
        (0.56, -0.36, 0.33, 0.26, 0.22),
        (-0.58, 0.62, 0.32, 0.28, 0.25),
        (0.58, 0.62, 0.32, 0.28, 0.25),
    ]
    for idx, (lx, ly, lz, r1, r2) in enumerate(legs):
        _add_part(
            parts,
            create_cone(f"_tmp_leg_{idx}", 6, r1, r2, 0.66, (lx, ly, lz)),
            mat_prefix,
            "body_teal",
            pal,
        )
        for claw_i, cx_off in enumerate([-0.12, 0.0, 0.12]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_claw_{idx}_{claw_i}",
                    4,
                    0.065,
                    0.012,
                    0.20,
                    (lx + cx_off, ly - 0.26, 0.065),
                    (math.radians(86), 0.0, 0.0),
                ),
                mat_prefix,
                "claws_white",
                pal,
            )

    # 3. CABEÇA LARGA, FOCINHO, ORELHAS, PRESAS E OLHOS RUBI (-Y)
    _add_part(
        parts,
        create_cube("_tmp_head", (1.26, 0.98, 0.90), (0.0, -0.76, 1.02), (math.radians(-4), 0.0, 0.0)),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_snout", (0.98, 0.40, 0.42), (0.0, -1.24, 0.84)),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth", (0.86, 0.08, 0.06), (0.0, -1.42, 0.80)),
        mat_prefix,
        "spots_dark",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_forehead_spot", (0.24, 0.08, 0.22), (-0.14, -1.25, 1.24), (0.0, math.radians(18), 0.0)),
        mat_prefix,
        "spots_dark",
        pal,
    )

    for side_idx, sx in enumerate([-1.0, 1.0]):
        # Orelha triangular no topo do crânio
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{side_idx}",
                4,
                0.22,
                0.03,
                0.42,
                (sx * 0.46, -0.62, 1.54),
                (math.radians(-10), math.radians(sx * 24), 0.0),
                scale=(0.85, 0.72, 1.0),
            ),
            mat_prefix,
            "body_teal",
            pal,
        )
        # Olho branco + íris vermelho-rubi
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_sclera_{side_idx}",
                (0.26, 0.10, 0.28),
                (sx * 0.34, -1.23, 1.06),
                (0.0, math.radians(sx * -12), 0.0),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_iris_{side_idx}",
                (0.15, 0.08, 0.22),
                (sx * 0.33, -1.26, 1.06),
                (0.0, math.radians(sx * -12), 0.0),
            ),
            mat_prefix,
            "eyes_ruby",
            pal,
        )
        # Presas inferiores/laterais
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{side_idx}",
                4,
                0.06,
                0.01,
                0.14,
                (sx * 0.26, -1.42, 0.74),
                (math.radians(180), 0.0, 0.0),
            ),
            mat_prefix,
            "claws_white",
            pal,
        )

    # 4. GRANDE BULBO DORSAL VEGETAL EM CAMADAS FACETADAS
    _add_part(
        parts,
        create_icosphere("_tmp_bulb_base", 1, 0.68, (0.0, 0.30, 1.34), (math.radians(-18), 0.0, 0.0), scale=(1.05, 1.15, 0.88)),
        mat_prefix,
        "bulb_green",
        pal,
    )
    # 4 Gomos/pétalas convergindo no topo do bulbo
    for idx, (ox, oy, rx, ry) in enumerate([
        (0.0, -0.18, -28.0, 0.0),
        (0.0, 0.18, 12.0, 0.0),
        (-0.20, 0.0, -14.0, -24.0),
        (0.20, 0.0, -14.0, 24.0),
    ]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_bulb_petal_{idx}",
                6,
                0.48,
                0.18,
                0.76,
                (ox, 0.34 + oy, 1.56),
                (math.radians(rx), math.radians(ry), 0.0),
            ),
            mat_prefix,
            "bulb_green",
            pal,
        )
    # Ponta espiralada no topo do bulbo
    _add_part(
        parts,
        create_cone("_tmp_bulb_tip", 6, 0.34, 0.05, 0.56, (0.0, 0.50, 1.96), (math.radians(-22), 0.0, 0.0)),
        mat_prefix,
        "bulb_tip",
        pal,
    )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """
    Gera lado a lado todos os 5 modelos do 001. Bulbavine (Bulbasaur):
      1. Shiny (1.0x) | 2. Normal (1.0x) | 3. Grande (1.35x) | 4. Gigante (1.85x) | 5. Colossal (2.60x)
    """
    build_bulbavine("Bulbavine_Shiny", location=(-6.8, 0.0, 0.0), scale=CONFIG["scales"]["Shiny"], is_shiny=True)
    build_bulbavine("Bulbavine_Normal", location=(-4.2, 0.0, 0.0), scale=CONFIG["scales"]["Normal"], is_shiny=False)
    build_bulbavine("Bulbavine_Grande", location=(-1.2, 0.0, 0.0), scale=CONFIG["scales"]["Grande"], is_shiny=False)
    build_bulbavine("Bulbavine_Gigante", location=(2.8, 0.0, 0.0), scale=CONFIG["scales"]["Gigante"], is_shiny=False)
    build_bulbavine("Bulbavine_Colossal", location=(8.5, 0.0, 0.0), scale=CONFIG["scales"]["Colossal"], is_shiny=False)


if __name__ == "__main__":
    generate_variations()
    print("001. Bulbavine (5 variações: Shiny, Normal, Grande, Gigante e Colossal) gerado com sucesso!")
