"""
026_Thunderrat_Raichu_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "026. Thunderrat — Rato Trovão (Ref: Raichu)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Thunderrat_Shiny (1.0x - Paleta Shiny / Shyne Cobre-Tangerina + Bochechas e Raio Ouro)
  2. Thunderrat_Normal (1.0x - Corpo Laranja-Dourado + Barriga Creme + Orelhas Espirais + Cauda Raio)
  3. Thunderrat_Grande (1.35x - Normal)
  4. Thunderrat_Gigante (1.85x - Normal)
  5. Thunderrat_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Bochechas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.017`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e frente/rosto apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Thunderrat_Shiny`, `Thunderrat_Normal`, `Thunderrat_Grande`,
     `Thunderrat_Gigante`, `Thunderrat_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.017,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_orange": (0.94, 0.58, 0.16, 1.0),
        "belly_cream": (0.98, 0.92, 0.72, 1.0),
        "bolt_yellow": (0.98, 0.86, 0.18, 1.0),
        "paw_brown": (0.34, 0.22, 0.14, 1.0),
        "eye_dark": (0.12, 0.10, 0.12, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_orange": (0.88, 0.40, 0.10, 1.0),
        "belly_cream": (0.99, 0.92, 0.70, 1.0),
        "bolt_yellow": (0.99, 0.84, 0.16, 1.0),
        "paw_brown": (0.36, 0.20, 0.12, 1.0),
        "eye_dark": (0.12, 0.10, 0.12, 1.0),
        "eye_white": (0.99, 0.99, 0.98, 1.0),
    },
    "golden_super_rare_palette": {
        "body_orange": (0.98, 0.78, 0.14, 1.0),
        "belly_cream": (1.00, 0.95, 0.62, 1.0),
        "bolt_yellow": (0.10, 0.92, 1.00, 1.0),
        "paw_brown": (0.80, 0.54, 0.08, 1.0),
        "eye_dark": (0.16, 0.12, 0.06, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_thunderrat(
    name: str = "Thunderrat_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 026. Thunderrat (Ref: Raichu):
      - Frente/rosto apontando para -Y e pés grandes apoiados em Z = 0.0
      - Corpo bípede laranja-dourado corpulento com barriga oval creme
      - Cabeça com bochechas amarelas, orelhas marrom-amarelo com pontas em espiral
      - Braços com pontas marrons e longa cauda-cabo preta com lâmina de raio amarela
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Rai_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Rai_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Rai_Norm"

    parts = []

    # 1. TORSO ROBUSTO LARANJA-DOURADO + BARRIGA CREME
    _add_part(
        parts,
        create_icosphere("_tmp_torso_main", 1, 0.66, (0.0, 0.06, 0.82), scale=(0.94, 0.90, 1.08)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_torso_upper", (0.98, 0.82, 0.78), (0.0, 0.02, 1.06)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_belly_cream", 1, 0.52, (0.0, -0.24, 0.82), scale=(0.92, 0.68, 1.06)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    for s_idx, sz in enumerate((1.06, 0.78)):
        _add_part(
            parts,
            create_cube(f"_tmp_back_stripe_{s_idx}", (0.72, 0.10, 0.14), (0.0, 0.44, sz)),
            mat_prefix,
            "paw_brown",
            pal,
        )

    # 2. CABEÇA, BOCHECHAS AMARELAS E ORELHAS ENROLADAS EM ESPIRAL
    _add_part(
        parts,
        create_cube("_tmp_head_main", (0.96, 0.86, 0.78), (0.0, -0.04, 1.66)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_nose", (0.12, 0.08, 0.06), (0.0, -0.49, 1.66)),
        mat_prefix,
        "eye_dark",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_smile", (0.28, 0.06, 0.06), (0.0, -0.48, 1.54)),
        mat_prefix,
        "eye_dark",
        pal,
    )

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_eye_{tag}", (0.18, 0.08, 0.20), (side * 0.26, -0.48, 1.74)),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_shine_{tag}", (0.07, 0.06, 0.08), (side * 0.23, -0.51, 1.78)),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Bochechas circulares ouro-amarelo
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_cheek_{tag}",
                6,
                0.17,
                0.08,
                (side * 0.36, -0.46, 1.50),
                rotation=(math.radians(90.0), 0.0, math.radians(side * 16.0)),
            ),
            mat_prefix,
            "bolt_yellow",
            pal,
        )

        # Orelha externa marrom-chocolate + interior amarelo + espiral na ponta lateral
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_outer_{tag}",
                4,
                0.22,
                0.03,
                0.86,
                (side * 0.62, -0.02, 2.22),
                rotation=(math.radians(-6.0), math.radians(side * 32.0), math.radians(45.0)),
                scale=(1.1, 0.45, 1.0),
            ),
            mat_prefix,
            "paw_brown",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_inner_{tag}",
                4,
                0.15,
                0.03,
                0.56,
                (side * 0.62, -0.08, 2.12),
                rotation=(math.radians(-6.0), math.radians(side * 38.0), math.radians(45.0)),
                scale=(1.0, 0.40, 1.0),
            ),
            mat_prefix,
            "bolt_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_ear_curl_bridge_{tag}",
                (0.24, 0.08, 0.14),
                (side * 0.72, -0.04, 2.04),
                rotation=(0.0, math.radians(side * 16.0), 0.0),
            ),
            mat_prefix,
            "bolt_yellow",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ear_curl_{tag}",
                1,
                0.12,
                (side * 0.84, -0.04, 2.00),
                scale=(1.0, 0.65, 1.0),
            ),
            mat_prefix,
            "paw_brown",
            pal,
        )

    # 3. BRAÇOS COM LUVAS MARRONS + PERNAS E PÉS GRANDES TOCANDO Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_arm_upper_{tag}",
                (0.36, 0.28, 0.24),
                (side * 0.58, -0.08, 1.18),
                rotation=(0.0, math.radians(side * 12.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_arm_paw_{tag}",
                (0.28, 0.24, 0.22),
                (side * 0.84, -0.14, 1.14),
                rotation=(0.0, math.radians(side * 12.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "paw_brown",
            pal,
        )

        # Pernas + pés compridos (ponta marrom + sola creme)
        _add_part(
            parts,
            create_cube(f"_tmp_leg_{tag}", (0.34, 0.36, 0.36), (side * 0.36, 0.02, 0.28)),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_base_{tag}", (0.32, 0.42, 0.14), (side * 0.38, -0.14, 0.07)),
            mat_prefix,
            "belly_cream",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_tip_{tag}", (0.30, 0.24, 0.13), (side * 0.38, -0.44, 0.065)),
            mat_prefix,
            "paw_brown",
            pal,
        )

    # 4. LONGA CAUDA-CABO ESCURA + PONTA DE RAIO AMARELA ACHATADA
    tail_wire = [
        (0.06, 0.48, (0.32, 0.52, 0.44), (0.0, 68.0, 0.0)),
        (0.055, 0.56, (0.74, 0.52, 0.62), (0.0, 56.0, 0.0)),
        (0.05, 0.54, (1.06, 0.48, 0.96), (0.0, 32.0, 0.0)),
    ]
    for idx, (rad, depth, loc, rot) in enumerate(tail_wire):
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_tail_wire_{idx}",
                6,
                rad,
                depth,
                loc,
                rotation=tuple(math.radians(a) for a in rot),
            ),
            mat_prefix,
            "paw_brown",
            pal,
        )
    # Grande ponta de raio achatada amarela (em 2 blocos facetados formando o raio)
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_bolt_main",
            4,
            0.40,
            0.04,
            0.94,
            (1.42, 0.46, 1.38),
            rotation=(0.0, math.radians(52.0), math.radians(45.0)),
            scale=(1.0, 0.30, 1.0),
        ),
        mat_prefix,
        "bolt_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_tail_bolt_notch",
            (0.42, 0.10, 0.34),
            (1.18, 0.46, 1.24),
            rotation=(0.0, math.radians(-26.0), 0.0),
        ),
        mat_prefix,
        "bolt_yellow",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 026. Thunderrat lado a lado."""
    specs = [
        ("Thunderrat_Shiny", (-8.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Thunderrat_Normal", (-4.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Thunderrat_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Thunderrat_Gigante", (4.5, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Thunderrat_Dourada_SuperRara", (11.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_thunderrat(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
