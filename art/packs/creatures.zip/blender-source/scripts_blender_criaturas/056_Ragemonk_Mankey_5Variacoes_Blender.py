"""
056_Ragemonk_Mankey_5Variacoes_Blender.py
=========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "056. Ragemonk — Macaco Furioso (Ref: Mankey)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Ragemonk_Shiny (1.0x - Paleta Shiny Pelagem Verde-Lima + Punhos e Pés Verde-Oliva Escuro)
  2. Ragemonk_Normal (1.0x - Bola Peluda Creme-Bege + Focinho de Porquinho Rosa + Cauda Longa Curva)
  3. Ragemonk_Grande (1.35x - Normal)
  4. Ragemonk_Gigante (1.85x - Normal)
  5. Ragemonk_Dourada_SuperRara (2.25x - Ouro Reluzente + Focinho e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + tufos de pelo em cones 5-6 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés de macaco alinhados exatamente em `Z = 0.0` e focinho/rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "fur_cream": (0.93, 0.87, 0.75, 1.0),
        "fur_shade": (0.83, 0.76, 0.64, 1.0),
        "limb_brown": (0.62, 0.46, 0.34, 1.0),
        "ear_inner": (0.52, 0.36, 0.25, 1.0),
        "snout_pink": (0.94, 0.66, 0.72, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "iris_red": (0.88, 0.22, 0.16, 1.0),
        "dark_detail": (0.12, 0.11, 0.13, 1.0),
    },
    "shiny_palette": {
        "fur_cream": (0.58, 0.78, 0.36, 1.0),
        "fur_shade": (0.46, 0.64, 0.28, 1.0),
        "limb_brown": (0.36, 0.42, 0.22, 1.0),
        "ear_inner": (0.32, 0.36, 0.18, 1.0),
        "snout_pink": (0.94, 0.68, 0.74, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "iris_red": (0.90, 0.24, 0.18, 1.0),
        "dark_detail": (0.12, 0.12, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "fur_cream": (0.98, 0.78, 0.14, 1.0),
        "fur_shade": (0.86, 0.62, 0.09, 1.0),
        "limb_brown": (0.76, 0.52, 0.08, 1.0),
        "ear_inner": (0.10, 0.92, 1.00, 1.0),
        "snout_pink": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (1.00, 0.98, 0.90, 1.0),
        "iris_red": (0.10, 0.92, 1.00, 1.0),
        "dark_detail": (0.06, 0.56, 0.72, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_ragemonk(
    name: str = "Ragemonk_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 056. Ragemonk (Ref: Mankey):
      - Corpo esférico peludo creme-bege cheio de tufos arrepiados ao redor da silhueta
      - Orelhas triangulares pontudas no topo com interior marrom
      - Focinho redondo rosa de porquinho com duas narinas verticais
      - Olhos triangulares furiosos em V com íris vermelha
      - Braços erguidos em postura de luta (antebraços e punhos marrons)
      - Pernas curtas com pés marrons de macaco de 3 dedos abertos apoiados em Z = 0.0
      - Cauda longa curva saindo para o lado direito com ponta marrom enrolada
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Rage_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Rage_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Rage_Norm"

    parts = []

    # 1. CORPO ESFÉRICO PELUDO + TUFOS ARREPIADOS AO REDOR
    _add_part(
        parts,
        create_icosphere("_tmp_body", 2, 0.72, (0.0, 0.0, 1.04), scale=(1.04, 0.94, 0.98)),
        mat_prefix,
        "fur_cream",
        pal,
    )
    # Tufos de pelo espetados no topo, laterais e queixo (assinatura visual do Mankey!)
    tuft_specs = [
        # (loc, r1, dep, rot_deg)
        ((-0.10, -0.02, 1.78), 0.14, 0.28, (6.0, -18.0, 0.0)),
        ((0.10, 0.00, 1.80), 0.15, 0.30, (4.0, 20.0, 0.0)),
        ((-0.74, -0.04, 1.18), 0.13, 0.26, (0.0, -76.0, 0.0)),
        ((-0.72, -0.08, 0.92), 0.13, 0.26, (0.0, -108.0, 0.0)),
        ((0.74, -0.04, 1.18), 0.13, 0.26, (0.0, 76.0, 0.0)),
        ((0.72, -0.08, 0.92), 0.13, 0.26, (0.0, 108.0, 0.0)),
        ((-0.22, -0.26, 0.42), 0.12, 0.24, (158.0, -20.0, 0.0)),
        ((0.0, -0.28, 0.38), 0.13, 0.26, (162.0, 0.0, 0.0)),
        ((0.22, -0.26, 0.42), 0.12, 0.24, (158.0, 20.0, 0.0)),
    ]
    for t_idx, (loc, r1, dep, rot_d) in enumerate(tuft_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tuft_{t_idx}",
                5,
                r1,
                0.014,
                dep,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
                scale=(1.0, 0.65, 1.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )

    # 2. ORELHAS TRIANGULARES PONTUDAS COM INTERIOR MARROM
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_out_{tag}",
                4,
                0.26,
                0.02,
                0.48,
                (side * 0.46, -0.04, 1.68),
                rotation=(math.radians(-8.0), math.radians(side * 34.0), math.radians(side * 12.0)),
                scale=(1.0, 0.48, 1.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_in_{tag}",
                4,
                0.17,
                0.015,
                0.34,
                (side * 0.46, -0.10, 1.66),
                rotation=(math.radians(-8.0), math.radians(side * 34.0), math.radians(side * 12.0)),
                scale=(1.0, 0.32, 1.0),
            ),
            mat_prefix,
            "ear_inner",
            pal,
        )

    # 3. ROSTO FURIOSO: FOCINHO DE PORQUINHO ROSA + OLHOS TRIANGULARES EM V
    _add_part(
        parts,
        create_icosphere("_tmp_snout", 2, 0.20, (0.0, -0.70, 0.94), scale=(1.22, 0.66, 0.80)),
        mat_prefix,
        "snout_pink",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Narina vertical no focinho
        _add_part(
            parts,
            create_cube(
                f"_tmp_nostril_{tag}",
                (0.032, 0.045, 0.095),
                (side * 0.068, -0.82, 0.94),
            ),
            mat_prefix,
            "dark_detail",
            pal,
        )
        # Olho branco triangular/furioso inclinado para o centro
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.17,
                (side * 0.24, -0.63, 1.15),
                rotation=(0.0, math.radians(side * -14.0), math.radians(side * -18.0)),
                scale=(1.18, 0.44, 0.72),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Íris vermelha feroz + pupila preta
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_iris_{tag}",
                1,
                0.078,
                (side * 0.22, -0.695, 1.14),
                scale=(0.74, 0.42, 0.96),
            ),
            mat_prefix,
            "iris_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.036,
                (side * 0.22, -0.72, 1.14),
                scale=(0.55, 0.40, 1.0),
            ),
            mat_prefix,
            "dark_detail",
            pal,
        )
        # Sobrancelha furiosa creme/escura formando o V da raiva
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.32, 0.11, 0.08),
                (side * 0.22, -0.66, 1.24),
                rotation=(math.radians(8.0), math.radians(side * -28.0), math.radians(side * -18.0)),
            ),
            mat_prefix,
            "fur_shade",
            pal,
        )

    # 4. BRAÇOS ERGUIDOS EM POSTURA DE LUTA (SUPERIOR CREME -> ANTEBRAÇO E PUNHO MARROM)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Braço horizontal saindo do corpo (creme)
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_h_{tag}",
                7,
                0.15,
                0.12,
                0.56,
                (side * 0.88, -0.02, 1.14),
                rotation=(0.0, math.radians(side * 84.0), 0.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
        # Cotovelo
        _add_part(
            parts,
            create_icosphere(f"_tmp_elbow_{tag}", 1, 0.125, (side * 1.14, -0.02, 1.18)),
            mat_prefix,
            "fur_cream",
            pal,
        )
        # Antebraço subindo (metade inferior creme, punho marrom)
        _add_part(
            parts,
            create_cone(
                f"_tmp_forearm_low_{tag}",
                7,
                0.12,
                0.115,
                0.28,
                (side * 1.18, -0.04, 1.32),
                rotation=(math.radians(-8.0), math.radians(side * 10.0), 0.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_forearm_hi_{tag}",
                7,
                0.12,
                0.13,
                0.32,
                (side * 1.22, -0.08, 1.56),
                rotation=(math.radians(-10.0), math.radians(side * 6.0), 0.0),
            ),
            mat_prefix,
            "limb_brown",
            pal,
        )
        # Punho cerrado marrom voltado para frente/dentro
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_fist_{tag}",
                2,
                0.20,
                (side * 1.14, -0.14, 1.72),
                scale=(1.12, 0.92, 0.94),
            ),
            mat_prefix,
            "limb_brown",
            pal,
        )

    # 5. PERNAS CURTAS + PÉS DE MACACO MARRONS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa creme
        _add_part(
            parts,
            create_cone(
                f"_tmp_thigh_{tag}",
                7,
                0.17,
                0.13,
                0.44,
                (side * 0.44, -0.04, 0.46),
                rotation=(math.radians(16.0), math.radians(side * 24.0), 0.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
        # Tornozelo marrom
        _add_part(
            parts,
            create_cone(
                f"_tmp_ankle_{tag}",
                7,
                0.12,
                0.11,
                0.28,
                (side * 0.56, -0.08, 0.20),
                rotation=(math.radians(-12.0), math.radians(side * 8.0), 0.0),
            ),
            mat_prefix,
            "limb_brown",
            pal,
        )
        # Base do pé marrom
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                1,
                0.15,
                (side * 0.58, -0.16, 0.085),
                scale=(1.10, 1.25, 0.54),
            ),
            mat_prefix,
            "limb_brown",
            pal,
        )
        # 2 dedos frontais abertos + polegar lateral de macaco
        for f_idx, ang_d in enumerate([-34.0, 26.0, side * -84.0]):
            ang = math.radians(ang_d + side * -12.0)
            tx = side * 0.58 + math.sin(ang) * 0.20
            ty = -0.16 - math.cos(ang) * 0.22
            _add_part(
                parts,
                create_cone(
                    f"_tmp_ftoe_{tag}_{f_idx}",
                    5,
                    0.062,
                    0.046,
                    0.24,
                    (tx, ty, 0.07),
                    rotation=(math.radians(90.0), 0.0, ang),
                ),
                mat_prefix,
                "limb_brown",
                pal,
            )

    # 6. CAUDA LONGA CURVA PARA O LADO DIREITO COM PONTA MARROM ENROLADA
    tail_points = [
        # (loc, r, mat_key)
        ((0.28, 0.62, 0.64), 0.095, "fur_shade"),
        ((0.60, 0.68, 0.66), 0.090, "fur_shade"),
        ((0.92, 0.64, 0.76), 0.088, "fur_shade"),
        ((1.22, 0.54, 0.94), 0.088, "limb_brown"),
        ((1.40, 0.42, 1.18), 0.088, "limb_brown"),
        ((1.34, 0.34, 1.40), 0.085, "limb_brown"),
        ((1.14, 0.30, 1.44), 0.082, "limb_brown"),
        ((1.02, 0.28, 1.32), 0.075, "limb_brown"),
    ]
    for idx in range(len(tail_points) - 1):
        p0, r0, mk = tail_points[idx]
        p1, r1, _ = tail_points[idx + 1]
        dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
        dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
        horiz = math.sqrt(dx * dx + dy * dy)
        rot_x = math.atan2(horiz, dz)
        rot_z = math.atan2(dx, -dy)
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_seg_{idx}",
                6,
                r0,
                r1,
                dist + 0.06,
                mid,
                rotation=(rot_x, 0.0, rot_z),
            ),
            mat_prefix,
            mk,
            pal,
        )
    _add_part(
        parts,
        create_icosphere("_tmp_tail_tip", 1, 0.078, tail_points[-1][0]),
        mat_prefix,
        "limb_brown",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 056. Ragemonk lado a lado."""
    specs = [
        ("Ragemonk_Shiny", (-10.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Ragemonk_Normal", (-6.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Ragemonk_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Ragemonk_Gigante", (5.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Ragemonk_Dourada_SuperRara", (14.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_ragemonk(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
