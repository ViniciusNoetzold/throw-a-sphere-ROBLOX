"""
081_Voltmagnet_Magnemite_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "081. Voltmagnet — Esfera Magnética (Ref: Magnemite)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Voltmagnet_Shiny (1.0x - Paleta Shiny Ouro-Pálido + Pontas dos Ímãs Preto-Carvão)
  2. Voltmagnet_Normal (1.0x - Esfera Aço-Azulado + Ímãs em U Vermelho/Azul + 3 Parafusos Phillips)
  3. Voltmagnet_Grande (1.35x - Normal)
  4. Voltmagnet_Gigante (1.85x - Normal)
  5. Voltmagnet_Dourada_SuperRara (2.25x - Ouro Reluzente + Olho e Polos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2, cilindros, cones e ímãs em U vazados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base alinhada exatamente em `Z = 0.0` e frente/olho apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_steel": (0.76, 0.84, 0.88, 1.0),
        "magnet_gray": (0.60, 0.63, 0.66, 1.0),
        "screw_silver": (0.72, 0.75, 0.79, 1.0),
        "screw_dark": (0.28, 0.30, 0.35, 1.0),
        "magnet_red": (0.86, 0.32, 0.30, 1.0),
        "magnet_blue": (0.22, 0.62, 0.88, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "shiny_palette": {
        "body_steel": (0.90, 0.84, 0.56, 1.0),
        "magnet_gray": (0.56, 0.55, 0.50, 1.0),
        "screw_silver": (0.76, 0.74, 0.62, 1.0),
        "screw_dark": (0.24, 0.24, 0.26, 1.0),
        "magnet_red": (0.18, 0.20, 0.22, 1.0),
        "magnet_blue": (0.22, 0.24, 0.27, 1.0),
        "eye_white": (0.98, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "body_steel": (0.98, 0.78, 0.14, 1.0),
        "magnet_gray": (0.86, 0.66, 0.12, 1.0),
        "screw_silver": (1.00, 0.86, 0.28, 1.0),
        "screw_dark": (0.10, 0.92, 1.00, 1.0),
        "magnet_red": (0.10, 0.92, 1.00, 1.0),
        "magnet_blue": (0.06, 0.72, 0.92, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel angular e Flat Shading."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _rot_pt(pt, rx, ry, rz):
    """Aplica rotação Euler XYZ a um ponto local (x, y, z)."""
    x, y, z = pt
    cx, sx = math.cos(rx), math.sin(rx)
    y, z = y * cx - z * sx, y * sx + z * cx
    cy, sy = math.cos(ry), math.sin(ry)
    x, z = x * cy + z * sy, -x * sy + z * cy
    cz, sz = math.cos(rz), math.sin(rz)
    x, y = x * cz - y * sz, x * sz + y * cz
    return (x, y, z)


def _add_u_magnet(
    parts: list,
    tag: str,
    pivot: tuple,
    side: float,
    tilt_y_deg: float,
    top_mat: str,
    bot_mat: str,
    mat_prefix: str,
    pal: dict,
):
    """
    Constrói um ímã em U (ferradura) vazado autêntico, preso firmemente na lateral da esfera:
      - side = -1.0 aponta para -X (esquerda da tela); side = +1.0 aponta para +X (direita).
      - tilt_y_deg inclina o ímã no plano XZ.
    """
    ry = math.radians(tilt_y_deg)
    px, py, pz = pivot

    def to_world(lx, ly, lz):
        wx, wy, wz = _rot_pt((lx * side, ly, lz), 0.0, ry, 0.0)
        return (px + wx, py + wy, pz + wz)

    # Pino de conexão discreto garantindo contato sólido com a esfera
    _add_part(
        parts,
        create_cylinder(
            f"_tmp_mag_pin_{tag}",
            8,
            0.12,
            0.24,
            to_world(0.02, 0.0, 0.0),
            rotation=(0.0, math.radians(90.0) + ry, 0.0),
        ),
        mat_prefix,
        "magnet_gray",
        pal,
    )

    # Arco traseiro curvo do U (5 blocos facetados em semicírculo de raio 0.30)
    arch_center_x = 0.42
    arch_r = 0.30
    thick = 0.21
    depth_y = 0.22
    for idx, ang_deg in enumerate([105.0, 142.0, 180.0, 218.0, 255.0]):
        ang = math.radians(ang_deg)
        lx = arch_center_x + arch_r * math.cos(ang)
        lz = arch_r * math.sin(ang)
        # Normal radial do arco; o bloco fica tangente
        seg_ry = ry + side * (ang - math.pi)
        _add_part(
            parts,
            create_cube(
                f"_tmp_mag_arch_{tag}_{idx}",
                (thick, depth_y, 0.25),
                to_world(lx, 0.0, lz),
                rotation=(0.0, seg_ry, 0.0),
            ),
            mat_prefix,
            "magnet_gray",
            pal,
        )

    # Braços paralelos metálicos (superior e inferior)
    for arm_tag, sz in (("top", 1.0), ("bot", -1.0)):
        _add_part(
            parts,
            create_cube(
                f"_tmp_mag_arm_{tag}_{arm_tag}",
                (0.46, depth_y, thick),
                to_world(0.62, 0.0, sz * arch_r),
                rotation=(0.0, ry, 0.0),
            ),
            mat_prefix,
            "magnet_gray",
            pal,
        )

    # Pontas coloridas (polos vermelho e azul)
    _add_part(
        parts,
        create_cube(
            f"_tmp_mag_tip_{tag}_top",
            (0.32, depth_y, thick),
            to_world(0.98, 0.0, arch_r),
            rotation=(0.0, ry, 0.0),
        ),
        mat_prefix,
        top_mat,
        pal,
    )
    _add_part(
        parts,
        create_cube(
            f"_tmp_mag_tip_{tag}_bot",
            (0.32, depth_y, thick),
            to_world(0.98, 0.0, -arch_r),
            rotation=(0.0, ry, 0.0),
        ),
        mat_prefix,
        bot_mat,
        pal,
    )


def _add_phillips_screw(
    parts: list,
    tag: str,
    location: tuple,
    rotation: tuple,
    head_r: float,
    shaft_len: float,
    is_top: bool,
    mat_prefix: str,
    pal: dict,
):
    """Cria um parafuso Phillips com rosca + cabeça facetada + fenda em cruz (+)."""
    rx, ry, rz = rotation
    ox, oy, oz = location

    def to_world(lx, ly, lz):
        wx, wy, wz = _rot_pt((lx, ly, lz), rx, ry, rz)
        return (ox + wx, oy + wy, oz + wz)

    # Haste roscada
    _add_part(
        parts,
        create_cylinder(
            f"_tmp_screw_shaft_{tag}",
            8,
            head_r * 0.42,
            shaft_len,
            to_world(0.0, 0.0, shaft_len * 0.5),
            rotation=rotation,
        ),
        mat_prefix,
        "screw_dark",
        pal,
    )
    if is_top:
        for r_idx, frac in enumerate((0.28, 0.54, 0.80)):
            _add_part(
                parts,
                create_cylinder(
                    f"_tmp_screw_thread_{tag}_{r_idx}",
                    8,
                    head_r * 0.54,
                    0.045,
                    to_world(0.0, 0.0, shaft_len * frac),
                    rotation=rotation,
                ),
                mat_prefix,
                "screw_silver",
                pal,
            )

    # Cabeça do parafuso
    head_z = shaft_len + head_r * 0.16
    _add_part(
        parts,
        create_icosphere(
            f"_tmp_screw_head_{tag}",
            2,
            head_r,
            to_world(0.0, 0.0, head_z),
            rotation=rotation,
            scale=(1.0, 1.0, 0.36),
        ),
        mat_prefix,
        "screw_silver",
        pal,
    )

    # Fenda Phillips em cruz (+) bem legível
    cross_z = head_z + head_r * 0.30
    cross_len = head_r * 1.18
    cross_w = head_r * 0.30
    cross_h = head_r * 0.16
    _add_part(
        parts,
        create_cube(
            f"_tmp_screw_cross_a_{tag}",
            (cross_len, cross_w, cross_h),
            to_world(0.0, 0.0, cross_z),
            rotation=rotation,
        ),
        mat_prefix,
        "screw_dark",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            f"_tmp_screw_cross_b_{tag}",
            (cross_w, cross_len, cross_h),
            to_world(0.0, 0.0, cross_z),
            rotation=rotation,
        ),
        mat_prefix,
        "screw_dark",
        pal,
    )


def build_voltmagnet(
    name: str = "Voltmagnet_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 081. Voltmagnet (Ref: Magnemite):
      - Esfera metálica central aço-azulado (icosphere subdiv=2)
      - Grande olho circular branco central com contorno escuro e pupila preta nítida
      - Parafuso Phillips grande roscado no topo da cabeça com leve inclinação charmosa
      - Dois parafusos Phillips menores na frente inferior esquerda e direita
      - Dois grandes ímãs em U (ferradura) vazados laterais com polos opostos vermelho e azul
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Volt_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Volt_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Volt_Norm"

    parts = []

    # 1. ESFERA METÁLICA CENTRAL
    _add_part(
        parts,
        create_icosphere("_tmp_body_sphere", 2, 0.72, (0.0, 0.0, 0.96)),
        mat_prefix,
        "body_steel",
        pal,
    )

    # 2. GRANDE OLHO CIRCULAR CENTRAL (FRENTE -Y)
    _add_part(
        parts,
        create_cylinder(
            "_tmp_eye_rim",
            12,
            0.355,
            0.05,
            (0.0, -0.66, 1.00),
            rotation=(math.radians(90.0), 0.0, 0.0),
        ),
        mat_prefix,
        "screw_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_eye_white",
            2,
            0.34,
            (0.0, -0.64, 1.00),
            scale=(1.0, 0.34, 1.0),
        ),
        mat_prefix,
        "eye_white",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_eye_pupil",
            1,
            0.058,
            (0.0, -0.77, 1.00),
            scale=(1.0, 0.55, 1.0),
        ),
        mat_prefix,
        "eye_dark",
        pal,
    )

    # 3. PARAFUSO PHILLIPS GRANDE NO TOPO (INCLINADO SUAVEMENTE COMO NA REFERÊNCIA)
    _add_phillips_screw(
        parts,
        tag="top",
        location=(-0.06, 0.0, 1.62),
        rotation=(math.radians(4.0), math.radians(-12.0), 0.0),
        head_r=0.33,
        shaft_len=0.32,
        is_top=True,
        mat_prefix=mat_prefix,
        pal=pal,
    )

    # 4. DOIS PARAFUSOS PHILLIPS INFERIORES NA FRENTE
    _add_phillips_screw(
        parts,
        tag="front_L",
        location=(-0.44, -0.50, 0.58),
        rotation=(math.radians(108.0), 0.0, math.radians(-38.0)),
        head_r=0.175,
        shaft_len=0.14,
        is_top=False,
        mat_prefix=mat_prefix,
        pal=pal,
    )
    _add_phillips_screw(
        parts,
        tag="front_R",
        location=(0.44, -0.50, 0.66),
        rotation=(math.radians(104.0), 0.0, math.radians(38.0)),
        head_r=0.175,
        shaft_len=0.14,
        is_top=False,
        mat_prefix=mat_prefix,
        pal=pal,
    )

    # 5. DOIS ÍMÃS EM U (FERRADURA) COM POLOS OPOSTOS (FIEL À REFERÊNCIA)
    # Esquerda (-X): Vermelho no topo, Azul embaixo, levemente inclinado
    _add_u_magnet(
        parts,
        tag="L",
        pivot=(-0.66, 0.02, 0.80),
        side=-1.0,
        tilt_y_deg=-10.0,
        top_mat="magnet_red",
        bot_mat="magnet_blue",
        mat_prefix=mat_prefix,
        pal=pal,
    )
    # Direita (+X): Azul no topo, Vermelho embaixo, levemente inclinado para cima
    _add_u_magnet(
        parts,
        tag="R",
        pivot=(0.66, 0.02, 1.12),
        side=1.0,
        tilt_y_deg=-14.0,
        top_mat="magnet_blue",
        bot_mat="magnet_red",
        mat_prefix=mat_prefix,
        pal=pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 081. Voltmagnet lado a lado."""
    specs = [
        ("Voltmagnet_Shiny", (-11.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Voltmagnet_Normal", (-7.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Voltmagnet_Grande", (-1.2, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Voltmagnet_Gigante", (6.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Voltmagnet_Dourada_SuperRara", (15.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_voltmagnet(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
