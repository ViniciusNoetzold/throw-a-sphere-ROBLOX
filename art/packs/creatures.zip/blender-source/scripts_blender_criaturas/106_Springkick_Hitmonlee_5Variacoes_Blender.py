"""
106_Springkick_Hitmonlee_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "106. Springkick — Mestre dos Chutes (Ref: Hitmonlee)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Springkick_Shiny (1.0x - Corpo Verde-Oliva + Molas Bege-Areia + Tornozelos Amarelos)
  2. Springkick_Normal (1.0x - Corpo Marrom-Bronze Sem Pescoço + Pernas em Mola + Chute Alto!)
  3. Springkick_Grande (1.35x - Normal)
  4. Springkick_Gigante (1.85x - Normal)
  5. Springkick_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Garras Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (tronco em amêndoa sem pescoço, anéis de mola segmentados, chute alto dinâmico)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pé de apoio alinhado exatamente em `Z = 0.0` e rosto/olhos apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_brown": (0.72, 0.56, 0.46, 1.0),
        "body_shade": (0.56, 0.42, 0.34, 1.0),
        "coil_cream": (0.90, 0.86, 0.68, 1.0),
        "coil_dark": (0.48, 0.44, 0.34, 1.0),
        "heel_yellow": (0.96, 0.88, 0.36, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
        "claw_white": (0.98, 0.98, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_brown": (0.46, 0.66, 0.32, 1.0),
        "body_shade": (0.34, 0.52, 0.22, 1.0),
        "coil_cream": (0.92, 0.88, 0.68, 1.0),
        "coil_dark": (0.42, 0.44, 0.30, 1.0),
        "heel_yellow": (0.98, 0.90, 0.34, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
        "claw_white": (0.98, 0.98, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_brown": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.82, 0.60, 0.08, 1.0),
        "coil_cream": (1.00, 0.94, 0.62, 1.0),
        "coil_dark": (0.68, 0.48, 0.06, 1.0),
        "heel_yellow": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.04, 0.38, 0.54, 1.0),
        "claw_white": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_spring_limb(
    parts: list,
    tag: str,
    start: tuple,
    end: tuple,
    count: int,
    rad_start: float,
    rad_end: float,
    mat_prefix: str,
    pal: dict,
):
    """Constrói um membro flexível em anéis espiralados bege (assinatura do Hitmonlee)."""
    sx, sy, sz = start
    ex, ey, ez = end
    dx, dy, dz = ex - sx, ey - sy, ez - sz
    total_len = math.sqrt(dx * dx + dy * dy + dz * dz)
    # Orientação do cilindro/anéis ao longo do vetor (dx, dy, dz)
    horiz = math.sqrt(dx * dx + dy * dy)
    tilt_y = math.atan2(dx, dz)
    tilt_x = -math.atan2(dy, math.sqrt(dx * dx + dz * dz))

    # Núcleo interno escuro contínuo que garante união sólida entre todos os anéis
    mid = ((sx + ex) * 0.5, (sy + ey) * 0.5, (sz + ez) * 0.5)
    _add_part(
        parts,
        create_cylinder(
            f"_tmp_spring_core_{tag}",
            8,
            min(rad_start, rad_end) * 0.72,
            total_len * 1.04,
            mid,
            rotation=(tilt_x, tilt_y, 0.0),
        ),
        mat_prefix,
        "coil_dark",
        pal,
    )

    # Anéis arredondados salientes de mola
    seg_len = total_len / count
    for i in range(count):
        t = (i + 0.5) / count
        px = sx + dx * t
        py = sy + dy * t
        pz = sz + dz * t
        rad = rad_start + (rad_end - rad_start) * t
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_spring_ring_{tag}_{i}",
                2,
                rad,
                (px, py, pz),
                rotation=(tilt_x, tilt_y, 0.0),
                scale=(1.04, 1.04, max(0.58, (seg_len * 0.62) / rad)),
            ),
            mat_prefix,
            "coil_cream",
            pal,
        )


def build_springkick(
    name: str = "Springkick_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel do 106. Springkick (Ref: Hitmonlee):
      - Corpo oval/amêndoa marrom-bronze (verde-oliva na Shiny) SEM pescoço, topo arredondado
      - Olhos triangulares brancos inseridos em máscara facial preta direto no peito/testa
      - Perna direita (-X) vertical em 6 anéis de mola bege + pé de 3 garras brancas e calcanhar amarelo
      - Perna esquerda (+X) em CHUTE ALTO DINÂMICO com 7 anéis de mola estendidos + 3 garras!
      - Braços musculosos com punhos em mola e mãos abertas de 3 dedos em guarda de artes marciais
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Springkick_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Springkick_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Springkick_Norm"

    parts = []

    # 1. CORPO EM FORMA DE AMÊNDOA SEM PESCOÇO (ASSINATURA DO HITMONLEE!)
    # Domo superior liso (cabeça integrada ao peito)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_torso_top",
            2,
            0.54,
            (-0.10, 0.02, 1.76),
            rotation=(math.radians(-6.0), math.radians(-6.0), 0.0),
            scale=(0.94, 0.88, 1.18),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Tronco inferior afunilado até os quadris
    _add_part(
        parts,
        create_cone(
            "_tmp_torso_mid",
            10,
            0.28,
            0.50,
            0.84,
            (-0.14, 0.04, 1.30),
            rotation=(math.radians(-4.0), math.radians(-8.0), 0.0),
            scale=(0.94, 0.84, 1.0),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Quadril conectando as duas pernas
    _add_part(
        parts,
        create_icosphere("_tmp_pelvis", 2, 0.30, (-0.12, 0.04, 0.98), scale=(1.12, 0.88, 0.88)),
        mat_prefix,
        "body_brown",
        pal,
    )

    # 2. OLHOS FEROZES EM MÁSCARA ESCURA DIRETO NO PEITO/TESTA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Máscara preta amendoada inclinada para baixo em direção ao centro (V feroz!)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_mask_{tag}",
                2,
                0.18,
                (-0.10 + side * 0.22, -0.42, 1.76),
                rotation=(0.0, math.radians(-side * 22.0), math.radians(-side * 16.0)),
                scale=(1.15, 0.42, 0.72),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        # Olho branco focado dentro da máscara
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                1,
                0.10,
                (-0.10 + side * 0.21, -0.47, 1.75),
                rotation=(0.0, math.radians(-side * 20.0), math.radians(-side * 16.0)),
                scale=(1.06, 0.42, 0.68),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pupila escura afiada
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.045,
                (-0.10 + side * 0.20, -0.50, 1.75),
                scale=(0.75, 0.40, 1.05),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # 3. PERNA DE APOIO (-X) COM 6 ANÉIS DE MOLA + PÉ DE 3 GARRAS EM Z = 0.0
    _add_spring_limb(
        parts,
        "leg_stand",
        (-0.24, 0.04, 0.94),
        (-0.26, 0.02, 0.22),
        6,
        0.165,
        0.145,
        mat_prefix,
        pal,
    )
    # Pé de apoio achatado marrom
    _add_part(
        parts,
        create_icosphere("_tmp_foot_stand", 2, 0.24, (-0.26, -0.08, 0.12), scale=(1.08, 1.24, 0.56)),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Almofada amarela no calcanhar/tornozelo
    _add_part(
        parts,
        create_icosphere("_tmp_heel_stand", 1, 0.11, (-0.26, 0.14, 0.16), scale=(0.92, 0.68, 0.90)),
        mat_prefix,
        "heel_yellow",
        pal,
    )
    # 3 garras brancas no pé de apoio
    for c_idx, (dx, rz_d) in enumerate([(-0.16, 16.0), (0.0, 0.0), (0.16, -16.0)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_claw_stand_{c_idx}",
                5,
                0.068,
                0.014,
                0.22,
                (-0.26 + dx, -0.34, 0.09),
                rotation=(math.radians(-86.0), 0.0, math.radians(rz_d)),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 4. PERNA DE CHUTE ALTO (+X) COM 7 ANÉIS DE MOLA ESTENDIDOS + PÉ COM 3 GARRAS!
    # Coxa saindo do quadril para cima/direita
    _add_part(
        parts,
        create_cone(
            "_tmp_hip_kick",
            8,
            0.22,
            0.17,
            0.38,
            (0.18, -0.02, 1.12),
            rotation=(0.0, math.radians(68.0), 0.0),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    _add_spring_limb(
        parts,
        "leg_kick",
        (0.32, -0.04, 1.18),
        (1.36, -0.14, 1.56),
        7,
        0.165,
        0.150,
        mat_prefix,
        pal,
    )
    # Pé chutando aberto no topo do chute
    _add_part(
        parts,
        create_icosphere(
            "_tmp_foot_kick",
            2,
            0.26,
            (1.56, -0.16, 1.66),
            rotation=(0.0, math.radians(-26.0), 0.0),
            scale=(1.12, 0.78, 1.18),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    # Almofada amarela no calcanhar do pé chutando (bem visível na arte!)
    _add_part(
        parts,
        create_icosphere(
            "_tmp_heel_kick",
            1,
            0.12,
            (1.58, -0.22, 1.44),
            rotation=(0.0, math.radians(-24.0), 0.0),
            scale=(1.05, 0.65, 0.76),
        ),
        mat_prefix,
        "heel_yellow",
        pal,
    )
    # 3 garras brancas afiadas apontando para cima/fora no pé chutando!
    kick_claws = [
        (1.48, -0.18, 1.98, 14.0),
        (1.68, -0.18, 1.94, 34.0),
        (1.82, -0.18, 1.78, 56.0),
    ]
    for c_idx, (cx, cy, cz, ry_d) in enumerate(kick_claws):
        _add_part(
            parts,
            create_cone(
                f"_tmp_claw_kick_{c_idx}",
                5,
                0.072,
                0.015,
                0.26,
                (cx, cy, cz),
                rotation=(0.0, math.radians(ry_d), 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 5. BRAÇOS EM GUARDA DE ARTES MARCIAIS COM PUNHOS EM MOLA BEGE
    # Braço direito (-X) dobrado para frente em guarda de ataque
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R_up",
            7,
            0.14,
            0.11,
            0.46,
            (-0.70, 0.02, 1.74),
            rotation=(0.0, math.radians(-82.0), math.radians(16.0)),
        ),
        mat_prefix,
        "body_brown",
        pal,
    )
    _add_spring_limb(
        parts,
        "arm_R_coil",
        (-0.88, -0.02, 1.72),
        (-0.62, -0.34, 1.68),
        3,
        0.105,
        0.095,
        mat_prefix,
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hand_R", 2, 0.14, (-0.54, -0.44, 1.66)),
        mat_prefix,
        "body_brown",
        pal,
    )
    for f_idx, (fx, fz) in enumerate([(-0.08, 0.09), (0.04, 0.02), (-0.04, -0.08)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_finger_R_{f_idx}",
                5,
                0.045,
                0.020,
                0.15,
                (-0.46 + fx, -0.52, 1.66 + fz),
                rotation=(math.radians(-70.0), math.radians(24.0), 0.0),
            ),
            mat_prefix,
            "body_brown",
            pal,
        )

    # Braço esquerdo (+X) estendido para trás/lado dando equilíbrio ao chute
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_L_up",
            7,
            0.14,
            0.11,
            0.46,
            (0.44, 0.12, 1.66),
            rotation=(math.radians(18.0), math.radians(72.0), 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )
    _add_spring_limb(
        parts,
        "arm_L_coil",
        (0.62, 0.16, 1.54),
        (0.84, 0.18, 1.24),
        3,
        0.100,
        0.092,
        mat_prefix,
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hand_L", 2, 0.13, (0.90, 0.18, 1.14)),
        mat_prefix,
        "body_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 106. Springkick lado a lado."""
    specs = [
        ("Springkick_Shiny", (-12.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Springkick_Normal", (-6.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Springkick_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Springkick_Gigante", (6.5, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Springkick_Dourada_SuperRara", (15.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_springkick(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
