"""
032_PinbunnyM_Nidoran_M_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "032. PinbunnyM — Coelho Espinhoso Macho (Ref: Nidoran-M)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. PinbunnyM_Shiny (1.0x - Paleta Shiny / Shyne Azul-Celeste + Manchas Azul-Marinho)
  2. PinbunnyM_Normal (1.0x - Roxo-Magenta + Manchas Roxo-Escuro + Orelhas Turquesa + Chifre Frontal)
  3. PinbunnyM_Grande (1.35x - Normal)
  4. PinbunnyM_Gigante (1.85x - Normal)
  5. PinbunnyM_Dourada_SuperRara (2.25x - Ouro Reluzente + Orelhas e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e frente/chifre apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`PinbunnyM_Shiny`, `PinbunnyM_Normal`, `PinbunnyM_Grande`,
     `PinbunnyM_Gigante`, `PinbunnyM_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_magenta": (0.76, 0.44, 0.72, 1.0),
        "spot_plum": (0.50, 0.22, 0.48, 1.0),
        "ear_teal": (0.28, 0.72, 0.72, 1.0),
        "eye_ruby": (0.86, 0.20, 0.24, 1.0),
        "claw_white": (0.98, 0.98, 0.99, 1.0),
    },
    "shiny_palette": {
        "body_magenta": (0.48, 0.74, 0.92, 1.0),
        "spot_plum": (0.26, 0.46, 0.70, 1.0),
        "ear_teal": (0.30, 0.68, 0.78, 1.0),
        "eye_ruby": (0.88, 0.22, 0.26, 1.0),
        "claw_white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_magenta": (0.98, 0.78, 0.14, 1.0),
        "spot_plum": (0.84, 0.56, 0.08, 1.0),
        "ear_teal": (0.10, 0.92, 1.00, 1.0),
        "eye_ruby": (0.10, 0.92, 1.00, 1.0),
        "claw_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base das patas em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_pinbunnym(
    name: str = "PinbunnyM_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 032. PinbunnyM (Ref: Nidoran-M):
      - Frente/chifre apontando para -Y e patinhas tocando Z = 0.0
      - Quadrúpede compacto roxo-magenta com manchas roxo-escuro e 4 espinhos dorsais longos
      - Cabeça com chifre pontiagudo único na testa, olho rubi feroz, dentinho frontal branco
      - Orelhas grandes pontiagudas verticais com interior turquesa vibrante
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_PinM_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_PinM_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_PinM_Norm"

    parts = []

    # 1. CORPO QUADRÚPEDE COMPACTO ROXO-MAGENTA + MANCHAS + LEQUE DE ESPINHOS DORSAIS
    _add_part(
        parts,
        create_icosphere("_tmp_torso_main", 1, 0.56, (0.0, 0.14, 0.52), scale=(0.94, 1.12, 0.88)),
        mat_prefix,
        "body_magenta",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_spot_hi_{tag}", (0.12, 0.22, 0.18), (side * 0.49, 0.20, 0.62)),
            mat_prefix,
            "spot_plum",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_spot_lo_{tag}", (0.12, 0.20, 0.16), (side * 0.50, 0.48, 0.46)),
            mat_prefix,
            "spot_plum",
            pal,
        )

    # 4 espinhos dorsais pontiagudos característicos do macho
    for s_idx, (sy, sz, rx, depth) in enumerate([
        (0.06, 1.06, -16.0, 0.42),
        (0.32, 1.06, -32.0, 0.46),
        (0.56, 0.94, -50.0, 0.42),
        (0.74, 0.74, -70.0, 0.34),
    ]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_back_spine_{s_idx}",
                4,
                0.13,
                0.02,
                depth,
                (0.0, sy, sz),
                rotation=(math.radians(rx), 0.0, math.radians(45.0)),
            ),
            mat_prefix,
            "body_magenta",
            pal,
        )

    # 2. CABEÇA, CHIFRE PONTIAGUDO ÚNICO, OLHOS RUBI E ORELHAS PONTUDAS VERTICAIS
    _add_part(
        parts,
        create_cube("_tmp_head_main", (0.76, 0.72, 0.58), (0.0, -0.44, 0.72)),
        mat_prefix,
        "body_magenta",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            4,
            0.24,
            0.12,
            0.30,
            (0.0, -0.88, 0.66),
            rotation=(math.radians(96.0), 0.0, math.radians(45.0)),
            scale=(1.10, 0.78, 1.0),
        ),
        mat_prefix,
        "body_magenta",
        pal,
    )
    # Chifre pontiagudo proeminente na testa (assinatura do Nidoran-M)
    _add_part(
        parts,
        create_cone(
            "_tmp_forehead_horn",
            4,
            0.13,
            0.018,
            0.46,
            (0.0, -0.88, 0.98),
            rotation=(math.radians(74.0), 0.0, math.radians(45.0)),
        ),
        mat_prefix,
        "body_magenta",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_forehead_spot", (0.16, 0.08, 0.14), (0.0, -0.80, 0.86)),
        mat_prefix,
        "spot_plum",
        pal,
    )
    # Dentinho frontal branco
    _add_part(
        parts,
        create_cone(
            "_tmp_tooth_front",
            4,
            0.08,
            0.015,
            0.16,
            (0.0, -0.94, 0.48),
            rotation=(math.radians(180.0), 0.0, math.radians(45.0)),
        ),
        mat_prefix,
        "claw_white",
        pal,
    )

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_eye_white_{tag}", (0.16, 0.24, 0.19), (side * 0.30, -0.74, 0.78)),
            mat_prefix,
            "claw_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_ruby_{tag}", (0.14, 0.16, 0.15), (side * 0.31, -0.80, 0.78)),
            mat_prefix,
            "eye_ruby",
            pal,
        )

        # Grandes orelhas pontudas verticais com interior turquesa vibrante
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_outer_{tag}",
                4,
                0.34,
                0.04,
                0.96,
                (side * 0.44, -0.22, 1.38),
                rotation=(math.radians(-12.0), math.radians(side * 24.0), math.radians(45.0)),
                scale=(1.15, 0.44, 1.0),
            ),
            mat_prefix,
            "body_magenta",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_teal_{tag}",
                4,
                0.23,
                0.03,
                0.70,
                (side * 0.44, -0.28, 1.34),
                rotation=(math.radians(-12.0), math.radians(side * 24.0), math.radians(45.0)),
                scale=(1.05, 0.36, 1.0),
            ),
            mat_prefix,
            "ear_teal",
            pal,
        )

    # 3. QUATRO PATAS COM GARRAS BRANCAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_front_leg_{tag}", (0.28, 0.32, 0.38), (side * 0.34, -0.26, 0.19)),
            mat_prefix,
            "body_magenta",
            pal,
        )
        for c_idx, dx in enumerate((-0.07, 0.07)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_front_claw_{tag}_{c_idx}",
                    4,
                    0.05,
                    0.01,
                    0.16,
                    (side * 0.34 + dx, -0.46, 0.055),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

        _add_part(
            parts,
            create_cube(f"_tmp_back_leg_{tag}", (0.30, 0.36, 0.36), (side * 0.36, 0.46, 0.18)),
            mat_prefix,
            "body_magenta",
            pal,
        )
        for c_idx, dx in enumerate((-0.07, 0.07)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_back_claw_{tag}_{c_idx}",
                    4,
                    0.05,
                    0.01,
                    0.16,
                    (side * 0.36 + dx, 0.24, 0.055),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 032. PinbunnyM lado a lado."""
    specs = [
        ("PinbunnyM_Shiny", (-6.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("PinbunnyM_Normal", (-3.8, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("PinbunnyM_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("PinbunnyM_Gigante", (3.5, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("PinbunnyM_Dourada_SuperRara", (8.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_pinbunnym(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
