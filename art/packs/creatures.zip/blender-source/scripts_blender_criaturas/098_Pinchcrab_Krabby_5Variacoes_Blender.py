"""
098_Pinchcrab_Krabby_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "098. Pinchcrab — Caranguejo da Praia (Ref: Krabby)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Pinchcrab_Shiny (1.0x - Paleta Shiny Carapaça Amarelo-Ouro Limão + Barriga Creme + Pinças Douradas)
  2. Pinchcrab_Normal (1.0x - Carapaça Vermelho-Coral + Mandíbula Creme Dentada + 2 Enormes Pinças)
  3. Pinchcrab_Grande (1.35x - Normal)
  4. Pinchcrab_Gigante (1.85x - Normal)
  5. Pinchcrab_Dourada_SuperRara (2.25x - Carapaça e Pinças Ouro Reluzente + Olhos e Espinhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para carapaça e pinças; cones/cilindros para patas articuladas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pontas das 4 patas apoiadas exatamente em `Z = 0.0` e olhos/pinças apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "shell_coral": (0.91, 0.48, 0.30, 1.0),
        "shell_shade": (0.74, 0.34, 0.20, 1.0),
        "belly_cream": (0.95, 0.91, 0.87, 1.0),
        "leg_grey": (0.80, 0.76, 0.75, 1.0),
        "claw_dark": (0.28, 0.26, 0.28, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "pupil_dark": (0.08, 0.08, 0.10, 1.0),
    },
    "shiny_palette": {
        "shell_coral": (0.84, 0.78, 0.22, 1.0),
        "shell_shade": (0.66, 0.60, 0.14, 1.0),
        "belly_cream": (0.96, 0.94, 0.84, 1.0),
        "leg_grey": (0.82, 0.80, 0.70, 1.0),
        "claw_dark": (0.30, 0.28, 0.20, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "pupil_dark": (0.08, 0.08, 0.10, 1.0),
    },
    "golden_super_rare_palette": {
        "shell_coral": (0.98, 0.78, 0.14, 1.0),
        "shell_shade": (0.80, 0.56, 0.08, 1.0),
        "belly_cream": (1.00, 0.96, 0.78, 1.0),
        "leg_grey": (0.90, 0.74, 0.26, 1.0),
        "claw_dark": (0.44, 0.30, 0.06, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.28, 0.42, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_pinchcrab(
    name: str = "Pinchcrab_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 098. Pinchcrab (Ref: Krabby):
      - Carapaça oval larga dividida entre metade superior vermelho-coral e mandíbula/barriga creme
      - Dois dentes/espinhos cremes erguidos na borda frontal da mandíbula + dois espinhos corais no topo
      - Olhos grandes brancos arregalados com pupilas pontuais
      - Duas ENORMES pinças corais erguidas em arco com interior escuro e hastes brancas articuladas
      - Quatro patas finas articuladas de caranguejo com pontas bifurcadas tocando Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Pin_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Pin_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Pin_Norm"

    parts = []

    # 1. CARAPAÇA LARGA BICOLOR (TOPO VERMELHO-CORAL + MANDÍBULA/BARRIGA CREME)
    _add_part(
        parts,
        create_icosphere("_tmp_shell_top", 2, 0.62, (0.0, 0.04, 0.74), scale=(1.18, 0.88, 0.68)),
        mat_prefix,
        "shell_coral",
        pal,
    )
    # Metade inferior / mandíbula creme-branca
    _add_part(
        parts,
        create_icosphere("_tmp_belly_cream", 2, 0.60, (0.0, -0.02, 0.50), scale=(1.22, 0.92, 0.58)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # Almofadas inferiores arredondadas da barriga (detalhe fiel à referência!)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_belly_lobe_{tag}",
                1,
                0.24,
                (side * 0.34, -0.22, 0.32),
                scale=(1.08, 0.92, 0.64),
            ),
            mat_prefix,
            "leg_grey",
            pal,
        )
        # Dois espinhos/presas cremes subindo na borda frontal da mandíbula
        _add_part(
            parts,
            create_cone(
                f"_tmp_jaw_spike_{tag}",
                5,
                0.14,
                0.024,
                0.32,
                (side * 0.44, -0.44, 0.70),
                rotation=(math.radians(-10.0), math.radians(side * 10.0), 0.0),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )

    # 2. DOIS ESPINHOS CORAIS NO TOPO DA CABEÇA + OLHOS GRANDES ARREGALADOS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Chifre/espinho pontudo coral no topo da cabeça
        _add_part(
            parts,
            create_cone(
                f"_tmp_head_horn_{tag}",
                6,
                0.13,
                0.028,
                0.42,
                (side * 0.20, -0.10, 1.16),
                rotation=(math.radians(-6.0), math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "shell_coral",
            pal,
        )
        # Olho branco grande arregalado
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.19,
                (side * 0.28, -0.44, 0.94),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(1.04, 0.72, 0.96),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pupila pontual negra
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.036,
                (side * 0.27, -0.58, 0.95),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 3. DUAS ENORMES PINÇAS CORAIS ERGUIDAS COM HASTES ARTICULADAS BRANCAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Braço fino creme saindo da lateral do corpo até o cotovelo
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_claw_arm_h_{tag}",
                6,
                0.068,
                0.46,
                (side * 0.88, -0.06, 0.64),
                rotation=(0.0, math.radians(side * 86.0), 0.0),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )
        # Articulação do cotovelo + haste vertical subindo para a pinça
        _add_part(
            parts,
            create_icosphere(f"_tmp_claw_elbow_{tag}", 1, 0.10, (side * 1.10, -0.08, 0.64)),
            mat_prefix,
            "belly_cream",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_claw_arm_v_{tag}",
                6,
                0.072,
                0.38,
                (side * 1.12, -0.10, 0.84),
                rotation=(math.radians(-6.0), math.radians(side * -8.0), 0.0),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )
        # Colarinho branco arredondado do pulso da pinça
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_claw_wrist_{tag}",
                2,
                0.20,
                (side * 1.12, -0.12, 1.04),
                scale=(1.08, 0.88, 0.72),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )

        # ENORME PINÇA CORAL — CORPO + LÂMINA SUPERIOR CURVA + POLEGAR INFERIOR OPOSTO
        # Base robusta da pinça
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pincer_palm_{tag}",
                2,
                0.36,
                (side * 1.16, -0.14, 1.38),
                rotation=(0.0, math.radians(side * 14.0), 0.0),
                scale=(0.86, 0.82, 1.16),
            ),
            mat_prefix,
            "shell_coral",
            pal,
        )
        # Lâmina superior enorme curvando por cima para dentro (direção à cabeça!)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pincer_upper_mid_{tag}",
                2,
                0.34,
                (side * 1.04, -0.16, 1.76),
                rotation=(0.0, math.radians(side * -28.0), 0.0),
                scale=(1.04, 0.76, 0.86),
            ),
            mat_prefix,
            "shell_coral",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_pincer_upper_tip_{tag}",
                6,
                0.24,
                0.032,
                0.56,
                (side * 0.68, -0.18, 1.82),
                rotation=(0.0, math.radians(side * -96.0), 0.0),
                scale=(0.92, 0.72, 1.0),
            ),
            mat_prefix,
            "shell_coral",
            pal,
        )
        # Polegar inferior oposto apontando para cima-dentro
        _add_part(
            parts,
            create_cone(
                f"_tmp_pincer_lower_{tag}",
                6,
                0.22,
                0.042,
                0.56,
                (side * 0.82, -0.18, 1.28),
                rotation=(0.0, math.radians(side * -42.0), 0.0),
                scale=(0.88, 0.74, 1.0),
            ),
            mat_prefix,
            "shell_coral",
            pal,
        )
        # Cavidade interna escura entre as duas lâminas da pinça
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pincer_inner_{tag}",
                1,
                0.20,
                (side * 0.94, -0.14, 1.50),
                scale=(0.76, 0.66, 0.96),
            ),
            mat_prefix,
            "claw_dark",
            pal,
        )

    # 4. QUATRO PATAS FINAS ARTICULADAS DE CARANGUEJO TOCANDO Z = 0.0
    leg_configs = [
        # (pair_name, y_hip, y_knee, y_foot, x_knee, x_foot, z_knee)
        ("front", -0.10, -0.20, -0.26, 1.12, 1.44, 0.50),
        ("back", 0.24, 0.34, 0.40, 1.02, 1.32, 0.46),
    ]
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        for pname, yh, yk, yf, xk, xf, zk in leg_configs:
            # Segmento superior saindo do corpo até o joelho
            _add_part(
                parts,
                create_cylinder(
                    f"_tmp_leg_up_{pname}_{tag}",
                    6,
                    0.062,
                    0.56,
                    (side * (0.58 + (xk - 0.58) * 0.5), 0.5 * (yh + yk), 0.46),
                    rotation=(math.radians((yk - yh) * 40.0), math.radians(side * 82.0), 0.0),
                ),
                mat_prefix,
                "leg_grey",
                pal,
            )
            # Joelho
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_leg_knee_{pname}_{tag}",
                    1,
                    0.088,
                    (side * xk, yk, zk),
                ),
                mat_prefix,
                "leg_grey",
                pal,
            )
            # Canela descendo até o pé no chão
            _add_part(
                parts,
                create_cone(
                    f"_tmp_leg_low_{pname}_{tag}",
                    6,
                    0.052,
                    0.072,
                    0.56,
                    (side * (0.5 * (xk + xf)), 0.5 * (yk + yf), 0.24),
                    rotation=(math.radians((yf - yk) * 20.0), math.radians(side * -34.0), 0.0),
                ),
                mat_prefix,
                "leg_grey",
                pal,
            )
            # Garra bifurcada da pata apoiada em Z = 0.0
            _add_part(
                parts,
                create_cone(
                    f"_tmp_leg_tipA_{pname}_{tag}",
                    5,
                    0.058,
                    0.016,
                    0.20,
                    (side * (xf + 0.08), yf - 0.04, 0.06),
                    rotation=(0.0, math.radians(side * 108.0), 0.0),
                ),
                mat_prefix,
                "leg_grey",
                pal,
            )
            _add_part(
                parts,
                create_cone(
                    f"_tmp_leg_tipB_{pname}_{tag}",
                    5,
                    0.052,
                    0.015,
                    0.18,
                    (side * (xf + 0.05), yf + 0.06, 0.06),
                    rotation=(0.0, math.radians(side * 116.0), math.radians(side * 18.0)),
                ),
                mat_prefix,
                "claw_dark",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 098. Pinchcrab lado a lado."""
    specs = [
        ("Pinchcrab_Shiny", (-13.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Pinchcrab_Normal", (-8.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Pinchcrab_Grande", (-2.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Pinchcrab_Gigante", (4.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Pinchcrab_Dourada_SuperRara", (13.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_pinchcrab(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
