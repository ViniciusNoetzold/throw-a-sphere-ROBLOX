"""
024_Cobracrest_Arbok_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "024. Cobracrest — Nája Intimidadora (Ref: Arbok)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Cobracrest_Shiny (1.0x - Paleta Shiny / Shyne Bronze-Oliva + Capuz Rubi/Preto)
  2. Cobracrest_Normal (1.0x - Corpo Roxo-Ametista + Capuz Largo com Marcas Pretas/Rubi/Creme)
  3. Cobracrest_Grande (1.35x - Normal)
  4. Cobracrest_Gigante (1.85x - Normal)
  5. Cobracrest_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Marcas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.018`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Espiral base apoiada exatamente em `Z = 0.0` e frente/capuz apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Cobracrest_Shiny`, `Cobracrest_Normal`, `Cobracrest_Grande`,
     `Cobracrest_Gigante`, `Cobracrest_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.018,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_purple": (0.58, 0.36, 0.68, 1.0),
        "hood_black": (0.14, 0.12, 0.16, 1.0),
        "hood_red": (0.90, 0.22, 0.28, 1.0),
        "hood_cream": (0.96, 0.90, 0.66, 1.0),
        "tongue_pink": (0.92, 0.54, 0.64, 1.0),
        "fang_white": (0.98, 0.98, 0.99, 1.0),
    },
    "shiny_palette": {
        "body_purple": (0.78, 0.72, 0.24, 1.0),
        "hood_black": (0.14, 0.12, 0.16, 1.0),
        "hood_red": (0.76, 0.24, 0.58, 1.0),
        "hood_cream": (0.98, 0.94, 0.68, 1.0),
        "tongue_pink": (0.92, 0.54, 0.64, 1.0),
        "fang_white": (0.99, 0.99, 0.96, 1.0),
    },
    "golden_super_rare_palette": {
        "body_purple": (0.98, 0.78, 0.14, 1.0),
        "hood_black": (0.16, 0.12, 0.08, 1.0),
        "hood_red": (0.10, 0.92, 1.00, 1.0),
        "hood_cream": (1.00, 0.95, 0.58, 1.0),
        "tongue_pink": (0.94, 0.68, 0.18, 1.0),
        "fang_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base da espiral em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_cobracrest(
    name: str = "Cobracrest_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 024. Cobracrest (Ref: Arbok):
      - Frente/capuz apontando para -Y e base enrolada tocando Z = 0.0
      - Grande serpente roxa-ametista erguida com cauda sinuosa saindo para o lado
      - Capuz largo achatado com marcas faciais intimidadoras em preto, vermelho-rubi e creme
      - Cabeça de nája no topo com boca aberta, presas brancas e língua bífida rosada
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Cobra_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Cobra_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Cobra_Norm"

    parts = []

    # 1. BASE ENROLADA + CAUDA SINUOSA APOIADAS EM Z = 0.0
    for idx in range(7):
        ang = math.radians(idx * 45.0 - 90.0)
        r_ring = 0.62
        x = r_ring * math.cos(ang)
        y = r_ring * math.sin(ang) + 0.16
        _add_part(
            parts,
            create_cube(
                f"_tmp_coil_base_{idx}",
                (0.56, 0.40, 0.36),
                (x, y, 0.18),
                rotation=(0.0, 0.0, ang + math.pi * 0.5),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )

    # Cauda estendida para a esquerda/trás afinando em ponta curva
    tail_segs = [
        (0.19, 0.16, 0.50, (-0.86, 0.34, 0.22), (0.0, 76.0, 14.0)),
        (0.16, 0.12, 0.46, (-1.26, 0.40, 0.34), (0.0, 56.0, 12.0)),
        (0.12, 0.075, 0.42, (-1.48, 0.42, 0.64), (0.0, 16.0, 8.0)),
        (0.075, 0.025, 0.34, (-1.46, 0.38, 0.94), (0.0, -24.0, 4.0)),
    ]
    for t_idx, (r1, r2, depth, loc, rot) in enumerate(tail_segs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_seg_{t_idx}",
                6,
                r1,
                r2,
                depth,
                loc,
                rotation=tuple(math.radians(a) for a in rot),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )

    # 2. TRONCO ERGUIDO + CAPUZ LARGO DE NÁJA COM MARCAS FACIAIS INTIMIDADORAS
    _add_part(
        parts,
        create_cylinder(
            "_tmp_trunk_lower",
            6,
            0.34,
            0.72,
            (0.0, -0.14, 0.58),
            rotation=(math.radians(-10.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_purple",
        pal,
    )
    # Faixa preta sutil na cintura/barriga
    _add_part(
        parts,
        create_cube("_tmp_belly_line", (0.46, 0.08, 0.05), (0.0, -0.44, 0.78)),
        mat_prefix,
        "hood_black",
        pal,
    )

    # Capuz largo achatado (estrutura central + abas laterais inclinadas)
    _add_part(
        parts,
        create_cube("_tmp_hood_center", (1.28, 0.38, 1.32), (0.0, -0.02, 1.54), rotation=(math.radians(8.0), 0.0, 0.0)),
        mat_prefix,
        "body_purple",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_hood_wing_{tag}",
                (0.56, 0.28, 1.12),
                (side * 0.76, 0.04, 1.58),
                rotation=(math.radians(8.0), math.radians(side * -14.0), math.radians(side * -18.0)),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_hood_top_{tag}",
                4,
                0.42,
                0.18,
                0.44,
                (side * 0.48, 0.06, 2.24),
                rotation=(math.radians(10.0), math.radians(side * 22.0), math.radians(45.0)),
                scale=(1.1, 0.58, 1.0),
            ),
            mat_prefix,
            "body_purple",
            pal,
        )

    # Marcas faciais ferozes no capuz (olhos falsos preto+vermelho+creme + sorriso negro + V frontal)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_mark_ring_{tag}",
                (0.46, 0.08, 0.36),
                (side * 0.38, -0.22, 1.64),
                rotation=(math.radians(8.0), 0.0, math.radians(side * 16.0)),
            ),
            mat_prefix,
            "hood_black",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_mark_red_{tag}",
                (0.36, 0.08, 0.26),
                (side * 0.38, -0.25, 1.64),
                rotation=(math.radians(8.0), 0.0, math.radians(side * 16.0)),
            ),
            mat_prefix,
            "hood_red",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_mark_cream_{tag}",
                (0.18, 0.08, 0.14),
                (side * 0.40, -0.28, 1.64),
                rotation=(math.radians(8.0), 0.0, math.radians(side * 16.0)),
            ),
            mat_prefix,
            "hood_cream",
            pal,
        )

    # Sorriso dentado negro abaixo dos olhos falsos + marca em V acima
    _add_part(
        parts,
        create_cube("_tmp_mark_grin_mid", (0.76, 0.08, 0.20), (0.0, -0.26, 1.24), rotation=(math.radians(8.0), 0.0, 0.0)),
        mat_prefix,
        "hood_black",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_mark_grin_side_{tag}",
                (0.32, 0.08, 0.14),
                (side * 0.48, -0.25, 1.32),
                rotation=(math.radians(8.0), 0.0, math.radians(side * 28.0)),
            ),
            mat_prefix,
            "hood_black",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_mark_v_{tag}",
                (0.28, 0.08, 0.09),
                (side * 0.14, -0.21, 1.94),
                rotation=(math.radians(8.0), 0.0, math.radians(side * 34.0)),
            ),
            mat_prefix,
            "hood_black",
            pal,
        )

    # 3. CABEÇA DE NÁJA NO TOPO, PRESAS BRANCAS E LÍNGUA BÍFIDA ROSA
    _add_part(
        parts,
        create_cube("_tmp_head_upper", (0.64, 0.86, 0.38), (0.0, -0.44, 2.26), rotation=(math.radians(10.0), 0.0, 0.0)),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_snout_cobra",
            4,
            0.28,
            0.14,
            0.30,
            (0.0, -0.94, 2.20),
            rotation=(math.radians(96.0), 0.0, math.radians(45.0)),
            scale=(1.15, 0.68, 1.0),
        ),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_jaw_lower", (0.48, 0.58, 0.16), (0.0, -0.56, 1.88), rotation=(math.radians(22.0), 0.0, 0.0)),
        mat_prefix,
        "body_purple",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_mouth_inner", (0.38, 0.36, 0.24), (0.0, -0.58, 2.02)),
        mat_prefix,
        "tongue_pink",
        pal,
    )

    # Língua bífida saindo para fora
    _add_part(
        parts,
        create_cube("_tmp_tongue_stem", (0.10, 0.42, 0.05), (0.0, -0.96, 1.92), rotation=(math.radians(24.0), 0.0, 0.0)),
        mat_prefix,
        "tongue_pink",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_tongue_fork_{tag}",
                4,
                0.04,
                0.008,
                0.18,
                (side * 0.07, -1.20, 1.80),
                rotation=(math.radians(114.0), 0.0, math.radians(side * 22.0)),
            ),
            mat_prefix,
            "tongue_pink",
            pal,
        )
        # Presas venenosas brancas
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.048,
                0.01,
                0.18,
                (side * 0.16, -0.82, 2.06),
                rotation=(math.radians(180.0), 0.0, 0.0),
            ),
            mat_prefix,
            "fang_white",
            pal,
        )
        # Olhos ferozes da nája
        _add_part(
            parts,
            create_cube(f"_tmp_eye_white_{tag}", (0.12, 0.24, 0.15), (side * 0.30, -0.56, 2.30)),
            mat_prefix,
            "fang_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_pupil_{tag}", (0.13, 0.10, 0.13), (side * 0.32, -0.60, 2.30)),
            mat_prefix,
            "hood_black",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 024. Cobracrest lado a lado."""
    specs = [
        ("Cobracrest_Shiny", (-7.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Cobracrest_Normal", (-4.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Cobracrest_Grande", (-0.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Cobracrest_Gigante", (4.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Cobracrest_Dourada_SuperRara", (10.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_cobracrest(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
