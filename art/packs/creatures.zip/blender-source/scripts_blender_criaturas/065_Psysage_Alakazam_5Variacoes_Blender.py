"""
065_Psysage_Alakazam_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "065. Psysage — Sábio Mental (Ref: Alakazam)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Psysage_Shiny (1.0x - Paleta Shiny Amarelo-Limão + Armadura Magenta-Violeta)
  2. Psysage_Normal (1.0x - Amarelo-Ouro + Armadura Marrom + Bigode Gigante + 2 Colheres de Prata)
  3. Psysage_Grande (1.35x - Normal)
  4. Psysage_Gigante (1.85x - Normal)
  5. Psysage_Dourada_SuperRara (2.25x - Ouro Reluzente + Armadura, Colheres e Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2, cones/cilindros 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés alinhados exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_yellow": (0.95, 0.83, 0.26, 1.0),
        "mustache_tip": (0.98, 0.93, 0.62, 1.0),
        "armor_brown": (0.46, 0.39, 0.44, 1.0),
        "spoon_silver": (0.85, 0.88, 0.93, 1.0),
        "claw_white": (0.98, 0.98, 0.99, 1.0),
        "eye_dark": (0.12, 0.12, 0.15, 1.0),
    },
    "shiny_palette": {
        "body_yellow": (0.98, 0.90, 0.36, 1.0),
        "mustache_tip": (1.00, 0.96, 0.72, 1.0),
        "armor_brown": (0.82, 0.34, 0.68, 1.0),
        "spoon_silver": (0.88, 0.92, 0.97, 1.0),
        "claw_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.14, 0.12, 0.16, 1.0),
    },
    "golden_super_rare_palette": {
        "body_yellow": (0.98, 0.78, 0.14, 1.0),
        "mustache_tip": (1.00, 0.94, 0.56, 1.0),
        "armor_brown": (0.10, 0.92, 1.00, 1.0),
        "spoon_silver": (0.10, 0.92, 1.00, 1.0),
        "claw_white": (1.00, 0.98, 0.90, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_segment(
    name: str,
    p1: tuple,
    p2: tuple,
    r1: float,
    r2: float,
    vertices: int = 8,
    extend: float = 1.05,
):
    """Cria um cone/segmento conectando exatamente p1 -> p2 sem folgas."""
    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    dz = p2[2] - p1[2]
    dist = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dist < 1e-6:
        dist = 1e-6
    mid = ((p1[0] + p2[0]) * 0.5, (p1[1] + p2[1]) * 0.5, (p1[2] + p2[2]) * 0.5)
    theta = math.acos(max(-1.0, min(1.0, dz / dist)))
    phi = math.atan2(dy, dx)
    return create_cone(
        name=name,
        vertices=vertices,
        radius1=r1,
        radius2=r2,
        depth=dist * extend,
        location=mid,
        rotation=(0.0, theta, phi),
    )


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha os pés em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_psysage(
    name: str = "Psysage_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 065. Psysage (Ref: Alakazam):
      - Silhueta esguia de sábio psíquico sem cauda, com couraça peitoral, ombreiras,
        braceletes e joelheiras blindadas em marrom-taupe (magenta na Shiny)
      - Cabeça icônica em estrela de 5 pontas: 2 chifres/orelhas muito longos para cima
        + 2 pontas laterais nas bochechas + focinho estreito afilado
      - Bigodes gigantescos em asas abrindo-se largamente para os dois lados com pontas franjadas creme
      - Ambas as mãos segurando 2 colheres prateadas apontando para a frente/centro
      - Pernas dinâmicas com pés grandes de 3 garras brancas firmes em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Psysage_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Psysage_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Psysage_Norm"

    parts = []

    # 1. TRONCO ESBELTO: PELVE AMARELA + PEITORAL E OMBREIRAS MARRONS
    _add_part(
        parts,
        create_icosphere("_tmp_pelvis", 2, 0.30, (0.0, 0.00, 0.86), scale=(0.94, 0.86, 1.06)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_chest_armor", 2, 0.40, (0.0, -0.02, 1.36), scale=(1.12, 0.86, 1.00)),
        mat_prefix,
        "armor_brown",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pauldron_{tag}",
                2,
                0.28,
                (side * 0.48, -0.02, 1.54),
                rotation=(0.0, math.radians(side * 20.0), 0.0),
                scale=(1.14, 0.90, 0.86),
            ),
            mat_prefix,
            "armor_brown",
            pal,
        )

    # 2. CABEÇA EM ESTRELA DE 5 PONTAS + BIGODES GIGANTES FLUTUANTES
    _add_part(
        parts,
        create_icosphere("_tmp_head_cranium", 2, 0.36, (0.0, -0.10, 1.92), scale=(1.04, 0.96, 1.02)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Focinho longo estreito apontando para frente-baixo (-Y)
    _add_part(
        parts,
        create_segment(
            "_tmp_snout",
            (0.0, -0.18, 1.88),
            (0.0, -0.68, 1.50),
            r1=0.25,
            r2=0.065,
            vertices=8,
            extend=1.04,
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # 2 chifres/orelhas superiores muito longos + 2 espinhos laterais das bochechas
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_segment(
                f"_tmp_horn_top_{tag}",
                (side * 0.22, -0.06, 2.12),
                (side * 0.68, -0.02, 2.74),
                0.17,
                0.022,
                vertices=6,
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_segment(
                f"_tmp_cheek_spike_{tag}",
                (side * 0.24, -0.14, 1.86),
                (side * 0.56, -0.14, 1.76),
                0.14,
                0.024,
                vertices=5,
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )

    # Olhos estreitos focados (branco + pupila escura)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                1,
                0.092,
                (side * 0.16, -0.45, 1.84),
                rotation=(0.0, math.radians(side * -14.0), math.radians(side * -22.0)),
                scale=(1.15, 0.52, 0.58),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.042,
                (side * 0.15, -0.49, 1.84),
                scale=(0.68, 0.52, 1.05),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # BIGODES GIGANTES EM FAIXA ABRINDO PARA OS LADOS COM PONTAS FRANJADAS CREME
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        m_pts = [
            (side * 0.06, -0.58, 1.56, 0.045),
            (side * 0.36, -0.54, 1.58, 0.068),
            (side * 0.72, -0.34, 1.76, 0.095),
            (side * 1.08, -0.18, 1.94, 0.135),
        ]
        for i in range(len(m_pts) - 1):
            _add_part(
                parts,
                create_segment(
                    f"_tmp_mustache_{tag}_{i}",
                    m_pts[i][:3],
                    m_pts[i + 1][:3],
                    m_pts[i][3],
                    m_pts[i + 1][3],
                    vertices=6,
                    extend=1.08,
                ),
                mat_prefix,
                "body_yellow",
                pal,
            )
        # Leque franjado creme nas pontas externas do bigode (3 pontas dramáticas)
        fan_base = m_pts[-1][:3]
        fan_tips = [
            (side * 1.44, -0.10, 2.22),
            (side * 1.54, -0.10, 2.02),
            (side * 1.38, -0.12, 1.82),
        ]
        for f_idx, f_tip in enumerate(fan_tips):
            _add_part(
                parts,
                create_segment(
                    f"_tmp_mustache_tip_{tag}_{f_idx}",
                    fan_base,
                    f_tip,
                    0.105,
                    0.016,
                    vertices=5,
                ),
                mat_prefix,
                "mustache_tip",
                pal,
            )

    # 3. DOIS BRAÇOS COM BRACELETES MARRONS E DUAS COLHERES DE PRATA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        p_sh = (side * 0.56, -0.02, 1.48)
        p_el = (side * 0.88, -0.14, 1.36)
        p_wr = (side * 1.12, -0.42, 1.24)
        # Braço superior esbelto amarelo
        _add_part(parts, create_segment(f"_tmp_arm_up_{tag}", p_sh, p_el, 0.082, 0.072, vertices=6), mat_prefix, "body_yellow", pal)
        # Bracelete blindado marrom no antebraço
        _add_part(parts, create_segment(f"_tmp_bracer_{tag}", p_el, p_wr, 0.14, 0.13, vertices=7), mat_prefix, "armor_brown", pal)
        # Mão amarela segurando a colher
        hand_c = (p_wr[0] + side * 0.08, p_wr[1] - 0.12, p_wr[2] - 0.04)
        _add_part(parts, create_icosphere(f"_tmp_hand_{tag}", 2, 0.14, hand_c), mat_prefix, "body_yellow", pal)
        # 3 dedos curvados sobre a colher
        for f_idx, fx in enumerate((-0.07, 0.0, 0.07)):
            _add_part(
                parts,
                create_segment(
                    f"_tmp_finger_{tag}_{f_idx}",
                    (hand_c[0] + fx, hand_c[1] - 0.06, hand_c[2] + 0.04),
                    (hand_c[0] + fx, hand_c[1] - 0.14, hand_c[2] - 0.12),
                    0.042,
                    0.028,
                    vertices=5,
                ),
                mat_prefix,
                "body_yellow",
                pal,
            )
        # COLHER PRATEADA NA MÃO (apontando para o centro/frente como na referência!)
        spoon_outer = (hand_c[0] + side * 0.36, hand_c[1] - 0.14, hand_c[2] - 0.02)
        spoon_inner = (hand_c[0] - side * 0.36, hand_c[1] - 0.22, hand_c[2] - 0.08)
        _add_part(
            parts,
            create_segment(f"_tmp_spoon_stem_{tag}", spoon_outer, spoon_inner, 0.036, 0.030, vertices=6),
            mat_prefix,
            "spoon_silver",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_spoon_pommel_{tag}", 1, 0.055, spoon_outer, scale=(1.1, 0.75, 0.75)),
            mat_prefix,
            "spoon_silver",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_spoon_bowl_{tag}",
                2,
                0.18,
                (spoon_inner[0] - side * 0.14, spoon_inner[1] - 0.04, spoon_inner[2]),
                scale=(1.38, 0.90, 0.52),
            ),
            mat_prefix,
            "spoon_silver",
            pal,
        )

    # 4. PERNAS COM JOELHEIRAS MARRONS E PÉS DE 3 GARRAS BRANCAS FIRMES EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        p_hip = (side * 0.24, 0.00, 0.78)
        p_knee = (side * 0.64, -0.24, 0.64)
        p_ankle = (side * 0.68, -0.14, 0.16)
        _add_part(parts, create_segment(f"_tmp_thigh_{tag}", p_hip, p_knee, 0.105, 0.095, vertices=6), mat_prefix, "body_yellow", pal)
        # Joelheira blindada marrom-taupe
        _add_part(
            parts,
            create_icosphere(f"_tmp_kneepad_{tag}", 2, 0.17, p_knee, scale=(1.02, 1.12, 1.08)),
            mat_prefix,
            "armor_brown",
            pal,
        )
        # Canela grossa amarela
        _add_part(parts, create_segment(f"_tmp_shin_{tag}", p_knee, p_ankle, 0.145, 0.135, vertices=7), mat_prefix, "body_yellow", pal)
        _add_part(
            parts,
            create_icosphere(f"_tmp_foot_{tag}", 2, 0.18, (p_ankle[0], p_ankle[1] - 0.10, 0.12), scale=(1.16, 1.30, 0.64)),
            mat_prefix,
            "body_yellow",
            pal,
        )
        foot_c = (p_ankle[0], p_ankle[1] - 0.12, 0.10)
        toes = [
            (foot_c[0] + side * 0.20, foot_c[1] - 0.26, 0.06),
            (foot_c[0] - side * 0.08, foot_c[1] - 0.30, 0.06),
            (foot_c[0] - side * 0.10, foot_c[1] + 0.24, 0.06),
        ]
        for t_idx, t_mid in enumerate(toes):
            dx = t_mid[0] - foot_c[0]
            dy = t_mid[1] - foot_c[1]
            t_tip = (t_mid[0] + dx * 0.42, t_mid[1] + dy * 0.42, 0.03)
            _add_part(parts, create_segment(f"_tmp_toe_{tag}_{t_idx}", foot_c, t_mid, 0.068, 0.048, vertices=5), mat_prefix, "body_yellow", pal)
            _add_part(parts, create_segment(f"_tmp_tclaw_{tag}_{t_idx}", t_mid, t_tip, 0.044, 0.010, vertices=4), mat_prefix, "claw_white", pal)

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 065. Psysage lado a lado."""
    specs = [
        ("Psysage_Shiny", (-13.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Psysage_Normal", (-7.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Psysage_Grande", (-1.0, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Psysage_Gigante", (6.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Psysage_Dourada_SuperRara", (16.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_psysage(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
