"""
137_Polyvoxel_Porygon_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "137. Polyvoxel — Pássaro Poligonal (Ref: Porygon)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta geométrica original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Polyvoxel_Shiny (1.0x - Paleta Shiny Azul-Violeta + Peito/Bico/Patas/Cauda Rosa-Neon)
  2. Polyvoxel_Normal (1.0x - Corpo Rosa-Poligonal + Peito, Bico, Patas e Cauda Ciano-Azul)
  3. Polyvoxel_Grande (1.35x - Normal)
  4. Polyvoxel_Gigante (1.85x - Normal)
  5. Polyvoxel_Dourada_SuperRara (2.25x - Ouro Reluzente + Peito, Bico, Olhos e Cauda Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria 100% poligonal facetada (prismas, cones de 4-6 lados e blocos chanfrados fiéis ao Porygon)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas prismáticas alinhadas exatamente em `Z = 0.0` e bico apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_pink": (0.94, 0.44, 0.54, 1.0),
        "body_pink_light": (0.98, 0.68, 0.74, 1.0),
        "body_pink_shade": (0.78, 0.34, 0.42, 1.0),
        "cyan_blue": (0.34, 0.78, 0.88, 1.0),
        "cyan_light": (0.64, 0.90, 0.96, 1.0),
        "cyan_shade": (0.22, 0.60, 0.74, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "eye_dark": (0.08, 0.08, 0.12, 1.0),
    },
    "shiny_palette": {
        "body_pink": (0.46, 0.54, 0.94, 1.0),
        "body_pink_light": (0.66, 0.72, 0.98, 1.0),
        "body_pink_shade": (0.34, 0.40, 0.76, 1.0),
        "cyan_blue": (0.96, 0.42, 0.68, 1.0),
        "cyan_light": (0.99, 0.66, 0.82, 1.0),
        "cyan_shade": (0.78, 0.28, 0.52, 1.0),
        "eye_white": (0.98, 0.98, 0.99, 1.0),
        "eye_dark": (0.08, 0.08, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "body_pink": (0.98, 0.78, 0.14, 1.0),
        "body_pink_light": (1.00, 0.90, 0.40, 1.0),
        "body_pink_shade": (0.82, 0.60, 0.08, 1.0),
        "cyan_blue": (0.10, 0.92, 1.00, 1.0),
        "cyan_light": (0.46, 0.96, 1.00, 1.0),
        "cyan_shade": (0.06, 0.64, 0.80, 1.0),
        "eye_white": (1.00, 0.99, 0.94, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une primitivas, normaliza a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_polyvoxel(
    name: str = "Polyvoxel_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 137. Polyvoxel (Ref: Porygon):
      - Silhueta 100% origami/poligonal com facetas planas super nítidas
      - Corpo rosa-poligonal com peito saliente prismático ciano em quilha
      - Cabeça angular facetada afunilando para frente em um bico prismático ciano
      - Olhos hexagonais brancos grandes nas laterais da cabeça com pupila preta nítida
      - Duas patas prismáticas ciano inclinadas lateralmente apoiadas em Z = 0.0
      - Cauda estreita em prisma ciano erguida verticalmente atrás
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Poly_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Poly_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Poly_Norm"

    parts = []

    # 1. CORPO CENTRAL POLIGONAL ROSA + PEITO PRISMÁTICO CIANO EM QUILHA
    # Dorso angular rosa (prisma de 6 lados achatado)
    _add_part(
        parts,
        create_cone(
            "_tmp_body_back",
            6,
            0.52,
            0.34,
            0.96,
            (0.0, 0.14, 0.66),
            rotation=(math.radians(82.0), 0.0, 0.0),
            scale=(1.04, 0.84, 1.0),
        ),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Bloco traseiro angular rosa fechando a garupa
    _add_part(
        parts,
        create_cone(
            "_tmp_body_rear",
            4,
            0.46,
            0.22,
            0.44,
            (0.0, 0.54, 0.60),
            rotation=(math.radians(96.0), 0.0, math.radians(45.0)),
            scale=(1.06, 0.86, 1.0),
        ),
        mat_prefix,
        "body_pink_shade",
        pal,
    )
    # Grande peito saliente prismático CIANO em forma de quilha/diamante
    _add_part(
        parts,
        create_cone(
            "_tmp_chest_prism_front",
            4,
            0.50,
            0.12,
            0.72,
            (0.0, -0.34, 0.56),
            rotation=(math.radians(-68.0), 0.0, math.radians(45.0)),
            scale=(1.04, 0.96, 1.0),
        ),
        mat_prefix,
        "cyan_blue",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_chest_keel_bot",
            4,
            0.48,
            0.14,
            0.62,
            (0.0, -0.14, 0.36),
            rotation=(math.radians(150.0), 0.0, math.radians(45.0)),
            scale=(1.04, 1.06, 1.0),
        ),
        mat_prefix,
        "cyan_light",
        pal,
    )

    # 2. PESCOÇO PRISMÁTICO E CABEÇA POLIGONAL DE PATO VIRTUAL
    _add_part(
        parts,
        create_cone(
            "_tmp_neck",
            6,
            0.28,
            0.24,
            0.38,
            (0.0, -0.22, 1.02),
            rotation=(math.radians(-16.0), 0.0, 0.0),
            scale=(1.0, 0.96, 1.0),
        ),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Crânio principal poligonal (prisma hexagonal alongado para frente)
    _add_part(
        parts,
        create_cone(
            "_tmp_head_main",
            6,
            0.46,
            0.30,
            0.82,
            (0.0, -0.44, 1.38),
            rotation=(math.radians(-64.0), 0.0, 0.0),
            scale=(0.92, 0.96, 1.0),
        ),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Faceta clara do topo da testa (como na referência)
    _add_part(
        parts,
        create_cube(
            "_tmp_head_crown_plate",
            (0.42, 0.62, 0.16),
            (0.0, -0.52, 1.60),
            rotation=(math.radians(24.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_pink_light",
        pal,
    )
    # Traseira angular da cabeça (occipital plano inclinado)
    _add_part(
        parts,
        create_cone(
            "_tmp_head_occiput",
            4,
            0.42,
            0.18,
            0.36,
            (0.0, -0.02, 1.48),
            rotation=(math.radians(74.0), 0.0, math.radians(45.0)),
            scale=(0.94, 0.88, 1.0),
        ),
        mat_prefix,
        "body_pink_shade",
        pal,
    )

    # Bico prismático longo CIANO apontando para -Y
    _add_part(
        parts,
        create_cone(
            "_tmp_beak_cyan",
            4,
            0.31,
            0.13,
            0.48,
            (0.0, -0.98, 1.18),
            rotation=(math.radians(-70.0), 0.0, math.radians(45.0)),
            scale=(0.96, 0.88, 1.0),
        ),
        mat_prefix,
        "cyan_light",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_beak_tip",
            (0.24, 0.14, 0.18),
            (0.0, -1.16, 1.10),
            rotation=(math.radians(22.0), 0.0, 0.0),
        ),
        mat_prefix,
        "cyan_blue",
        pal,
    )

    # 3. OLHOS HEXAGONAIS BRANCOS GRANDES COM PUPILAS PRETAS NÍTIDAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_eye_hex_{tag}",
                6,
                0.19,
                0.08,
                (side * 0.34, -0.48, 1.40),
                rotation=(math.radians(12.0), math.radians(side * 78.0), math.radians(side * 16.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_pupil_{tag}",
                6,
                0.068,
                0.06,
                (side * 0.37, -0.52, 1.40),
                rotation=(math.radians(12.0), math.radians(side * 78.0), math.radians(side * 16.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # 4. DUAS PATAS PRISMÁTICAS CIANO LATERAIS APOIADAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_leg_block_{tag}",
                (0.32, 0.72, 0.44),
                (side * 0.56, -0.04, 0.32),
                rotation=(math.radians(-14.0), math.radians(side * -6.0), math.radians(side * 6.0)),
            ),
            mat_prefix,
            "cyan_blue",
            pal,
        )
        # Sola frontal angulada para assentar perfeitamente em Z = 0.0
        _add_part(
            parts,
            create_cube(
                f"_tmp_leg_sole_{tag}",
                (0.32, 0.58, 0.16),
                (side * 0.56, -0.14, 0.08),
                rotation=(0.0, 0.0, math.radians(side * 6.0)),
            ),
            mat_prefix,
            "cyan_shade",
            pal,
        )

    # 5. CAUDA ESTREITA EM PRISMA CIANO ERGUIDA VERTICALMENTE ATRÁS
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_prism",
            4,
            0.22,
            0.05,
            1.14,
            (0.0, 0.64, 1.32),
            rotation=(math.radians(14.0), 0.0, math.radians(45.0)),
            scale=(0.56, 1.10, 1.0),
        ),
        mat_prefix,
        "cyan_light",
        pal,
    )
    _add_part(
        parts,
        create_cube(
            "_tmp_tail_base",
            (0.18, 0.24, 0.28),
            (0.0, 0.54, 0.78),
            rotation=(math.radians(14.0), 0.0, 0.0),
        ),
        mat_prefix,
        "cyan_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 137. Polyvoxel lado a lado."""
    specs = [
        ("Polyvoxel_Shiny", (-8.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Polyvoxel_Normal", (-4.9, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Polyvoxel_Grande", (-0.7, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Polyvoxel_Gigante", (4.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Polyvoxel_Dourada_SuperRara", (11.5, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_polyvoxel(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
