"""
055_Aquakappa_Golduck_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "055. Aquakappa — Pato Psíquico (Ref: Golduck)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Aquakappa_Shiny (1.0x - Paleta Shiny Azul-Marinho Profundo + Bico e Membranas Rosa-Coral)
  2. Aquakappa_Normal (1.0x - Azul-Cobalto Esbelto + 4 Cristas Pontudas + Joia Rubi + Membranas Creme)
  3. Aquakappa_Grande (1.35x - Normal)
  4. Aquakappa_Gigante (1.85x - Normal)
  5. Aquakappa_Dourada_SuperRara (2.25x - Ouro Reluzente + Joia, Olhos e Membranas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + cones 6-8 lados para cristas, bico e cauda)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés palmados alinhados exatamente em `Z = 0.0` e rosto/bico apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_blue": (0.28, 0.56, 0.82, 1.0),
        "body_dark": (0.20, 0.44, 0.70, 1.0),
        "beak_cream": (0.96, 0.91, 0.70, 1.0),
        "web_cream": (0.95, 0.89, 0.66, 1.0),
        "gem_red": (0.94, 0.22, 0.20, 1.0),
        "mouth_deep": (0.58, 0.26, 0.34, 1.0),
        "tongue_pink": (0.86, 0.50, 0.58, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "iris_red": (0.88, 0.22, 0.18, 1.0),
        "pupil_dark": (0.10, 0.10, 0.14, 1.0),
        "claw_white": (0.98, 0.98, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_blue": (0.15, 0.36, 0.78, 1.0),
        "body_dark": (0.10, 0.26, 0.62, 1.0),
        "beak_cream": (0.96, 0.46, 0.58, 1.0),
        "web_cream": (0.94, 0.44, 0.56, 1.0),
        "gem_red": (0.98, 0.20, 0.26, 1.0),
        "mouth_deep": (0.52, 0.18, 0.30, 1.0),
        "tongue_pink": (0.92, 0.48, 0.62, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "iris_red": (0.92, 0.24, 0.26, 1.0),
        "pupil_dark": (0.10, 0.10, 0.14, 1.0),
        "claw_white": (0.98, 0.98, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_blue": (0.98, 0.78, 0.14, 1.0),
        "body_dark": (0.86, 0.62, 0.09, 1.0),
        "beak_cream": (1.00, 0.94, 0.62, 1.0),
        "web_cream": (0.10, 0.92, 1.00, 1.0),
        "gem_red": (0.10, 0.92, 1.00, 1.0),
        "mouth_deep": (0.72, 0.44, 0.08, 1.0),
        "tongue_pink": (0.96, 0.80, 0.34, 1.0),
        "eye_white": (1.00, 0.98, 0.90, 1.0),
        "iris_red": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.06, 0.58, 0.72, 1.0),
        "claw_white": (1.00, 0.99, 0.94, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_aquakappa(
    name: str = "Aquakappa_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 055. Aquakappa (Ref: Golduck):
      - Tronco atlético esbelto azul-cobalto inclinado em pose de combate aquático
      - Cabeça afilada com 4 cristas pontudas em leque para cima/trás
      - Joia rubi redonda brilhante na testa + olhos estreitos ferozes com íris vermelha
      - Bico longo afilado creme aberto exibindo boca e língua
      - Braços musculosos estendidos com mãos palmadas (membranas creme + 3 garras brancas)
      - Pernas musculosas com grandes pés palmados e garras brancas + cauda longa curva
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Aqua_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Aqua_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Aqua_Norm"

    parts = []

    # 1. TORSO ATLÉTICO ESBELTO (QUADRIL + PEITO + PESCOÇO)
    _add_part(
        parts,
        create_icosphere("_tmp_pelvis", 2, 0.56, (0.0, 0.14, 0.94), scale=(1.04, 1.06, 0.98)),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_torso",
            8,
            0.52,
            0.40,
            0.86,
            (0.0, 0.02, 1.44),
            rotation=(math.radians(16.0), 0.0, 0.0),
            scale=(1.02, 0.88, 1.0),
        ),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_chest", 2, 0.44, (0.0, -0.06, 1.66), scale=(1.08, 0.86, 0.88)),
        mat_prefix,
        "body_blue",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_neck",
            8,
            0.27,
            0.23,
            0.34,
            (0.0, -0.14, 1.98),
            rotation=(math.radians(18.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_blue",
        pal,
    )

    # 2. CABEÇA AFILADA + 4 CRISTAS PONTUDAS EM LEQUE + JOIA RUBI NA TESTA
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.44, (0.0, -0.22, 2.26), scale=(0.94, 1.04, 0.96)),
        mat_prefix,
        "body_blue",
        pal,
    )
    # 4 cristas pontudas (assinatura visual do Golduck!)
    crest_specs = [
        # (x, y, z, r1, depth, rx_deg, ry_deg)
        (-0.24, 0.02, 2.74, 0.15, 0.64, -22.0, -24.0),
        (-0.04, 0.06, 2.86, 0.16, 0.72, -26.0, -4.0),
        (0.18, 0.04, 2.82, 0.16, 0.70, -28.0, 22.0),
        (0.32, 0.10, 2.58, 0.15, 0.64, -36.0, 50.0),
    ]
    for c_idx, (cx, cy, cz, r1, dep, rx, ry) in enumerate(crest_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_crest_{c_idx}",
                5,
                r1,
                0.015,
                dep,
                (cx, cy, cz),
                rotation=(math.radians(rx), math.radians(ry), 0.0),
                scale=(0.82, 1.0, 1.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    # Joia Rubi redonda na testa com brilho branco
    _add_part(
        parts,
        create_icosphere("_tmp_gem", 2, 0.095, (0.0, -0.64, 2.40), scale=(0.92, 0.56, 1.06)),
        mat_prefix,
        "gem_red",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_gem_shine", 1, 0.032, (-0.025, -0.69, 2.44)),
        mat_prefix,
        "claw_white",
        pal,
    )

    # 3. OLHOS FEROZES INCLINADOS + BICO LONGO ABERTO COM LÍNGUA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.13,
                (side * 0.21, -0.58, 2.28),
                rotation=(0.0, math.radians(side * -18.0), math.radians(side * -22.0)),
                scale=(1.22, 0.45, 0.64),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_iris_{tag}",
                1,
                0.072,
                (side * 0.21, -0.63, 2.27),
                scale=(0.76, 0.45, 0.96),
            ),
            mat_prefix,
            "iris_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.036,
                (side * 0.21, -0.655, 2.27),
                scale=(0.55, 0.40, 1.0),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )
        # Sobrancelha feroz azul inclinada em V sobre o olho
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.24, 0.08, 0.065),
                (side * 0.21, -0.60, 2.34),
                rotation=(math.radians(8.0), math.radians(side * -22.0), math.radians(side * -22.0)),
            ),
            mat_prefix,
            "body_dark",
            pal,
        )

    # Bico superior longo e afunilado para frente e levemente para baixo
    _add_part(
        parts,
        create_cone(
            "_tmp_beak_upper",
            6,
            0.24,
            0.10,
            0.66,
            (0.0, -0.82, 2.12),
            rotation=(math.radians(104.0), 0.0, 0.0),
            scale=(1.15, 0.46, 1.0),
        ),
        mat_prefix,
        "beak_cream",
        pal,
    )
    # Ponta arredondada do bico superior
    _add_part(
        parts,
        create_icosphere("_tmp_beak_tip", 1, 0.11, (0.0, -1.10, 2.04), scale=(1.05, 0.90, 0.48)),
        mat_prefix,
        "beak_cream",
        pal,
    )
    # Mandíbula inferior aberta + boca interna + língua
    _add_part(
        parts,
        create_cone(
            "_tmp_beak_lower",
            6,
            0.20,
            0.10,
            0.46,
            (0.0, -0.68, 1.88),
            rotation=(math.radians(138.0), 0.0, 0.0),
            scale=(1.08, 0.42, 1.0),
        ),
        mat_prefix,
        "beak_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_inner", 2, 0.18, (0.0, -0.66, 2.00), scale=(0.94, 0.85, 0.84)),
        mat_prefix,
        "mouth_deep",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_tongue", 1, 0.13, (0.0, -0.72, 1.94), scale=(0.86, 0.90, 0.42)),
        mat_prefix,
        "tongue_pink",
        pal,
    )

    # 4. BRAÇOS ATLÉTICOS + MÃOS PALMADAS COM MEMBRANAS CREME E GARRAS BRANCAS
    def _connect_arm(seg_name: str, p0: tuple, p1: tuple, r0: float, r1: float):
        dx, dy, dz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
        dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5, (p0[2] + p1[2]) * 0.5)
        horiz = math.sqrt(dx * dx + dy * dy)
        rot_x = math.atan2(horiz, dz)
        rot_z = math.atan2(dx, -dy)
        _add_part(
            parts,
            create_cone(seg_name, 7, r0, r1, dist + 0.08, mid, rotation=(rot_x, 0.0, rot_z)),
            mat_prefix,
            "body_blue",
            pal,
        )

    arm_configs = [
        # (tag, side, shoulder_loc, elbow_loc, wrist_loc)
        ("L", -1.0, (-0.42, -0.04, 1.72), (-0.82, -0.06, 1.64), (-1.10, -0.38, 1.42)),
        ("R", 1.0, (0.42, -0.04, 1.72), (0.80, -0.06, 1.64), (0.96, -0.44, 1.44)),
    ]
    for tag, side, s_loc, e_loc, w_loc in arm_configs:
        _add_part(
            parts,
            create_icosphere(f"_tmp_shoulder_{tag}", 2, 0.19, s_loc),
            mat_prefix,
            "body_blue",
            pal,
        )
        _connect_arm(f"_tmp_upper_arm_{tag}", s_loc, e_loc, 0.16, 0.13)
        _add_part(
            parts,
            create_icosphere(f"_tmp_elbow_{tag}", 2, 0.135, e_loc),
            mat_prefix,
            "body_blue",
            pal,
        )
        _connect_arm(f"_tmp_forearm_{tag}", e_loc, w_loc, 0.13, 0.12)
        # Palma da mão
        _add_part(
            parts,
            create_icosphere(f"_tmp_palm_{tag}", 2, 0.15, w_loc, scale=(1.15, 1.0, 0.65)),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Membrana creme encaixada certinho entre os 3 dedos
        base_ang = math.radians(side * -18.0)
        _add_part(
            parts,
            create_cone(
                f"_tmp_hand_web_{tag}",
                4,
                0.08,
                0.24,
                0.26,
                (w_loc[0] + math.sin(base_ang) * 0.16, w_loc[1] - math.cos(base_ang) * 0.16, w_loc[2] - 0.08),
                rotation=(math.radians(114.0), 0.0, base_ang),
                scale=(1.15, 0.14, 1.0),
            ),
            mat_prefix,
            "web_cream",
            pal,
        )
        # 3 dedos azuis com garras brancas
        for d_idx, ang_d in enumerate([-30.0, 0.0, 30.0]):
            ang = math.radians(ang_d + side * -18.0)
            fx = w_loc[0] + math.sin(ang) * 0.20
            fy = w_loc[1] - math.cos(ang) * 0.20
            fz = w_loc[2] - 0.09
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hfinger_{tag}_{d_idx}",
                    5,
                    0.052,
                    0.032,
                    0.24,
                    (fx, fy, fz),
                    rotation=(math.radians(114.0), 0.0, ang),
                ),
                mat_prefix,
                "body_blue",
                pal,
            )
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hclaw_{tag}_{d_idx}",
                    5,
                    0.038,
                    0.008,
                    0.16,
                    (fx + math.sin(ang) * 0.12, fy - math.cos(ang) * 0.12, fz - 0.08),
                    rotation=(math.radians(134.0), 0.0, ang),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 5. PERNAS MUSCULOSAS + GRANDES PÉS PALMADOS COM MEMBRANAS CREME E GARRAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa musculosa
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.28,
                (side * 0.44, 0.02, 0.72),
                rotation=(math.radians(24.0), math.radians(side * -16.0), 0.0),
                scale=(0.86, 1.16, 1.24),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Canela / tornozelo
        _add_part(
            parts,
            create_cone(
                f"_tmp_shin_{tag}",
                8,
                0.19,
                0.16,
                0.52,
                (side * 0.56, -0.02, 0.34),
                rotation=(math.radians(-14.0), math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Base do pé
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_base_{tag}",
                2,
                0.22,
                (side * 0.58, -0.14, 0.11),
                scale=(1.08, 1.24, 0.46),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )
        # Membrana creme do pé
        _add_part(
            parts,
            create_cone(
                f"_tmp_foot_web_{tag}",
                4,
                0.28,
                0.12,
                0.34,
                (side * 0.62, -0.34, 0.075),
                rotation=(math.radians(90.0), 0.0, math.radians(side * -14.0)),
                scale=(1.22, 0.16, 1.0),
            ),
            mat_prefix,
            "web_cream",
            pal,
        )
        # 3 dedos frontais azuis + garras brancas
        for t_idx, ang_d in enumerate([-30.0, 0.0, 30.0]):
            ang = math.radians(ang_d + side * -14.0)
            tx = side * 0.60 + math.sin(ang) * 0.26
            ty = -0.22 - math.cos(ang) * 0.26
            _add_part(
                parts,
                create_cone(
                    f"_tmp_ftoe_{tag}_{t_idx}",
                    5,
                    0.068,
                    0.042,
                    0.30,
                    (tx, ty, 0.085),
                    rotation=(math.radians(92.0), 0.0, ang),
                ),
                mat_prefix,
                "body_blue",
                pal,
            )
            _add_part(
                parts,
                create_cone(
                    f"_tmp_fclaw_{tag}_{t_idx}",
                    5,
                    0.045,
                    0.008,
                    0.16,
                    (tx + math.sin(ang) * 0.16, ty - math.cos(ang) * 0.16, 0.07),
                    rotation=(math.radians(102.0), 0.0, ang),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )
        # Esporão/garra traseira do calcanhar
        _add_part(
            parts,
            create_cone(
                f"_tmp_heel_{tag}",
                5,
                0.045,
                0.008,
                0.18,
                (side * 0.54, 0.16, 0.10),
                rotation=(math.radians(-82.0), 0.0, 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 6. CAUDA LONGA AFILADA CURVADA PARA CIMA E LATERAL DIREITA
    tail_segs = [
        # (r1, r2, dep, loc, rot_deg)
        (0.28, 0.21, 0.56, (0.14, 0.64, 0.88), (-78.0, 22.0, 0.0)),
        (0.21, 0.13, 0.58, (0.42, 1.04, 1.06), (-58.0, 36.0, 0.0)),
        (0.13, 0.02, 0.62, (0.74, 1.38, 1.38), (-36.0, 42.0, 0.0)),
    ]
    for ts_idx, (r1, r2, dep, loc, rot_d) in enumerate(tail_segs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_{ts_idx}",
                7,
                r1,
                r2,
                dep,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
            ),
            mat_prefix,
            "body_blue",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 055. Aquakappa lado a lado."""
    specs = [
        ("Aquakappa_Shiny", (-10.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Aquakappa_Normal", (-5.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Aquakappa_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Aquakappa_Gigante", (5.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Aquakappa_Dourada_SuperRara", (13.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_aquakappa(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
