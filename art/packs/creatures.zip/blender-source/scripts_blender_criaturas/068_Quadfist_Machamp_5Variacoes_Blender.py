"""
068_Quadfist_Machamp_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "068. Quadfist — Colosso de 4 Braços (Ref: Machamp)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Quadfist_Shiny (1.0x - Paleta Shiny Verde-Hulk Intenso + Lábios Creme + Cinturão Ouro)
  2. Quadfist_Normal (1.0x - Cinza-Azulado + 4 Braços Completos + 3 Cristas Bege + Cinturão Ouro)
  3. Quadfist_Grande (1.35x - Normal)
  4. Quadfist_Gigante (1.85x - Normal)
  5. Quadfist_Dourada_SuperRara (2.25x - Ouro Reluzente + Cristas, Olhos e Emblema Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2, cones/cilindros 6-8 lados)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés largos alinhados exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_skin": (0.58, 0.67, 0.76, 1.0),
        "body_shade": (0.44, 0.53, 0.62, 1.0),
        "crest_tan": (0.76, 0.68, 0.58, 1.0),
        "lips_cream": (0.94, 0.88, 0.56, 1.0),
        "mouth_pink": (0.84, 0.50, 0.56, 1.0),
        "trunks_black": (0.14, 0.14, 0.17, 1.0),
        "belt_gold": (0.94, 0.82, 0.28, 1.0),
        "emblem_red": (0.88, 0.24, 0.24, 1.0),
        "white": (0.98, 0.98, 0.99, 1.0),
        "dark": (0.12, 0.12, 0.15, 1.0),
    },
    "shiny_palette": {
        "body_skin": (0.42, 0.72, 0.34, 1.0),
        "body_shade": (0.30, 0.56, 0.24, 1.0),
        "crest_tan": (0.68, 0.68, 0.44, 1.0),
        "lips_cream": (0.96, 0.90, 0.54, 1.0),
        "mouth_pink": (0.86, 0.50, 0.56, 1.0),
        "trunks_black": (0.14, 0.16, 0.16, 1.0),
        "belt_gold": (0.96, 0.84, 0.28, 1.0),
        "emblem_red": (0.90, 0.24, 0.24, 1.0),
        "white": (0.98, 0.98, 0.99, 1.0),
        "dark": (0.12, 0.14, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "body_skin": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.62, 0.10, 1.0),
        "crest_tan": (0.10, 0.92, 1.00, 1.0),
        "lips_cream": (1.00, 0.94, 0.52, 1.0),
        "mouth_pink": (0.86, 0.62, 0.18, 1.0),
        "trunks_black": (0.12, 0.14, 0.20, 1.0),
        "belt_gold": (1.00, 0.92, 0.44, 1.0),
        "emblem_red": (0.10, 0.92, 1.00, 1.0),
        "white": (1.00, 0.99, 0.92, 1.0),
        "dark": (0.06, 0.56, 0.72, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_segment(
    name: str,
    p1: tuple,
    p2: tuple,
    r1: float,
    r2: float,
    vertices: int = 8,
    extend: float = 1.05,
):
    """Cria um cone/segmento conectando exatamente p1 -> p2 sem folgas."""
    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    dz = p2[2] - p1[2]
    dist = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dist < 1e-6:
        dist = 1e-6
    mid = ((p1[0] + p2[0]) * 0.5, (p1[1] + p2[1]) * 0.5, (p1[2] + p2[2]) * 0.5)
    theta = math.acos(max(-1.0, min(1.0, dz / dist)))
    phi = math.atan2(dy, dx)
    return create_cone(
        name=name,
        vertices=vertices,
        radius1=r1,
        radius2=r2,
        depth=dist * extend,
        location=mid,
        rotation=(0.0, theta, phi),
    )


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha os pés em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_quadfist(
    name: str = "Quadfist_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 068. Quadfist (Ref: Machamp):
      - 4 braços musculosos completos: par superior erguido com enormes punhos cerrados acima
        da cabeça + par inferior estendido em guarda marcial com mãos abertas em golpe de karatê
      - Cabeça poderosa com 3 cristas bege altas, olhos vermelhos ferozes e boca larga com
        lábios creme-amarelos abertos em rugido de batalha
      - Calção preto + cinturão de campeão dourado cravejado com fivela redonda e emblema 'P'
      - Pernas musculosas em base aberta e pés fendidos firmes em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Quadfist_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Quadfist_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Quadfist_Norm"

    parts = []

    # 1. CALÇÃO PRETO + CINTURÃO DE CAMPEÃO CRAVEJADO COM FIVELA DOURADA E 'P'
    _add_part(
        parts,
        create_icosphere("_tmp_trunks", 2, 0.42, (0.0, 0.00, 1.02), scale=(1.10, 0.88, 0.86)),
        mat_prefix,
        "trunks_black",
        pal,
    )
    _add_part(
        parts,
        create_cylinder("_tmp_belt_strap", 10, 0.44, 0.18, (0.0, -0.01, 1.24), scale=(1.08, 0.88, 1.0)),
        mat_prefix,
        "trunks_black",
        pal,
    )
    # Tachinhas douradas ao redor do cinturão
    for ang_deg in (-65, -42, 42, 65):
        ang = math.radians(ang_deg)
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_stud_{ang_deg}",
                1,
                0.045,
                (math.sin(ang) * 0.47, -math.cos(ang) * 0.39, 1.24),
            ),
            mat_prefix,
            "belt_gold",
            pal,
        )
    # Grande fivela redonda dourada + emblema 'P' vermelho
    _add_part(
        parts,
        create_cylinder(
            "_tmp_buckle_out",
            10,
            0.22,
            0.09,
            (0.0, -0.38, 1.24),
            rotation=(math.radians(90.0), 0.0, 0.0),
        ),
        mat_prefix,
        "belt_gold",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_emblem_p_bar", (0.04, 0.05, 0.12), (-0.025, -0.43, 1.26)),
        mat_prefix,
        "emblem_red",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_emblem_p_top", 1, 0.048, (0.015, -0.43, 1.30), scale=(1.05, 0.60, 0.85)),
        mat_prefix,
        "emblem_red",
        pal,
    )

    # 2. TRONCO TITÂNICO MUSCULOSO (PEITORAIS + COSTAS LARGAS PARA 4 BRAÇOS)
    _add_part(
        parts,
        create_icosphere("_tmp_torso_main", 2, 0.56, (0.0, 0.04, 1.66), scale=(1.24, 0.90, 0.96)),
        mat_prefix,
        "body_skin",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(f"_tmp_pec_{tag}", 2, 0.35, (side * 0.32, -0.26, 1.66), scale=(1.14, 0.86, 0.86)),
            mat_prefix,
            "body_skin",
            pal,
        )
    # Pescoço poderoso
    _add_part(
        parts,
        create_cylinder("_tmp_neck", 8, 0.28, 0.34, (0.0, -0.02, 2.04)),
        mat_prefix,
        "body_skin",
        pal,
    )

    # 3. CABEÇA ICÔNICA COM LÁBIOS CREME-AMARELOS, OLHOS VERMELHOS E 3 CRISTAS ALTAS
    _add_part(
        parts,
        create_icosphere("_tmp_head_main", 2, 0.38, (0.0, -0.10, 2.28), scale=(1.00, 1.04, 1.00)),
        mat_prefix,
        "body_skin",
        pal,
    )
    # Placa labial larga creme-amarela (assinatura visual do Machamp!)
    _add_part(
        parts,
        create_icosphere("_tmp_lip_upper", 2, 0.30, (0.0, -0.36, 2.22), scale=(1.32, 0.86, 0.52)),
        mat_prefix,
        "lips_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_lip_lower", 2, 0.26, (0.0, -0.34, 2.04), scale=(1.22, 0.84, 0.42)),
        mat_prefix,
        "lips_cream",
        pal,
    )
    # Boca aberta rugindo rosa no centro dos lábios creme
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_open", 2, 0.21, (0.0, -0.44, 2.13), scale=(1.12, 0.55, 0.58)),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # Olhos vermelhos expressivos com sobrancelha forte
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_w_{tag}",
                1,
                0.115,
                (side * 0.19, -0.42, 2.38),
                rotation=(0.0, 0.0, math.radians(side * -18.0)),
                scale=(1.05, 0.55, 0.86),
            ),
            mat_prefix,
            "white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_red_{tag}",
                1,
                0.075,
                (side * 0.18, -0.46, 2.38),
                scale=(0.75, 0.50, 1.05),
            ),
            mat_prefix,
            "emblem_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.036,
                (side * 0.18, -0.49, 2.38),
                scale=(0.65, 0.50, 1.20),
            ),
            mat_prefix,
            "dark",
            pal,
        )

    # 3 CRISTAS BEGE ALTAS NO TOPO DA CABEÇA (central mais proeminente)
    for c_tag, cx, rad, cz in (("L", -0.15, 0.28, 2.66), ("C", 0.0, 0.34, 2.74), ("R", 0.15, 0.28, 2.66)):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_crest_{c_tag}",
                2,
                rad,
                (cx, -0.06, cz),
                rotation=(math.radians(-18.0), 0.0, 0.0),
                scale=(0.24, 1.24, 0.96),
            ),
            mat_prefix,
            "crest_tan",
            pal,
        )

    # 4A. PAR DE BRAÇOS SUPERIORES (TRASEIROS): ERGUIDOS BEM ALTO COM PUNHOS CERRADOS GIGANTES!
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        p_sh_u = (side * 0.58, 0.24, 2.12)
        p_el_u = (side * 1.24, 0.20, 2.28)
        p_wr_u = (side * 1.04, 0.06, 2.94)
        _add_part(parts, create_icosphere(f"_tmp_sh_up_{tag}", 2, 0.28, p_sh_u, scale=(1.15, 0.95, 0.95)), mat_prefix, "body_skin", pal)
        _add_part(parts, create_segment(f"_tmp_bicep_up_{tag}", p_sh_u, p_el_u, 0.23, 0.21, vertices=8), mat_prefix, "body_skin", pal)
        _add_part(parts, create_icosphere(f"_tmp_el_up_{tag}", 2, 0.22, p_el_u), mat_prefix, "body_skin", pal)
        _add_part(parts, create_segment(f"_tmp_fore_up_{tag}", p_el_u, p_wr_u, 0.21, 0.22, vertices=8), mat_prefix, "body_skin", pal)
        # Punho fechado colossal erguido!
        fist_u = (p_wr_u[0] - side * 0.10, p_wr_u[1] - 0.08, p_wr_u[2] + 0.14)
        _add_part(parts, create_icosphere(f"_tmp_fist_up_{tag}", 2, 0.29, fist_u, scale=(1.16, 1.02, 0.96)), mat_prefix, "body_skin", pal)
        for k_idx, kx in enumerate((-0.14, -0.05, 0.05, 0.14)):
            _add_part(
                parts,
                create_icosphere(f"_tmp_kn_up_{tag}_{k_idx}", 1, 0.082, (fist_u[0] + kx, fist_u[1] - 0.22, fist_u[2] + 0.02)),
                mat_prefix,
                "body_skin",
                pal,
            )

    # 4B. PAR DE BRAÇOS INFERIORES (FRONTAIS): EM GUARDA MARCIAL COM MÃOS ABERTAS EM KARATÊ!
    # Braço frontal esquerdo (-X): cotovelo aberto e mão aberta em guarda perto do peito
    fl_sh = (-0.64, -0.06, 1.76)
    fl_el = (-1.18, -0.14, 1.56)
    fl_wr = (-0.92, -0.58, 1.38)
    _add_part(parts, create_icosphere("_tmp_sh_lo_L", 2, 0.28, fl_sh), mat_prefix, "body_skin", pal)
    _add_part(parts, create_segment("_tmp_bicep_lo_L", fl_sh, fl_el, 0.22, 0.20, vertices=8), mat_prefix, "body_skin", pal)
    _add_part(parts, create_icosphere("_tmp_el_lo_L", 2, 0.20, fl_el), mat_prefix, "body_skin", pal)
    _add_part(parts, create_segment("_tmp_fore_lo_L", fl_el, fl_wr, 0.20, 0.18, vertices=8), mat_prefix, "body_skin", pal)
    # Mão aberta em palma marcial
    _add_part(parts, create_icosphere("_tmp_palm_L", 2, 0.18, (-0.82, -0.68, 1.42), scale=(0.92, 0.60, 1.15)), mat_prefix, "body_skin", pal)
    for f_idx, (fx, fz) in enumerate([(-0.10, 0.18), (-0.03, 0.22), (0.04, 0.21), (0.11, 0.16)]):
        _add_part(
            parts,
            create_segment(
                f"_tmp_fl_finger_{f_idx}",
                (-0.82 + fx, -0.70, 1.48),
                (-0.82 + fx * 1.4, -0.76, 1.56 + fz * 0.7),
                0.042,
                0.024,
                vertices=5,
            ),
            mat_prefix,
            "body_skin",
            pal,
        )

    # Braço frontal direito (+X): estendido para frente-baixo em golpe aberto
    fr_sh = (0.64, -0.06, 1.76)
    fr_el = (1.06, -0.26, 1.50)
    fr_wr = (1.38, -0.58, 1.16)
    _add_part(parts, create_icosphere("_tmp_sh_lo_R", 2, 0.28, fr_sh), mat_prefix, "body_skin", pal)
    _add_part(parts, create_segment("_tmp_bicep_lo_R", fr_sh, fr_el, 0.22, 0.20, vertices=8), mat_prefix, "body_skin", pal)
    _add_part(parts, create_icosphere("_tmp_el_lo_R", 2, 0.20, fr_el), mat_prefix, "body_skin", pal)
    _add_part(parts, create_segment("_tmp_fore_lo_R", fr_el, fr_wr, 0.20, 0.18, vertices=8), mat_prefix, "body_skin", pal)
    _add_part(parts, create_icosphere("_tmp_palm_R", 2, 0.19, (1.46, -0.66, 1.10), scale=(1.10, 0.90, 0.62)), mat_prefix, "body_skin", pal)
    for f_idx, (fx, fy) in enumerate([(0.16, -0.14), (0.20, -0.06), (0.18, 0.04), (0.08, -0.20)]):
        _add_part(
            parts,
            create_segment(
                f"_tmp_fr_finger_{f_idx}",
                (1.48, -0.66, 1.08),
                (1.48 + fx, -0.66 + fy, 0.96),
                0.044,
                0.024,
                vertices=5,
            ),
            mat_prefix,
            "body_skin",
            pal,
        )

    # 5. PERNAS MUSCULOSAS EM BASE LARGA DE COMBATE + PÉS FENDIDOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        p_hip = (side * 0.34, 0.00, 0.96)
        p_knee = (side * 0.74, -0.20, 0.56)
        p_ankle = (side * 0.78, -0.06, 0.16)
        _add_part(parts, create_segment(f"_tmp_thigh_{tag}", p_hip, p_knee, 0.27, 0.23, vertices=8), mat_prefix, "body_skin", pal)
        _add_part(parts, create_icosphere(f"_tmp_knee_{tag}", 2, 0.23, p_knee), mat_prefix, "body_skin", pal)
        _add_part(parts, create_segment(f"_tmp_shin_{tag}", p_knee, p_ankle, 0.22, 0.17, vertices=8), mat_prefix, "body_skin", pal)
        foot_c = (p_ankle[0] + side * 0.04, p_ankle[1] - 0.12, 0.10)
        _add_part(parts, create_icosphere(f"_tmp_foot_{tag}", 2, 0.20, foot_c, scale=(1.14, 1.32, 0.52)), mat_prefix, "body_skin", pal)
        # 2 grandes dedos fendidos icônicos do Machamp
        for t_idx, tx in enumerate((-0.11, 0.11)):
            _add_part(
                parts,
                create_segment(
                    f"_tmp_toe_{tag}_{t_idx}",
                    (foot_c[0] + tx * 0.6, foot_c[1] - 0.12, 0.09),
                    (foot_c[0] + tx * 1.4, foot_c[1] - 0.38, 0.06),
                    0.085,
                    0.055,
                    vertices=6,
                ),
                mat_prefix,
                "body_skin",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 068. Quadfist lado a lado."""
    specs = [
        ("Quadfist_Shiny", (-13.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Quadfist_Normal", (-7.6, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Quadfist_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Quadfist_Gigante", (7.4, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Quadfist_Dourada_SuperRara", (18.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_quadfist(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
