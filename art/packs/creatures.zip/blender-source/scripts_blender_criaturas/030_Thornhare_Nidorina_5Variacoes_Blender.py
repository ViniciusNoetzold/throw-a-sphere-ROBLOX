"""
030_Thornhare_Nidorina_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "030. Thornhare — Fera Espinhosa Azul (Ref: Nidorina)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Thornhare_Shiny (1.0x - Paleta Shiny / Shyne Roxo-Orquídea + Manchas Ameixa)
  2. Thornhare_Normal (1.0x - Corpo Azul-Ciano + Manchas Azul-Marinho + Barriga Creme + Olhos Rubi)
  3. Thornhare_Grande (1.35x - Normal)
  4. Thornhare_Gigante (1.85x - Normal)
  5. Thornhare_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Orelhas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.017`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e frente/focinho apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Thornhare_Shiny`, `Thornhare_Normal`, `Thornhare_Grande`,
     `Thornhare_Gigante`, `Thornhare_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.017,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_cyan": (0.48, 0.76, 0.88, 1.0),
        "spot_navy": (0.24, 0.46, 0.66, 1.0),
        "belly_cream": (0.94, 0.92, 0.78, 1.0),
        "eye_ruby": (0.88, 0.20, 0.24, 1.0),
        "claw_white": (0.98, 0.98, 0.99, 1.0),
    },
    "shiny_palette": {
        "body_cyan": (0.74, 0.46, 0.78, 1.0),
        "spot_navy": (0.48, 0.24, 0.56, 1.0),
        "belly_cream": (0.95, 0.90, 0.84, 1.0),
        "eye_ruby": (0.90, 0.22, 0.28, 1.0),
        "claw_white": (0.99, 0.99, 0.98, 1.0),
    },
    "golden_super_rare_palette": {
        "body_cyan": (0.98, 0.78, 0.14, 1.0),
        "spot_navy": (0.84, 0.56, 0.08, 1.0),
        "belly_cream": (1.00, 0.95, 0.64, 1.0),
        "eye_ruby": (0.10, 0.92, 1.00, 1.0),
        "claw_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base das patas em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_thornhare(
    name: str = "Thornhare_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 030. Thornhare (Ref: Nidorina):
      - Frente/focinho apontando para -Y e patas traseiras tocando Z = 0.0
      - Corpo robusto azul-ciano semi-erguido com barriga creme e manchas azul-marinho
      - Grandes orelhas recortadas bicolores, olhos rubi, presas curtas e 2 fileiras de espinhos dorsais
      - Cauda grossa curta e patas musculosas com garras brancas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Thorn_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Thorn_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Thorn_Norm"

    parts = []

    # 1. CORPO ROBUSTO AZUL-CIANO + BARRIGA CREME + MANCHAS + 2 FILEIRAS DE ESPINHOS DORSAIS
    _add_part(
        parts,
        create_icosphere("_tmp_torso_main", 1, 0.66, (0.0, 0.14, 0.72), scale=(0.96, 1.06, 0.98)),
        mat_prefix,
        "body_cyan",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_belly_cream", 1, 0.50, (0.0, -0.18, 0.68), scale=(0.88, 0.68, 0.96)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(f"_tmp_spot_hi_{tag}", (0.14, 0.24, 0.22), (side * 0.56, 0.22, 0.86)),
            mat_prefix,
            "spot_navy",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_spot_lo_{tag}", (0.14, 0.22, 0.20), (side * 0.58, 0.42, 0.58)),
            mat_prefix,
            "spot_navy",
            pal,
        )
        # Duas fileiras de espinhos curtos nas costas
        for sp_idx, (sy, sz, rx) in enumerate([(0.34, 1.24, -28.0), (0.62, 1.02, -52.0)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_spine_{tag}_{sp_idx}",
                    4,
                    0.14,
                    0.02,
                    0.34,
                    (side * 0.24, sy, sz),
                    rotation=(math.radians(rx), math.radians(side * 12.0), math.radians(45.0)),
                ),
                mat_prefix,
                "body_cyan",
                pal,
            )

    # 2. CABEÇA ROBUSTA, PRESAS, OLHOS RUBI E GRANDES ORELHAS RECORTADAS
    _add_part(
        parts,
        create_cube("_tmp_head_main", (0.86, 0.80, 0.68), (0.0, -0.30, 1.26), rotation=(math.radians(10.0), 0.0, 0.0)),
        mat_prefix,
        "body_cyan",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            4,
            0.30,
            0.14,
            0.38,
            (0.0, -0.78, 1.18),
            rotation=(math.radians(98.0), 0.0, math.radians(45.0)),
            scale=(1.12, 0.78, 1.0),
        ),
        mat_prefix,
        "body_cyan",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_jaw", (0.56, 0.42, 0.16), (0.0, -0.60, 1.02)),
        mat_prefix,
        "body_cyan",
        pal,
    )

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Presinhas brancas visíveis na lateral da boca
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.048,
                0.01,
                0.15,
                (side * 0.20, -0.78, 1.02),
                rotation=(math.radians(180.0), 0.0, 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )
        # Olhos rubi ferozes bem visíveis de frente
        _add_part(
            parts,
            create_cube(f"_tmp_eye_white_{tag}", (0.16, 0.26, 0.20), (side * 0.34, -0.66, 1.32)),
            mat_prefix,
            "claw_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_ruby_{tag}", (0.15, 0.16, 0.16), (side * 0.35, -0.72, 1.32)),
            mat_prefix,
            "eye_ruby",
            pal,
        )
        # Orelha grande arredondada com entalhe superior + interior azul-marinho
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ear_outer_{tag}",
                6,
                0.42,
                0.15,
                (side * 0.62, -0.14, 1.72),
                rotation=(math.radians(74.0), math.radians(side * -28.0), math.radians(side * 22.0)),
                scale=(1.12, 1.28, 1.0),
            ),
            mat_prefix,
            "body_cyan",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_tip_{tag}",
                4,
                0.15,
                0.02,
                0.34,
                (side * 0.86, -0.06, 2.04),
                rotation=(math.radians(-10.0), math.radians(side * 34.0), math.radians(45.0)),
                scale=(0.8, 0.45, 1.0),
            ),
            mat_prefix,
            "body_cyan",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ear_inner_{tag}",
                6,
                0.28,
                0.09,
                (side * 0.60, -0.21, 1.70),
                rotation=(math.radians(74.0), math.radians(side * -28.0), math.radians(side * 22.0)),
                scale=(1.04, 1.16, 1.0),
            ),
            mat_prefix,
            "spot_navy",
            pal,
        )

    # 3. BRAÇOS DIANTEIROS + PERNAS TRASEIRAS ROBUSTAS COM GARRAS EM Z = 0.0 + CAUDA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_arm_{tag}",
                6,
                0.16,
                0.56,
                (side * 0.50, -0.34, 0.72),
                rotation=(math.radians(34.0), 0.0, math.radians(side * 10.0)),
            ),
            mat_prefix,
            "body_cyan",
            pal,
        )
        for c_idx, dx in enumerate((-0.07, 0.0, 0.07)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{tag}_{c_idx}",
                    4,
                    0.042,
                    0.01,
                    0.16,
                    (side * 0.50 + dx, -0.54, 0.46),
                    rotation=(math.radians(122.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

        _add_part(
            parts,
            create_cube(f"_tmp_thigh_{tag}", (0.38, 0.48, 0.54), (side * 0.46, 0.14, 0.36)),
            mat_prefix,
            "body_cyan",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{tag}", (0.34, 0.46, 0.14), (side * 0.46, 0.02, 0.07)),
            mat_prefix,
            "body_cyan",
            pal,
        )
        for c_idx, dx in enumerate((-0.09, 0.0, 0.09)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_claw_{tag}_{c_idx}",
                    4,
                    0.055,
                    0.012,
                    0.18,
                    (side * 0.46 + dx, -0.26, 0.06),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    _add_part(
        parts,
        create_cone(
            "_tmp_tail",
            6,
            0.22,
            0.03,
            0.76,
            (0.0, 0.88, 0.46),
            rotation=(math.radians(-62.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_cyan",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 030. Thornhare lado a lado."""
    specs = [
        ("Thornhare_Shiny", (-7.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Thornhare_Normal", (-4.1, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Thornhare_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Thornhare_Gigante", (4.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Thornhare_Dourada_SuperRara", (9.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_thornhare(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
