"""
090_Bivalve_Shellder_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "090. Bivalve — Ostra Pérola (Ref: Shellder)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Bivalve_Shiny (1.0x - Paleta Shiny Laranja-Tangerina Vibrante + Pérola Negra + Língua Rosa)
  2. Bivalve_Normal (1.0x - Concha Lavanda-Roxa + Pérola Negra + Olhos Brancos + Língua Rosa)
  3. Bivalve_Grande (1.35x - Normal)
  4. Bivalve_Gigante (1.85x - Normal)
  5. Bivalve_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Detalhes Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para concha arqueada, pérola e língua; cones para chifres)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base alinhada exatamente em `Z = 0.0` e frente/língua apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "shell_main": (0.56, 0.50, 0.78, 1.0),
        "shell_ridge": (0.42, 0.36, 0.64, 1.0),
        "shell_inner": (0.28, 0.25, 0.30, 1.0),
        "pearl_black": (0.11, 0.11, 0.14, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.08, 0.08, 0.10, 1.0),
        "tongue_pink": (0.92, 0.62, 0.68, 1.0),
        "tongue_crease": (0.64, 0.36, 0.44, 1.0),
    },
    "shiny_palette": {
        "shell_main": (0.96, 0.54, 0.16, 1.0),
        "shell_ridge": (0.78, 0.38, 0.10, 1.0),
        "shell_inner": (0.36, 0.22, 0.14, 1.0),
        "pearl_black": (0.11, 0.11, 0.14, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.08, 0.08, 0.10, 1.0),
        "tongue_pink": (0.94, 0.60, 0.66, 1.0),
        "tongue_crease": (0.66, 0.34, 0.42, 1.0),
    },
    "golden_super_rare_palette": {
        "shell_main": (0.98, 0.78, 0.14, 1.0),
        "shell_ridge": (0.82, 0.58, 0.08, 1.0),
        "shell_inner": (0.46, 0.32, 0.06, 1.0),
        "pearl_black": (0.26, 0.18, 0.05, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.28, 0.42, 1.0),
        "tongue_pink": (0.10, 0.92, 1.00, 1.0),
        "tongue_crease": (0.06, 0.58, 0.74, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_bivalve(
    name: str = "Bivalve_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 090. Bivalve (Ref: Shellder):
      - Pérola negra esférica interna com dois olhos brancos grandes e pupilas pontuais
      - Língua rosa carnuda longa projetada para frente e para baixo com vinco central
      - Concha superior arqueada em cúpula com estrias radiais, aba frontal ondulada e 2 chifres frontais
      - Concha inferior com forro interno escuro, bordas recortadas e 2 chifres traseiros + dobradiça posterior
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Biv_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Biv_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Biv_Norm"

    parts = []

    # 1. NÚCLEO INTERNO — PÉROLA NEGRA ESFÉRICA
    _add_part(
        parts,
        create_icosphere("_tmp_pearl_core", 2, 0.56, (0.0, -0.06, 0.68), scale=(1.04, 0.94, 0.96)),
        mat_prefix,
        "pearl_black",
        pal,
    )

    # 2. OLHOS GRANDES BRANCOS + PUPILAS PONTUAIS (BEM VISÍVEIS SOB A ABA DA CONCHA)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.20,
                (side * 0.28, -0.52, 0.72),
                rotation=(0.0, 0.0, math.radians(side * -20.0)),
                scale=(0.88, 0.42, 1.02),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.042,
                (side * 0.29, -0.60, 0.73),
                scale=(0.75, 0.55, 0.95),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 3. LÍNGUA LONGA ROSA CARNUDA PROJETADA PARA FRENTE E PARA BAIXO + VINCO CENTRAL
    tongue_segs = [
        (0.24, (0.0, -0.52, 0.46), (1.06, 0.78, 0.56), 28.0),
        (0.26, (0.0, -0.72, 0.34), (1.14, 0.92, 0.48), 38.0),
        (0.27, (0.0, -0.92, 0.22), (1.18, 0.96, 0.42), 34.0),
        (0.25, (0.0, -1.06, 0.16), (1.12, 0.86, 0.36), 22.0),
    ]
    for idx, (rad, loc, sc, rx_deg) in enumerate(tongue_segs):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_tongue_{idx}",
                2,
                rad,
                loc,
                rotation=(math.radians(rx_deg), 0.0, 0.0),
                scale=sc,
            ),
            mat_prefix,
            "tongue_pink",
            pal,
        )
    # Vinco central vertical na parte superior da língua
    _add_part(
        parts,
        create_cube(
            "_tmp_tongue_crease",
            (0.036, 0.36, 0.06),
            (0.0, -0.76, 0.41),
            rotation=(math.radians(36.0), 0.0, 0.0),
        ),
        mat_prefix,
        "tongue_crease",
        pal,
    )

    # 4. CONCHA SUPERIOR ARQUEADA (CÚPULA + ABAS LATERAIS + ESTRIAS + 2 CHIFRES FRONTAIS)
    # Cúpula principal inclinada levemente aberta para cima na frente
    _add_part(
        parts,
        create_icosphere(
            "_tmp_top_shell_center",
            2,
            0.78,
            (0.0, 0.08, 1.06),
            rotation=(math.radians(16.0), 0.0, 0.0),
            scale=(1.04, 1.12, 0.54),
        ),
        mat_prefix,
        "shell_main",
        pal,
    )
    # Aba frontal central que forma o arco característico sobre a testa da pérola
    _add_part(
        parts,
        create_icosphere(
            "_tmp_top_lip_front",
            2,
            0.52,
            (0.0, -0.44, 1.12),
            rotation=(math.radians(18.0), 0.0, 0.0),
            scale=(1.12, 0.68, 0.32),
        ),
        mat_prefix,
        "shell_main",
        pal,
    )
    # Abas laterais caídas da concha superior abraçando os lados da pérola
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_top_wing_{tag}",
                2,
                0.54,
                (side * 0.64, -0.10, 0.94),
                rotation=(math.radians(14.0), math.radians(side * 44.0), math.radians(side * -14.0)),
                scale=(0.82, 1.14, 0.36),
            ),
            mat_prefix,
            "shell_main",
            pal,
        )
        # Borda frontal saliente lateral (ponta curvada para baixo)
        _add_part(
            parts,
            create_cone(
                f"_tmp_top_corner_{tag}",
                6,
                0.24,
                0.08,
                0.42,
                (side * 0.78, -0.46, 0.78),
                rotation=(math.radians(148.0), math.radians(side * 30.0), 0.0),
                scale=(0.85, 0.55, 1.0),
            ),
            mat_prefix,
            "shell_main",
            pal,
        )
        # Estrias/sulcos escuros longitudinais na concha superior (como na arte oficial)
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_top_ridge_{tag}",
                6,
                0.045,
                1.18,
                (side * 0.32, -0.02, 1.32),
                rotation=(math.radians(78.0), 0.0, math.radians(side * -10.0)),
                scale=(0.8, 1.0, 0.7),
            ),
            mat_prefix,
            "shell_ridge",
            pal,
        )
        # Chifres frontais icônicos da concha superior (robustos, apontando para cima e fora)
        _add_part(
            parts,
            create_cone(
                f"_tmp_horn_top_{tag}",
                7,
                0.20,
                0.065,
                0.62,
                (side * 0.72, -0.20, 1.38),
                rotation=(math.radians(-18.0), math.radians(side * 40.0), 0.0),
            ),
            mat_prefix,
            "shell_main",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_horn_tip_{tag}",
                1,
                0.072,
                (side * 0.90, -0.30, 1.60),
            ),
            mat_prefix,
            "shell_main",
            pal,
        )

    # Forro interno escuro sob a concha superior
    _add_part(
        parts,
        create_icosphere(
            "_tmp_top_lining",
            2,
            0.70,
            (0.0, 0.08, 0.92),
            rotation=(math.radians(14.0), 0.0, 0.0),
            scale=(1.02, 1.04, 0.44),
        ),
        mat_prefix,
        "shell_inner",
        pal,
    )

    # 5. DOBRADIÇA / CRISTA TRASEIRA DA CONCHA
    _add_part(
        parts,
        create_icosphere(
            "_tmp_hinge_main",
            2,
            0.38,
            (0.0, 0.72, 0.96),
            rotation=(math.radians(-16.0), 0.0, 0.0),
            scale=(1.18, 0.72, 0.88),
        ),
        mat_prefix,
        "shell_ridge",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_hinge_rib_{tag}",
                (0.24, 0.34, 0.36),
                (side * 0.28, 0.76, 0.92),
                rotation=(math.radians(-14.0), math.radians(side * 12.0), 0.0),
            ),
            mat_prefix,
            "shell_main",
            pal,
        )

    # 6. CONCHA INFERIOR + FORRO ESCURO + BORDAS RECORTADAS + 2 CHIFRES TRASEIROS
    _add_part(
        parts,
        create_icosphere(
            "_tmp_bot_shell_base",
            2,
            0.74,
            (0.0, 0.08, 0.34),
            rotation=(math.radians(-8.0), 0.0, 0.0),
            scale=(1.08, 1.06, 0.44),
        ),
        mat_prefix,
        "shell_main",
        pal,
    )
    # Forro interno escuro da concha inferior
    _add_part(
        parts,
        create_icosphere(
            "_tmp_bot_lining",
            2,
            0.66,
            (0.0, 0.02, 0.46),
            scale=(1.04, 0.98, 0.36),
        ),
        mat_prefix,
        "shell_inner",
        pal,
    )
    # Abas recortadas inferiores nas laterais frontais + chifres traseiros inferiores
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Aba lateral inferior envolvente
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_bot_cheek_{tag}",
                2,
                0.34,
                (side * 0.58, -0.24, 0.34),
                rotation=(0.0, math.radians(side * -24.0), math.radians(side * 18.0)),
                scale=(0.88, 1.12, 0.54),
            ),
            mat_prefix,
            "shell_main",
            pal,
        )
        # Borda escura interna visível na curva inferior
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_bot_cheek_inner_{tag}",
                1,
                0.28,
                (side * 0.52, -0.26, 0.42),
                scale=(0.84, 0.96, 0.52),
            ),
            mat_prefix,
            "shell_inner",
            pal,
        )
        # Chifres traseiros inferiores (apontando para fora e trás)
        _add_part(
            parts,
            create_cone(
                f"_tmp_horn_bot_{tag}",
                6,
                0.18,
                0.055,
                0.56,
                (side * 0.68, 0.54, 0.34),
                rotation=(math.radians(72.0), math.radians(side * 54.0), 0.0),
            ),
            mat_prefix,
            "shell_main",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 090. Bivalve lado a lado."""
    specs = [
        ("Bivalve_Shiny", (-8.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Bivalve_Normal", (-5.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Bivalve_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Bivalve_Gigante", (4.6, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Bivalve_Dourada_SuperRara", (11.6, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_bivalve(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
