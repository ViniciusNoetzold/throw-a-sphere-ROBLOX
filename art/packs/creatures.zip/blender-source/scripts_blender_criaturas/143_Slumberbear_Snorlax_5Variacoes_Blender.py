"""
143_Slumberbear_Snorlax_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "143. Slumberbear — Gigante Adormecido (Ref: Snorlax)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Slumberbear_Shiny (1.0x - Paleta Shiny Azul-Marinho Profundo + Barriga, Rosto e Patas Creme)
  2. Slumberbear_Normal (1.0x - Azul-Petróleo + Barriga Gigante Creme + Olhos Fechados + 2 Presinhas)
  3. Slumberbear_Grande (1.35x - Normal)
  4. Slumberbear_Gigante (1.85x - Normal)
  5. Slumberbear_Dourada_SuperRara (2.25x - Corpo Ouro Reluzente + Olhos, Garras e Detalhes Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para corpo gigante, barriga, cabeça e pés redondos)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Corpo sentado e pés redondos alinhados exatamente em `Z = 0.0` e rosto adormecido apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_teal": (0.20, 0.44, 0.56, 1.0),
        "body_shade": (0.14, 0.34, 0.44, 1.0),
        "belly_cream": (0.94, 0.90, 0.82, 1.0),
        "pad_brown": (0.58, 0.48, 0.40, 1.0),
        "claw_white": (0.98, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "shiny_palette": {
        "body_teal": (0.14, 0.28, 0.62, 1.0),
        "body_shade": (0.09, 0.20, 0.48, 1.0),
        "belly_cream": (0.96, 0.92, 0.84, 1.0),
        "pad_brown": (0.56, 0.46, 0.38, 1.0),
        "claw_white": (0.98, 0.99, 1.00, 1.0),
        "eye_dark": (0.10, 0.11, 0.14, 1.0),
    },
    "golden_super_rare_palette": {
        "body_teal": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.80, 0.58, 0.08, 1.0),
        "belly_cream": (1.00, 0.95, 0.72, 1.0),
        "pad_brown": (0.10, 0.92, 1.00, 1.0),
        "claw_white": (0.10, 0.92, 1.00, 1.0),
        "eye_dark": (0.06, 0.56, 0.72, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une primitivas, normaliza a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_slumberbear(
    name: str = "Slumberbear_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 143. Slumberbear (Ref: Snorlax):
      - Corpo gigantesco, redondo e rechonchudo azul-petróleo sentado com imensa barriga oval creme
      - Cabeça larga com orelhas triangulares pontudas e máscara facial creme em formato de coração
      - Expressão pacífica de sono: olhos fechados em risco escuro, sorriso sereno e 2 presinhas brancas
      - Braços rechonchudos abertos com 5 garras brancas curtas em cada mão
      - Pés redondos enormes creme com almofadas marrons e 3 garras brancas firmes em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Slum_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Slum_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Slum_Norm"

    parts = []

    # 1. CORPO GIGANTESCO ARREDONDADO SENTADO + IMENSA BARRIGA CREME
    _add_part(
        parts,
        create_icosphere("_tmp_body_lower", 2, 0.88, (0.0, 0.12, 0.82), scale=(1.12, 0.96, 0.96)),
        mat_prefix,
        "body_teal",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_body_upper", 2, 0.72, (0.0, 0.10, 1.32), scale=(1.06, 0.88, 0.84)),
        mat_prefix,
        "body_teal",
        pal,
    )
    # Enorme barriga macia creme dominando toda a frente do corpo
    _add_part(
        parts,
        create_icosphere("_tmp_belly_cream", 2, 0.78, (0.0, -0.22, 0.82), scale=(1.06, 0.76, 0.96)),
        mat_prefix,
        "belly_cream",
        pal,
    )

    # 2. CABEÇA LARGA, ORELHAS TRIANGULARES E MÁSCARA FACIAL EM CORAÇÃO
    _add_part(
        parts,
        create_icosphere("_tmp_head_main", 2, 0.50, (0.0, -0.02, 1.72), scale=(1.12, 1.00, 0.92)),
        mat_prefix,
        "body_teal",
        pal,
    )
    # Orelhas triangulares pontudas no topo da cabeça
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{tag}",
                6,
                0.22,
                0.03,
                0.42,
                (side * 0.36, -0.02, 2.12),
                rotation=(math.radians(-6.0), math.radians(side * 16.0), 0.0),
                scale=(0.94, 0.72, 1.0),
            ),
            mat_prefix,
            "body_teal",
            pal,
        )

    # Máscara facial creme em formato de coração (bochechas + queixo + recorte V na testa)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_face_lobe_{tag}",
                2,
                0.30,
                (side * 0.18, -0.34, 1.68),
                scale=(1.04, 0.72, 1.02),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )
    _add_part(
        parts,
        create_icosphere("_tmp_face_chin", 2, 0.30, (0.0, -0.38, 1.56), scale=(1.22, 0.72, 0.82)),
        mat_prefix,
        "belly_cream",
        pal,
    )
    # Pico em V azul-petróleo descendo no centro da testa (assinatura clássica do Snorlax!)
    _add_part(
        parts,
        create_cone(
            "_tmp_forehead_vpeak",
            4,
            0.18,
            0.025,
            0.28,
            (0.0, -0.44, 1.88),
            rotation=(math.radians(164.0), 0.0, math.radians(45.0)),
            scale=(1.14, 0.56, 1.0),
        ),
        mat_prefix,
        "body_teal",
        pal,
    )

    # Rosto adormecido: olhos fechados em risco escuro, sorriso e 2 presinhas brancas
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_closed_eye_{tag}",
                (0.22, 0.05, 0.032),
                (side * 0.22, -0.58, 1.66),
                rotation=(0.0, math.radians(side * 6.0), math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
    # Linha da boca serena
    _add_part(
        parts,
        create_cube("_tmp_mouth_line", (0.28, 0.05, 0.028), (0.0, -0.60, 1.50)),
        mat_prefix,
        "eye_dark",
        pal,
    )
    # 2 presinhas brancas pontudas para cima nos cantos da boca
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                4,
                0.038,
                0.008,
                0.095,
                (side * 0.13, -0.62, 1.54),
                rotation=(math.radians(-10.0), 0.0, 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 3. BRAÇOS RECHONCHUDOS ABERTOS COM 5 GARRINHAS BRANCAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_{tag}",
                8,
                0.34,
                0.18,
                0.88,
                (side * 0.90, -0.02, 1.18),
                rotation=(math.radians(-10.0), math.radians(side * 124.0), 0.0),
                scale=(1.0, 0.84, 1.0),
            ),
            mat_prefix,
            "body_teal",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hand_{tag}",
                2,
                0.18,
                (side * 1.18, -0.08, 0.96),
                scale=(1.04, 0.88, 0.82),
            ),
            mat_prefix,
            "body_teal",
            pal,
        )
        # 4 garras brancas visíveis na ponta de cada mão
        for c_idx, (dy, dz) in enumerate([(-0.10, -0.06), (-0.03, -0.10), (0.04, -0.10), (0.10, -0.06)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{tag}_{c_idx}",
                    4,
                    0.032,
                    0.008,
                    0.11,
                    (side * 1.30, -0.08 + dy, 0.94 + dz),
                    rotation=(0.0, math.radians(side * 130.0), 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 4. PÉS REDONDOS ENORMES CREME COM ALMOFADAS MARRONS E 3 GARRAS BRANCAS (Z = 0.0)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa curta ligando o corpo ao pé sentado
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hip_{tag}",
                2,
                0.34,
                (side * 0.56, -0.22, 0.34),
                scale=(1.02, 1.06, 0.86),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )
        # Grande pé redondo creme virado para frente
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.36,
                (side * 0.68, -0.60, 0.34),
                rotation=(0.0, 0.0, math.radians(side * -16.0)),
                scale=(1.00, 0.72, 1.02),
            ),
            mat_prefix,
            "belly_cream",
            pal,
        )
        # Almofada marrom oval no centro da sola do pé
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_pad_{tag}",
                2,
                0.20,
                (side * 0.70, -0.80, 0.28),
                rotation=(0.0, 0.0, math.radians(side * -16.0)),
                scale=(0.98, 0.38, 1.06),
            ),
            mat_prefix,
            "pad_brown",
            pal,
        )
        # 3 garras brancas grandes no topo de cada pé
        claw_specs = [
            (-0.20, 0.24, -26.0),
            (0.00, 0.32, 0.0),
            (0.20, 0.24, 26.0),
        ]
        for c_idx, (dx, dz, ry_c) in enumerate(claw_specs):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_claw_{tag}_{c_idx}",
                    5,
                    0.072,
                    0.015,
                    0.20,
                    (side * 0.68 + dx, -0.66, 0.34 + dz),
                    rotation=(math.radians(-18.0), math.radians(ry_c), 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 143. Slumberbear lado a lado."""
    specs = [
        ("Slumberbear_Shiny", (-10.4, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Slumberbear_Normal", (-6.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Slumberbear_Grande", (-1.0, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Slumberbear_Gigante", (5.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Slumberbear_Dourada_SuperRara", (13.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_slumberbear(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
