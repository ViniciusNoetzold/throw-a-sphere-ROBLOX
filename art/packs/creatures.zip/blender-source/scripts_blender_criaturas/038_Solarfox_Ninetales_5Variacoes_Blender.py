"""
038_Solarfox_Ninetales_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "038. Solarfox — Kitsune Dourada (Ref: Ninetales)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Solarfox_Shiny (1.0x - Paleta Shiny Prata-Platina + Pontas das 9 Caudas Azul-Safira)
  2. Solarfox_Normal (1.0x - Dourado-Creme + 9 Caudas com Pontas Laranja-Solar + Olhos Rubi)
  3. Solarfox_Grande (1.35x - Normal)
  4. Solarfox_Gigante (1.85x - Normal)
  5. Solarfox_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Pontas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + cones 6-8 lados para as 9 caudas e crista)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "fur_gold": (0.96, 0.90, 0.60, 1.0),
        "fur_cream": (0.99, 0.96, 0.78, 1.0),
        "fur_shade": (0.82, 0.74, 0.44, 1.0),
        "tail_tip": (0.94, 0.56, 0.18, 1.0),
        "eye_ruby": (0.88, 0.16, 0.20, 1.0),
        "dark_accent": (0.14, 0.12, 0.12, 1.0),
        "white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "fur_gold": (0.86, 0.88, 0.94, 1.0),
        "fur_cream": (0.96, 0.97, 1.00, 1.0),
        "fur_shade": (0.70, 0.74, 0.84, 1.0),
        "tail_tip": (0.36, 0.56, 0.94, 1.0),
        "eye_ruby": (0.88, 0.16, 0.22, 1.0),
        "dark_accent": (0.14, 0.14, 0.18, 1.0),
        "white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "fur_gold": (0.98, 0.78, 0.14, 1.0),
        "fur_cream": (1.00, 0.92, 0.44, 1.0),
        "fur_shade": (0.84, 0.60, 0.08, 1.0),
        "tail_tip": (0.10, 0.92, 1.00, 1.0),
        "eye_ruby": (0.10, 0.92, 1.00, 1.0),
        "dark_accent": (0.06, 0.54, 0.70, 1.0),
        "white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_solarfox(
    name: str = "Solarfox_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D de alta fidelidade do 038. Solarfox (Ref: Ninetales):
      - Kitsune elegante sentada com postura nobre, peito empinado e pescoço longo arqueado
      - Gola fofa em camadas no peito (creme-claro), patas esguias alinhadas em Z = 0.0
      - Cabeça afilada de raposa com olhos rubi amendoados e crista de 4 plumas fluindo para trás
      - 9 caudas majestosas em leque radiante com pontas laranja-solar (azul-safira na Shiny),
        incluindo 2 caudas dianteiras contornando elegantemente as patas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Solarfox_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Solarfox_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Solarfox_Norm"

    parts = []

    # 1. CORPO ESGUIO SENTADO + QUADRIL + PATAS DIANTEIRAS E TRASEIRAS
    _add_part(
        parts,
        create_icosphere("_tmp_chest", 2, 0.44, (0.0, -0.14, 1.08), scale=(0.84, 0.96, 1.18)),
        mat_prefix,
        "fur_gold",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_hips", 2, 0.46, (0.0, 0.24, 0.56), scale=(0.94, 1.10, 0.92)),
        mat_prefix,
        "fur_gold",
        pal,
    )
    # Gola fofa de pelos no peito (em formato de leque/escudo)
    _add_part(
        parts,
        create_icosphere("_tmp_mane_main", 2, 0.42, (0.0, -0.34, 1.24), scale=(0.92, 0.72, 1.14)),
        mat_prefix,
        "fur_cream",
        pal,
    )
    for m_idx, (mx, mz, md, ry) in enumerate([(-0.18, 0.92, 0.42, -14.0), (0.0, 0.84, 0.52, 0.0), (0.18, 0.92, 0.42, 14.0)]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_mane_tuft_{m_idx}",
                6,
                0.18,
                0.02,
                md,
                (mx, -0.48, mz),
                rotation=(math.radians(170.0), math.radians(ry), 0.0),
                scale=(1.0, 0.55, 1.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )

    # Patas dianteiras esguias e retas apoiadas em Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fleg_{tag}",
                8,
                0.095,
                0.155,
                0.96,
                (side * 0.22, -0.28, 0.50),
                rotation=(math.radians(-4.0), 0.0, 0.0),
            ),
            mat_prefix,
            "fur_gold",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_fpaw_{tag}",
                1,
                0.115,
                (side * 0.22, -0.36, 0.06),
                scale=(0.96, 1.32, 0.56),
            ),
            mat_prefix,
            "fur_gold",
            pal,
        )
        # Coxas traseiras dobradas na pose sentada
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.28,
                (side * 0.34, 0.22, 0.44),
                rotation=(math.radians(-18.0), 0.0, math.radians(side * -14.0)),
                scale=(0.74, 1.24, 1.02),
            ),
            mat_prefix,
            "fur_gold",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hpaw_{tag}",
                1,
                0.12,
                (side * 0.36, -0.02, 0.07),
                scale=(0.94, 1.38, 0.56),
            ),
            mat_prefix,
            "fur_shade",
            pal,
        )

    # 2. PESCOÇO LONGO ARQUEADO + CABEÇA DE RAPOSA NOBRE
    _add_part(
        parts,
        create_cone(
            "_tmp_neck",
            8,
            0.26,
            0.18,
            0.78,
            (0.0, -0.22, 1.62),
            rotation=(math.radians(10.0), 0.0, 0.0),
        ),
        mat_prefix,
        "fur_gold",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.34, (0.0, -0.32, 2.02), scale=(0.94, 1.08, 0.92)),
        mat_prefix,
        "fur_gold",
        pal,
    )
    # Focinho longo afilado
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            8,
            0.20,
            0.055,
            0.54,
            (0.0, -0.70, 1.94),
            rotation=(math.radians(-84.0), 0.0, 0.0),
            scale=(0.86, 0.78, 1.0),
        ),
        mat_prefix,
        "fur_gold",
        pal,
    )
    # Nariz preto pequeno na ponta do focinho
    _add_part(
        parts,
        create_icosphere("_tmp_nose", 1, 0.048, (0.0, -0.96, 1.97), scale=(1.05, 0.85, 0.78)),
        mat_prefix,
        "dark_accent",
        pal,
    )
    # Olhos rubi amendoados ferozes e elegantes
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                1,
                0.105,
                (side * 0.18, -0.57, 2.06),
                rotation=(math.radians(8.0), math.radians(side * -14.0), math.radians(side * -16.0)),
                scale=(1.28, 0.44, 0.62),
            ),
            mat_prefix,
            "eye_ruby",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.032,
                (side * 0.16, -0.62, 2.08),
                scale=(0.88, 0.46, 0.88),
            ),
            mat_prefix,
            "white",
            pal,
        )

    # Orelhas pontiagudas erguidas
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{tag}",
                6,
                0.15,
                0.018,
                0.56,
                (side * 0.26, -0.22, 2.38),
                rotation=(math.radians(-12.0), math.radians(side * 22.0), math.radians(side * -10.0)),
                scale=(1.0, 0.48, 1.0),
            ),
            mat_prefix,
            "fur_gold",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_in_{tag}",
                4,
                0.09,
                0.014,
                0.38,
                (side * 0.25, -0.27, 2.36),
                rotation=(math.radians(-12.0), math.radians(side * 22.0), math.radians(side * -10.0)),
                scale=(1.0, 0.34, 1.0),
            ),
            mat_prefix,
            "fur_shade",
            pal,
        )

    # Crista majestosa de 4 plumas fluindo para cima e para trás
    crest_plumes = [
        (0.00, -0.06, 2.48, 0.19, 0.88, 34.0, 0.0),
        (0.00, 0.10, 2.36, 0.17, 0.90, 62.0, 0.0),
        (-0.18, 0.06, 2.28, 0.14, 0.78, 72.0, -24.0),
        (0.18, 0.06, 2.28, 0.14, 0.78, 72.0, 24.0),
    ]
    for p_idx, (px, py, pz, pr, pd, rx, rz) in enumerate(crest_plumes):
        _add_part(
            parts,
            create_cone(
                f"_tmp_crest_{p_idx}",
                6,
                pr,
                0.018,
                pd,
                (px, py, pz),
                rotation=(math.radians(rx), 0.0, math.radians(rz)),
                scale=(0.88, 1.0, 1.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )

    # 3. NOVE CAUDAS MAJESTOSAS EM HALO + PONTAS LARANJA-SOLAR (AZUL-SAFIRA NA SHINY)
    # 7 caudas em grande leque arqueado atrás (fanning -1.48 a +1.48 em X e até 2.70 em Z)
    fan_tails = [
        # (ang_deg, length_scale, z_lift, y_back)
        (-68.0, 0.94, 0.15, 0.74),
        (-46.0, 1.04, 0.32, 0.84),
        (-24.0, 1.12, 0.46, 0.92),
        (0.0, 1.18, 0.54, 0.98),
        (24.0, 1.12, 0.46, 0.92),
        (46.0, 1.04, 0.32, 0.84),
        (68.0, 0.94, 0.15, 0.74),
    ]
    for t_idx, (ang_deg, l_sc, z_lift, y_back) in enumerate(fan_tails):
        rad = math.radians(ang_deg)
        sx = math.sin(rad)
        cz = math.cos(rad)
        p1 = (sx * 0.52 * l_sc, 0.56 + (y_back - 0.56) * 0.45, 0.62 + cz * 0.52 * l_sc + z_lift * 0.4)
        p2 = (sx * 1.02 * l_sc, y_back, 0.88 + cz * 1.08 * l_sc + z_lift)
        p3 = (sx * 1.24 * l_sc, y_back - 0.16, 1.06 + cz * 1.38 * l_sc + z_lift * 1.12)

        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_base_{t_idx}",
                7,
                0.15,
                0.28,
                0.96 * l_sc,
                p1,
                rotation=(math.radians(-24.0), math.radians(ang_deg * 0.95), 0.0),
                scale=(1.0, 0.80, 1.0),
            ),
            mat_prefix,
            "fur_gold",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_tail_body_{t_idx}",
                2,
                0.30,
                p2,
                rotation=(math.radians(-10.0), math.radians(ang_deg * 0.82), 0.0),
                scale=(0.88, 0.78, 1.56),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_tip_{t_idx}",
                7,
                0.22,
                0.025,
                0.56 * l_sc,
                p3,
                rotation=(math.radians(24.0), math.radians(ang_deg * 0.72), 0.0),
                scale=(0.94, 0.76, 1.0),
            ),
            mat_prefix,
            "tail_tip",
            pal,
        )

    # 2 caudas frontais inferiores (8ª e 9ª) envolvendo graciosamente as patas como na arte oficial!
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_low_tail_base_{tag}",
                2,
                0.26,
                (side * 0.72, 0.26, 0.36),
                rotation=(0.0, 0.0, math.radians(side * 34.0)),
                scale=(0.84, 1.56, 0.78),
            ),
            mat_prefix,
            "fur_gold",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_low_tail_mid_{tag}",
                2,
                0.22,
                (side * 0.96, -0.18, 0.32),
                rotation=(0.0, 0.0, math.radians(side * -24.0)),
                scale=(0.78, 1.42, 0.68),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_low_tail_tip_{tag}",
                6,
                0.15,
                0.018,
                0.62,
                (side * 0.72, -0.58, 0.26),
                rotation=(math.radians(-86.0), 0.0, math.radians(side * -52.0)),
                scale=(0.88, 0.70, 1.0),
            ),
            mat_prefix,
            "tail_tip",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 038. Solarfox lado a lado."""
    specs = [
        ("Solarfox_Shiny", (-11.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Solarfox_Normal", (-6.5, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Solarfox_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Solarfox_Gigante", (6.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Solarfox_Dourada_SuperRara", (15.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_solarfox(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
