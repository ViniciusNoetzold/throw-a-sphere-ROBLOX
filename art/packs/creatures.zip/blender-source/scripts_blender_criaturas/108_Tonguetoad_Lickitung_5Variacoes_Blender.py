"""
108_Tonguetoad_Lickitung_5Variacoes_Blender.py
==============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "108. Tonguetoad — Lagarto da Língua (Ref: Lickitung)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Tonguetoad_Shiny (1.0x - Paleta Shiny Amarelo-Dourado + Listras Creme + Língua Rosa)
  2. Tonguetoad_Normal (1.0x - Rosa-Pastel + Listras Amarelo-Creme + Língua Longa + Cauda Arqueada)
  3. Tonguetoad_Grande (1.35x - Normal)
  4. Tonguetoad_Gigante (1.85x - Normal)
  5. Tonguetoad_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Listras Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para tronco/língua/cauda, cones 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e rosto/língua apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_pink": (0.95, 0.65, 0.72, 1.0),
        "body_shade": (0.82, 0.50, 0.58, 1.0),
        "stripe_cream": (0.96, 0.92, 0.68, 1.0),
        "tongue_pink": (0.96, 0.70, 0.79, 1.0),
        "tongue_tip": (0.99, 0.84, 0.90, 1.0),
        "mouth_deep": (0.48, 0.34, 0.44, 1.0),
        "eye_dark": (0.12, 0.14, 0.22, 1.0),
        "claw_white": (0.98, 0.98, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_pink": (0.96, 0.84, 0.28, 1.0),
        "body_shade": (0.80, 0.66, 0.18, 1.0),
        "stripe_cream": (0.98, 0.96, 0.84, 1.0),
        "tongue_pink": (0.98, 0.62, 0.74, 1.0),
        "tongue_tip": (0.99, 0.78, 0.86, 1.0),
        "mouth_deep": (0.54, 0.32, 0.40, 1.0),
        "eye_dark": (0.12, 0.14, 0.22, 1.0),
        "claw_white": (0.98, 0.98, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_pink": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.60, 0.08, 1.0),
        "stripe_cream": (1.00, 0.94, 0.56, 1.0),
        "tongue_pink": (0.10, 0.92, 1.00, 1.0),
        "tongue_tip": (0.68, 0.98, 1.00, 1.0),
        "mouth_deep": (0.62, 0.40, 0.06, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "claw_white": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_tonguetoad(
    name: str = "Tonguetoad_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 108. Tonguetoad (Ref: Lickitung):
      - Corpo bípede atarracado em forma de pera com cabeça arredondada contínua
      - 3 listras amarelas-creme horizontais na barriga e anéis ovais creme nas coxas
      - Boca larga sorridente com enorme língua rosa comprida estendida para frente e baixo
      - Braços curtos rechonchudos com garras brancas, patas grossas com unhas brancas largas
      - Cauda colossal espessa arqueada subindo pelo lado direito da silhueta
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Tongue_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Tongue_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Tongue_Norm"

    parts = []

    # 1. CORPO ATARRACADO EM PERA + CABEÇA ARREDONDADA CONTÍNUA
    _add_part(
        parts,
        create_icosphere("_tmp_belly_lower", 2, 0.78, (0.0, 0.08, 0.80), scale=(1.04, 0.94, 0.92)),
        mat_prefix,
        "body_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_torso_upper", 2, 0.64, (0.0, 0.04, 1.26), scale=(0.98, 0.90, 0.94)),
        mat_prefix,
        "body_pink",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_head_dome", 2, 0.54, (0.0, -0.06, 1.66), scale=(1.02, 0.98, 0.92)),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Focinho / lábio superior largo
    _add_part(
        parts,
        create_icosphere("_tmp_snout_upper", 2, 0.36, (0.0, -0.44, 1.56), scale=(1.18, 0.82, 0.58)),
        mat_prefix,
        "body_pink",
        pal,
    )
    # Narinas sutis
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(f"_tmp_nostril_{tag}", 1, 0.032, (side * 0.11, -0.71, 1.60), scale=(0.9, 0.5, 1.1)),
            mat_prefix,
            "body_shade",
            pal,
        )

    # 2. LISTRAS AMARELAS-CREME NA BARRIGA (3 FAIXAS CURVAS EM RELEVO)
    belly_bands = [
        (0.49, (0.0, -0.14, 1.14), (1.08, 0.98, 0.28)),
        (0.60, (0.0, -0.10, 0.86), (1.06, 1.02, 0.25)),
        (0.58, (0.0, -0.06, 0.58), (1.02, 1.02, 0.23)),
    ]
    for b_idx, (rad, loc, sc) in enumerate(belly_bands):
        _add_part(
            parts,
            create_icosphere(f"_tmp_stripe_{b_idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "stripe_cream",
            pal,
        )

    # 3. ROSTO EXPRESSIVO: OLHOS OVAIS + BOCA ABERTA + LÍNGUA GIGANTE ESTENDIDA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.095,
                (side * 0.28, -0.50, 1.78),
                scale=(0.72, 0.48, 1.16),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.036,
                (side * 0.27, -0.545, 1.82),
                scale=(0.8, 0.5, 1.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # Interior escuro da boca aberta
    _add_part(
        parts,
        create_icosphere("_tmp_mouth_open", 2, 0.34, (0.0, -0.44, 1.38), scale=(1.16, 0.58, 0.68)),
        mat_prefix,
        "mouth_deep",
        pal,
    )

    # LÍNGUA GIGANTE CURVANDO PARA FRENTE E PARA BAIXO (ASSINATURA DO LICKITUNG)
    tongue_segs = [
        # (rad, loc, rot_x_deg, rot_z_deg, scale, mat_key)
        (0.24, (-0.02, -0.58, 1.28), 38.0, 6.0, (1.16, 0.88, 0.42), "tongue_pink"),
        (0.27, (-0.06, -0.80, 1.08), 48.0, 8.0, (1.22, 0.96, 0.36), "tongue_pink"),
        (0.30, (-0.11, -1.00, 0.84), 56.0, 10.0, (1.28, 1.02, 0.34), "tongue_pink"),
        (0.32, (-0.15, -1.16, 0.58), 64.0, 11.0, (1.32, 1.00, 0.32), "tongue_tip"),
        (0.30, (-0.17, -1.24, 0.36), 72.0, 11.0, (1.30, 0.90, 0.30), "tongue_tip"),
    ]
    for t_idx, (rad, loc, rx, rz, sc, mkey) in enumerate(tongue_segs):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_tongue_{t_idx}",
                2,
                rad,
                loc,
                rotation=(math.radians(rx), 0.0, math.radians(rz)),
                scale=sc,
            ),
            mat_prefix,
            mkey,
            pal,
        )
    # Sulco central sutil ao longo da língua para leitura nítida
    _add_part(
        parts,
        create_cylinder(
            "_tmp_tongue_groove",
            6,
            0.028,
            0.82,
            (-0.09, -0.94, 0.92),
            rotation=(math.radians(-42.0), math.radians(-10.0), math.radians(8.0)),
            scale=(0.8, 0.5, 1.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    # 4. BRAÇOS CURTOS RECHONCHUDOS ABERTOS COM GARRINHA BRANCA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_arm_{tag}",
                8,
                0.24,
                0.18,
                0.56,
                (side * 0.78, -0.06, 1.22),
                rotation=(math.radians(-10.0), math.radians(side * 80.0), math.radians(side * -12.0)),
                scale=(1.0, 0.94, 1.0),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_hand_{tag}", 2, 0.19, (side * 1.02, -0.12, 1.16), scale=(1.08, 0.90, 0.86)),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_hand_claw_{tag}",
                5,
                0.052,
                0.010,
                0.13,
                (side * 1.04, -0.16, 1.00),
                rotation=(math.radians(170.0), math.radians(side * -14.0), 0.0),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 5. PERNAS GROSSAS COM ANEL CREME NAS COXAS E PATAS COM UNHA BRANCA EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.42,
                (side * 0.56, -0.04, 0.48),
                scale=(0.88, 1.04, 1.12),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        # Anel amarelo-creme característico na lateral/frente da coxa
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_ring_{tag}",
                2,
                0.21,
                (side * 0.72, -0.26, 0.48),
                rotation=(0.0, 0.0, math.radians(side * 34.0)),
                scale=(0.94, 0.36, 1.04),
            ),
            mat_prefix,
            "stripe_cream",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_ring_core_{tag}",
                1,
                0.11,
                (side * 0.75, -0.31, 0.48),
                rotation=(0.0, 0.0, math.radians(side * 34.0)),
                scale=(0.88, 0.34, 0.96),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        # Pé curto apoiado no chão + unha branca arredondada
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.26,
                (side * 0.58, -0.18, 0.16),
                scale=(1.02, 1.24, 0.64),
            ),
            mat_prefix,
            "body_pink",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_toenail_{tag}",
                1,
                0.16,
                (side * 0.58, -0.44, 0.09),
                scale=(1.12, 0.92, 0.52),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 6. CAUDA GIGANTE ESPESSA ARQUEADA ATRÁS E PARA A DIREITA (+X)
    tail_nodes = [
        # (rad, loc, scale)
        (0.56, (0.20, 0.62, 0.56), (1.02, 1.02, 1.00)),
        (0.54, (0.58, 0.76, 0.88), (1.00, 0.98, 1.08)),
        (0.50, (0.86, 0.76, 1.28), (1.00, 0.92, 1.06)),
        (0.46, (1.06, 0.68, 1.56), (1.04, 0.88, 0.98)),
        (0.42, (1.28, 0.60, 1.44), (0.96, 0.86, 1.06)),
        (0.36, (1.42, 0.54, 1.12), (0.90, 0.84, 1.14)),
        (0.28, (1.44, 0.50, 0.74), (0.86, 0.82, 1.18)),
        (0.20, (1.38, 0.46, 0.44), (0.82, 0.80, 1.14)),
    ]
    for tl_idx, (rad, loc, sc) in enumerate(tail_nodes):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tail_{tl_idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "body_pink",
            pal,
        )
    # Ponta afilada da cauda curvando para baixo-trás
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_tip",
            6,
            0.18,
            0.03,
            0.38,
            (1.36, 0.44, 0.24),
            rotation=(math.radians(176.0), math.radians(-14.0), 0.0),
        ),
        mat_prefix,
        "body_shade",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 108. Tonguetoad lado a lado."""
    specs = [
        ("Tonguetoad_Shiny", (-9.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Tonguetoad_Normal", (-5.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Tonguetoad_Grande", (-0.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Tonguetoad_Gigante", (5.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Tonguetoad_Dourada_SuperRara", (13.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_tonguetoad(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
