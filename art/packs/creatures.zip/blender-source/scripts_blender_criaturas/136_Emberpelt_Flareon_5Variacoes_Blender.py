"""
136_Emberpelt_Flareon_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "136. Emberpelt — Raposa de Flama (Ref: Flareon)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Emberpelt_Shiny (1.0x - Paleta Shiny Ocre-Dourado + Juba e Cauda Creme-Claro)
  2. Emberpelt_Normal (1.0x - Laranja-Brasa + Topete de Chama, Juba Macia e Cauda Enorme Creme)
  3. Emberpelt_Grande (1.35x - Normal)
  4. Emberpelt_Gigante (1.85x - Normal)
  5. Emberpelt_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos e Juba Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para juba fofa, corpo e cauda flamejante + cones para orelhas e pontas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patinhas alinhadas exatamente em `Z = 0.0` e rosto/focinho apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_orange": (0.92, 0.44, 0.20, 1.0),
        "body_shade": (0.76, 0.32, 0.14, 1.0),
        "paw_light": (0.96, 0.62, 0.36, 1.0),
        "fur_cream": (0.96, 0.88, 0.56, 1.0),
        "fur_shade": (0.86, 0.76, 0.44, 1.0),
        "ear_inner": (0.10, 0.16, 0.22, 1.0),
        "eye_dark": (0.09, 0.10, 0.14, 1.0),
        "eye_teal": (0.12, 0.30, 0.42, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "mouth_pink": (0.82, 0.42, 0.48, 1.0),
    },
    "shiny_palette": {
        "body_orange": (0.86, 0.68, 0.28, 1.0),
        "body_shade": (0.72, 0.54, 0.20, 1.0),
        "paw_light": (0.94, 0.80, 0.46, 1.0),
        "fur_cream": (0.98, 0.94, 0.72, 1.0),
        "fur_shade": (0.88, 0.82, 0.56, 1.0),
        "ear_inner": (0.14, 0.14, 0.18, 1.0),
        "eye_dark": (0.09, 0.10, 0.14, 1.0),
        "eye_teal": (0.14, 0.32, 0.44, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "mouth_pink": (0.84, 0.44, 0.50, 1.0),
    },
    "golden_super_rare_palette": {
        "body_orange": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.84, 0.62, 0.08, 1.0),
        "paw_light": (1.00, 0.90, 0.42, 1.0),
        "fur_cream": (0.10, 0.92, 1.00, 1.0),
        "fur_shade": (0.06, 0.66, 0.82, 1.0),
        "ear_inner": (0.06, 0.48, 0.66, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "eye_teal": (0.44, 0.96, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.94, 1.0),
        "mouth_pink": (0.94, 0.72, 0.24, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une primitivas, normaliza a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_emberpelt(
    name: str = "Emberpelt_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 136. Emberpelt (Ref: Flareon):
      - Corpo felpudo quadrúpede laranja-brasa em postura ágil e fofa
      - Juba volumosa e macia amarelo-creme em nuvens/tufos envolvendo todo o pescoço e peito
      - Topete de chama curvado creme-amarelo no topo da cabeça
      - Orelhas longas e largas com interior escuro-azulado
      - Cauda enorme, macia e flamejante erguida atrás do dorso
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Emb_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Emb_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Emb_Norm"

    parts = []

    # 1. TRONCO QUADRÚPEDE LARANJA-BRASA (LEVE AGACHAMENTO DINÂMICO)
    _add_part(
        parts,
        create_icosphere("_tmp_chest", 2, 0.44, (0.0, -0.14, 0.78), scale=(0.96, 1.12, 0.92)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_torso_mid", 2, 0.42, (0.0, 0.20, 0.80), scale=(0.94, 1.18, 0.90)),
        mat_prefix,
        "body_orange",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_rump", 2, 0.42, (0.0, 0.50, 0.84), scale=(0.98, 1.04, 0.94)),
        mat_prefix,
        "body_orange",
        pal,
    )

    # 2. JUBA IMENSA E FELPUDA CREME AO REDOR DO PESCOÇO E PEITO
    mane_puffs = [
        (0.46, (0.0, -0.34, 0.88), (1.16, 1.02, 0.96), "fur_cream"),
        (0.36, (0.0, -0.58, 0.76), (1.12, 0.90, 0.92), "fur_cream"),
        (0.34, (-0.36, -0.44, 0.86), (0.98, 0.98, 0.96), "fur_cream"),
        (0.34, (0.36, -0.44, 0.86), (0.98, 0.98, 0.96), "fur_cream"),
        (0.30, (-0.42, -0.18, 0.98), (0.96, 1.02, 0.96), "fur_shade"),
        (0.30, (0.42, -0.18, 0.98), (0.96, 1.02, 0.96), "fur_shade"),
        (0.32, (0.0, -0.14, 1.10), (1.14, 0.96, 0.86), "fur_cream"),
    ]
    for idx, (rad, loc, sc, mkey) in enumerate(mane_puffs):
        _add_part(
            parts,
            create_icosphere(f"_tmp_mane_puff_{idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            mkey,
            pal,
        )
    # Tufos suaves nas pontas da juba para silhueta fofa e flamejante
    mane_tufts = [
        ((0.0, -0.78, 0.56), (-148.0, 0.0, 0.0), 0.16, 0.34),
        ((-0.34, -0.68, 0.64), (-140.0, -30.0, 0.0), 0.15, 0.32),
        ((0.34, -0.68, 0.64), (-140.0, 30.0, 0.0), 0.15, 0.32),
        ((-0.56, -0.42, 0.84), (112.0, -68.0, 0.0), 0.15, 0.34),
        ((0.56, -0.42, 0.84), (112.0, 68.0, 0.0), 0.15, 0.34),
        ((-0.44, -0.06, 1.18), (44.0, -48.0, 0.0), 0.15, 0.34),
        ((0.44, -0.06, 1.18), (44.0, 48.0, 0.0), 0.15, 0.34),
    ]
    for idx, (loc, (rx, ry, rz), r1, dep) in enumerate(mane_tufts):
        _add_part(
            parts,
            create_cone(
                f"_tmp_mane_tuft_{idx}",
                6,
                r1,
                0.02,
                dep,
                loc,
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )

    # 3. CABEÇA FOFA, ROSTO EXPRESSIVO E TOPETE DE CHAMA CREME
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.43, (0.0, -0.58, 1.24), scale=(1.02, 1.04, 0.92)),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Focinho curto e macio
    _add_part(
        parts,
        create_icosphere("_tmp_snout", 2, 0.22, (0.0, -0.92, 1.15), scale=(1.04, 1.08, 0.82)),
        mat_prefix,
        "body_orange",
        pal,
    )
    # Narizinho escuro
    _add_part(
        parts,
        create_icosphere("_tmp_nose", 1, 0.048, (0.0, -1.12, 1.18), scale=(1.15, 0.78, 0.70)),
        mat_prefix,
        "eye_dark",
        pal,
    )
    # Boquinha aberta fofa sob o focinho
    _add_part(
        parts,
        create_icosphere("_tmp_mouth", 1, 0.065, (0.0, -1.03, 1.04), scale=(0.95, 0.55, 0.85)),
        mat_prefix,
        "mouth_pink",
        pal,
    )

    # Olhos amendoados grandes com reflexo azulado e brilho branco
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                2,
                0.125,
                (side * 0.24, -0.88, 1.24),
                rotation=(0.0, math.radians(side * -12.0), math.radians(side * -22.0)),
                scale=(0.88, 0.48, 1.12),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_iris_{tag}",
                1,
                0.080,
                (side * 0.25, -0.92, 1.21),
                rotation=(0.0, 0.0, math.radians(side * -20.0)),
                scale=(0.82, 0.42, 0.90),
            ),
            mat_prefix,
            "eye_teal",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.042,
                (side * 0.22, -0.96, 1.29),
                scale=(0.82, 0.46, 0.96),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # Topete icônico de chama curvado no topo da testa (Flareon signature!)
    crest_parts = [
        (0.24, (0.0, -0.78, 1.54), (0.94, 1.12, 0.92)),
        (0.21, (0.0, -0.68, 1.66), (0.86, 1.16, 0.96)),
        (0.16, (0.0, -0.58, 1.76), (0.76, 1.06, 1.02)),
    ]
    for idx, (rad, loc, sc) in enumerate(crest_parts):
        _add_part(
            parts,
            create_icosphere(f"_tmp_crest_{idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "fur_cream",
            pal,
        )
    _add_part(
        parts,
        create_cone(
            "_tmp_crest_tip",
            6,
            0.13,
            0.015,
            0.34,
            (0.0, -0.50, 1.92),
            rotation=(math.radians(24.0), 0.0, 0.0),
            scale=(0.76, 1.0, 1.0),
        ),
        mat_prefix,
        "fur_cream",
        pal,
    )

    # 4. ORELHAS LONGAS DE RAPOSA COM INTERIOR ESCURO-AZULADO
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_outer_{tag}",
                6,
                0.24,
                0.022,
                0.96,
                (side * 0.48, -0.34, 1.72),
                rotation=(math.radians(28.0), math.radians(side * 38.0), math.radians(side * -10.0)),
                scale=(1.0, 0.46, 1.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_inner_{tag}",
                5,
                0.155,
                0.016,
                0.70,
                (side * 0.47, -0.39, 1.70),
                rotation=(math.radians(28.0), math.radians(side * 38.0), math.radians(side * -10.0)),
                scale=(0.94, 0.36, 1.0),
            ),
            mat_prefix,
            "ear_inner",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_tuft_{tag}",
                4,
                0.08,
                0.015,
                0.22,
                (side * 0.62, -0.32, 1.78),
                rotation=(math.radians(34.0), math.radians(side * 58.0), 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )

    # 5. QUATRO PATAS EM POSTURA AGACHADA PRONTA PARA SALTAR (Z = 0.0)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Patas dianteiras um pouco abertas para frente
        _add_part(
            parts,
            create_cone(
                f"_tmp_fleg_upper_{tag}",
                8,
                0.14,
                0.18,
                0.42,
                (side * 0.30, -0.30, 0.48),
                rotation=(math.radians(-24.0), math.radians(side * 10.0), 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_fleg_lower_{tag}",
                8,
                0.115,
                0.14,
                0.38,
                (side * 0.34, -0.44, 0.20),
                rotation=(math.radians(-26.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_fpaw_{tag}",
                2,
                0.14,
                (side * 0.35, -0.56, 0.08),
                scale=(0.98, 1.24, 0.62),
            ),
            mat_prefix,
            "paw_light",
            pal,
        )

        # Patas traseiras fortes
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_thigh_{tag}",
                2,
                0.24,
                (side * 0.30, 0.48, 0.64),
                rotation=(math.radians(-20.0), 0.0, 0.0),
                scale=(0.86, 1.18, 1.20),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_hleg_shin_{tag}",
                8,
                0.115,
                0.155,
                0.40,
                (side * 0.32, 0.58, 0.36),
                rotation=(math.radians(-26.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_shade",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_hleg_ankle_{tag}",
                8,
                0.11,
                0.125,
                0.28,
                (side * 0.32, 0.54, 0.16),
                rotation=(math.radians(24.0), 0.0, 0.0),
            ),
            mat_prefix,
            "body_orange",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hpaw_{tag}",
                2,
                0.135,
                (side * 0.32, 0.44, 0.08),
                scale=(0.98, 1.22, 0.62),
            ),
            mat_prefix,
            "paw_light",
            pal,
        )

    # 6. CAUDA ENORME, FELPUDA E FLAMEJANTE CREME ERGUIDA ATRÁS DO CORPO
    tail_clouds = [
        (0.46, (0.0, 0.78, 1.02), (1.06, 1.12, 1.02), "fur_shade"),
        (0.54, (0.0, 0.96, 1.26), (1.12, 1.18, 1.06), "fur_cream"),
        (0.48, (0.0, 1.04, 1.54), (1.02, 1.10, 1.04), "fur_cream"),
        (0.36, (-0.28, 0.94, 1.32), (0.92, 1.02, 0.96), "fur_cream"),
        (0.36, (0.28, 0.94, 1.32), (0.92, 1.02, 0.96), "fur_cream"),
        (0.34, (0.0, 1.14, 1.78), (0.88, 0.96, 1.06), "fur_cream"),
    ]
    for idx, (rad, loc, sc, mkey) in enumerate(tail_clouds):
        _add_part(
            parts,
            create_icosphere(f"_tmp_tail_cloud_{idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            mkey,
            pal,
        )
    # Ponta de chama curvada no topo da cauda + tufos laterais
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_flame_tip",
            6,
            0.24,
            0.02,
            0.58,
            (0.0, 1.20, 2.12),
            rotation=(math.radians(-16.0), 0.0, 0.0),
            scale=(0.86, 1.0, 1.0),
        ),
        mat_prefix,
        "fur_cream",
        pal,
    )
    tail_tufts = [
        ((-0.26, 0.76, 1.66), (-18.0, -24.0, 0.0), 0.16, 0.38),
        ((0.26, 0.76, 1.66), (-18.0, 24.0, 0.0), 0.16, 0.38),
        ((0.0, 0.68, 1.64), (-26.0, 0.0, 0.0), 0.18, 0.42),
    ]
    for idx, (loc, (rx, ry, rz), r1, dep) in enumerate(tail_tufts):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_tuft_{idx}",
                5,
                r1,
                0.018,
                dep,
                loc,
                rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 136. Emberpelt lado a lado."""
    specs = [
        ("Emberpelt_Shiny", (-8.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Emberpelt_Normal", (-5.0, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Emberpelt_Grande", (-0.7, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Emberpelt_Gigante", (4.7, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Emberpelt_Dourada_SuperRara", (11.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_emberpelt(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
