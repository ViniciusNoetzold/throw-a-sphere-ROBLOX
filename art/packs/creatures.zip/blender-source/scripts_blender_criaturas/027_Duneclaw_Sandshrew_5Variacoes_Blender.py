"""
027_Duneclaw_Sandshrew_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "027. Duneclaw — Tatu da Areia (Ref: Sandshrew)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Duneclaw_Shiny (1.0x - Paleta Shiny / Shyne Carapaça Verde-Menta + Barriga Creme)
  2. Duneclaw_Normal (1.0x - Carapaça Amarelo-Areia em Placas + Barriga Branca + Garras Brancas)
  3. Duneclaw_Grande (1.35x - Normal)
  4. Duneclaw_Gigante (1.85x - Normal)
  5. Duneclaw_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e frente/focinho apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Duneclaw_Shiny`, `Duneclaw_Normal`, `Duneclaw_Grande`,
     `Duneclaw_Gigante`, `Duneclaw_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "shell_sand": (0.90, 0.78, 0.40, 1.0),
        "shell_seam": (0.74, 0.58, 0.26, 1.0),
        "belly_white": (0.96, 0.95, 0.90, 1.0),
        "eye_dark": (0.12, 0.16, 0.24, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "shell_sand": (0.58, 0.82, 0.36, 1.0),
        "shell_seam": (0.42, 0.64, 0.24, 1.0),
        "belly_white": (0.96, 0.96, 0.90, 1.0),
        "eye_dark": (0.12, 0.16, 0.24, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "shell_sand": (0.98, 0.78, 0.14, 1.0),
        "shell_seam": (0.82, 0.56, 0.10, 1.0),
        "belly_white": (1.00, 0.96, 0.66, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.94, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_duneclaw(
    name: str = "Duneclaw_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 027. Duneclaw (Ref: Sandshrew):
      - Frente/focinho apontando para -Y e pés apoiados em Z = 0.0
      - Corpo bípede roliço amarelo-areia com placas em tijolos facetados nas costas e cabeça
      - Barriga e queixo brancos, grandes olhos escuros brilhantes e orelhas triangulares
      - Braços curtos com garras duplas brancas e cauda grossa afunilada em placas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Dune_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Dune_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Dune_Norm"

    parts = []

    # 1. CORPO ROLIÇO COM BARRIGA BRANCA + CARAPAÇA EM PLACAS DE TIJOLO
    _add_part(
        parts,
        create_icosphere("_tmp_torso_shell", 1, 0.62, (0.0, 0.08, 0.68), scale=(0.94, 0.96, 1.00)),
        mat_prefix,
        "shell_sand",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_belly_white", 1, 0.50, (0.0, -0.20, 0.62), scale=(0.90, 0.72, 0.96)),
        mat_prefix,
        "belly_white",
        pal,
    )
    # Placas facetadas estilo tijolo nas costas (3 fileiras horizontais + juntas)
    for row_idx, (ry, rz) in enumerate([(0.54, 0.96), (0.60, 0.70), (0.54, 0.44)]):
        _add_part(
            parts,
            create_cube(f"_tmp_back_band_{row_idx}", (0.86, 0.14, 0.06), (0.0, ry, rz)),
            mat_prefix,
            "shell_seam",
            pal,
        )

    # 2. CABEÇA ARREDONDADA EM PLACAS, FOCINHO BRANCO, OLHOS GRANDES E ORELHAS
    _add_part(
        parts,
        create_cube("_tmp_head_shell", (0.86, 0.82, 0.64), (0.0, -0.14, 1.24), rotation=(math.radians(8.0), 0.0, 0.0)),
        mat_prefix,
        "shell_sand",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_head_seam_h", (0.88, 0.84, 0.05), (0.0, -0.14, 1.38), rotation=(math.radians(8.0), 0.0, 0.0)),
        mat_prefix,
        "shell_seam",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_head_seam_v", (0.05, 0.84, 0.34), (0.0, -0.16, 1.44), rotation=(math.radians(8.0), 0.0, 0.0)),
        mat_prefix,
        "shell_seam",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_snout_sand",
            4,
            0.28,
            0.12,
            0.30,
            (0.0, -0.64, 1.20),
            rotation=(math.radians(96.0), 0.0, math.radians(45.0)),
            scale=(1.15, 0.78, 1.0),
        ),
        mat_prefix,
        "shell_sand",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_chin_white", (0.58, 0.44, 0.20), (0.0, -0.44, 1.02)),
        mat_prefix,
        "belly_white",
        pal,
    )

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Olhos grandes expressivos com brilho branco
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_{tag}",
                (0.16, 0.24, 0.26),
                (side * 0.34, -0.48, 1.26),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_shine_{tag}", (0.08, 0.10, 0.11), (side * 0.37, -0.53, 1.32)),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Orelhas triangulares curtas
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_outer_{tag}",
                4,
                0.20,
                0.02,
                0.34,
                (side * 0.38, -0.06, 1.66),
                rotation=(math.radians(-8.0), math.radians(side * 24.0), math.radians(45.0)),
                scale=(1.0, 0.58, 1.0),
            ),
            mat_prefix,
            "shell_sand",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_inner_{tag}",
                4,
                0.12,
                0.02,
                0.22,
                (side * 0.38, -0.11, 1.64),
                rotation=(math.radians(-8.0), math.radians(side * 24.0), math.radians(45.0)),
                scale=(1.0, 0.45, 1.0),
            ),
            mat_prefix,
            "belly_white",
            pal,
        )

    # 3. BRAÇOS CURTOS E PERNAS COM GARRAS DUPLAS BRANCAS TOCANDO Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_arm_{tag}",
                (0.28, 0.44, 0.26),
                (side * 0.46, -0.28, 0.78),
                rotation=(math.radians(16.0), 0.0, math.radians(side * 22.0)),
            ),
            mat_prefix,
            "shell_sand",
            pal,
        )
        for c_idx, dx in enumerate((-0.06, 0.06)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_hand_claw_{tag}_{c_idx}",
                    4,
                    0.05,
                    0.01,
                    0.18,
                    (side * 0.40 + dx, -0.54, 0.72),
                    rotation=(math.radians(104.0), 0.0, 0.0),
                ),
                mat_prefix,
                "belly_white",
                pal,
            )

        # Coxas gorduchas + pés apoiados em Z = 0.0
        _add_part(
            parts,
            create_cube(f"_tmp_thigh_{tag}", (0.34, 0.42, 0.40), (side * 0.42, 0.04, 0.32)),
            mat_prefix,
            "shell_sand",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{tag}", (0.30, 0.42, 0.14), (side * 0.42, -0.12, 0.07)),
            mat_prefix,
            "shell_sand",
            pal,
        )
        for c_idx, dx in enumerate((-0.07, 0.07)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_claw_{tag}_{c_idx}",
                    4,
                    0.06,
                    0.012,
                    0.20,
                    (side * 0.42 + dx, -0.40, 0.06),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "belly_white",
                pal,
            )

    # 4. CAUDA GROSSA AFUNILADA EM PLACAS
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_base",
            6,
            0.24,
            0.14,
            0.54,
            (0.0, 0.74, 0.36),
            rotation=(math.radians(-68.0), 0.0, 0.0),
        ),
        mat_prefix,
        "shell_sand",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_tail_tip",
            6,
            0.14,
            0.025,
            0.46,
            (0.0, 1.12, 0.56),
            rotation=(math.radians(-48.0), 0.0, 0.0),
        ),
        mat_prefix,
        "shell_sand",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 027. Duneclaw lado a lado."""
    specs = [
        ("Duneclaw_Shiny", (-6.2, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Duneclaw_Normal", (-3.5, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Duneclaw_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Duneclaw_Gigante", (3.1, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Duneclaw_Dourada_SuperRara", (7.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_duneclaw(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
