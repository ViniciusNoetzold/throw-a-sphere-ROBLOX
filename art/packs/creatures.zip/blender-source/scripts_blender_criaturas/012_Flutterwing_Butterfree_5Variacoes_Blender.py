"""
012_Flutterwing_Butterfree_5Variacoes_Blender.py
================================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "012. Flutterwing — Borboleta Prisma (Ref: Butterfree)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Flutterwing_Shiny (1.0x - Paleta Shiny / Shyne Asas Rosadas + Olhos Verde-Esmeralda)
  2. Flutterwing_Normal (1.0x - Corpo Índigo + Grandes Asas Brancas Veias Pretas + Olhos Rubi)
  3. Flutterwing_Grande (1.35x - Normal)
  4. Flutterwing_Gigante (1.85x - Normal)
  5. Flutterwing_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 6 lados, cilindros 6-8 lados, icosphere subdiv=1)
  - Bevel final (`width=0.016`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés alinhados exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Flutterwing_Shiny`, `Flutterwing_Normal`, `Flutterwing_Grande`,
     `Flutterwing_Gigante`, `Flutterwing_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.016,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_indigo": (0.38, 0.30, 0.66, 1.0),
        "body_dark": (0.24, 0.18, 0.48, 1.0),
        "wing_white": (0.97, 0.98, 1.00, 1.0),
        "wing_vein": (0.14, 0.14, 0.18, 1.0),
        "eye_ruby": (0.92, 0.18, 0.22, 1.0),
        "limb_blue": (0.76, 0.88, 0.98, 1.0),
        "white_shine": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_indigo": (0.48, 0.34, 0.78, 1.0),
        "body_dark": (0.30, 0.18, 0.56, 1.0),
        "wing_white": (0.99, 0.84, 0.90, 1.0),
        "wing_vein": (0.20, 0.16, 0.24, 1.0),
        "eye_ruby": (0.18, 0.84, 0.42, 1.0),
        "limb_blue": (0.96, 0.56, 0.76, 1.0),
        "white_shine": (1.00, 0.98, 0.99, 1.0),
    },
    "golden_super_rare_palette": {
        "body_indigo": (0.96, 0.74, 0.12, 1.0),
        "body_dark": (0.70, 0.46, 0.06, 1.0),
        "wing_white": (1.00, 0.95, 0.58, 1.0),
        "wing_vein": (0.58, 0.38, 0.06, 1.0),
        "eye_ruby": (0.10, 0.92, 1.00, 1.0),
        "limb_blue": (1.00, 0.92, 0.48, 1.0),
        "white_shine": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_flutterwing(
    name: str = "Flutterwing_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 012. Flutterwing (Ref: Butterfree):
      - Frente apontando para -Y e pés tocando Z = 0.0
      - Corpo índigo oval/blocky, mãozinhas e pezinhos azul-claros
      - Cabeça grande com enormes olhos compostos facetados rubi, focinho com presas e antenas
      - Quatro amplas asas facetadas brancas com bordas e nervuras pretas marcantes
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Flutter_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Flutter_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Flutter"

    parts = []

    # 1. TRONCO ÍNDIGO OVAL + CABEÇA
    _add_part(parts, create_cube("_tmp_torso_main", (0.76, 0.70, 0.86), (0.0, 0.06, 0.72)), mat_prefix, "body_indigo", pal)
    _add_part(parts, create_icosphere("_tmp_belly_bulb", 1, 0.44, (0.0, 0.04, 0.62)), mat_prefix, "body_indigo", pal)
    _add_part(parts, create_cube("_tmp_back_patch", (0.58, 0.24, 0.70), (0.0, 0.36, 0.78)), mat_prefix, "body_dark", pal)

    _add_part(parts, create_cube("_tmp_head_main", (0.82, 0.76, 0.74), (0.0, -0.06, 1.38)), mat_prefix, "body_indigo", pal)
    _add_part(parts, create_icosphere("_tmp_head_crown", 1, 0.45, (0.0, -0.06, 1.44)), mat_prefix, "body_indigo", pal)

    # Focinho claro + presas + grandes olhos compostos facetados rubi
    _add_part(parts, create_cube("_tmp_snout", (0.34, 0.22, 0.22), (0.0, -0.44, 1.24)), mat_prefix, "limb_blue", pal)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(f"_tmp_fang_{tag}", 4, 0.06, 0.01, 0.14, (side * 0.11, -0.48, 1.12), rotation=(math.radians(170.0), 0.0, 0.0)),
            mat_prefix,
            "white_shine",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_{tag}",
                1,
                0.24,
                (side * 0.28, -0.34, 1.42),
                scale=(0.86, 0.74, 1.16),
            ),
            mat_prefix,
            "eye_ruby",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_glint_{tag}", (0.09, 0.06, 0.11), (side * 0.34, -0.50, 1.50)),
            mat_prefix,
            "white_shine",
            pal,
        )
        # Antenas inclinadas para trás e para fora
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_ant_stem_{tag}",
                6,
                0.045,
                0.56,
                (side * 0.24, 0.12, 1.88),
                rotation=(math.radians(-28.0), math.radians(side * 24.0), 0.0),
            ),
            mat_prefix,
            "body_dark",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ant_club_{tag}",
                6,
                0.08,
                0.03,
                0.18,
                (side * 0.38, 0.26, 2.14),
                rotation=(math.radians(-34.0), math.radians(side * 24.0), 0.0),
            ),
            mat_prefix,
            "body_indigo",
            pal,
        )

    # 2. MÃOZINHAS FRONTAIS E PEZINHOS AZUL-CLAROS (TOCANDO Z = 0.0)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_hand_{tag}",
                (0.18, 0.28, 0.18),
                (side * 0.32, -0.36, 0.86),
                rotation=(math.radians(18.0), 0.0, math.radians(side * -14.0)),
            ),
            mat_prefix,
            "limb_blue",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_foot_{tag}",
                (0.24, 0.42, 0.22),
                (side * 0.26, -0.14, 0.12),
                rotation=(math.radians(18.0), 0.0, math.radians(side * 8.0)),
            ),
            mat_prefix,
            "limb_blue",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_ankle_{tag}", (0.18, 0.20, 0.28), (side * 0.24, -0.02, 0.30)),
            mat_prefix,
            "limb_blue",
            pal,
        )

    # 3. QUATRO GRANDES ASAS DE BORBOLETA BRANCAS COM NERVURAS PRETAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        yaw_w = math.radians(side * 16.0)

        # Asa Superior (grande painel superior)
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_up_pane_{tag}",
                (1.18, 0.08, 0.96),
                (side * 0.94, 0.44, 1.48),
                rotation=(math.radians(-10.0), math.radians(side * -14.0), yaw_w),
            ),
            mat_prefix,
            "wing_white",
            pal,
        )
        # Borda externa e superior da asa superior
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_up_toprim_{tag}",
                (1.26, 0.11, 0.12),
                (side * 0.96, 0.44, 1.94),
                rotation=(math.radians(-10.0), math.radians(side * -14.0), yaw_w),
            ),
            mat_prefix,
            "wing_vein",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_up_outrim_{tag}",
                (0.14, 0.11, 1.04),
                (side * 1.48, 0.58, 1.56),
                rotation=(math.radians(-10.0), math.radians(side * -14.0), yaw_w),
            ),
            mat_prefix,
            "wing_vein",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_up_botrim_{tag}",
                (1.16, 0.11, 0.10),
                (side * 0.90, 0.43, 1.02),
                rotation=(math.radians(-10.0), math.radians(side * -14.0), yaw_w),
            ),
            mat_prefix,
            "wing_vein",
            pal,
        )
        # Nervura diagonal e mancha preta característica na asa superior
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_up_vein1_{tag}",
                (0.96, 0.11, 0.09),
                (side * 0.92, 0.44, 1.46),
                rotation=(math.radians(-10.0), math.radians(side * -30.0), yaw_w),
            ),
            mat_prefix,
            "wing_vein",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_up_vein2_{tag}",
                (0.09, 0.11, 0.78),
                (side * 1.08, 0.48, 1.46),
                rotation=(math.radians(-10.0), math.radians(side * -14.0), yaw_w),
            ),
            mat_prefix,
            "wing_vein",
            pal,
        )

        # Asa Inferior (formato gota arredondada)
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_low_pane_{tag}",
                (0.84, 0.08, 0.72),
                (side * 0.76, 0.46, 0.68),
                rotation=(math.radians(8.0), math.radians(side * 12.0), yaw_w),
            ),
            mat_prefix,
            "wing_white",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_low_outrim_{tag}",
                (0.12, 0.11, 0.76),
                (side * 1.14, 0.56, 0.64),
                rotation=(math.radians(8.0), math.radians(side * 12.0), yaw_w),
            ),
            mat_prefix,
            "wing_vein",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_low_botrim_{tag}",
                (0.88, 0.11, 0.11),
                (side * 0.74, 0.46, 0.34),
                rotation=(math.radians(8.0), math.radians(side * 12.0), yaw_w),
            ),
            mat_prefix,
            "wing_vein",
            pal,
        )
        _add_part(
            parts,
            create_cube(
                f"_tmp_wing_low_vein_{tag}",
                (0.70, 0.11, 0.09),
                (side * 0.74, 0.46, 0.68),
                rotation=(math.radians(8.0), math.radians(side * 24.0), yaw_w),
            ),
            mat_prefix,
            "wing_vein",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 012. Flutterwing lado a lado."""
    specs = [
        ("Flutterwing_Shiny", (-8.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Flutterwing_Normal", (-5.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Flutterwing_Grande", (-1.1, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Flutterwing_Gigante", (4.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Flutterwing_Dourada_SuperRara", (10.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_flutterwing(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
