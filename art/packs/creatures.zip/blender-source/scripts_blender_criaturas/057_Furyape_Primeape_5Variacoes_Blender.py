"""
057_Furyape_Primeape_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "057. Furyape — Gorila Furioso (Ref: Primeape)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Furyape_Shiny (1.0x - Paleta Shiny Pelagem Verde-Oliva/Lima + Membros Oliva Escuro + Algemas Pretas)
  2. Furyape_Normal (1.0x - Bola Peluda Arrepiada Bege + Membros Musculosos Marrons + Algemas Pretas + Veia de Raiva)
  3. Furyape_Grande (1.35x - Normal)
  4. Furyape_Gigante (1.85x - Normal)
  5. Furyape_Dourada_SuperRara (2.25x - Ouro Reluzente + Algemas, Olhos e Focinho Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + tufos arrepiados + algemas metálicas cilíndricas)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés largos alinhados exatamente em `Z = 0.0` e focinho/rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "fur_cream": (0.93, 0.87, 0.76, 1.0),
        "fur_shade": (0.82, 0.75, 0.64, 1.0),
        "limb_brown": (0.64, 0.48, 0.36, 1.0),
        "limb_dark": (0.50, 0.36, 0.26, 1.0),
        "shackle_black": (0.14, 0.15, 0.18, 1.0),
        "snout_pink": (0.92, 0.65, 0.72, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "dark_detail": (0.10, 0.10, 0.12, 1.0),
    },
    "shiny_palette": {
        "fur_cream": (0.56, 0.76, 0.36, 1.0),
        "fur_shade": (0.44, 0.62, 0.26, 1.0),
        "limb_brown": (0.42, 0.46, 0.28, 1.0),
        "limb_dark": (0.30, 0.34, 0.20, 1.0),
        "shackle_black": (0.14, 0.15, 0.18, 1.0),
        "snout_pink": (0.92, 0.66, 0.73, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "dark_detail": (0.10, 0.10, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "fur_cream": (0.98, 0.78, 0.14, 1.0),
        "fur_shade": (0.86, 0.62, 0.09, 1.0),
        "limb_brown": (0.78, 0.56, 0.10, 1.0),
        "limb_dark": (0.64, 0.44, 0.08, 1.0),
        "shackle_black": (0.10, 0.92, 1.00, 1.0),
        "snout_pink": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (1.00, 0.98, 0.90, 1.0),
        "dark_detail": (0.06, 0.58, 0.74, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_furyape(
    name: str = "Furyape_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 057. Furyape (Ref: Primeape):
      - Corpo esférico grande e densamente arrepiado bege-areia (sem cauda!)
      - Orelhas triangulares pontudas com interior rosa
      - Rosto em fúria: olhos estreitos em V profundo + focinho rosa + veia de raiva em cruz na testa
      - Braços musculosos marrons em postura de golpe (esquerdo erguido acima da cabeça, direito pronto)
      - Braceletes/algemas pretas metálicas grossas nos dois punhos e nos dois tornozelos
      - Pernas marrons fortes com pés largos de lutador apoiados em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Fury_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Fury_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Fury_Norm"

    parts = []

    # 1. CORPO ESFÉRICO MUSCULOSO E PELUDO COM TUFOS ARREPIADOS RADIANTES
    _add_part(
        parts,
        create_icosphere("_tmp_body", 2, 0.88, (0.0, 0.02, 1.24), scale=(1.06, 0.96, 1.02)),
        mat_prefix,
        "fur_cream",
        pal,
    )
    # Coroa densa de espinhos de pelo arrepiado ao redor do corpo
    spike_specs = [
        # Topo da cabeça
        ((-0.24, -0.02, 2.12), 0.16, 0.36, (4.0, -24.0, 0.0)),
        ((0.00, 0.02, 2.20), 0.18, 0.40, (6.0, 0.0, 0.0)),
        ((0.24, -0.02, 2.12), 0.16, 0.36, (4.0, 24.0, 0.0)),
        # Laterais esquerda e direita (pelagem explosiva)
        ((-0.88, 0.04, 1.62), 0.17, 0.38, (0.0, -56.0, 0.0)),
        ((-0.94, 0.02, 1.26), 0.18, 0.40, (0.0, -86.0, 0.0)),
        ((-0.86, 0.00, 0.90), 0.16, 0.36, (0.0, -118.0, 0.0)),
        ((0.88, 0.04, 1.62), 0.17, 0.38, (0.0, 56.0, 0.0)),
        ((0.94, 0.02, 1.26), 0.18, 0.40, (0.0, 86.0, 0.0)),
        ((0.86, 0.00, 0.90), 0.16, 0.36, (0.0, 118.0, 0.0)),
        # Parte inferior arrepiada
        ((-0.38, -0.18, 0.48), 0.16, 0.34, (162.0, -28.0, 0.0)),
        ((0.00, -0.22, 0.42), 0.18, 0.38, (166.0, 0.0, 0.0)),
        ((0.38, -0.18, 0.48), 0.16, 0.34, (162.0, 28.0, 0.0)),
        # Tufos dorsais
        ((-0.46, 0.72, 1.56), 0.18, 0.38, (-46.0, -32.0, 0.0)),
        ((0.46, 0.72, 1.56), 0.18, 0.38, (-46.0, 32.0, 0.0)),
    ]
    for s_idx, (loc, r1, dep, rot_d) in enumerate(spike_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_spike_{s_idx}",
                5,
                r1,
                0.014,
                dep,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
                scale=(1.0, 0.65, 1.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )

    # 2. ORELHAS TRIANGULARES PONTUDAS COM INTERIOR ROSA
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_out_{tag}",
                4,
                0.30,
                0.02,
                0.58,
                (side * 0.56, -0.06, 2.02),
                rotation=(math.radians(-6.0), math.radians(side * 34.0), math.radians(side * 10.0)),
                scale=(1.0, 0.46, 1.0),
            ),
            mat_prefix,
            "fur_cream",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_in_{tag}",
                4,
                0.19,
                0.014,
                0.40,
                (side * 0.56, -0.13, 2.00),
                rotation=(math.radians(-6.0), math.radians(side * 34.0), math.radians(side * 10.0)),
                scale=(1.0, 0.30, 1.0),
            ),
            mat_prefix,
            "snout_pink",
            pal,
        )

    # 3. ROSTO EM FÚRIA: FOCINHO ROSA + OLHOS EM V + VEIA DE RAIVA NA TESTA
    _add_part(
        parts,
        create_icosphere("_tmp_snout", 2, 0.24, (0.0, -0.84, 1.12), scale=(1.22, 0.68, 0.80)),
        mat_prefix,
        "snout_pink",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Narina vertical
        _add_part(
            parts,
            create_cube(
                f"_tmp_nostril_{tag}",
                (0.036, 0.05, 0.11),
                (side * 0.078, -0.99, 1.12),
            ),
            mat_prefix,
            "dark_detail",
            pal,
        )
        # Olho estreito branco furioso
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.20,
                (side * 0.28, -0.76, 1.38),
                rotation=(0.0, math.radians(side * -24.0), math.radians(side * -18.0)),
                scale=(1.28, 0.42, 0.54),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Pupila fina escura
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.048,
                (side * 0.28, -0.84, 1.37),
                scale=(0.62, 0.42, 1.12),
            ),
            mat_prefix,
            "dark_detail",
            pal,
        )
        # Sobrancelha furiosa grossa formando o V intenso
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_{tag}",
                (0.42, 0.13, 0.10),
                (side * 0.26, -0.79, 1.48),
                rotation=(math.radians(8.0), math.radians(side * -34.0), math.radians(side * -18.0)),
            ),
            mat_prefix,
            "fur_shade",
            pal,
        )

    # Veia de raiva icônica (💢) na testa direita superior (visível na vista frontal!)
    vein_cx, vein_cy, vein_cz = 0.26, -0.76, 1.72
    for v_idx, (dx, dz, ry_d) in enumerate([
        (-0.055, 0.055, 42.0),
        (0.055, 0.055, -42.0),
        (-0.055, -0.055, -42.0),
        (0.055, -0.055, 42.0),
    ]):
        _add_part(
            parts,
            create_cube(
                f"_tmp_vein_{v_idx}",
                (0.11, 0.045, 0.032),
                (vein_cx + dx, vein_cy, vein_cz + dz),
                rotation=(0.0, math.radians(ry_d), math.radians(-16.0)),
            ),
            mat_prefix,
            "dark_detail",
            pal,
        )

    # 4. BRAÇOS MUSCULOSOS MARRONS + ALGEMAS PRETAS + PUNHOS GIGANTES DE LUTADOR
    # Braço direito (-X) dobrado para o lado/cima em postura de boxe
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_L_up",
            8,
            0.18,
            0.15,
            0.64,
            (-1.02, -0.04, 1.24),
            rotation=(0.0, math.radians(-82.0), 0.0),
        ),
        mat_prefix,
        "limb_brown",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_elbow_L", 1, 0.16, (-1.34, -0.04, 1.28)),
        mat_prefix,
        "limb_brown",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_forearm_L",
            8,
            0.16,
            0.18,
            0.66,
            (-1.38, -0.10, 1.62),
            rotation=(math.radians(-10.0), math.radians(-6.0), 0.0),
        ),
        mat_prefix,
        "limb_brown",
        pal,
    )
    # Algema preta no punho direito (-X)
    _add_part(
        parts,
        create_cylinder(
            "_tmp_cuff_wrist_L",
            10,
            0.22,
            0.18,
            (-1.40, -0.14, 1.82),
            rotation=(math.radians(-10.0), math.radians(-6.0), 0.0),
        ),
        mat_prefix,
        "shackle_black",
        pal,
    )
    # Punho gigante marrom (-X)
    _add_part(
        parts,
        create_icosphere("_tmp_fist_L", 2, 0.30, (-1.22, -0.18, 2.08), scale=(1.18, 0.94, 0.96)),
        mat_prefix,
        "limb_brown",
        pal,
    )

    # Braço esquerdo (+X) erguido bem alto sobre a cabeça pronto para golpear (como na arte!)
    _add_part(
        parts,
        create_cone(
            "_tmp_arm_R_up",
            8,
            0.19,
            0.16,
            0.72,
            (0.98, -0.02, 1.72),
            rotation=(0.0, math.radians(44.0), 0.0),
        ),
        mat_prefix,
        "limb_brown",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_elbow_R", 1, 0.17, (1.22, -0.04, 2.02)),
        mat_prefix,
        "limb_brown",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_forearm_R",
            8,
            0.17,
            0.19,
            0.74,
            (0.92, -0.12, 2.34),
            rotation=(math.radians(-12.0), math.radians(-48.0), 0.0),
        ),
        mat_prefix,
        "limb_brown",
        pal,
    )
    # Algema preta no punho esquerdo (+X)
    _add_part(
        parts,
        create_cylinder(
            "_tmp_cuff_wrist_R",
            10,
            0.23,
            0.18,
            (0.70, -0.18, 2.52),
            rotation=(math.radians(-12.0), math.radians(-48.0), 0.0),
        ),
        mat_prefix,
        "shackle_black",
        pal,
    )
    # Punho gigante marrom erguido acima da cabeça (+X)
    _add_part(
        parts,
        create_icosphere("_tmp_fist_R", 2, 0.32, (0.36, -0.22, 2.58), scale=(1.22, 0.96, 0.94)),
        mat_prefix,
        "limb_brown",
        pal,
    )

    # 5. PERNAS MUSCULOSAS MARRONS + ALGEMAS PRETAS NOS TORNOZELOS + PÉS LARGOS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Coxa marrom
        _add_part(
            parts,
            create_cone(
                f"_tmp_thigh_{tag}",
                8,
                0.20,
                0.17,
                0.54,
                (side * 0.62, -0.02, 0.64),
                rotation=(math.radians(16.0), math.radians(side * 30.0), 0.0),
            ),
            mat_prefix,
            "limb_brown",
            pal,
        )
        # Canela marrom
        _add_part(
            parts,
            create_cone(
                f"_tmp_shin_{tag}",
                8,
                0.16,
                0.15,
                0.44,
                (side * 0.78, -0.06, 0.30),
                rotation=(math.radians(-8.0), math.radians(side * 8.0), 0.0),
            ),
            mat_prefix,
            "limb_brown",
            pal,
        )
        # Algema preta metálica no tornozelo
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_cuff_ankle_{tag}",
                10,
                0.20,
                0.16,
                (side * 0.80, -0.07, 0.24),
                rotation=(math.radians(-8.0), math.radians(side * 8.0), 0.0),
            ),
            mat_prefix,
            "shackle_black",
            pal,
        )
        # Pé largo e forte apoiado em Z = 0.0
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_foot_{tag}",
                2,
                0.24,
                (side * 0.82, -0.20, 0.11),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(1.22, 1.32, 0.48),
            ),
            mat_prefix,
            "limb_brown",
            pal,
        )
        # Dedão lateral interno do pé de gorila
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_bigtoe_{tag}",
                1,
                0.12,
                (side * 0.62, -0.34, 0.09),
                scale=(1.1, 1.2, 0.68),
            ),
            mat_prefix,
            "limb_brown",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 057. Furyape lado a lado."""
    specs = [
        ("Furyape_Shiny", (-11.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Furyape_Normal", (-6.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Furyape_Grande", (-0.6, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Furyape_Gigante", (6.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Furyape_Dourada_SuperRara", (15.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_furyape(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
