"""
010_Silkworm_Caterpie_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "010. Silkworm — Lagarta Verde (Ref: Caterpie)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Silkworm_Shiny (1.0x - Paleta Shiny / Shyne Amarelo-Dourado Luminoso + Antena Laranja)
  2. Silkworm_Normal (1.0x - Corpo Verde-Lima Segmentado + Antena Y Vermelha + Clava Creme)
  3. Silkworm_Grande (1.35x - Normal)
  4. Silkworm_Gigante (1.85x - Normal)
  5. Silkworm_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cones 6 lados, cilindros 6-8 lados, cubos escalonados, icosphere subdiv=1)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base ventral/pés alinhada exatamente em `Z = 0.0` e frente apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Silkworm_Shiny`, `Silkworm_Normal`, `Silkworm_Grande`,
     `Silkworm_Gigante`, `Silkworm_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_green": (0.40, 0.80, 0.28, 1.0),
        "belly_cream": (0.96, 0.90, 0.56, 1.0),
        "horn_red": (0.94, 0.28, 0.24, 1.0),
        "eye_ring": (0.98, 0.92, 0.58, 1.0),
        "eye_dark": (0.10, 0.10, 0.12, 1.0),
        "white_shine": (0.98, 0.98, 0.99, 1.0),
    },
    "shiny_palette": {
        "body_green": (0.98, 0.82, 0.20, 1.0),
        "belly_cream": (1.00, 0.94, 0.68, 1.0),
        "horn_red": (0.98, 0.36, 0.20, 1.0),
        "eye_ring": (1.00, 0.95, 0.72, 1.0),
        "eye_dark": (0.14, 0.12, 0.08, 1.0),
        "white_shine": (1.00, 0.99, 0.95, 1.0),
    },
    "golden_super_rare_palette": {
        "body_green": (0.98, 0.76, 0.12, 1.0),
        "belly_cream": (1.00, 0.94, 0.54, 1.0),
        "horn_red": (1.00, 0.96, 0.76, 1.0),
        "eye_ring": (1.00, 0.92, 0.46, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "white_shine": (1.00, 0.99, 0.92, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base ventral em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_silkworm(
    name: str = "Silkworm_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 010. Silkworm (Ref: Caterpie):
      - Frente apontando para -Y e base ventral em Z = 0.0
      - Corpo segmentado em arco com 5 segmentos verdes, barriga creme e 4 patinhas ventrais
      - Cabeça grande arredondada, focinho verde, olhos escuros com aro amarelo e antena Y vermelha
      - Ponta da cauda terminando em guizo/clava amarela
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Silk_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Silk_GoldSR"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Silk"

    parts = []

    # 1. CORPO SEGMENTADO EM ARCO DE LAGARTA + BARRIGA AMARELO-CREME
    _add_part(parts, create_icosphere("_tmp_seg1", 1, 0.44, (0.0, -0.10, 0.98)), mat_prefix, "body_green", pal)
    _add_part(parts, create_icosphere("_tmp_belly1", 1, 0.38, (0.0, -0.26, 0.88)), mat_prefix, "belly_cream", pal)

    _add_part(parts, create_icosphere("_tmp_seg2", 1, 0.42, (0.0, 0.14, 0.64)), mat_prefix, "body_green", pal)
    _add_part(parts, create_icosphere("_tmp_belly2", 1, 0.36, (0.0, -0.06, 0.52)), mat_prefix, "belly_cream", pal)

    _add_part(parts, create_icosphere("_tmp_seg3", 1, 0.38, (0.0, 0.48, 0.38)), mat_prefix, "body_green", pal)
    _add_part(parts, create_cube("_tmp_belly3", (0.54, 0.50, 0.22), (0.0, 0.44, 0.14)), mat_prefix, "belly_cream", pal)

    _add_part(parts, create_icosphere("_tmp_seg4", 1, 0.32, (0.0, 0.86, 0.34)), mat_prefix, "body_green", pal)
    _add_part(parts, create_cube("_tmp_belly4", (0.44, 0.44, 0.18), (0.0, 0.84, 0.14)), mat_prefix, "belly_cream", pal)

    _add_part(
        parts,
        create_cone("_tmp_seg5_tail", 6, 0.26, 0.12, 0.52, (0.0, 1.24, 0.46), (math.radians(-62), 0.0, 0.0)),
        mat_prefix,
        "body_green",
        pal,
    )
    _add_part(parts, create_icosphere("_tmp_tail_bead", 1, 0.09, (0.0, 1.48, 0.62)), mat_prefix, "belly_cream", pal)
    _add_part(
        parts,
        create_cone("_tmp_tail_rattle", 6, 0.14, 0.06, 0.46, (0.0, 1.56, 0.88), (math.radians(-14), 0.0, 0.0)),
        mat_prefix,
        "belly_cream",
        pal,
    )

    # Patinhas ventrais creme + manchas laterais amarelas nos segmentos
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_icosphere(f"_tmp_paw_up_{side_idx}", 1, 0.15, (sx * 0.28, -0.44, 0.82)),
            mat_prefix,
            "belly_cream",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_paw_low_{side_idx}", 1, 0.15, (sx * 0.28, -0.24, 0.48)),
            mat_prefix,
            "belly_cream",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_side_ring_a_{side_idx}",
                6,
                0.13,
                0.08,
                (sx * 0.38, 0.16, 0.64),
                (0.0, math.radians(90), 0.0),
            ),
            mat_prefix,
            "eye_ring",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_side_ring_b_{side_idx}",
                6,
                0.11,
                0.08,
                (sx * 0.34, 0.50, 0.38),
                (0.0, math.radians(90), 0.0),
            ),
            mat_prefix,
            "eye_ring",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_side_ring_c_{side_idx}",
                6,
                0.09,
                0.08,
                (sx * 0.28, 0.86, 0.34),
                (0.0, math.radians(90), 0.0),
            ),
            mat_prefix,
            "eye_ring",
            pal,
        )

    # 2. CABEÇA GRANDE (-Y), FOCINHO VERDE, ANTENA EM "Y" VERMELHA E OLHOS COM ARO AMARELO
    _add_part(
        parts,
        create_icosphere("_tmp_head", 1, 0.56, (0.0, -0.22, 1.48), scale=(1.04, 0.98, 0.96)),
        mat_prefix,
        "body_green",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_snout", 1, 0.28, (0.0, -0.66, 1.28), scale=(1.08, 0.86, 0.88)),
        mat_prefix,
        "body_green",
        pal,
    )

    # Antena bifurcada em Y no topo frontal da testa
    _add_part(
        parts,
        create_cone("_tmp_horn_stem", 6, 0.11, 0.13, 0.24, (0.0, -0.68, 1.66), (math.radians(35), 0.0, 0.0)),
        mat_prefix,
        "horn_red",
        pal,
    )
    for side_idx, sx in enumerate([-1.0, 1.0]):
        _add_part(
            parts,
            create_cone(
                f"_tmp_horn_branch_{side_idx}",
                6,
                0.12,
                0.14,
                0.56,
                (sx * 0.24, -0.76, 1.84),
                (math.radians(28), math.radians(sx * 48), 0.0),
            ),
            mat_prefix,
            "horn_red",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(f"_tmp_horn_tip_{side_idx}", 1, 0.13, (sx * 0.44, -0.82, 1.98)),
            mat_prefix,
            "horn_red",
            pal,
        )

        # Olho grande com aro amarelo-creme, pupila escura e brilho branco
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_eye_ring_{side_idx}",
                8,
                0.22,
                0.10,
                (sx * 0.42, -0.52, 1.50),
                (math.radians(78), 0.0, math.radians(sx * 34)),
            ),
            mat_prefix,
            "eye_ring",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_eye_pupil_{side_idx}",
                8,
                0.16,
                0.11,
                (sx * 0.44, -0.54, 1.50),
                (math.radians(78), 0.0, math.radians(sx * 34)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_shine_{side_idx}", (0.07, 0.07, 0.07), (sx * 0.45, -0.57, 1.56)),
            mat_prefix,
            "white_shine",
            pal,
        )

    return join_and_bevel(parts, name, location=location, scale=scale)


def generate_variations():
    """
    Gera lado a lado os 5 modelos do 010. Silkworm (Caterpie):
      1. Shiny (1.0x) | 2. Normal (1.0x) | 3. Grande (1.35x) | 4. Gigante (1.85x) | 5. Dourada Super Rara (2.25x)
    """
    build_silkworm("Silkworm_Shiny", location=(-5.8, 0.0, 0.0), scale=CONFIG["scales"]["Shiny"], variant="Shiny")
    build_silkworm("Silkworm_Normal", location=(-3.4, 0.0, 0.0), scale=CONFIG["scales"]["Normal"], variant="Normal")
    build_silkworm("Silkworm_Grande", location=(-0.7, 0.0, 0.0), scale=CONFIG["scales"]["Grande"], variant="Normal")
    build_silkworm("Silkworm_Gigante", location=(2.5, 0.0, 0.0), scale=CONFIG["scales"]["Gigante"], variant="Normal")
    build_silkworm(
        "Silkworm_Dourada_SuperRara",
        location=(6.8, 0.0, 0.0),
        scale=CONFIG["scales"]["DouradaSuperRara"],
        variant="DouradaSuperRara",
    )


if __name__ == "__main__":
    generate_variations()
    print("010. Silkworm (5 variações: Shiny, Normal, Grande, Gigante e Dourada Super Rara) gerado com sucesso!")
