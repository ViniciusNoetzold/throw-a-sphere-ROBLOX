"""
058_Cinderpup_Growlithe_5Variacoes_Blender.py
=============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "058. Cinderpup — Cão Guardião (Ref: Growlithe)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Cinderpup_Shiny (1.0x - Paleta Shiny Pelagem Amarelo-Ouro + Juba Creme Claro + Listras Negras)
  2. Cinderpup_Normal (1.0x - Cãozinho Laranja-Tigre + Peitoral e Topete Creme + Listras Pretas)
  3. Cinderpup_Grande (1.35x - Normal)
  4. Cinderpup_Gigante (1.85x - Normal)
  5. Cinderpup_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Nariz e Listras Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 + tufos de juba e cauda em cones 5-6 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Quatro patas alinhadas exatamente em `Z = 0.0` e focinho/peitoral apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "fur_orange": (0.92, 0.56, 0.28, 1.0),
        "fur_shade": (0.80, 0.45, 0.20, 1.0),
        "fluff_cream": (0.94, 0.88, 0.72, 1.0),
        "fluff_shade": (0.83, 0.76, 0.60, 1.0),
        "stripe_black": (0.20, 0.22, 0.24, 1.0),
        "ear_inner": (0.54, 0.46, 0.38, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.14, 0.14, 0.20, 1.0),
        "claw_white": (0.98, 0.98, 1.00, 1.0),
    },
    "shiny_palette": {
        "fur_orange": (0.96, 0.80, 0.24, 1.0),
        "fur_shade": (0.84, 0.66, 0.16, 1.0),
        "fluff_cream": (0.98, 0.95, 0.84, 1.0),
        "fluff_shade": (0.88, 0.84, 0.72, 1.0),
        "stripe_black": (0.20, 0.22, 0.24, 1.0),
        "ear_inner": (0.58, 0.50, 0.36, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.14, 0.14, 0.20, 1.0),
        "claw_white": (0.98, 0.98, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "fur_orange": (0.98, 0.78, 0.14, 1.0),
        "fur_shade": (0.86, 0.62, 0.09, 1.0),
        "fluff_cream": (1.00, 0.94, 0.60, 1.0),
        "fluff_shade": (0.92, 0.80, 0.36, 1.0),
        "stripe_black": (0.10, 0.92, 1.00, 1.0),
        "ear_inner": (0.08, 0.74, 0.88, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "claw_white": (1.00, 0.99, 0.94, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_cinderpup(
    name: str = "Cinderpup_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 058. Cinderpup (Ref: Growlithe):
      - Cãozinho guardião quadrúpede laranja-tigre com corpo compacto e peitoral erguido
      - Grande juba/peitoral fofo e espetado creme no peito e pescoço
      - Topete creme volumoso arrepiado no topo da cabeça + orelhas redondas em concha
      - Focinho creme largo com nariz escuro e sorriso confiante + olhos grandes expressivos
      - Listras pretas de tigre no dorso, coxas e faixas em V nas patas dianteiras
      - Cauda felpuda creme erguida atrás da garupa e 4 patas com garras brancas em Z = 0.0
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Cind_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Cind_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Cind_Norm"

    parts = []

    # 1. TRONCO QUADRÚPEDE LARANJA + BARRIGA CREME + LISTRAS PRETAS DE TIGRE
    _add_part(
        parts,
        create_icosphere("_tmp_torso_front", 2, 0.56, (0.0, -0.14, 0.92), scale=(0.94, 1.08, 0.96)),
        mat_prefix,
        "fur_orange",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_torso_back", 2, 0.54, (0.0, 0.42, 0.78), scale=(0.94, 1.12, 0.94)),
        mat_prefix,
        "fur_orange",
        pal,
    )
    # Barriguinha creme suave embaixo
    _add_part(
        parts,
        create_icosphere("_tmp_belly", 2, 0.44, (0.0, 0.16, 0.62), scale=(0.82, 1.24, 0.60)),
        mat_prefix,
        "fluff_shade",
        pal,
    )
    # Listras pretas no dorso e flancos
    for b_idx, (by, bz, rx_d) in enumerate([(0.24, 1.06, -12.0), (0.50, 0.98, -22.0)]):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_back_stripe_{b_idx}",
                1,
                0.48,
                (0.0, by, bz),
                rotation=(math.radians(rx_d), 0.0, 0.0),
                scale=(1.04, 0.22, 0.78),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )

    # 2. PEITORAL FOFO E ESPETADO CREME (JUBA NO PEITO E PESCOÇO)
    _add_part(
        parts,
        create_icosphere("_tmp_chest_fluff", 2, 0.54, (0.0, -0.44, 1.04), scale=(1.04, 0.78, 0.98)),
        mat_prefix,
        "fluff_cream",
        pal,
    )
    # Pontas arrepiadas do peitoral creme
    ruff_spikes = [
        ((0.00, -0.74, 0.60), 0.16, 0.34, (162.0, 0.0, 0.0)),
        ((-0.24, -0.66, 0.68), 0.15, 0.32, (150.0, -26.0, 0.0)),
        ((0.24, -0.66, 0.68), 0.15, 0.32, (150.0, 26.0, 0.0)),
        ((-0.48, -0.50, 0.98), 0.16, 0.34, (98.0, -68.0, 0.0)),
        ((0.48, -0.50, 0.98), 0.16, 0.34, (98.0, 68.0, 0.0)),
        ((-0.44, -0.44, 1.24), 0.15, 0.30, (72.0, -62.0, 0.0)),
        ((0.44, -0.44, 1.24), 0.15, 0.30, (72.0, 62.0, 0.0)),
    ]
    for r_idx, (loc, r1, dep, rot_d) in enumerate(ruff_spikes):
        _add_part(
            parts,
            create_cone(
                f"_tmp_ruff_{r_idx}",
                5,
                r1,
                0.014,
                dep,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
                scale=(1.0, 0.65, 1.0),
            ),
            mat_prefix,
            "fluff_cream",
            pal,
        )

    # 3. PESCOÇO + CABEÇA + TOPETE CREME ARREPIADO + ORELHAS REDONDAS
    _add_part(
        parts,
        create_cylinder(
            "_tmp_neck",
            8,
            0.34,
            0.40,
            (0.0, -0.26, 1.38),
            rotation=(math.radians(14.0), 0.0, 0.0),
        ),
        mat_prefix,
        "fur_orange",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_head", 2, 0.50, (0.0, -0.34, 1.72), scale=(1.02, 1.00, 0.94)),
        mat_prefix,
        "fur_orange",
        pal,
    )
    # Topete creme volumoso arrepiado para cima e trás (assinatura do Growlithe!)
    _add_part(
        parts,
        create_icosphere("_tmp_crest_base", 2, 0.34, (0.0, -0.26, 2.18), scale=(0.82, 1.18, 0.78)),
        mat_prefix,
        "fluff_cream",
        pal,
    )
    crest_tufts = [
        ((0.00, -0.10, 2.46), 0.18, 0.44, (-44.0, 0.0, 0.0)),
        ((0.00, 0.08, 2.34), 0.17, 0.42, (-68.0, 0.0, 0.0)),
        ((-0.14, -0.14, 2.36), 0.14, 0.34, (-48.0, -18.0, 0.0)),
        ((0.14, -0.14, 2.36), 0.14, 0.34, (-48.0, 18.0, 0.0)),
    ]
    for c_idx, (loc, r1, dep, rot_d) in enumerate(crest_tufts):
        _add_part(
            parts,
            create_cone(
                f"_tmp_crest_tuft_{c_idx}",
                5,
                r1,
                0.015,
                dep,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
                scale=(0.85, 1.0, 1.0),
            ),
            mat_prefix,
            "fluff_cream",
            pal,
        )

    # Orelhas arredondadas em concha (laranja fora, marrom-taupe dentro)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ear_out_{tag}",
                2,
                0.26,
                (side * 0.48, -0.24, 1.92),
                rotation=(math.radians(-10.0), math.radians(side * 22.0), math.radians(side * -18.0)),
                scale=(0.95, 0.42, 1.12),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_ear_in_{tag}",
                1,
                0.19,
                (side * 0.48, -0.32, 1.90),
                rotation=(math.radians(-10.0), math.radians(side * 22.0), math.radians(side * -18.0)),
                scale=(0.88, 0.28, 1.02),
            ),
            mat_prefix,
            "ear_inner",
            pal,
        )

    # 4. FOCINHO CREME LARGO + NARIZ ESCURO + OLHOS DETERMINADOS + SORRISO
    _add_part(
        parts,
        create_icosphere("_tmp_muzzle", 2, 0.36, (0.0, -0.68, 1.56), scale=(1.12, 0.88, 0.68)),
        mat_prefix,
        "fluff_cream",
        pal,
    )
    # Nariz oval escuro na ponta do focinho
    _add_part(
        parts,
        create_icosphere("_tmp_nose", 1, 0.095, (0.0, -0.98, 1.66), scale=(1.22, 0.82, 0.72)),
        mat_prefix,
        "eye_dark",
        pal,
    )
    # Linha sutil de sorriso confiante com cantinhos erguidos
    _add_part(
        parts,
        create_cube("_tmp_smile_mid", (0.18, 0.05, 0.025), (0.0, -0.97, 1.47)),
        mat_prefix,
        "eye_dark",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_smile_c_{tag}",
                (0.11, 0.05, 0.025),
                (side * 0.12, -0.95, 1.495),
                rotation=(0.0, math.radians(side * -26.0), math.radians(side * -16.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                2,
                0.145,
                (side * 0.24, -0.76, 1.80),
                rotation=(0.0, math.radians(side * -10.0), math.radians(side * -18.0)),
                scale=(1.12, 0.46, 0.82),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.085,
                (side * 0.23, -0.82, 1.80),
                scale=(0.82, 0.45, 1.02),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_shine_{tag}",
                1,
                0.032,
                (side * 0.21, -0.86, 1.84),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # 5. PATAS DIANTEIRAS COM LISTRAS EM V E GARRAS + PATAS TRASEIRAS EM Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Pata dianteira reta e firme
        _add_part(
            parts,
            create_cone(
                f"_tmp_fleg_{tag}",
                8,
                0.19,
                0.16,
                0.86,
                (side * 0.34, -0.34, 0.46),
                rotation=(math.radians(4.0), 0.0, 0.0),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )
        # Faixa/listra preta em chevron na pata dianteira
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_fleg_stripe_{tag}",
                8,
                0.185,
                0.14,
                (side * 0.34, -0.35, 0.48),
                rotation=(math.radians(16.0), math.radians(side * -16.0), 0.0),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )
        # Pé dianteiro
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_fpaw_{tag}",
                2,
                0.19,
                (side * 0.34, -0.44, 0.11),
                scale=(1.04, 1.24, 0.62),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )
        # 2 garras brancas na pata dianteira
        for c_idx, dx in enumerate([-0.08, 0.08]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_fclaw_{tag}_{c_idx}",
                    5,
                    0.048,
                    0.010,
                    0.14,
                    (side * 0.34 + dx, -0.62, 0.07),
                    rotation=(math.radians(96.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

        # Coxa traseira forte com 2 listras pretas
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hthigh_{tag}",
                2,
                0.30,
                (side * 0.42, 0.48, 0.56),
                scale=(0.82, 1.12, 1.18),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hstripe_{tag}",
                1,
                0.28,
                (side * 0.44, 0.48, 0.58),
                rotation=(math.radians(-24.0), 0.0, 0.0),
                scale=(0.88, 0.24, 0.96),
            ),
            mat_prefix,
            "stripe_black",
            pal,
        )
        # Canela + pé traseiro apoiado em Z = 0.0
        _add_part(
            parts,
            create_cone(
                f"_tmp_hshin_{tag}",
                7,
                0.15,
                0.13,
                0.42,
                (side * 0.40, 0.56, 0.26),
                rotation=(math.radians(-14.0), 0.0, 0.0),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_hpaw_{tag}",
                2,
                0.18,
                (side * 0.40, 0.44, 0.10),
                scale=(1.02, 1.24, 0.58),
            ),
            mat_prefix,
            "fur_orange",
            pal,
        )

    # 6. CAUDA FELPUDA CREME LEVANTADA EM PLUMA
    _add_part(
        parts,
        create_icosphere("_tmp_tail_base", 2, 0.34, (0.0, 0.88, 1.02), scale=(0.86, 0.96, 1.12)),
        mat_prefix,
        "fluff_cream",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_tail_mid", 2, 0.36, (0.14, 1.06, 1.34), scale=(0.88, 1.02, 1.08)),
        mat_prefix,
        "fluff_cream",
        pal,
    )
    tail_tips = [
        ((0.24, 1.24, 1.56), 0.18, 0.42, (-46.0, 24.0, 0.0)),
        ((0.30, 1.32, 1.34), 0.16, 0.38, (-74.0, 32.0, 0.0)),
        ((0.18, 1.18, 1.68), 0.15, 0.36, (-24.0, 18.0, 0.0)),
    ]
    for tt_idx, (loc, r1, dep, rot_d) in enumerate(tail_tips):
        _add_part(
            parts,
            create_cone(
                f"_tmp_tail_tip_{tt_idx}",
                5,
                r1,
                0.015,
                dep,
                loc,
                rotation=tuple(math.radians(a) for a in rot_d),
            ),
            mat_prefix,
            "fluff_cream",
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 058. Cinderpup lado a lado."""
    specs = [
        ("Cinderpup_Shiny", (-8.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Cinderpup_Normal", (-4.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Cinderpup_Grande", (-0.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Cinderpup_Gigante", (4.5, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Cinderpup_Dourada_SuperRara", (11.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_cinderpup(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
