"""
028_Quilldig_Sandslash_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "028. Quilldig — Pangolim de Espinhos (Ref: Sandslash)" no estilo Low-Poly / Voxel Blocky
para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Quilldig_Shiny (1.0x - Paleta Shiny / Shyne Espinhos Vermelho-Carmesim + Corpo Areia-Ouro)
  2. Quilldig_Normal (1.0x - Corpo Amarelo-Creme + Espinhos Marrom-Ferrugem + Garras Duplas Gigantes)
  3. Quilldig_Grande (1.35x - Normal)
  4. Quilldig_Gigante (1.85x - Normal)
  5. Quilldig_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada (cubos escalonados, cones 4-6 lados, cilindros 6 lados, icosphere subdiv=1)
  - Bevel final (`width=0.017`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Patas alinhadas exatamente em `Z = 0.0` e frente/focinho apontando para `-Y`

Como executar no Blender:
  1. Abra o Blender (3.x ou 4.x).
  2. Vá na aba `Scripting`, clique em `New`, cole este script e aperte `Run Script`.
  3. Selecione cada variação (`Quilldig_Shiny`, `Quilldig_Normal`, `Quilldig_Grande`,
     `Quilldig_Gigante`, `Quilldig_Dourada_SuperRara`) e exporte em `.fbx` para o Roblox Studio.
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.017,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_yellow": (0.95, 0.84, 0.42, 1.0),
        "quill_rust": (0.68, 0.36, 0.20, 1.0),
        "claw_white": (0.96, 0.96, 0.96, 1.0),
        "eye_dark": (0.12, 0.12, 0.16, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
    },
    "shiny_palette": {
        "body_yellow": (0.92, 0.74, 0.36, 1.0),
        "quill_rust": (0.84, 0.20, 0.22, 1.0),
        "claw_white": (0.98, 0.98, 0.98, 1.0),
        "eye_dark": (0.12, 0.12, 0.16, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
    },
    "golden_super_rare_palette": {
        "body_yellow": (0.98, 0.78, 0.14, 1.0),
        "quill_rust": (0.88, 0.50, 0.08, 1.0),
        "claw_white": (1.00, 0.98, 0.82, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.94, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """
    Une todas as primitivas, alinha a base dos pés em Z = 0.0,
    aplica Bevel angular e garante Shading Flat no objeto final.
    """
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_quilldig(
    name: str = "Quilldig_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo do 028. Quilldig (Ref: Sandslash):
      - Frente/focinho apontando para -Y e pés apoiados em Z = 0.0
      - Corpo bípede curvo amarelo-creme com barriga branca e cauda grossa afunilada
      - Costas e topo da cabeça cobertos por grandes espinhos cônicos marrom-ferrugem em 3 fileiras
      - Braços musculosos armados com garras duplas gigantes brancas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Quill_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Quill_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Quill_Norm"

    parts = []

    # 1. TORSO BÍPEDE CURVO AMARELO + BARRIGA BRANCA
    _add_part(
        parts,
        create_icosphere("_tmp_torso_main", 1, 0.64, (0.0, 0.08, 0.90), scale=(0.94, 0.98, 1.06)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_belly_white", 1, 0.48, (0.0, -0.22, 0.86), scale=(0.86, 0.66, 0.98)),
        mat_prefix,
        "claw_white",
        pal,
    )

    # 2. CABEÇA PONTUDA, CRISTA FRONTAL, OLHOS FEROZES E ORELHAS LONGAS
    _add_part(
        parts,
        create_cube("_tmp_head_main", (0.76, 0.72, 0.56), (0.0, -0.26, 1.48), rotation=(math.radians(14.0), 0.0, 0.0)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cone(
            "_tmp_snout",
            4,
            0.24,
            0.09,
            0.40,
            (0.0, -0.74, 1.40),
            rotation=(math.radians(104.0), 0.0, math.radians(45.0)),
            scale=(1.05, 0.78, 1.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    _add_part(
        parts,
        create_cube("_tmp_jaw_white", (0.48, 0.40, 0.16), (0.0, -0.54, 1.24)),
        mat_prefix,
        "claw_white",
        pal,
    )
    # Pequeno chifre/escama frontal amarelo na testa
    _add_part(
        parts,
        create_cone(
            "_tmp_forehead_horn",
            4,
            0.13,
            0.02,
            0.34,
            (0.0, -0.44, 1.74),
            rotation=(math.radians(16.0), 0.0, math.radians(45.0)),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )

    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_{tag}",
                (0.14, 0.24, 0.20),
                (side * 0.32, -0.52, 1.48),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_eye_shine_{tag}", (0.07, 0.09, 0.10), (side * 0.35, -0.56, 1.52)),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_cone(
                f"_tmp_ear_{tag}",
                4,
                0.15,
                0.02,
                0.56,
                (side * 0.44, -0.18, 1.88),
                rotation=(math.radians(-10.0), math.radians(side * 28.0), math.radians(45.0)),
                scale=(0.85, 0.52, 1.0),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )

    # 3. COROA E COSTAS COBERTAS POR GRANDES ESPINHOS MARROM-FERRUGEM EM 3 FILEIRAS
    quill_specs = [
        # Fileira superior / coroa da cabeça (visível de frente)
        ((-0.24, -0.02, 2.02), (-22.0, -14.0, 45.0), 0.22, 0.72),
        ((0.24, -0.02, 2.02), (-22.0, 14.0, 45.0), 0.22, 0.72),
        ((0.0, 0.14, 2.12), (-30.0, 0.0, 45.0), 0.26, 0.84),
        # Fileira média larga nos ombros e costas
        ((-0.56, 0.22, 1.72), (-38.0, -34.0, 45.0), 0.24, 0.82),
        ((0.56, 0.22, 1.72), (-38.0, 34.0, 45.0), 0.24, 0.82),
        ((-0.26, 0.44, 1.74), (-52.0, -14.0, 45.0), 0.25, 0.88),
        ((0.26, 0.44, 1.74), (-52.0, 14.0, 45.0), 0.25, 0.88),
        # Fileira inferior nas costas
        ((-0.52, 0.48, 1.24), (-64.0, -28.0, 45.0), 0.24, 0.80),
        ((0.0, 0.64, 1.28), (-72.0, 0.0, 45.0), 0.26, 0.88),
        ((0.52, 0.48, 1.24), (-64.0, 28.0, 45.0), 0.24, 0.80),
    ]
    for q_idx, (loc, rot, rad, depth) in enumerate(quill_specs):
        _add_part(
            parts,
            create_cone(
                f"_tmp_quill_{q_idx}",
                5,
                rad,
                0.025,
                depth,
                loc,
                rotation=tuple(math.radians(a) for a in rot),
            ),
            mat_prefix,
            "quill_rust",
            pal,
        )

    # 4. BRAÇOS COM GARRAS DUPLAS GIGANTES + PERNAS COM GARRAS TOCANDO Z = 0.0
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cylinder(
                f"_tmp_arm_{tag}",
                6,
                0.17,
                0.56,
                (side * 0.58, -0.34, 1.04),
                rotation=(math.radians(74.0), 0.0, math.radians(side * -18.0)),
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # Duas garras gigantes em foice em cada mão
        for c_idx, (dx, dz) in enumerate([(-0.08, 0.05), (0.08, -0.05)]):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_scythe_claw_{tag}_{c_idx}",
                    4,
                    0.095,
                    0.015,
                    0.66,
                    (side * 0.64 + dx, -0.82, 0.96 + dz),
                    rotation=(math.radians(104.0), 0.0, math.radians(side * -12.0)),
                    scale=(0.68, 1.0, 1.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

        # Pernas fortes + pés + garras duplas em Z = 0.0
        _add_part(
            parts,
            create_cube(f"_tmp_thigh_{tag}", (0.36, 0.44, 0.48), (side * 0.42, 0.06, 0.50)),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cylinder(f"_tmp_shin_{tag}", 6, 0.14, 0.34, (side * 0.42, 0.02, 0.22)),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_cube(f"_tmp_foot_{tag}", (0.30, 0.40, 0.12), (side * 0.42, -0.10, 0.06)),
            mat_prefix,
            "body_yellow",
            pal,
        )
        for c_idx, dx in enumerate((-0.075, 0.075)):
            _add_part(
                parts,
                create_cone(
                    f"_tmp_foot_claw_{tag}_{c_idx}",
                    4,
                    0.065,
                    0.014,
                    0.26,
                    (side * 0.42 + dx, -0.38, 0.06),
                    rotation=(math.radians(90.0), 0.0, 0.0),
                ),
                mat_prefix,
                "claw_white",
                pal,
            )

    # 5. CAUDA GROSSA AFUNILADA
    _add_part(
        parts,
        create_cone(
            "_tmp_tail",
            6,
            0.22,
            0.03,
            0.86,
            (0.0, 0.86, 0.48),
            rotation=(math.radians(-78.0), 0.0, 0.0),
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 028. Quilldig lado a lado."""
    specs = [
        ("Quilldig_Shiny", (-7.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Quilldig_Normal", (-4.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Quilldig_Grande", (-0.5, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Quilldig_Gigante", (4.1, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Quilldig_Dourada_SuperRara", (10.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_quilldig(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
