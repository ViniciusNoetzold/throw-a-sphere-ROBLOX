"""
092_Phantasmorb_Gastly_5Variacoes_Blender.py
============================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "092. Phantasmorb — Esfera Espectral (Ref: Gastly)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Phantasmorb_Shiny (1.0x - Paleta Shiny Núcleo Índigo + Gás Azul-Celeste Elétrico)
  2. Phantasmorb_Normal (1.0x - Esfera Negra + Halo Gasoso Violeta-Espectral + Olhos Ferozes + Presas)
  3. Phantasmorb_Grande (1.35x - Normal)
  4. Phantasmorb_Gigante (1.85x - Normal)
  5. Phantasmorb_Dourada_SuperRara (2.25x - Aura Ouro Reluzente + Olhos e Presas Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2 para esfera e nuvem de gás; cones para presas e fios de fumaça)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base da nuvem alinhada exatamente em `Z = 0.0` e rosto/presas apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "core_black": (0.14, 0.12, 0.16, 1.0),
        "gas_purple": (0.56, 0.38, 0.66, 1.0),
        "gas_light": (0.70, 0.50, 0.80, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.06, 0.06, 0.08, 1.0),
        "eye_crease": (0.54, 0.22, 0.24, 1.0),
        "mouth_pink": (0.86, 0.54, 0.64, 1.0),
    },
    "shiny_palette": {
        "core_black": (0.18, 0.22, 0.46, 1.0),
        "gas_purple": (0.30, 0.58, 0.92, 1.0),
        "gas_light": (0.52, 0.78, 0.98, 1.0),
        "eye_white": (0.98, 0.98, 1.00, 1.0),
        "pupil_dark": (0.06, 0.08, 0.14, 1.0),
        "eye_crease": (0.38, 0.24, 0.56, 1.0),
        "mouth_pink": (0.86, 0.52, 0.72, 1.0),
    },
    "golden_super_rare_palette": {
        "core_black": (0.34, 0.24, 0.06, 1.0),
        "gas_purple": (0.98, 0.78, 0.14, 1.0),
        "gas_light": (1.00, 0.90, 0.42, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "pupil_dark": (0.04, 0.28, 0.44, 1.0),
        "eye_crease": (0.82, 0.56, 0.08, 1.0),
        "mouth_pink": (0.96, 0.72, 0.22, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_phantasmorb(
    name: str = "Phantasmorb_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 092. Phantasmorb (Ref: Gastly):
      - Núcleo esférico sólido preto-carvão central suspenso sobre névoa espectral
      - Olhos enormes brancos em meia-lua inclinada com sobrancelha furiosa e pupilas verticais finas
      - Boca aberta rosa sorridente com duas presas brancas afiadas nos cantos superiores
      - Halo contínuo e orgânico de nuvens gasosas roxo-violeta com gavinhas de fumaça conectadas
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Pha_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Pha_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Pha_Norm"

    parts = []

    # 1. NÚCLEO ESFÉRICO NEGRO SÓLIDO
    _add_part(
        parts,
        create_icosphere("_tmp_core_orb", 2, 0.72, (0.0, -0.06, 1.24)),
        mat_prefix,
        "core_black",
        pal,
    )

    # 2. GRANDES OLHOS BRANCOS EM MEIA-LUA FEROZ (ASSINATURA DO GASTLY)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        # Corpo principal enorme do olho branco abraçando a frente da esfera
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_main_{tag}",
                2,
                0.33,
                (side * 0.30, -0.60, 1.26),
                rotation=(math.radians(6.0), math.radians(side * -24.0), math.radians(side * -22.0)),
                scale=(1.18, 0.42, 0.94),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Ponta externa pontiaguda ascendente do olho
        _add_part(
            parts,
            create_cone(
                f"_tmp_eye_tip_{tag}",
                5,
                0.18,
                0.02,
                0.38,
                (side * 0.56, -0.45, 1.48),
                rotation=(math.radians(16.0), math.radians(side * 38.0), math.radians(side * -20.0)),
                scale=(1.0, 0.46, 1.0),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        # Sobrancelha negra posicionada mais alta para manter os olhos ENORMES e expressivos
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_cut_{tag}",
                (0.56, 0.24, 0.14),
                (side * 0.26, -0.58, 1.54),
                rotation=(math.radians(6.0), math.radians(side * -30.0), math.radians(side * -18.0)),
            ),
            mat_prefix,
            "core_black",
            pal,
        )
        # Pupila vertical nítida escura bem visível no centro dos olhos brancos
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pupil_{tag}",
                1,
                0.052,
                (side * 0.26, -0.75, 1.24),
                scale=(0.56, 0.50, 1.38),
            ),
            mat_prefix,
            "pupil_dark",
            pal,
        )

    # 3. BOCA ABERTA ROSA SORRIDENTE + 2 PRESAS BRANCAS AFIADAS
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_open",
            2,
            0.28,
            (0.0, -0.65, 0.86),
            rotation=(math.radians(20.0), 0.0, 0.0),
            scale=(1.28, 0.44, 0.64),
        ),
        mat_prefix,
        "mouth_pink",
        pal,
    )
    # Lábio superior curvo preto para delinear o sorriso
    _add_part(
        parts,
        create_cube(
            "_tmp_upper_lip",
            (0.58, 0.14, 0.10),
            (0.0, -0.68, 0.98),
            rotation=(math.radians(16.0), 0.0, 0.0),
        ),
        mat_prefix,
        "core_black",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_cone(
                f"_tmp_fang_{tag}",
                5,
                0.082,
                0.014,
                0.26,
                (side * 0.25, -0.74, 0.91),
                rotation=(math.radians(164.0), math.radians(side * -10.0), 0.0),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

    # 4. NUVEM GASOSA ESPECTRAL CONTÍNUA (CAMADA PRINCIPAL + GAVINHAS CONECTADAS)
    # Anel denso de fumaça atrás e ao redor do núcleo negro (tudo interconectado!)
    gas_puffs = [
        # (radius, (x, y, z), scale, mat_key)
        # Base de fumaça sustentando a esfera sobre Z=0.0
        (0.54, (0.0, 0.12, 0.54), (1.28, 0.72, 0.78), "gas_purple"),
        (0.42, (-0.48, 0.18, 0.48), (1.06, 0.68, 0.84), "gas_light"),
        (0.46, (0.50, 0.20, 0.50), (1.12, 0.70, 0.86), "gas_purple"),
        (0.32, (0.08, 0.16, 0.28), (1.20, 0.66, 0.72), "gas_light"),
        # Halo central traseiro amplo
        (0.86, (0.02, 0.36, 1.28), (1.24, 0.56, 1.18), "gas_purple"),
        # Nuvens laterais esquerdas
        (0.52, (-0.82, 0.26, 1.16), (1.04, 0.64, 1.08), "gas_purple"),
        (0.40, (-1.06, 0.34, 1.46), (0.98, 0.56, 0.96), "gas_light"),
        (0.36, (-0.98, 0.30, 0.80), (1.02, 0.58, 0.88), "gas_light"),
        # Nuvens laterais direitas (mais volumosas e onduladas como na arte!)
        (0.56, (0.86, 0.26, 1.24), (1.12, 0.64, 1.14), "gas_purple"),
        (0.46, (1.16, 0.34, 1.00), (1.08, 0.58, 0.98), "gas_light"),
        (0.44, (1.08, 0.34, 1.56), (1.04, 0.58, 1.02), "gas_purple"),
        (0.34, (1.24, 0.40, 0.72), (0.96, 0.54, 0.84), "gas_purple"),
        # Topo ondulado da aura de gás
        (0.50, (-0.42, 0.30, 1.94), (1.08, 0.62, 0.96), "gas_purple"),
        (0.52, (0.36, 0.32, 1.98), (1.12, 0.62, 1.02), "gas_light"),
        (0.38, (-0.06, 0.30, 2.16), (1.02, 0.58, 0.94), "gas_purple"),
        (0.34, (0.76, 0.36, 1.96), (0.98, 0.56, 0.98), "gas_light"),
    ]
    for idx, (rad, loc, sc, mkey) in enumerate(gas_puffs):
        _add_part(
            parts,
            create_icosphere(f"_tmp_gas_puff_{idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            mkey,
            pal,
        )

    # Gavinhas cônicas orgânicas de fumaça saindo das bordas da nuvem (conectadas na raiz)
    gas_wisps = [
        ((-0.66, 0.34, 2.22), (0.20, 0.05, 0.46), (-8.0, -32.0, 0.0), "gas_light"),
        ((0.62, 0.36, 2.26), (0.22, 0.05, 0.52), (-6.0, 36.0, 0.0), "gas_purple"),
        ((-1.20, 0.36, 1.26), (0.20, 0.05, 0.46), (0.0, -82.0, 0.0), "gas_purple"),
        ((1.34, 0.38, 1.38), (0.22, 0.05, 0.52), (0.0, 76.0, 0.0), "gas_light"),
        ((1.28, 0.40, 0.86), (0.18, 0.05, 0.42), (0.0, 108.0, 0.0), "gas_purple"),
        ((-1.04, 0.34, 0.62), (0.18, 0.05, 0.40), (0.0, -118.0, 0.0), "gas_light"),
    ]
    for w_idx, (loc, (r1, r2, dp), rot_deg, mkey) in enumerate(gas_wisps):
        _add_part(
            parts,
            create_cone(
                f"_tmp_gas_wisp_{w_idx}",
                6,
                r1,
                r2,
                dp,
                loc,
                rotation=tuple(math.radians(a) for a in rot_deg),
                scale=(1.0, 0.62, 1.0),
            ),
            mat_prefix,
            mkey,
            pal,
        )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 092. Phantasmorb lado a lado."""
    specs = [
        ("Phantasmorb_Shiny", (-11.8, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Phantasmorb_Normal", (-7.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Phantasmorb_Grande", (-2.2, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Phantasmorb_Gigante", (4.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Phantasmorb_Dourada_SuperRara", (12.0, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_phantasmorb(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
