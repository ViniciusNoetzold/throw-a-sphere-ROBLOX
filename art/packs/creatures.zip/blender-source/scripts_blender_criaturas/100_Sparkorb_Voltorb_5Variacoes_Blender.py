"""
100_Sparkorb_Voltorb_5Variacoes_Blender.py
==========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "100. Sparkorb — Esfera Elétrica (Ref: Voltorb)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Sparkorb_Shiny (1.0x - Hemisfério Superior Azul-Elétrico + Inferior Branco)
  2. Sparkorb_Normal (1.0x - Hemisfério Superior Vermelho + Inferior Branco + Olhos Determinados)
  3. Sparkorb_Grande (1.35x - Normal)
  4. Sparkorb_Gigante (1.85x - Normal)
  5. Sparkorb_Dourada_SuperRara (2.25x - Ouro Reluzente + Base Platina + Olhos Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Esfera facetada perfeita em dois hemisférios exatos (sem z-fighting) com linha equatorial nítida
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Base da esfera alinhada exatamente em `Z = 0.0` e rosto/olhos apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "top_red": (0.90, 0.24, 0.24, 1.0),
        "top_shade": (0.76, 0.18, 0.20, 1.0),
        "bottom_white": (0.95, 0.96, 0.98, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "seam_dark": (0.12, 0.12, 0.15, 1.0),
    },
    "shiny_palette": {
        "top_red": (0.20, 0.46, 0.94, 1.0),
        "top_shade": (0.14, 0.34, 0.78, 1.0),
        "bottom_white": (0.96, 0.97, 0.99, 1.0),
        "eye_white": (0.99, 0.99, 1.00, 1.0),
        "seam_dark": (0.10, 0.12, 0.18, 1.0),
    },
    "golden_super_rare_palette": {
        "top_red": (0.98, 0.78, 0.14, 1.0),
        "top_shade": (0.86, 0.62, 0.08, 1.0),
        "bottom_white": (1.00, 0.95, 0.72, 1.0),
        "eye_white": (0.10, 0.92, 1.00, 1.0),
        "seam_dark": (0.42, 0.30, 0.05, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def _add_faceted_hemisphere(
    parts: list,
    prefix: str,
    center_z: float,
    radius: float,
    is_upper: bool,
    mat_prefix: str,
    mat_key: str,
    pal: dict,
    ring_verts: int = 16,
):
    """Constrói um hemisfério facetado limpo por faixas latitudinais de cones (zero z-fighting)."""
    lat_degs = [0.0, 18.0, 36.0, 54.0, 72.0, 90.0]
    sign = 1.0 if is_upper else -1.0
    for i in range(len(lat_degs) - 1):
        a0 = math.radians(lat_degs[i])
        a1 = math.radians(lat_degs[i + 1])
        r0 = radius * math.cos(a0)
        r1 = max(0.015, radius * math.cos(a1))
        z0 = center_z + sign * radius * math.sin(a0)
        z1 = center_z + sign * radius * math.sin(a1)
        if is_upper:
            rb, rt = r0, r1
            dep = z1 - z0
        else:
            rb, rt = r1, r0
            dep = z0 - z1
        zc = (z0 + z1) * 0.5
        _add_part(
            parts,
            create_cone(f"_tmp_{prefix}_band_{i}", ring_verts, rb, rt, dep, (0.0, 0.0, zc)),
            mat_prefix,
            mat_key,
            pal,
        )


def build_sparkorb(
    name: str = "Sparkorb_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel do 100. Sparkorb (Ref: Voltorb):
      - Esfera facetada perfeita dividida em metade superior vermelha (azul na Shiny) e inferior branca
      - Linha divisória escura nítida ao longo do equador
      - Sobrancelhas franzidas proeminentes + olhos triangulares brancos determinados com pupila vertical
      - Sem boca (100% fiel à referência original)
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Sparkorb_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Sparkorb_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Sparkorb_Norm"

    parts = []
    radius = 0.92
    cz = radius

    # 1. HEMISFÉRIO SUPERIOR VERMELHO + HEMISFÉRIO INFERIOR BRANCO
    _add_faceted_hemisphere(parts, "top", cz, radius, True, mat_prefix, "top_red", pal, ring_verts=16)
    _add_faceted_hemisphere(parts, "bot", cz, radius, False, mat_prefix, "bottom_white", pal, ring_verts=16)

    # 2. ANEL DE DIVISÃO EQUATORIAL ESCURO NÍTIDO
    _add_part(
        parts,
        create_cylinder("_tmp_equator_seam", 16, radius + 0.012, 0.036, (0.0, 0.0, cz)),
        mat_prefix,
        "seam_dark",
        pal,
    )

    # 3. OLHOS TRIANGULARES DETERMINADOS COM SOBRANCELHAS FRANZIDAS (ASSINATURA DO VOLTORB)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"

        # Volume sutil de sobrancelha vermelha projetada acima do olho (inclinada para o centro: V feroz!)
        _add_part(
            parts,
            create_cone(
                f"_tmp_brow_ridge_{tag}",
                6,
                0.13,
                0.07,
                0.38,
                (side * 0.28, -0.82, cz + 0.34),
                rotation=(math.radians(10.0), math.radians(-side * 66.0), math.radians(-side * 16.0)),
                scale=(0.80, 0.56, 1.0),
            ),
            mat_prefix,
            "top_red",
            pal,
        )

        # Fundo/moldura escura triangular do olho (inclinada para baixo em direção ao centro!)
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_frame_{tag}",
                (0.36, 0.06, 0.22),
                (side * 0.31, -0.86, cz + 0.20),
                rotation=(math.radians(-12.0), math.radians(-side * 22.0), math.radians(-side * 20.0)),
            ),
            mat_prefix,
            "seam_dark",
            pal,
        )

        # Esclera branca triangular/trapezoidal do olho
        _add_part(
            parts,
            create_cube(
                f"_tmp_eye_white_{tag}",
                (0.30, 0.06, 0.16),
                (side * 0.31, -0.885, cz + 0.18),
                rotation=(math.radians(-12.0), math.radians(-side * 22.0), math.radians(-side * 20.0)),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )

        # Linha superior escura afiada da sobrancelha formando V determinado
        _add_part(
            parts,
            create_cube(
                f"_tmp_brow_line_{tag}",
                (0.42, 0.055, 0.052),
                (side * 0.30, -0.895, cz + 0.28),
                rotation=(math.radians(-14.0), math.radians(-side * 28.0), math.radians(-side * 20.0)),
            ),
            mat_prefix,
            "seam_dark",
            pal,
        )

        # Pupila vertical estreita preta
        _add_part(
            parts,
            create_cube(
                f"_tmp_pupil_{tag}",
                (0.048, 0.055, 0.11),
                (side * 0.27, -0.92, cz + 0.17),
                rotation=(math.radians(-12.0), 0.0, math.radians(-side * 16.0)),
            ),
            mat_prefix,
            "seam_dark",
            pal,
        )

    # Vinco central vertical entre as sobrancelhas (expressão intensa da arte)
    _add_part(
        parts,
        create_cube(
            "_tmp_brow_furrow",
            (0.035, 0.045, 0.16),
            (0.0, -0.91, cz + 0.28),
            rotation=(math.radians(-18.0), 0.0, 0.0),
        ),
        mat_prefix,
        "seam_dark",
        pal,
    )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 100. Sparkorb lado a lado."""
    specs = [
        ("Sparkorb_Shiny", (-7.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Sparkorb_Normal", (-4.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Sparkorb_Grande", (-0.4, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Sparkorb_Gigante", (4.2, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Sparkorb_Dourada_SuperRara", (10.2, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_sparkorb(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
