"""
088_Sludgeblob_Grimer_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "088. Sludgeblob — Lama Tóxica (Ref: Grimer)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Sludgeblob_Shiny (1.0x - Paleta Shiny Lodo Verde-Tóxico + Listras Verde-Oliva Escuro)
  2. Sludgeblob_Normal (1.0x - Massa Viscosa Roxo-Lavanda + Listras Roxas + Boca Aberta + 2 Braços de Lodo)
  3. Sludgeblob_Grande (1.35x - Normal)
  4. Sludgeblob_Gigante (1.85x - Normal)
  5. Sludgeblob_Dourada_SuperRara (2.25x - Ouro Reluzente + Olhos, Listras e Língua Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (poça derretida assimétrica, dobras de lodo, dedos viscosos, boca aberta)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Poça base apoiada exatamente em `Z = 0.0` e rosto/braços apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "sludge_main": (0.64, 0.51, 0.72, 1.0),
        "sludge_stripe": (0.40, 0.31, 0.47, 1.0),
        "mouth_dark": (0.14, 0.11, 0.18, 1.0),
        "tongue_gray": (0.68, 0.72, 0.78, 1.0),
        "eye_white": (0.97, 0.98, 1.00, 1.0),
        "eye_dark": (0.09, 0.09, 0.12, 1.0),
    },
    "shiny_palette": {
        "sludge_main": (0.38, 0.68, 0.38, 1.0),
        "sludge_stripe": (0.22, 0.44, 0.24, 1.0),
        "mouth_dark": (0.12, 0.16, 0.14, 1.0),
        "tongue_gray": (0.76, 0.66, 0.78, 1.0),
        "eye_white": (0.97, 0.98, 1.00, 1.0),
        "eye_dark": (0.09, 0.09, 0.12, 1.0),
    },
    "golden_super_rare_palette": {
        "sludge_main": (0.98, 0.78, 0.14, 1.0),
        "sludge_stripe": (0.10, 0.92, 1.00, 1.0),
        "mouth_dark": (0.46, 0.30, 0.06, 1.0),
        "tongue_gray": (0.22, 0.94, 1.00, 1.0),
        "eye_white": (1.00, 0.99, 0.92, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha a base em Z = 0.0, aplica Bevel angular e Flat Shading."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_sludgeblob(
    name: str = "Sludgeblob_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D completo e fiel à referência do 088. Sludgeblob (Ref: Grimer):
      - Base derretida em poça viscosa irregular com lobos escorrendo no chão (Z = 0.0)
      - Corpo/cabeça fundidos em montículo derretido com dobras de lama e listras horizontais escuras
      - Dois grandes olhos brancos esbugalhados com pupilas pequenas bem no alto
      - Grande boca escancarada sorridente com interior escuro, língua acinzentada e gota no queixo
      - Dois braços curtos viscosos estendidos à frente com 3 dedos-gotas arredondados em cada mão
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Slud_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Slud_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Slud_Norm"

    parts = []

    # 1. POÇA BASE DERRETIDA EM CAMADAS ASSIMÉTRICAS (Z = 0.0)
    puddle_blobs = [
        (0.92, (0.04, 0.06, 0.24), (1.16, 1.06, 0.28)),
        (0.56, (-0.72, -0.14, 0.18), (1.05, 0.88, 0.30)),
        (0.64, (0.76, 0.14, 0.18), (1.12, 0.96, 0.28)),
        (0.58, (0.98, 0.44, 0.15), (1.18, 0.90, 0.24)),
        (0.54, (-0.18, -0.56, 0.18), (1.12, 0.82, 0.28)),
        (0.52, (0.36, -0.46, 0.18), (1.04, 0.84, 0.28)),
        (0.60, (0.14, 0.68, 0.20), (1.18, 1.00, 0.30)),
    ]
    for p_idx, (rad, loc, sc) in enumerate(puddle_blobs):
        _add_part(
            parts,
            create_icosphere(f"_tmp_puddle_{p_idx}", 2, rad, loc, scale=sc),
            mat_prefix,
            "sludge_main",
            pal,
        )

    # 2. CORPO E CABEÇA EM MONTÍCULO VISCOSO DERRETIDO
    _add_part(
        parts,
        create_icosphere("_tmp_torso_low", 2, 0.78, (0.02, 0.08, 0.62), scale=(1.06, 0.98, 0.78)),
        mat_prefix,
        "sludge_main",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_torso_mid", 2, 0.66, (0.00, 0.04, 1.02), scale=(0.98, 0.94, 0.86)),
        mat_prefix,
        "sludge_main",
        pal,
    )
    # Cabeça redonda ligeiramente inclinada para frente
    _add_part(
        parts,
        create_icosphere("_tmp_head_dome", 2, 0.56, (-0.02, -0.06, 1.38), scale=(1.02, 0.96, 0.82)),
        mat_prefix,
        "sludge_main",
        pal,
    )
    # Dobra de barriguinha fofa abaixo do queixo
    _add_part(
        parts,
        create_icosphere("_tmp_belly_fold", 2, 0.38, (-0.14, -0.50, 0.44), scale=(1.22, 0.72, 0.56)),
        mat_prefix,
        "sludge_main",
        pal,
    )
    # Costas escorrendo em ondas para trás-direita
    _add_part(
        parts,
        create_icosphere("_tmp_back_slump", 2, 0.52, (0.48, 0.46, 0.54), scale=(1.06, 1.04, 0.72)),
        mat_prefix,
        "sludge_main",
        pal,
    )

    # 3. LISTRAS HORIZONTAIS ESCURAS DE LODO (ASSINATURA VISUAL DO GRIMER!)
    stripe_specs = [
        ((0.02, 0.06, 0.24), (1.16, 1.08, 0.14), 0.86),
        ((0.02, 0.06, 0.64), (1.07, 1.00, 0.15), 0.76),
        ((0.00, 0.02, 1.06), (1.00, 0.96, 0.14), 0.65),
        ((-0.02, -0.08, 1.46), (1.02, 0.98, 0.12), 0.52),
    ]
    for s_idx, (loc, sc, rad) in enumerate(stripe_specs):
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_stripe_{s_idx}",
                2,
                rad,
                loc,
                rotation=(math.radians(5.0), math.radians(-4.0 if s_idx % 2 == 0 else 5.0), 0.0),
                scale=sc,
            ),
            mat_prefix,
            "sludge_stripe",
            pal,
        )

    # 4. ROSTO ICÔNICO: OLHOS GRANDES ESBUGALHADOS + BOCA ESCANCARADA COM LÁBIO DERRETIDO
    # Lábio superior saliente
    _add_part(
        parts,
        create_icosphere(
            "_tmp_upper_lip",
            2,
            0.38,
            (-0.04, -0.50, 1.24),
            scale=(1.18, 0.76, 0.34),
        ),
        mat_prefix,
        "sludge_main",
        pal,
    )
    # Dois grandes olhos ovais brancos esbugalhados com pupilas pequeninas
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_w_{tag}",
                2,
                0.17,
                (-0.04 + side * 0.26, -0.50, 1.50),
                rotation=(0.0, 0.0, math.radians(side * -14.0)),
                scale=(0.86, 0.58, 1.12),
            ),
            mat_prefix,
            "eye_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_p_{tag}",
                1,
                0.042,
                (-0.04 + side * 0.26, -0.60, 1.52),
                scale=(1.0, 0.6, 1.0),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Caverna da boca escancarada + língua acinzentada + queixo derretido com gota
    _add_part(
        parts,
        create_icosphere(
            "_tmp_mouth_cav",
            2,
            0.36,
            (-0.04, -0.46, 0.94),
            scale=(0.98, 0.62, 1.06),
        ),
        mat_prefix,
        "mouth_dark",
        pal,
    )
    _add_part(
        parts,
        create_icosphere(
            "_tmp_tongue",
            2,
            0.26,
            (-0.04, -0.52, 0.78),
            scale=(1.02, 0.68, 0.54),
        ),
        mat_prefix,
        "tongue_gray",
        pal,
    )
    # Borda do lábio inferior em U + gota escorrendo do queixo
    _add_part(
        parts,
        create_icosphere(
            "_tmp_lower_lip",
            2,
            0.34,
            (-0.04, -0.54, 0.66),
            scale=(1.08, 0.64, 0.36),
        ),
        mat_prefix,
        "sludge_main",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_chin_drip", 1, 0.13, (-0.04, -0.68, 0.54), scale=(0.82, 0.68, 1.15)),
        mat_prefix,
        "sludge_main",
        pal,
    )

    # 5. DOIS BRAÇOS CURTOS VISCOSOS ESTENDIDOS PARA FRENTE COM 3 DEDOS-GOTAS CADA
    arm_specs = [
        ("L", -1.0, (-0.64, -0.22, 0.80), (-0.88, -0.66, 0.70), math.radians(32.0)),
        ("R", 1.0, (0.54, -0.24, 0.76), (0.62, -0.74, 0.62), math.radians(-22.0)),
    ]
    for tag, side, sh_loc, hand_loc, yaw in arm_specs:
        mid_loc = ((sh_loc[0] + hand_loc[0]) * 0.5, (sh_loc[1] + hand_loc[1]) * 0.5, (sh_loc[2] + hand_loc[2]) * 0.5)
        _add_part(
            parts,
            create_icosphere(f"_tmp_sh_{tag}", 2, 0.30, sh_loc, scale=(1.0, 1.1, 0.92)),
            mat_prefix,
            "sludge_main",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_arm_{tag}",
                2,
                0.28,
                mid_loc,
                rotation=(0.0, 0.0, yaw),
                scale=(0.86, 1.38, 0.80),
            ),
            mat_prefix,
            "sludge_main",
            pal,
        )
        # Listra escura no braço
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_arm_st_{tag}",
                1,
                0.26,
                mid_loc,
                rotation=(0.0, 0.0, yaw),
                scale=(0.94, 0.42, 0.86),
            ),
            mat_prefix,
            "sludge_stripe",
            pal,
        )
        # Mão viscosa + 3 dedos-gotas rechonchudos
        hx, hy, hz = hand_loc
        _add_part(
            parts,
            create_icosphere(f"_tmp_hand_{tag}", 2, 0.24, hand_loc, scale=(1.12, 1.05, 0.78)),
            mat_prefix,
            "sludge_main",
            pal,
        )
        for f_idx, (fdx, fdy, fdz) in enumerate([
            (side * 0.20, -0.18, 0.06),
            (0.0, -0.24, 0.02),
            (side * -0.18, -0.16, -0.06),
        ]):
            _add_part(
                parts,
                create_icosphere(
                    f"_tmp_finger_{tag}_{f_idx}",
                    1,
                    0.125,
                    (hx + fdx, hy + fdy, hz + fdz),
                    scale=(0.92, 1.24, 0.84),
                ),
                mat_prefix,
                "sludge_main",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 088. Sludgeblob lado a lado."""
    specs = [
        ("Sludgeblob_Shiny", (-10.6, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Sludgeblob_Normal", (-6.2, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Sludgeblob_Grande", (-0.8, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Sludgeblob_Gigante", (6.0, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Sludgeblob_Dourada_SuperRara", (14.4, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_sludgeblob(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
