"""
064_Spoonmage_Kadabra_5Variacoes_Blender.py
===========================================
Script Python completo e autossuficiente para o Blender (`bpy`) que gera os 5 modelos 3D
da criatura "064. Spoonmage — Mago Telepata (Ref: Kadabra)" no estilo Low-Poly Facetado
(alta fidelidade à silhueta original) para o jogo Roblox "Jogue uma Orbe / Throw a Sphere":
  1. Spoonmage_Shiny (1.0x - Paleta Shiny Amarelo-Claro + Armadura Magenta-Rosa)
  2. Spoonmage_Normal (1.0x - Amarelo-Ouro + Armadura Marrom + Estrela e 3 Ondas Vermelhas + Colher Prata)
  3. Spoonmage_Grande (1.35x - Normal)
  4. Spoonmage_Gigante (1.85x - Normal)
  5. Spoonmage_Dourada_SuperRara (2.25x - Ouro Reluzente + Armadura, Símbolos e Colher Ciano-Diamante)

Especificações Técnicas Aplicadas:
  - Shading 100% Flat (`bpy.ops.object.shade_flat()`) em todas as primitivas e no objeto final
  - Materiais em cor sólida (`use_nodes = False`, `mat.diffuse_color = rgba`)
  - Geometria facetada orgânica (icospheres subdiv=2, cones/cilindros 6-8 lados)
  - Bevel final (`width=0.015`, `segments=2`, `limit_method='ANGLE'`) aplicado via `modifier_apply`
  - Pés alinhados exatamente em `Z = 0.0` e rosto apontando para `-Y`
"""

import math
import bpy


CONFIG = {
    "bevel_width": 0.015,
    "bevel_segments": 2,
    "bevel_angle_deg": 30.0,
    "scales": {
        "Shiny": 1.00,
        "Normal": 1.00,
        "Grande": 1.35,
        "Gigante": 1.85,
        "DouradaSuperRara": 2.25,
    },
    "palette": {
        "body_yellow": (0.95, 0.83, 0.28, 1.0),
        "body_shade": (0.82, 0.70, 0.22, 1.0),
        "armor_brown": (0.48, 0.40, 0.41, 1.0),
        "mark_red": (0.88, 0.30, 0.34, 1.0),
        "spoon_silver": (0.84, 0.87, 0.92, 1.0),
        "claw_white": (0.98, 0.98, 0.99, 1.0),
        "eye_dark": (0.12, 0.12, 0.15, 1.0),
    },
    "shiny_palette": {
        "body_yellow": (0.98, 0.91, 0.46, 1.0),
        "body_shade": (0.86, 0.78, 0.36, 1.0),
        "armor_brown": (0.78, 0.36, 0.62, 1.0),
        "mark_red": (0.94, 0.22, 0.44, 1.0),
        "spoon_silver": (0.88, 0.92, 0.97, 1.0),
        "claw_white": (0.99, 0.99, 1.00, 1.0),
        "eye_dark": (0.14, 0.12, 0.16, 1.0),
    },
    "golden_super_rare_palette": {
        "body_yellow": (0.98, 0.78, 0.14, 1.0),
        "body_shade": (0.86, 0.64, 0.10, 1.0),
        "armor_brown": (0.10, 0.92, 1.00, 1.0),
        "mark_red": (0.10, 0.92, 1.00, 1.0),
        "spoon_silver": (0.10, 0.92, 1.00, 1.0),
        "claw_white": (1.00, 0.98, 0.90, 1.0),
        "eye_dark": (0.10, 0.92, 1.00, 1.0),
    },
}


def clean_existing_object(obj_name: str):
    """Remove objeto existente com o mesmo nome para permitir reexecução limpa."""
    obj = bpy.data.objects.get(obj_name)
    if obj is not None:
        bpy.data.objects.remove(obj, do_unlink=True)


def get_or_create_solid_material(name: str, rgba: tuple):
    """Cria material em cor sólida sem shader nodes (acabamento flat/voxel)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.use_nodes = False
    mat.diffuse_color = rgba
    return mat


def assign_material(obj, mat_name: str, rgba: tuple):
    """Atribui material sólido único ao objeto primitivo antes do join."""
    mat = get_or_create_solid_material(mat_name, rgba)
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def create_cube(name: str, size: tuple, location: tuple, rotation=(0.0, 0.0, 0.0)):
    """Cria um cubo facetado escalonado nas dimensões especificadas."""
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cone(
    name: str,
    vertices: int,
    radius1: float,
    radius2: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cone facetado (radius1 != radius2) com shading flat."""
    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_cylinder(
    name: str,
    vertices: int,
    radius: float,
    depth: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria um cilindro facetado com shading flat."""
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_icosphere(
    name: str,
    subdivisions: int,
    radius: float,
    location: tuple,
    rotation=(0.0, 0.0, 0.0),
    scale=(1.0, 1.0, 1.0),
):
    """Cria uma icosphere low-poly facetada com shading flat."""
    bpy.ops.mesh.primitive_ico_sphere_add(
        subdivisions=subdivisions,
        radius=radius,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    if scale != (1.0, 1.0, 1.0):
        obj.scale = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.shade_flat()
    return obj


def create_segment(
    name: str,
    p1: tuple,
    p2: tuple,
    r1: float,
    r2: float,
    vertices: int = 8,
    extend: float = 1.05,
):
    """Cria um cone/segmento conectando exatamente p1 -> p2 sem folgas."""
    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    dz = p2[2] - p1[2]
    dist = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dist < 1e-6:
        dist = 1e-6
    mid = ((p1[0] + p2[0]) * 0.5, (p1[1] + p2[1]) * 0.5, (p1[2] + p2[2]) * 0.5)
    theta = math.acos(max(-1.0, min(1.0, dz / dist)))
    phi = math.atan2(dy, dx)
    return create_cone(
        name=name,
        vertices=vertices,
        radius1=r1,
        radius2=r2,
        depth=dist * extend,
        location=mid,
        rotation=(0.0, theta, phi),
    )


def join_and_bevel(parts: list, final_name: str, location: tuple = (0.0, 0.0, 0.0), scale: float = 1.0):
    """Une todas as primitivas, alinha os pés em Z = 0.0, aplica Bevel e Shading Flat."""
    clean_existing_object(final_name)
    bpy.ops.object.select_all(action="DESELECT")
    for part in parts:
        part.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()

    joined = bpy.context.active_object
    joined.name = final_name

    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bevel = joined.modifiers.new(name="Bevel", type="BEVEL")
    bevel.width = CONFIG["bevel_width"]
    bevel.segments = CONFIG["bevel_segments"]
    bevel.limit_method = "ANGLE"
    bevel.angle_limit = math.radians(CONFIG["bevel_angle_deg"])
    bpy.ops.object.modifier_apply(modifier="Bevel")

    if joined.data.vertices:
        min_z = min(v.co.z for v in joined.data.vertices)
        for v in joined.data.vertices:
            v.co.z -= min_z
        joined.data.update()

    if scale != 1.0:
        joined.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    joined.location = location
    bpy.ops.object.shade_flat()
    return joined


def _add_part(parts: list, obj, mat_prefix: str, mat_key: str, pal: dict):
    assign_material(obj, f"{mat_prefix}_{mat_key}", pal[mat_key])
    parts.append(obj)
    return obj


def build_spoonmage(
    name: str = "Spoonmage_Normal",
    location: tuple = (0.0, 0.0, 0.0),
    scale: float = 1.0,
    variant: str = "Normal",
):
    """
    Constrói o modelo 3D fiel à referência do 064. Spoonmage (Ref: Kadabra):
      - Base bípede agachada com pés grandes de 3 garras brancas firmes em Z = 0.0
      - Abdômen amarelo com 3 ondas vermelhas verticais + couraça peitoral e ombreiras marrons
      - Cabeça de raposa com focinho comprido, orelhas pontudas, estrela vermelha na testa
        e bigodes longos amarelos curvados para baixo
      - Braço esquerdo (-X) erguido segurando a icônica colher prateada acima da cabeça
      - Braço direito (+X) erguido para fora com 3 dedos com garras brancas
      - Cauda gigantesca e espessa curvada por trás para a esquerda (-X) com faixa marrom
    """
    if bpy.context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    if variant == "Shiny":
        pal = CONFIG["shiny_palette"]
        mat_prefix = "Mat_Spoon_Shiny"
    elif variant == "DouradaSuperRara":
        pal = CONFIG["golden_super_rare_palette"]
        mat_prefix = "Mat_Spoon_Gold"
    else:
        pal = CONFIG["palette"]
        mat_prefix = "Mat_Spoon_Norm"

    parts = []

    # 1. ABDÔMEN AMARELO COM 3 LINHAS ONDULADAS VERMELHAS + COURAÇA PEITORAL MARROM
    _add_part(
        parts,
        create_icosphere("_tmp_abdomen", 2, 0.34, (0.0, -0.02, 0.72), scale=(0.94, 0.92, 1.14)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # 3 marcas onduladas vermelhas no ventre
    for s_idx, sx in enumerate((-0.10, 0.0, 0.10)):
        _add_part(
            parts,
            create_segment(
                f"_tmp_belly_wave_a_{s_idx}",
                (sx, -0.32, 0.84),
                (sx + 0.03, -0.34, 0.72),
                0.022,
                0.022,
                vertices=5,
            ),
            mat_prefix,
            "mark_red",
            pal,
        )
        _add_part(
            parts,
            create_segment(
                f"_tmp_belly_wave_b_{s_idx}",
                (sx + 0.03, -0.34, 0.72),
                (sx - 0.02, -0.33, 0.58),
                0.022,
                0.018,
                vertices=5,
            ),
            mat_prefix,
            "mark_red",
            pal,
        )

    # Couraça peitoral robusta marrom-taupe + ombreiras
    _add_part(
        parts,
        create_icosphere("_tmp_chest_armor", 2, 0.42, (0.0, -0.02, 1.18), scale=(1.12, 0.94, 0.88)),
        mat_prefix,
        "armor_brown",
        pal,
    )
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_pauldron_{tag}",
                2,
                0.30,
                (side * 0.44, -0.02, 1.32),
                rotation=(0.0, math.radians(side * 18.0), 0.0),
                scale=(1.04, 0.92, 0.96),
            ),
            mat_prefix,
            "armor_brown",
            pal,
        )

    # 2. CABEÇA PONTUDA DE RAPOSA + ESTRELA VERMELHA + BIGODES LONGOS
    _add_part(
        parts,
        create_icosphere("_tmp_head_main", 2, 0.38, (0.0, -0.10, 1.72), scale=(1.02, 1.06, 0.92)),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Focinho longo apontando para frente (-Y)
    _add_part(
        parts,
        create_segment(
            "_tmp_snout",
            (0.0, -0.16, 1.66),
            (0.0, -0.78, 1.50),
            r1=0.28,
            r2=0.07,
            vertices=8,
            extend=1.04,
        ),
        mat_prefix,
        "body_yellow",
        pal,
    )
    # Orelhas altas pontiagudas inclinadas para trás e lados
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_segment(
                f"_tmp_ear_{tag}",
                (side * 0.24, -0.02, 1.92),
                (side * 0.48, 0.16, 2.38),
                0.15,
                0.022,
                vertices=6,
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )

    # Estrela vermelha na testa (5 pontas em cruz estilizada)
    star_center = (0.0, -0.45, 1.82)
    for p_idx, ang_deg in enumerate((90, 162, 234, 306, 18)):
        ang = math.radians(ang_deg)
        tip = (
            star_center[0] + math.cos(ang) * 0.11,
            star_center[1] - 0.02,
            star_center[2] + math.sin(ang) * 0.11,
        )
        _add_part(
            parts,
            create_segment(f"_tmp_star_ray_{p_idx}", star_center, tip, 0.032, 0.010, vertices=4),
            mat_prefix,
            "mark_red",
            pal,
        )

    # Olhos brancos estreitos com pupilas escuras
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_white_{tag}",
                1,
                0.10,
                (side * 0.19, -0.46, 1.72),
                rotation=(0.0, 0.0, math.radians(side * -24.0)),
                scale=(1.15, 0.55, 0.62),
            ),
            mat_prefix,
            "claw_white",
            pal,
        )
        _add_part(
            parts,
            create_icosphere(
                f"_tmp_eye_pupil_{tag}",
                1,
                0.045,
                (side * 0.18, -0.51, 1.72),
                scale=(0.65, 0.55, 1.05),
            ),
            mat_prefix,
            "eye_dark",
            pal,
        )

    # Bigodes longos curvados caindo sobre o peito (assinatura da Kadabra!)
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        m_pts = [
            (side * 0.08, -0.60, 1.50, 0.055),
            (side * 0.28, -0.62, 1.38, 0.075),
            (side * 0.44, -0.56, 1.12, 0.068),
            (side * 0.50, -0.48, 0.78, 0.018),
        ]
        for i in range(len(m_pts) - 1):
            _add_part(
                parts,
                create_segment(
                    f"_tmp_mustache_{tag}_{i}",
                    m_pts[i][:3],
                    m_pts[i + 1][:3],
                    m_pts[i][3],
                    m_pts[i + 1][3],
                    vertices=6,
                    extend=1.08,
                ),
                mat_prefix,
                "body_yellow",
                pal,
            )

    # 3. BRAÇO ESQUERDO (-X) ERGUIDO COM COLHER PRATEADA + BRAÇO DIREITO (+X) EM POSE PSÍQUICA
    # Braço esquerdo (-X) levantado bem alto
    l_sh = (-0.48, -0.02, 1.38)
    l_el = (-0.64, -0.06, 1.88)
    l_wr = (-0.60, -0.14, 2.38)
    _add_part(parts, create_segment("_tmp_arm_L_up", l_sh, l_el, 0.085, 0.075, vertices=6), mat_prefix, "body_yellow", pal)
    _add_part(parts, create_icosphere("_tmp_elbow_L", 1, 0.085, l_el), mat_prefix, "body_yellow", pal)
    _add_part(parts, create_segment("_tmp_arm_L_lo", l_el, l_wr, 0.11, 0.095, vertices=6), mat_prefix, "body_yellow", pal)
    _add_part(parts, create_icosphere("_tmp_hand_L", 2, 0.15, (-0.58, -0.16, 2.48)), mat_prefix, "body_yellow", pal)
    # Dedos envolvendo o cabo da colher + garras brancas
    for f_idx, fx in enumerate((-0.70, -0.58, -0.46)):
        _add_part(
            parts,
            create_segment(
                f"_tmp_l_finger_{f_idx}",
                (fx, -0.16, 2.54),
                (fx, -0.28, 2.46),
                0.048,
                0.036,
                vertices=5,
            ),
            mat_prefix,
            "body_yellow",
            pal,
        )
        _add_part(
            parts,
            create_segment(
                f"_tmp_l_claw_{f_idx}",
                (fx, -0.28, 2.46),
                (fx, -0.34, 2.38),
                0.032,
                0.008,
                vertices=4,
            ),
            mat_prefix,
            "claw_white",
            pal,
        )

    # COLHER PRATEADA HORIZONTAL ACIMA DA CABEÇA
    _add_part(
        parts,
        create_segment(
            "_tmp_spoon_handle",
            (-0.96, -0.22, 2.44),
            (-0.18, -0.22, 2.46),
            0.042,
            0.034,
            vertices=6,
        ),
        mat_prefix,
        "spoon_silver",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_spoon_pommel", 1, 0.062, (-0.98, -0.22, 2.44), scale=(1.1, 0.8, 0.7)),
        mat_prefix,
        "spoon_silver",
        pal,
    )
    _add_part(
        parts,
        create_icosphere("_tmp_spoon_bowl", 2, 0.20, (0.04, -0.22, 2.46), scale=(1.42, 0.92, 0.54)),
        mat_prefix,
        "spoon_silver",
        pal,
    )

    # Braço direito (+X) erguido para fora em gesto telepático
    r_sh = (0.48, -0.02, 1.24)
    r_el = (0.86, -0.08, 1.18)
    r_wr = (1.06, -0.26, 1.54)
    _add_part(parts, create_segment("_tmp_arm_R_up", r_sh, r_el, 0.082, 0.072, vertices=6), mat_prefix, "body_yellow", pal)
    _add_part(parts, create_icosphere("_tmp_elbow_R", 1, 0.085, r_el), mat_prefix, "body_yellow", pal)
    _add_part(parts, create_segment("_tmp_arm_R_lo", r_el, r_wr, 0.105, 0.092, vertices=6), mat_prefix, "body_yellow", pal)
    _add_part(parts, create_icosphere("_tmp_hand_R", 2, 0.16, (1.12, -0.32, 1.66)), mat_prefix, "body_yellow", pal)
    # 3 dedos abertos com garras brancas
    r_hand = (1.12, -0.32, 1.66)
    for f_idx, (dx, dy, dz) in enumerate([(-0.14, -0.08, 0.16), (0.04, -0.10, 0.22), (0.20, -0.06, 0.12)]):
        f_mid = (r_hand[0] + dx, r_hand[1] + dy, r_hand[2] + dz)
        f_tip = (f_mid[0] + dx * 0.45, f_mid[1] - 0.06, f_mid[2] + dz * 0.45)
        _add_part(parts, create_segment(f"_tmp_r_finger_{f_idx}", r_hand, f_mid, 0.052, 0.038, vertices=5), mat_prefix, "body_yellow", pal)
        _add_part(parts, create_segment(f"_tmp_r_claw_{f_idx}", f_mid, f_tip, 0.036, 0.008, vertices=4), mat_prefix, "claw_white", pal)

    # 4. PERNAS AGACHADAS E PÉS GRANDES COM 3 GARRAS BRANCAS
    for side in (-1.0, 1.0):
        tag = "L" if side < 0 else "R"
        p_hip = (side * 0.24, -0.02, 0.64)
        p_knee = (side * 0.66, -0.22, 0.64)
        p_ankle = (side * 0.58, -0.12, 0.16)
        _add_part(parts, create_segment(f"_tmp_thigh_{tag}", p_hip, p_knee, 0.15, 0.13, vertices=7), mat_prefix, "body_yellow", pal)
        _add_part(parts, create_icosphere(f"_tmp_knee_{tag}", 1, 0.14, p_knee), mat_prefix, "body_yellow", pal)
        _add_part(parts, create_segment(f"_tmp_shin_{tag}", p_knee, p_ankle, 0.13, 0.11, vertices=7), mat_prefix, "body_yellow", pal)
        _add_part(
            parts,
            create_icosphere(f"_tmp_foot_{tag}", 2, 0.16, (p_ankle[0], p_ankle[1] - 0.08, 0.12), scale=(1.15, 1.25, 0.65)),
            mat_prefix,
            "body_yellow",
            pal,
        )
        # 2 dedos frontais + 1 traseiro com garras brancas apoiados em Z = 0.0
        foot_c = (p_ankle[0], p_ankle[1] - 0.10, 0.10)
        toes = [
            (foot_c[0] + side * 0.20, foot_c[1] - 0.24, 0.06),
            (foot_c[0] - side * 0.08, foot_c[1] - 0.28, 0.06),
            (foot_c[0] - side * 0.14, foot_c[1] + 0.22, 0.06),
        ]
        for t_idx, t_mid in enumerate(toes):
            dx = t_mid[0] - foot_c[0]
            dy = t_mid[1] - foot_c[1]
            t_tip = (t_mid[0] + dx * 0.42, t_mid[1] + dy * 0.42, 0.03)
            _add_part(parts, create_segment(f"_tmp_toe_{tag}_{t_idx}", foot_c, t_mid, 0.065, 0.045, vertices=5), mat_prefix, "body_yellow", pal)
            _add_part(parts, create_segment(f"_tmp_tclaw_{tag}_{t_idx}", t_mid, t_tip, 0.042, 0.010, vertices=4), mat_prefix, "claw_white", pal)

    # 5. CAUDA GIGANTESCA E VOLUMOSA ENROLADA ATRÁS E PARA A ESQUERDA (-X) COM FAIXA MARROM
    tail_pts = [
        (0.0, 0.26, 0.56, 0.36),
        (-0.34, 0.48, 0.62, 0.44),
        (-0.62, 0.52, 0.72, 0.45),  # início da faixa marrom
        (-0.80, 0.48, 0.78, 0.44),  # fim da faixa marrom
        (-1.14, 0.38, 0.80, 0.38),
        (-1.38, 0.24, 0.54, 0.26),
        (-1.58, 0.16, 0.42, 0.14),
        (-1.72, 0.14, 0.62, 0.03),  # pontinha curvada para cima
    ]
    for i in range(len(tail_pts) - 1):
        p1 = tail_pts[i][:3]
        p2 = tail_pts[i + 1][:3]
        r1 = tail_pts[i][3]
        r2 = tail_pts[i + 1][3]
        mat_key = "armor_brown" if i == 2 else "body_yellow"
        _add_part(
            parts,
            create_segment(f"_tmp_tail_seg_{i}", p1, p2, r1, r2, vertices=8, extend=1.10),
            mat_prefix,
            mat_key,
            pal,
        )
        if i < len(tail_pts) - 2 and i not in (1, 2):
            _add_part(
                parts,
                create_icosphere(f"_tmp_tail_j_{i}", 2, r2 * 0.98, p2),
                mat_prefix,
                "body_yellow",
                pal,
            )

    return join_and_bevel(parts, final_name=name, location=location, scale=scale)


def generate_variations():
    """Gera as 5 variações de tamanho e raridade do 064. Spoonmage lado a lado."""
    specs = [
        ("Spoonmage_Shiny", (-13.0, 0.0, 0.0), CONFIG["scales"]["Shiny"], "Shiny"),
        ("Spoonmage_Normal", (-7.4, 0.0, 0.0), CONFIG["scales"]["Normal"], "Normal"),
        ("Spoonmage_Grande", (-1.0, 0.0, 0.0), CONFIG["scales"]["Grande"], "Grande"),
        ("Spoonmage_Gigante", (6.8, 0.0, 0.0), CONFIG["scales"]["Gigante"], "Gigante"),
        ("Spoonmage_Dourada_SuperRara", (16.8, 0.0, 0.0), CONFIG["scales"]["DouradaSuperRara"], "DouradaSuperRara"),
    ]
    created = []
    for obj_name, loc, sc, var in specs:
        created.append(build_spoonmage(name=obj_name, location=loc, scale=sc, variant=var))
    return created


if __name__ == "__main__":
    generate_variations()
